//
//  SCManager.m
//  SocketClient
//
//  Created by Linus on 2017/11/23.
//  Copyright © 2017年 Edward. All rights reserved.
//

#import "SCManager.h"
#import "YMSocketUtils.h"
#import "Models.h"

#import <objc/runtime.h>

// 后面NSString这是运行时能获取到的C语言的类型
NSString * const TYPE_UINT8   = @"TC";// char是1个字节，8位
NSString * const TYPE_UINT16   = @"TS";// short是2个字节，16位
NSString * const TYPE_UINT32   = @"TI";
NSString * const TYPE_UINT64   = @"TQ";
NSString * const TYPE_STRING   = @"T@\"NSString\"";
NSString * const TYPE_ARRAY   = @"T@\"NSArray\"";

@interface SCManager()
@property (nonatomic, strong) NSMutableData *data;
@property (nonatomic,strong)id object;
@end

@implementation SCManager


-(void)resultSpliceAttribute:(NSData*)result andObj:(id)obj{
    
    unsigned int numIvars; //成员变量个数
    
    objc_property_t *propertys = class_copyPropertyList(NSClassFromString([NSString stringWithUTF8String:object_getClassName(obj)]), &numIvars);
    
    NSString *type = nil;
    NSString *name = nil;
    
    NSInteger index = 0;
    
    for (int i = 0; i < numIvars; i++) {
        objc_property_t thisProperty = propertys[i];
        
        name = [NSString stringWithUTF8String:property_getName(thisProperty)];
        NSLog(@"%d.name:%@",i,name);
        type = [[[NSString stringWithUTF8String:property_getAttributes(thisProperty)] componentsSeparatedByString:@","] objectAtIndex:0]; //获取成员变量的数据类型
        NSLog(@"%d.type:%@",i,type);
        
        if ([type isEqualToString:TYPE_UINT8]) {
            
            NSData *data = [result subdataWithRange:NSMakeRange(index, 1)];
            
            uint8_t value;
            [data getBytes:&value length:sizeof(value)];
            
            value = CFSwapInt16BigToHost(value);
            
            NSNumber * number = [NSNumber numberWithChar:value];
            [obj setValue:number forKey:[(NSString *)name substringFromIndex:0]];
            
            index += 1;
            
        }else if([type isEqualToString:TYPE_UINT16]){
            NSData *data = [result subdataWithRange:NSMakeRange(index, 2)];
            
            uint16_t value;
            [data getBytes:&value length:sizeof(value)];
            
            value = CFSwapInt16BigToHost(value);
            
            NSNumber * number = [NSNumber numberWithShort:value];
            [obj setValue:number forKey:[(NSString *)name substringFromIndex:0]];
            
            index += 2;
        }else if([type isEqualToString:TYPE_UINT32]){
            NSData *data = [result subdataWithRange:NSMakeRange(index, 4)];
            
            uint32_t value;
            [data getBytes:&value length:sizeof(value)];
            
            value = CFSwapInt32BigToHost(value);
            
            NSNumber * number = [NSNumber numberWithInt:value];
            
            [obj setValue:number forKey:[(NSString *)name substringFromIndex:0]];
            
            index += 4;
        }else if([type isEqualToString:TYPE_UINT64]){
            NSData *data = [result subdataWithRange:NSMakeRange(index, 8)];
            
            uint64_t value;
            [data getBytes:&value length:sizeof(value)];
            
            value = CFSwapInt64BigToHost(value);
            
            NSNumber * number = [NSNumber numberWithLong:value];
            
            [obj setValue:number forKey:[(NSString *)name substringFromIndex:0]];
            
            index += 8;
        }else if([type isEqualToString:TYPE_STRING]){
            NSData *data = [result subdataWithRange:NSMakeRange(index, 4)];
            
            uint32_t value;
            [data getBytes:&value length:sizeof(value)];
            
            value = CFSwapInt32BigToHost(value);
            
            int headerLength = value;
            
            index += 4;
            
            NSData * stringData = [result subdataWithRange:NSMakeRange(index, headerLength)];
            
            NSString *stringValue = [[NSString alloc] initWithData:stringData encoding:NSUTF8StringEncoding];
            
            [obj setValue:stringValue forKey:[(NSString*)name substringFromIndex:0]];
            
            index += headerLength;
            
        }else {
            NSLog(@"RequestSpliceAttribute:未知类型");
            NSAssert(YES, @"RequestSpliceAttribute:未知类型");
        }
        
    }
}


-(id)RequestSpliceAttribute:(id)obj{
    if (obj == nil) {
        self.object = self.data;
    }
    unsigned int numIvars; //成员变量个数
    
    objc_property_t *propertys = class_copyPropertyList(NSClassFromString([NSString stringWithUTF8String:object_getClassName(obj)]), &numIvars);
    
    NSString *type = nil;
    NSString *name = nil;
    
    for (int i = 0; i < numIvars; i++) {
        objc_property_t thisProperty = propertys[i];
        
        name = [NSString stringWithUTF8String:property_getName(thisProperty)];
        NSLog(@"%d.name:%@",i,name);
        type = [[[NSString stringWithUTF8String:property_getAttributes(thisProperty)] componentsSeparatedByString:@","] objectAtIndex:0]; //获取成员变量的数据类型
        NSLog(@"%d.type:%@",i,type);
        
        id propertyValue = [obj valueForKey:[(NSString *)name substringFromIndex:0]];
        NSLog(@"%d.propertyValue:%@",i,propertyValue);
        
        NSLog(@"\n");
        
        if ([type isEqualToString:TYPE_UINT8]) {
            uint8_t i = [propertyValue charValue];// 8位
            [self.data appendData:[YMSocketUtils byteFromUInt8:i]];
        }else if([type isEqualToString:TYPE_UINT16]){
            uint16_t i = [propertyValue shortValue];// 16位
            [self.data appendData:[YMSocketUtils bytesFromUInt16:i]];
        }else if([type isEqualToString:TYPE_UINT32]){
            uint32_t i = [propertyValue intValue];// 32位
            [self.data appendData:[YMSocketUtils bytesFromUInt32:i]];
        }else if([type isEqualToString:TYPE_UINT64]){
            uint64_t i = [propertyValue longLongValue];// 64位
            [self.data appendData:[YMSocketUtils bytesFromUInt64:i]];
        }else if([type isEqualToString:TYPE_STRING]){
            NSData *data = [(NSString*)propertyValue \
                            dataUsingEncoding:NSUTF8StringEncoding];// 通过utf-8转为data
            
            // 用2个字节拼接字符串的长度拼接在字符串data之前
            [self.data appendData:[YMSocketUtils bytesFromUInt32:(uint32_t)data.length]];
            // 然后拼接字符串
            [self.data appendData:data];
            
        }else {
            NSLog(@"RequestSpliceAttribute:未知类型");
            NSAssert(YES, @"RequestSpliceAttribute:未知类型");
        }
    }
    
    // hy: 记得释放C语言的结构体指针
    free(propertys);
    self.object = self.data;
    
    self.data = nil;
    
    return self.object;
}



#pragma mark - 懒加载
- (NSMutableData *)data{
    if (!_data) {
        _data = [NSMutableData new];
    }
    return _data;
}



static SCManager * instance = nil;

+ (instancetype)getInstance{
    static dispatch_once_t onceToken ;
    dispatch_once(&onceToken, ^{
        instance = [[SCManager alloc]init];
    });
    
    return instance;
    
}


@end
