
#import <Foundation/Foundation.h>

@interface CsCmd: NSObject

@property(nonatomic,assign) uint32_t cmd;
@property(nonatomic,assign) uint32_t userId;
@property(nonatomic,strong) NSString * content;

@end

@interface ScCmd : NSObject

@property(nonatomic,assign) uint32_t cmd;
@property(nonatomic,assign) uint32_t userId;
@property(nonatomic,strong) NSString * content;

@end


