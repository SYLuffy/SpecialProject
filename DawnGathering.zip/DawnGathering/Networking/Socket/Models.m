//
//  Models.m
//  RuntimeTestOne
//
//  Created by HEYANG on 16/6/30.
//  Copyright © 2016年 HeYang. All rights reserved.
//

#import "Models.h"

@implementation CsCmd : NSObject

@end

@implementation ScCmd : NSObject

@end



