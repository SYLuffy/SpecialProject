//
//  SCManager.h
//  SocketClient
//
//  Created by Linus on 2017/11/23.
//  Copyright © 2017年 Edward. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SCManager : NSObject
+ (instancetype)getInstance;
-(void)resultSpliceAttribute:(NSData*)result andObj:(id)obj;
-(id)RequestSpliceAttribute:(id)obj;

@end
