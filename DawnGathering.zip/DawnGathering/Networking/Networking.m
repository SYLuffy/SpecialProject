//
//  LinusNetworking.m
//  CultureChengDu
//
//  Created by Linus on 2017/11/20.
//  Copyright © 2017年 Linus. All rights reserved.
//

#import "Networking.h"
#import <AFNetworking.h>
#import "Utils.h"
#import "NSString+Extension.h"
#import <MBProgressHUD.h>
#import "SharedInstance.h"
#import "SystemMaintenanceViewController.h"


#define OUT_TIME 60

@interface Networking()

@end

@implementation Networking


+ (void)getWithURLString:(NSString *)urlString
              parameters:(id)parameters
                 success:(SuccessBlock)successBlock
                 failure:(FailureBlock)failureBlock
{
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    /**
     *  可以接受的类型
     */
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    /**
     *  请求队列的最大并发数
     */
    //    manager.operationQueue.maxConcurrentOperationCount = 5;
    /**
     *  请求超时的时间
     */
    manager.requestSerializer.timeoutInterval = OUT_TIME;
    
    
    [manager GET:urlString parameters:parameters headers:@{} progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        if (successBlock) {
            NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
            
            if(!dic)
            {
                dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
            }
            
            if(!dic)
            {
                dic = [responseObject copy];
            } 
            
            successBlock(dic);
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        if (failureBlock) {
            failureBlock(error);
            NSLog(@"网络异常 - T_T%@", error);
        }
    }];
}

/**** SSL Pinning ****/
+ (AFSecurityPolicy*)customSecurityPolicy {
    NSString *cerPath = [[NSBundle mainBundle] pathForResource:@"ygflh.com" ofType:@"crt"];
    NSData *certData = [NSData dataWithContentsOfFile:cerPath];
    AFSecurityPolicy *securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeNone];
    [securityPolicy setAllowInvalidCertificates:YES];
    securityPolicy.validatesDomainName = NO;
    NSSet *set = [NSSet setWithObjects:certData, nil];
    [securityPolicy setPinnedCertificates:set];
    /**** SSL Pinning ****/
    return securityPolicy;
}

+ (void)postWithParameters:(NSMutableDictionary*)parameters
                    andCmd:(NSNumber*)cmd
                   success:(SuccessBlock)successBlock
                   failure:(FailureBlock)failureBlock
{
    NSMutableArray * hideHUDDataSource = [SharedInstance getInstance].hideLoadingDataSource;
    UIWindow * window = [Utils currentWindow];
    BOOL isHideLoading = false;
    for(NSNumber * tempCmd in hideHUDDataSource)
    {
        if(tempCmd.intValue == cmd.intValue)
        {
            isHideLoading = true;
            break;
        }
    }
    [MBProgressHUD hideHUDForView:window animated:true];
    
    MBProgressHUD * hud;
    if(!isHideLoading)
    {
        hud = [MBProgressHUD showHUDAddedTo:window animated:true];
        hud.mode = MBProgressHUDModeIndeterminate;
    }
    
//    NSString * sid = [Utils getUserDefaultByKey:SID];
    NSString * sid = [Utils getUserDefaultByKey:SID];
    NSDictionary * param;
    
    NSString * jsonDataString = [Utils dictionaryToJson:[parameters copy]];
    
    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
    NSString *app_Version = [infoDictionary objectForKey:@"CFBundleShortVersionString"];
    
    if(!sid || sid.length == 0 || cmd.integerValue == 127)//短信无需判断sid
    {
        param = @{VERSION_S:app_Version,CMD:cmd,DATA:jsonDataString,APPLICATION_ID:@100003,CHANNEL_ID:@1};
    }else{
        param = @{SID:sid,VERSION_S:app_Version,CMD:cmd,DATA:jsonDataString,APPLICATION_ID:@100003,CHANNEL_ID:@1};
    }
    
    NSString * fullPathUrl = [Utils getBaseUrl];
    
    AFHTTPSessionManager *manager = [[AFHTTPSessionManager manager] initWithBaseURL:[NSURL URLWithString:[Utils getHost]]];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    
    if([fullPathUrl hasPrefix:@"https"])
    {
        manager.securityPolicy = [Networking customSecurityPolicy];
    }
    
    manager.responseSerializer = [AFJSONResponseSerializer serializerWithReadingOptions:NSJSONReadingMutableContainers];
    manager.requestSerializer.timeoutInterval = OUT_TIME;
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:
                                                         @"application/json",
                                                         @"text/json",
                                                         @"text/javascript",
                                                         @"text/html",@"text/plain", nil];
    
    [manager POST:fullPathUrl parameters:param headers:@{} progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        if (successBlock) {
            NSDictionary *dic = [responseObject copy];
            
            NSLog(@"parmas:%@;result:%@",param,dic);
            
            
            NSNumber * code = [dic objectForKey:@"code"];
            NSString * msg = [dic objectForKey:@"msg"];
            NSNumber * cmd = [dic objectForKey:@"cmd"];
            
             [BuglyManager reportExceptionWithMessage:[NSString stringWithFormat:@"%ld",[cmd integerValue]] parmas:param error:[NSString stringWithFormat:@"code:%@;message:%@",code,msg]];
            
            [MBProgressHUD hideHUDForView:window animated:true];
            
            if(code.integerValue == 0)
            {
                successBlock(dic);
            }else{
                if([code isEqual:[NSNull null]] == false){
                    
                if(code.integerValue == 100218) {
                        [Utils alertWithTitle:@"实名信息有误" msg:[NSString stringWithFormat:@"%@,(%zd)",msg,code.integerValue]];
                    }else if(code.integerValue == ERROR_CODE_GET_VERSION){
                        //版本信息错误
                        failureBlock(nil);
                    }else if(code.integerValue == ERROR_CODE_SID_NOT_LOGIN){
                        [SharedInstance clearLoginInfo];
//                        [Utils showToast:[NSString stringWithFormat:@"登录过期或在其他设备登录!(%zd)",code.integerValue]];
                        NSError * error = [NSError errorWithDomain:@"错误码见code" code:code.integerValue userInfo:@{MSG:msg}];
                        failureBlock(error);
                    }else if(code.integerValue == ERROR_CODE_NOT_HAVE_ACCOUNT){
                        
                        failureBlock(nil);
                        [Utils showToast:[NSString stringWithFormat:@"%@,(%zd)",msg,code.integerValue]];
                    }else if(code.integerValue == ERROR_ACCOUNT_NO_REAL_NAME){
                        NSError * error = [NSError errorWithDomain:@"错误码见code" code:code.integerValue userInfo:@{}];
                        failureBlock(error);
                        [[SharedInstance getInstance] showNeedRealNameView:msg];
                    }else if(code.integerValue == ERROR_SYSTEM_MAINTENANCE)
                    {
                        //系统维护中;
                        SystemMaintenanceViewController * vc = [[SystemMaintenanceViewController alloc] init];
                        
                        [[Utils getCurrentVC].navigationController pushViewController:vc animated:true];
                        
                    }else if(code.integerValue == ERROR_CODE_SID_EXPIRE_LOGIN)
                    {
                        [SharedInstance clearLoginInfo];
                        NSError * error = [NSError errorWithDomain:@"错误码见code" code:code.integerValue userInfo:@{MSG:msg}];
                        failureBlock(error);
                    }else if(code.integerValue == ERROR_NOT_LOGIN_GO_TO_LOGIN)
                    {
                        //用户未登录弹出登录界面;
                        //清除用户信息;
                        [SharedInstance clearLoginInfo];
                        //弹出登录窗口;
                        [[SharedInstance getInstance] checkLoginAndGotoLogin:[Utils getCurrentVC]];
                    }
                    else{
    
                        NSError * error = [NSError errorWithDomain:@"错误码见code" code:code.integerValue userInfo:@{MSG:msg}];
                        
                        
                        failureBlock(error);
                    }
                }else{
                    failureBlock(nil);
                    [Utils showToast:[NSString stringWithFormat:@"%@,(%zd)",msg,code.integerValue]];
                }
          
            }
        }
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        [MBProgressHUD hideHUDForView:[Utils currentWindow] animated:true];
        
        NSDictionary *userInfo = error.userInfo;
        NSString *localizedDescription = userInfo[NSLocalizedDescriptionKey];
        NSString *reloadString = [NSString stringWithFormat:@"code:%@;msg:%@",[NSString stringWithFormat:@"%ld",error.code],localizedDescription?:@"当前网络不可用，请检查你的网络设置"];
        [BuglyManager reportExceptionWithMessage:[NSString stringWithFormat:@"%ld",[cmd integerValue]] parmas:param?:@{@"":@""} error:reloadString];
        
        if (failureBlock) {
            //            [[NSNotificationCenter defaultCenter] postNotificationName:EVENT_UPDATE_FAILURE object:nil];
            failureBlock(error);
            [Utils showToast:@"当前网络不可用，请检查你的网络设置"];
        }
    }];
}

+ (void)postWithParameters:(NSDictionary *)parameters
                    andUrl:(NSString *)url
                   success:(SuccessBlock)successBlock
                   failure:(FailureBlock)failureBlock{


    NSString * fullPathUrl = [NSString stringWithFormat:@"%@%@",[Utils getHost],url];


    AFHTTPSessionManager *manager = [[AFHTTPSessionManager manager] initWithBaseURL:[NSURL URLWithString:[Utils getHost]]];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    manager.requestSerializer.timeoutInterval = 60;
    if([fullPathUrl hasPrefix:@"https"]){
        manager.securityPolicy = [Networking customSecurityPolicy];
    }

//    NSString *token = [Utils getUserDefaultByKey:@"businessToken"];
//    [manager.requestSerializer setValue:token ?: @"" forHTTPHeaderField:@"Authorization"];


    manager.responseSerializer = [AFJSONResponseSerializer serializerWithReadingOptions:NSJSONReadingMutableContainers];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:
                                                         @"application/json",
                                                         @"text/json",
                                                         @"text/javascript",
                                                         @"text/html",
                                                         @"text/plain", nil];

    NSLog(@"url:%@;parmas:%@",fullPathUrl,parameters);
    [manager POST:fullPathUrl parameters:parameters headers:@{} progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        if (successBlock) {
            NSDictionary *dic = [responseObject copy];

            NSInteger code = [dic[@"code"] integerValue];
            NSString * msg = [dic objectForKey:@"msg"];

            NSLog(@"result:%@",dic);
            NSLog(@"code:%ld,msg:%@",code,msg);


            if (code == 0) {
                //成功
                successBlock(dic);
            }else{
                
                NSError * error = [NSError errorWithDomain:@"错误码见code" code:code userInfo:@{MSG:msg}];
                failureBlock(error);
            }
        }

    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {


        NSDictionary *userInfo = error.userInfo;
        NSString *localizedDescription = userInfo[NSLocalizedDescriptionKey];
//        NSString *reloadString = [NSString stringWithFormat:@"code:%@;msg:%@",[NSString stringWithFormat:@"%ld",error.code],localizedDescription?:@"当前网络不可用，请检查你的网络设置"];
        if (failureBlock) {

            
            NSError * error = [NSError errorWithDomain:@"错误码见code" code:-1 userInfo:@{MSG:@"当前网络不可用，请检查你的网络设置"}];
            failureBlock(error);
            
            [Utils showToast:@"当前网络不可用，请检查你的网络设置"];
        }
    }];
}





@end
