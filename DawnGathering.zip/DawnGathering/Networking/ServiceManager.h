//
//  ServiceManager.h
//  HLGA
//
//  Created by Linus on 2018/5/15.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void (^SuccessCallBack)(NSDictionary *data);
typedef void (^FailureCallBack)(NSError *error);

@interface ServiceManager : NSObject

+ (void)userLoginByAccount:(NSString*)account andPassword:(NSString*)password success:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack;

+ (void)sendSecurityCodeByAccount:(NSString*)account moduleName:(NSString*)module success:(SuccessCallBack)successBack;

+ (void)setInitPasswordByAccount:(NSString*)account andPassword:(NSString*)password andSecurityCode:(NSString*)code success:(SuccessCallBack)successBack;

+ (void)verificationSecutityCodeByAccount:(NSString*)account andSecurityCode:(NSString*)code success:(SuccessCallBack)successBack;

+ (void)resetPasswordByAccount:(NSString*)account andSetPassword:(NSString*)password andSecurityCode:(NSString*)code success:(SuccessCallBack)successBack;

+ (void)modifyPasswordByAccount:(NSString*)account andNewPassword:(NSString*)newPassword andOldPassword:(NSString*)oldPassword success:(SuccessCallBack)successBack;

+ (void)getMessageCount:(SuccessCallBack)successback isShowLoading:(BOOL)isShowLoading;

+ (void)getMessageListByType:(NSString*)messageType andPageIndex:(NSNumber*)pageIndex andPageSize:(NSNumber*)pageSize success:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack;

+ (void)getPayPasswordStateSuccess:(SuccessCallBack)successBack;

+ (void)initPayPasswordByAccount:(NSString*)account andNewPassword:(NSString*)newPassword success:(SuccessCallBack)successBack;

+ (void)updatePayPasswordByAccount:(NSString*)account andNewPassword:(NSString*)newPassword  andOldPassword:(NSString*)oldPassword success:(SuccessCallBack)successBack;

+ (void)validationPayPasswordByPassword:(NSString*)password success:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack;

+ (void)forgetPayPasswordByAccount:(NSString*)account andPassword:(NSString*)password andSecurityCode:(NSString*)code success:(SuccessCallBack)successBack;

+ (void)nonSecretPaymentPayPasswordByButton:(NSInteger )button andPassword:(NSString*)password  success:(SuccessCallBack)successBack;

+ (void)bonusPointsBytype:(NSInteger )type andPage:(NSInteger )page andPageSize:(NSInteger )pageSize   success:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack;

+ (void)getCreditCardAdImageBack:(SuccessCallBack)successBack;

+ (void)popUpAdssuccess:(SuccessCallBack)successBack;

+ (void)flashAdvertisingSuccess:(SuccessCallBack)successBack;

+ (void)getVersionSuccess:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack;

+(void)getUserCreditBalanceSuccess:(SuccessCallBack)successBack;

+ (void)getHomeTopPageSuccess:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack;

+ (void)getHomeTowPagePageIndex:(NSNumber*)pageIndex andPageSize:(NSNumber*)pageSize Success:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack;

+ (void)exitLogin:(SuccessCallBack)successBack;

+ (void)getOperatorPhoneNo:(NSString *)phoneNo successBack:(SuccessCallBack)successBack;

+(void)getPaymentRecordsType:(WPLivingPaymentType)type  andOffset:(NSNumber*)offset andLimit:(NSNumber*)limit andRemark:(NSString *)remark successBack:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack;

+(void)paymentOfLivingExpenses:(WPLivingPaymentType)type andBillkey:(NSString *)billkey andMoney:(NSInteger)money successBack:(SuccessCallBack)successBack;

+(void)addMachineTableCardType:(WPLivingPaymentType)type andBillkey:(NSString *)billkey andCompanyId:(NSString *)companyId successBack:(SuccessCallBack)successBack;

+(void)delMachineTableCardId:(NSInteger)lpID  successBack:(SuccessCallBack)successBack;

+(void)getMachineTableCardListType:(WPLivingPaymentType)type successBack:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack;

+(void)getMachineTableCardType:(WPLivingPaymentType)type andBillkey:(NSString *)billkey successBack:(SuccessCallBack)successBack;

+ (void)getPayOrderData:(NSString*)orderId successBack:(SuccessCallBack)successBack;

+ (void)payByOrderId:(NSString*)orderId andPassword:(NSString*)password andPayType:(NSNumber*)type successBack:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack;
+ (void)combinationPayByOrderId:(NSString*)orderId andOtherOrderId:(NSString*)otherOrderId andPayType:(NSNumber*)type successBack:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack;

+ (void)getUserInformationBySid:(NSString*)sid successBack:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack;
+(void)getBusinessTravelUrlSuccessBack:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack;

+ (void)getQrPayAdImageBack:(SuccessCallBack)successBack;
+ (void)getLifepayListButtonBack:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack;
+(void)getCreditCardSelectBankListSuccess:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack;
+(void)getCreditCardPreOrderParam:(NSDictionary *)param success:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack;
+(void)getCreditCardCreateOrderParam:(NSDictionary *)param success:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack;
+ (void)getCreditCardRecordUserId:(NSNumber *)userId andPageIndex:(NSNumber*)pageIndex andPageSize:(NSNumber*)pageSize success:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack;
+ (void)getMyOrderListSuccessBack:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack;
+ (void)getNewsListSuccessBack:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack;

+ (void)getNewsDetailsListMoudelId:(NSInteger )moudelId andPageIndex:(NSNumber*)pageIndex andPageSize:(NSNumber*)pageSize SuccessBack:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack;

//绑卡
+ (void)bindingCardWithCardNO:(NSString*)cardNO password:(NSString*)password success:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack;


//申请实名认
+ (void)getRealNameLisenseWithName:(NSString*)name idCard:(NSString*)idCard success:(SuccessCallBack)success;

//认证回调
+ (void)postRealNameBackWithOrderNO:(NSString*)orderNO success:(SuccessCallBack)success;

//用户上传头像;
+ (void)postUploadAvatarImg:(NSString*)img success:(SuccessCallBack)success;

//通过渠道ID 获取用户信息JS交互
+ (void)getUserInfoWithChannelID:(NSString*)channelID success:(SuccessCallBack)success;

//注销账户
+ (void)userLogoutAccount:(SuccessCallBack)success;

//注销审核状态  status 0审核中 1通过 2拒绝
+ (void)getUserLogoutAccountStatus:(SuccessCallBack)success;

//获取首页数据
+ (void)getHomePageListData:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack;

//获取首页底部tabbar数据;
+ (void)getHomePageBottomListData:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack;

//获取首页数据通过ID
+ (void)getHomePageListDataWithID:(NSString*)homePageID success:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack;

//一键登录;
+ (void)onecKeyLoginWithToken:(NSString*)token success:(SuccessCallBack)success;

//设置免密支付金额;开关
+ (void)setNoPasswordWithAmount:(NSNumber*)amount pwd:(NSString*)pwd number:(NSNumber*)number success:(SuccessCallBack)success;

//查询查询扣款顺序;
+ (void)getUserPaymentSequence:(SuccessCallBack)success;

//设置扣款顺序;

+ (void)setUserPaymentSequenceWithWalletList:(NSArray*)walletList switchX:(NSNumber*)switchX itemPayOrder:(NSNumber*)itemPayOrder success:(SuccessCallBack)success;

//线下付款验证支付密码回调
+ (void)qrPayVerifyPasswordWithSerialNumber:(NSString*)serialNumber pwd:(NSString*)pwd success:(SuccessCallBack)success;

//获取多笔订单
+ (void)getPayOrderWithSerialNumbers:(NSArray<NSString*>*)serialNumbers isPayInfo:(BOOL)isPayInfo isSAAS:(BOOL)isSAAS success:(SuccessCallBack)success;

//第三方支付下单;
+ (void)thirdPayWithSerialNumbers:(NSArray<NSString*>*)serialNumbers payType:(NSInteger)payType accountFundingType:(NSString*)accountFundingType items:(NSArray*)items rpItems:(NSArray*)rpItems isSAAS:(BOOL)isSAAS success:(SuccessCallBack)success failure:(FailureCallBack)failure;

//密码支付
+ (void)defaultPayWithSerialNumbers:(NSArray<NSString*>*)serialNumbers password:(NSString*)password accountFundingType:(NSString*)accountFundingType items:(NSArray*)items rpItems:(NSArray*)rpItems isSAAS:(BOOL)isSAAS success:(SuccessCallBack)success failure:(FailureCallBack)failure;

//获取账单列表
+ (void)getAccountOrderListWithPage:(NSNumber*)page pageSize:(NSNumber*)pageSize type:(NSNumber*)type year:(NSString*)year success:(SuccessCallBack)success failure:(FailureCallBack)failure;


//获取账户详情
+ (void)getBillDetailWithOrderNo:(NSString*)orderNo success:(SuccessCallBack)success;

//获取saas商品集
+ (void)getMerchandiseWithPageNum:(NSNumber*)pageNum pageSize:(NSNumber*)pageSize keyword:(NSString*)keyword zoneId:(NSString*)zoneId selectionCodes:(NSString*)selectionCodes success:(SuccessCallBack)success failure:(FailureCallBack)failure;

//查询可用余额
+ (void)getCanUseAmountItemsWithOrderNo:(NSArray*)orderNos success:(SuccessCallBack)success;

//获取用户商品集
+ (void)getUserSectionCodes:(SuccessCallBack)success;

//获取SAAS所有URL
+ (void)getewayAllHTMLURL:(SuccessCallBack)success;

//获取订单状态以及URL
+ (void)getH5OrderURLListCount:(SuccessCallBack)success;

//查询订单状态;
+ (void)getOrderStatusWithSerialNumbers:(NSArray*)serialNumber success:(SuccessCallBack)success;

//获取单位;
+ (void)getAppUnit;

//领取优惠券;
+ (void)receiveCouponWithActivityID:(NSNumber*)activityID templateId:(NSNumber*)templateId templateCode:(NSString*)templateCode success:(SuccessCallBack)success;


//查询优惠券领取状态;
+ (void)getReceiveCouponStatsWithActivityID:(NSNumber*)activityID couponTemplateCodes:(NSArray*)couponTemplateCodes success:(SuccessCallBack)success;

//获取我的券列表;
+ (void)getMyCouponsWithState:(NSNumber*)state page:(NSNumber*)page pageSize:(NSNumber*)pageSize success:(SuccessCallBack)success failure:(FailureCallBack)failure;

//获取提货券列表;
+ (void)getPickupCardWithPage:(NSNumber*)page pageSize:(NSNumber*)pageSize itemID:(NSNumber*)itemID key:(NSString*)key success:(SuccessCallBack)success failure:(FailureCallBack)failure;

//绑定提货券;
+ (void)bindPickupCardWithCardNO:(NSString*)cardNO cardPWD:(NSString*)cardPWD equityIssueInfo:(NSDictionary*)equityIssueInfo success:(SuccessCallBack)success;

//修改卡密码;
+ (void)modifyPickupCardPWDWithCardNO:(NSString*)cardNO oldPassword:(NSString*)oldPassword newPassword:(NSString*)newPassword verifycationCode:(NSString*)verifycationCode success:(SuccessCallBack)success;

//获取分类列表;
+ (void)getSortDataWithPageID:(NSNumber*)pageID success:(SuccessCallBack)success;


//自定义页面;
+ (void)customURLWithURL:(NSString*)URL success:(SuccessCallBack)success;

//充值
+ (void)userAccountChargeWithItemID:(NSNumber*)itemID amount:(NSNumber*)amount payType:(NSNumber*)payType success:(SuccessCallBack)success;

//获取权益列表;
+ (void)getEquityWithState:(NSNumber*)state page:(NSNumber*)page pageSize:(NSNumber*)pageSize success:(SuccessCallBack)success failure:(FailureCallBack)failure;

//获取支付方式;
+ (void)getPayStyleWithAccountFundingType:(NSString*)accountFundingType success:(SuccessCallBack)success;

//1-随机、2-不随机 随机展示的个数,isRand=1时有效
+ (void)getFlashAdveriseWithAdids:(NSArray*)adIds isRand:(NSNumber*)isRand randNumToShow:(NSNumber*)randNumToShow success:(SuccessCallBack)success;

//获取首页shopSetURL
+ (void)getHomeH5URLWithRedirectType:(NSString*)redirectType homePageDTO:(NSDictionary*)homePageDTO success:(SuccessCallBack)success;

//获取搜索条件;
+ (void)getFilterConditionWithCityName:(NSString*)cityName blackWhiteIdList:(NSArray*)blackWhiteIdList success:(SuccessCallBack)success;

//获取商户列表; //resId页码，第二页要把返回值传给他
+ (void)getMerchantListWithItems:(NSArray<NSString*>*)items word:(NSString*)word isCutWord:(BOOL)isCutWord Lng:(NSNumber*)Lng Lat:(NSNumber*)Lat resId:(NSString*)resId page:(NSNumber*)page pageSize:(NSNumber*)pageSize areaIndex:(NSString*)areaIndex merchantIndex:(NSString*)merchantIndex sortType:(NSString*)sortType blackWhiteId:(NSNumber*)blackWhiteId brandIndex:(NSString*)brandIndex blackWhiteIdList:(NSArray*)blackWhiteIdList brandIndexList:(NSArray*)brandIndexList success:(SuccessCallBack)success failure:(FailureCallBack)failure;

//408-获取商户详细信息
+ (void)getMerchantDetailWithMerchantId:(NSNumber*)merchantId items:(NSArray*)items success:(SuccessCallBack)success;

//商户反馈
+ (void)setMerchantQuestionBackWithMerhcantId:(NSNumber*)merchantId content:(NSString*)content success:(SuccessCallBack)success;

//获取问题反馈列表问题
+ (void)getMerchantQuestionBackListWithMerhcantId:(NSNumber*)merchantId success:(SuccessCallBack)success;

//识别卡号
+ (void)getCardWithImageBase64:(NSString*)base64 success:(SuccessCallBack)success;

//红包余额
+ (void)getUserRedEnvelop:(SuccessCallBack)success;

//红包记录
+ (void)getUserRedEnvelopRecordListWithPage:(NSNumber*)page pageSize:(NSNumber*)pageSize success:(SuccessCallBack)success failure:(FailureCallBack)failure;

//通过卡号查询是否需要报备信息;
+ (void)getCheckUserInformtionWithCardNumber:(NSString*)cardNo success:(SuccessCallBack)success;

@end
