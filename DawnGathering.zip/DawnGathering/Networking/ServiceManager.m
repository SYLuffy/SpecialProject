//
//  ServiceManager.m
//  HLGA
//
//  Created by Linus on 2018/5/15.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "ServiceManager.h"
#import "Networking.h"
#import "RSA_Encryptor.h"
#import <OpenUDID.h>
@implementation ServiceManager

static NSInteger iOSSystemType = 2;

//用户登录，账号、密码
+ (void)userLoginByAccount:(NSString*)account andPassword:(NSString*)password success:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack
{
    NSNumber * sysType = [NSNumber numberWithInteger:iOSSystemType];
    
    NSString * pushToken = [SharedInstance getInstance].pushToken;
    
    if(pushToken == nil)
    {
        pushToken = @"rjfsdakljfkdlsajfkldsajkl";
    }
    
    NSDictionary * param = @{PASSWORD:[[RSA_Encryptor sharedRSA_Encryptor] encryptorString:password PublicKeyStr:RSA_PUBLIC_KEY],ACCOUNT:account,SYSTEM_TYPE:sysType,PUSH_TOKEN:pushToken};

    NSMutableDictionary * parameters = [param mutableCopy];
    
    [Networking postWithParameters:parameters andCmd:@101 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        failureBack(error);
    }];
}

//获取验证码，账号，验证module
+ (void)sendSecurityCodeByAccount:(NSString*)account moduleName:(NSString*)module success:(SuccessCallBack)successBack
{
    NSDictionary * param = @{ACCOUNT:account,MODULE:module};
    
    NSMutableDictionary * parameters = [param mutableCopy];
    [parameters setObject:[SharedInstance getInstance].userInfo.telephone forKey:@"phone"];
    [Networking postWithParameters:parameters andCmd:@119 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        [Utils showToast:TOAST_NET_FAILURE];
    }];
    
}

//设置初始密码，账号，密码，手机验证码
+ (void)setInitPasswordByAccount:(NSString*)account andPassword:(NSString*)password andSecurityCode:(NSString*)code success:(SuccessCallBack)successBack{
    
    NSDictionary * param = @{ACCOUNT:account,LOGIN_PASSWORD:[[RSA_Encryptor sharedRSA_Encryptor] encryptorString:password PublicKeyStr:RSA_PUBLIC_KEY],SECURITY_CODE:code};
    
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [Networking postWithParameters:parameters andCmd:@121 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        [Utils showToast:TOAST_NET_FAILURE];
    }];
}

//验证验证码，账号，手机验证码
+ (void)verificationSecutityCodeByAccount:(NSString*)account andSecurityCode:(NSString*)code success:(SuccessCallBack)successBack{
    
    NSDictionary * param = @{ACCOUNT:account,SECURITY_CODE:code};
    
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [Networking postWithParameters:parameters andCmd:@127 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        [Utils showToast:error.userInfo[@"msg"]];
    }];
    
}

//重设登录密码，账号，重设的密码，手机验证码
+ (void)resetPasswordByAccount:(NSString*)account andSetPassword:(NSString*)password andSecurityCode:(NSString*)code success:(SuccessCallBack)successBack
{
    NSDictionary * param = @{ACCOUNT:account,SECURITY_CODE:code,PASSWORD:[[RSA_Encryptor sharedRSA_Encryptor] encryptorString:password PublicKeyStr:RSA_PUBLIC_KEY]};
    
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [Networking postWithParameters:parameters andCmd:@120 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        [Utils showToast:TOAST_NET_FAILURE];
    }];
}

//修改登录密码，用户账号，新密码，旧密码
+ (void)modifyPasswordByAccount:(NSString*)account andNewPassword:(NSString*)newPassword andOldPassword:(NSString*)oldPassword success:(SuccessCallBack)successBack
{

    NSDictionary * param = @{ACCOUNT:account,NEWPASSWORD:[[RSA_Encryptor sharedRSA_Encryptor] encryptorString:newPassword PublicKeyStr:RSA_PUBLIC_KEY],OLDPASSWORD:[[RSA_Encryptor sharedRSA_Encryptor] encryptorString:oldPassword PublicKeyStr:RSA_PUBLIC_KEY]};
    
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [Networking postWithParameters:parameters andCmd:@103 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        [Utils showToast:[NSString stringWithFormat:@"code:%ld %@",error.code,error.userInfo[@"msg"]]];
    }];
}

+ (void)getMessageCount:(SuccessCallBack)successback isShowLoading:(BOOL)isShowLoading
{
    NSDictionary * param = @{};
    NSMutableDictionary * parameters = [param mutableCopy];
    
    if(!isShowLoading)
    {
        BOOL isHas = false;
        NSMutableArray * hideArray = [[SharedInstance getInstance].hideLoadingDataSource mutableCopy];
        
        NSInteger sum = hideArray.count;
        
        for(NSInteger i = 0; i < sum; i++)
        {
            NSNumber * cmd = hideArray[i];
            if(cmd.integerValue == 122)
            {
                isHas = true;
                break;
            }
        }
        if (isHas == false) {
            [[SharedInstance getInstance].hideLoadingDataSource addObject:@122];
        }
        
    }else{
        
        NSMutableArray * hideArray = [[SharedInstance getInstance].hideLoadingDataSource mutableCopy];
        
        NSInteger sum = hideArray.count;
        
        for(NSInteger i = 0; i < sum; i++)
        {
            NSNumber * cmd = hideArray[i];
            if(cmd.integerValue == 122)
            {
                [[SharedInstance getInstance].hideLoadingDataSource removeObjectAtIndex:i];
                break;
            }
        }
    }
    
    [Networking postWithParameters:parameters andCmd:@122 success:^(NSDictionary *data) {
        successback(data);
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

+ (void)getMessageListByType:(NSString*)messageType andPageIndex:(NSNumber*)pageIndex andPageSize:(NSNumber*)pageSize success:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack
{
    
    
    [[SharedInstance getInstance].hideLoadingDataSource addObject:@123];

    
    NSDictionary * param = @{TYPE_ID:messageType,PAGE_INDEX:pageIndex,PAGE_SZ:pageSize};
    NSMutableDictionary * parameters = [param mutableCopy];
    [Networking postWithParameters:parameters andCmd:@123 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        failureBack(error);
    }];
    
}

//获取支付密码状态
+ (void)getPayPasswordStateSuccess:(SuccessCallBack)successBack
{
    [[SharedInstance getInstance].hideLoadingDataSource addObject:@128];

    NSDictionary * param = @{CID:[OpenUDID value]};
    
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [Networking postWithParameters:parameters andCmd:@128 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        };
    }];
}
//设置支付初始密码，用户账号，新支付密码，旧支付密码
+ (void)initPayPasswordByAccount:(NSString*)account andNewPassword:(NSString*)newPassword success:(SuccessCallBack)successBack
{
    NSDictionary * param = @{ACCOUNT:account,NEWPASSWORD:[[RSA_Encryptor sharedRSA_Encryptor] encryptorString:newPassword PublicKeyStr:RSA_PUBLIC_KEY]};
    
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [Networking postWithParameters:parameters andCmd:@125 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//忘记支付初始密码，用户账号，新支付密码，旧支付密码
+ (void)forgetPayPasswordByAccount:(NSString*)account andPassword:(NSString*)password andSecurityCode:(NSString*)code success:(SuccessCallBack)successBack
{
    NSDictionary * param = @{ACCOUNT:account,PASSWORD:[[RSA_Encryptor sharedRSA_Encryptor] encryptorString:password PublicKeyStr:RSA_PUBLIC_KEY],SECURITY_CODE:code};
    
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [Networking postWithParameters:parameters andCmd:@126 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//设置支付初始密码，用户账号，新支付密码，旧支付密码
+ (void)updatePayPasswordByAccount:(NSString*)account andNewPassword:(NSString*)newPassword  andOldPassword:(NSString*)oldPassword success:(SuccessCallBack)successBack
{
    NSDictionary * param = @{ACCOUNT:account,NEWPASSWORD:[[RSA_Encryptor sharedRSA_Encryptor] encryptorString:newPassword PublicKeyStr:RSA_PUBLIC_KEY],OLDPASSWORD:[[RSA_Encryptor sharedRSA_Encryptor] encryptorString:oldPassword PublicKeyStr:RSA_PUBLIC_KEY]};
    
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [Networking postWithParameters:parameters andCmd:@111 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//验证支付的密码
+ (void)validationPayPasswordByPassword:(NSString*)password success:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack
{
    NSDictionary * param = @{PASSWORD:[[RSA_Encryptor sharedRSA_Encryptor] encryptorString:password PublicKeyStr:RSA_PUBLIC_KEY]};
    
    NSMutableDictionary * parameters = [param mutableCopy];
    [Networking postWithParameters:parameters andCmd:@129 success:^(NSDictionary *data) {
        
        successBack(data);
    } failure:^(NSError *error) {
        failureBack(error);
    }];
}

+ (void)nonSecretPaymentPayPasswordByButton:(NSInteger )button andPassword:(NSString*)password  success:(SuccessCallBack)successBack
{
    NSDictionary * param = @{BUTTON:@(button),PASSWORD:password,CID:[OpenUDID value]};
    
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [Networking postWithParameters:parameters andCmd:@112 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//获取用户的积分记录（4消费列表1充值列表）
+ (void)bonusPointsBytype:(NSInteger )type andPage:(NSInteger )page andPageSize:(NSInteger )pageSize   success:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack
{
    
    NSMutableDictionary * parameters = nil;
    NSNumber *number = @140;
    
    if(type == 0){
        NSDictionary * param = @{@"page":@(page),@"pageSize":@(pageSize)};
        parameters = [param mutableCopy];
    }else{
        NSDictionary * param = @{TYPE:@(type),PAGE_INDEX:@(page),PAGE_SZ:@(pageSize)};
        parameters = [param mutableCopy];
        number = @106;
    }
    [[SharedInstance getInstance].hideLoadingDataSource addObject:number];
    [Networking postWithParameters:parameters andCmd:number success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        failureBack(error);
    }];
    
    
}

//弹窗广告
+ (void)popUpAdssuccess:(SuccessCallBack)successBack
{
    [[SharedInstance getInstance].hideLoadingDataSource addObject:@131];

    
    NSDictionary * param = @{};
    
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [Networking postWithParameters:parameters andCmd:@131 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//闪屏广告
+ (void)flashAdvertisingSuccess:(SuccessCallBack)successBack
{
    [[SharedInstance getInstance].hideLoadingDataSource addObject:@132];

    NSDictionary * param = @{};
    
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [Networking postWithParameters:parameters andCmd:@132 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}


//获取版本号
+ (void)getVersionSuccess:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack{
    
    [[SharedInstance getInstance].hideLoadingDataSource addObject:@130];
    
    //获取当前版本号
    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
    NSString *app_Version = [infoDictionary objectForKey:@"CFBundleShortVersionString"];

    NSDictionary * param = @{SYSTEM_TYPE:@(2),VERSION:app_Version};
    NSMutableDictionary * parameters = [param mutableCopy];
    [Networking postWithParameters:parameters andCmd:@130 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
      failureBack(error);
    }];
}
//单独获取用户的积分余额
+ (void)getUserCreditBalanceSuccess:(SuccessCallBack)successBack{
   
    [[SharedInstance getInstance].hideLoadingDataSource addObject:@134];

    NSDictionary * param = @{};
    
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [Networking postWithParameters:parameters andCmd:@134 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//获取首页上半部分的数据
+ (void)getHomeTopPageSuccess:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack
{
    [[SharedInstance getInstance].hideLoadingDataSource addObject:@133];
    
    NSDictionary * param = @{};
    
    NSMutableDictionary * parameters = [param mutableCopy];

    [Networking postWithParameters:parameters andCmd:@133 success:^(NSDictionary *data) {
        successBack(data);
//        NSDictionary * dic = [Utils dictionaryWithJsonString:data[DATA][@"homeData"]];
//        
//        NSLog(@"%@",dic);
    } failure:^(NSError *error) {
        failureBack(error);
    }];
}

//获取首页第二部分的数据
+ (void)getHomeTowPagePageIndex:(NSNumber*)pageIndex andPageSize:(NSNumber*)pageSize Success:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack
{
    [[SharedInstance getInstance].hideLoadingDataSource addObject:@135];
    
    NSDictionary * param = @{PAGE_INDEX:pageIndex,PAGE_SZ:pageSize};

    NSMutableDictionary * parameters = [param mutableCopy];
    
    [Networking postWithParameters:parameters andCmd:@135 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
    
        failureBack(error);
    }];
}

//退出登录
+ (void)exitLogin:(SuccessCallBack)successBack{
    NSDictionary * param = @{};
    
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [Networking postWithParameters:parameters andCmd:@115 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//获取运营商名称
+ (void)getOperatorPhoneNo:(NSString *)phoneNo successBack:(SuccessCallBack)successBack{
    
    NSDictionary * param = @{PHONE:phoneNo};
    
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [Networking postWithParameters:parameters andCmd:@300 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

/**
 获取缴费记录

 @param type 缴费类型 1电费，2气费，4电话费 6水费
 @param offset 页码
 @param limit 第页页数
 @param remark 名称
 @param successBack 成功返回
 @param failureBack 失败返回
 */
+(void)getPaymentRecordsType:(WPLivingPaymentType)type  andOffset:(NSNumber*)offset andLimit:(NSNumber*)limit andRemark:(NSString *)remark successBack:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack{
    
    [[SharedInstance getInstance].hideLoadingDataSource addObject:@308];

    
    NSDictionary * param = @{TYPE:@(type),LIMIT:limit,OFFSET:offset};
    
    NSMutableDictionary * parameters = [param mutableCopy];

    [Networking postWithParameters:parameters andCmd:@308 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        failureBack(error);
    }];
}

/**
 生活缴费下单

 @param type 缴费类型 1电费，2气费，4电话费 6水费
 @param billkey 机表号
 @param money 金额单位分
 @param successBack 成功返回
 */
+(void)paymentOfLivingExpenses:(WPLivingPaymentType)type andBillkey:(NSString *)billkey andMoney:(NSInteger)money successBack:(SuccessCallBack)successBack{

    NSDictionary * param = @{TYPE:@(type),BILLKEY:billkey,MONEY:@(money)};
    
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [Networking postWithParameters:parameters andCmd:@302 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}


/**
 添加缴费卡信息

 @param type 缴费类型 1电费，2气费，6水费
 @param billkey 机表号名称
 @param companyId 机表ID号
 @param successBack 成功返回
 */
+(void)addMachineTableCardType:(WPLivingPaymentType)type andBillkey:(NSString *)billkey andCompanyId:(NSString *)companyId successBack:(SuccessCallBack)successBack{
    
    
    NSDictionary * param = @{TYPE:@(type),BILLKEY:billkey,COMPANYID:companyId};
    
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [Networking postWithParameters:parameters andCmd:@305 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}


/**
 删除缴费卡信息


 @param lpID 缴费卡ID
 @param successBack 成功返回
 */
+(void)delMachineTableCardId:(NSInteger)lpID  successBack:(SuccessCallBack)successBack{
    
    
    NSDictionary * param = @{ID:@(lpID)};
    
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [Networking postWithParameters:parameters andCmd:@307 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
        
    }];
}

/**
 获取缴费卡信息列表

 @param type 缴费类型 1电费，2气费，6水费
 @param successBack 成功返回
 @param failureBack 失败返回
 */
+(void)getMachineTableCardListType:(WPLivingPaymentType)type successBack:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack{
    
    NSDictionary * param = @{TYPE:@(type)};
    
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [Networking postWithParameters:parameters andCmd:@304 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        
        failureBack(error);
    }];
}

/**
 获取单个缴费卡信息
 
 @param type 缴费类型 1电费，2气费，6水费
 @param successBack 成功返回
 */
+(void)getMachineTableCardType:(WPLivingPaymentType)type andBillkey:(NSString *)billkey successBack:(SuccessCallBack)successBack{
    
    NSDictionary * param = @{TYPE:@(type),BILLKEY:billkey};
    
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [Networking postWithParameters:parameters andCmd:@309 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }[Utils showToast:TOAST_NET_FAILURE];
    }];
}

/**
 *@param orderId 订单号
 */
+ (void)getPayOrderData:(NSString*)orderId successBack:(SuccessCallBack)successBack
{
    
    [[SharedInstance getInstance].hideLoadingDataSource addObject:@202];
    
    NSDictionary * param = @{ORDER_ID:orderId};
    
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [Networking postWithParameters:parameters andCmd:@202 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

/**
 *@param orderId 订单号
 *@param password 支付密码
 *@param type 支付方式 0默认，1微信，2支付宝
 */

+ (void)payByOrderId:(NSString*)orderId andPassword:(NSString*)password andPayType:(NSNumber*)type successBack:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack
{
    NSDictionary * param = @{ORDER_ID:orderId,PASSWORD:[[RSA_Encryptor sharedRSA_Encryptor] encryptorString:password PublicKeyStr:RSA_PUBLIC_KEY],PAY_TYPE:type};
    
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [Networking postWithParameters:parameters andCmd:@203 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        failureBack(error);
        //[Utils showToast:TOAST_NET_FAILURE];
    }];
}
/**
 *@param orderId 订单号
 *@param otherOrderId 三方订单号
 *@param type 支付方式 0默认，1微信，2支付宝
 */
+ (void)combinationPayByOrderId:(NSString*)orderId andOtherOrderId:(NSString*)otherOrderId andPayType:(NSNumber*)type successBack:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack
{
    NSDictionary * param = @{ORDER_ID:orderId,OTHER_ODER_ID:otherOrderId,PAY_TYPE:type};
    
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [Networking postWithParameters:parameters andCmd:@204 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        failureBack(error);
        //[Utils showToast:TOAST_NET_FAILURE];
    }];
}


/**
 *@param sid 用户token
 */
+ (void)getUserInformationBySid:(NSString*)sid successBack:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack
{
    NSDictionary * param = @{};
    
    [SharedInstance getInstance].sid = sid;
    
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [[SharedInstance getInstance].hideLoadingDataSource addObject:@105];
    
    [Networking postWithParameters:parameters andCmd:@105 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        failureBack(error);
        //[Utils showToast:TOAST_NET_FAILURE];
    }];
}

///获取商旅url 接口地址
+(void)getBusinessTravelUrlSuccessBack:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack{
    
    NSDictionary * param = @{};
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [[SharedInstance getInstance].hideLoadingDataSource addObject:@141];
    
    [Networking postWithParameters:parameters andCmd:@141 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        failureBack(error);
    }];
}

/**
 * 获取支付后广告
 */
+ (void)getQrPayAdImageBack:(SuccessCallBack)successBack{
    
    NSDictionary * param = @{};
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [[SharedInstance getInstance].hideLoadingDataSource addObject:@137];
    
    [Networking postWithParameters:parameters andCmd:@137 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
    
}

/**
 * 信用卡还款后广告
 */
+ (void)getCreditCardAdImageBack:(SuccessCallBack)successBack{
    
    NSDictionary * param = @{};
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [[SharedInstance getInstance].hideLoadingDataSource addObject:@138];
    
    [Networking postWithParameters:parameters andCmd:@138 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
    
}

/**
 * 获取生活缴费按钮
 */
+ (void)getLifepayListButtonBack:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack{
    [[SharedInstance getInstance].hideLoadingDataSource addObject:@310];

    NSDictionary * param = @{};
    NSMutableDictionary * parameters = [param mutableCopy];
        
    [Networking postWithParameters:parameters andCmd:@310 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        failureBack(error);
    }];
}

//获取所支持的银行列表
+(void)getCreditCardSelectBankListSuccess:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack{
    
    [[SharedInstance getInstance].hideLoadingDataSource addObject:@321];
    NSDictionary * param = @{};
    NSMutableDictionary * parameters = [param mutableCopy];
    [Networking postWithParameters:parameters andCmd:@321 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        failureBack(error);
    }];
}

//创建订单前置接口(个人)
+(void)getCreditCardPreOrderParam:(NSDictionary *)param success:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack{
    
    NSMutableDictionary * parameters = [param mutableCopy];
    [Networking postWithParameters:parameters andCmd:@322 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}
//创建订单接口
+(void)getCreditCardCreateOrderParam:(NSDictionary *)param success:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack{
    
    NSMutableDictionary * parameters = [param mutableCopy];
    [Networking postWithParameters:parameters andCmd:@323 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//创建订单接口
+ (void)getCreditCardRecordUserId:(NSNumber *)userId andPageIndex:(NSNumber*)pageIndex andPageSize:(NSNumber*)pageSize success:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack{
   
    [[SharedInstance getInstance].hideLoadingDataSource addObject:@324];

    NSDictionary *param = @{@"userId":userId, @"page":pageIndex,@"pageSize":pageSize};
    NSMutableDictionary * parameters = [param mutableCopy];

    [Networking postWithParameters:parameters andCmd:@324 success:^(NSDictionary *data) {
        if(successBack){
            successBack(data);
        }
    } failure:^(NSError *error) {
        if (failureBack) {
            failureBack(error);
        }
    }];
}
//我的订单
+ (void)getMyOrderListSuccessBack:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack{
   
    [[SharedInstance getInstance].hideLoadingDataSource addObject:@139];
    NSDictionary * param = @{};
    NSMutableDictionary * parameters = [param mutableCopy];
    [Networking postWithParameters:parameters andCmd:@139 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        failureBack(error);
    }];
}

//新闻列表
+ (void)getNewsListSuccessBack:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack{
    
    NSDictionary * param = @{@"userId":[SharedInstance getInstance].userInfo.userId,@"telephone":[SharedInstance getInstance].userInfo.telephone};
    NSMutableDictionary * parameters = [param mutableCopy];
    [Networking postWithParameters:parameters andCmd:@142 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        failureBack(error);
    }];
}


+ (void)getNewsDetailsListMoudelId:(NSInteger )moudelId andPageIndex:(NSNumber*)pageIndex andPageSize:(NSNumber*)pageSize SuccessBack:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack{
    [[SharedInstance getInstance].hideLoadingDataSource addObject:@143];
    NSDictionary *param = @{@"moudelId":@(moudelId), @"page":pageIndex,@"pageSize":pageSize};
    NSMutableDictionary * parameters = [param mutableCopy];
    [Networking postWithParameters:parameters andCmd:@143 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        failureBack(error);
    }];
}

//绑卡
+ (void)bindingCardWithCardNO:(NSString*)cardNO password:(NSString*)password  success:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack
{
    NSDictionary *param = @{@"cardNo":cardNO, @"cardPwd":[[RSA_Encryptor sharedRSA_Encryptor] encryptorString:password PublicKeyStr:RSA_PUBLIC_KEY]};
    NSMutableDictionary * parameters = [param mutableCopy];
    [Networking postWithParameters:parameters andCmd:@148 success:^(NSDictionary *data) {
        successBack(data);
    } failure:^(NSError *error) {
        failureBack(error);
        
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

+ (void)getRealNameLisenseWithName:(NSString*)name idCard:(NSString*)idCard success:(SuccessCallBack)success
{
    
    NSDictionary *param = @{NAME:[[RSA_Encryptor sharedRSA_Encryptor] encryptorString:name PublicKeyStr:RSA_PUBLIC_KEY],@"idNo":[[RSA_Encryptor sharedRSA_Encryptor] encryptorString:idCard PublicKeyStr:RSA_PUBLIC_KEY],CLIENT_TYPE:@1};
    
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [Networking postWithParameters:parameters andCmd:@150 success:^(NSDictionary *data) {
        success(data);
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
        
    }];
}

+ (void)postRealNameBackWithOrderNO:(NSString*)orderNO success:(SuccessCallBack)success
{
    NSDictionary *param = @{@"orderNo":orderNO};
    
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [Networking postWithParameters:parameters andCmd:@151 success:^(NSDictionary *data) {
        success(data);
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//用户上传头像;
+ (void)postUploadAvatarImg:(NSString*)img success:(SuccessCallBack)success
{
    NSDictionary *param = @{@"img":img};
    
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [Networking postWithParameters:parameters andCmd:@152 success:^(NSDictionary *data) {
        success(data);
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//通过渠道ID 获取用户信息JS交互
+ (void)getUserInfoWithChannelID:(NSString*)channelID success:(SuccessCallBack)success
{
    NSDictionary * param = @{@"channelId":@(channelID.integerValue)};
    
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [Networking postWithParameters:parameters andCmd:@153 success:^(NSDictionary *data) {
        
        success(data);
        
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//注销账户
+ (void)userLogoutAccount:(SuccessCallBack)success
{
    NSDictionary * param = @{};
    NSMutableDictionary * paramters = [param mutableCopy];
    [Networking postWithParameters:paramters andCmd:@160 success:^(NSDictionary *data) {
        success(data);
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//注销审核状态  status 0审核中 1通过 2拒绝
+ (void)getUserLogoutAccountStatus:(SuccessCallBack)success
{
    NSDictionary * param = @{};
    NSMutableDictionary * paramters = [param mutableCopy];
    [Networking postWithParameters:paramters andCmd:@161 success:^(NSDictionary *data) {
        success(data);
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//获取首页底部tabbar数据;
+ (void)getHomePageBottomListData:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack
{
    [[SharedInstance getInstance].hideLoadingDataSource addObject:@402];
    
    NSNumber * companyID = [Utils getUserDefaultByKey:COMPANY_ID];
    
    if(!companyID) companyID = [SharedInstance getInstance].userInfo.companyId;
    
    if(!companyID) companyID = @(0);
    
    NSDictionary * param = @{COMPANY_ID:companyID,CHANNEL_ID:@(0),CLIENT_TYPE:@(1)};
    
    NSMutableDictionary * parameters = [param mutableCopy];

    [Networking postWithParameters:parameters andCmd:@402 success:^(NSDictionary *data) {
       
        NSDictionary * dic = [Utils dictionaryWithJsonString:data[DATA][BOTTOM_DETAIL]];
        successBack(dic);

    } failure:^(NSError *error) {
    
        failureBack(error);
        
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}


//获取首页数据
+ (void)getHomePageListData:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack
{
    [[SharedInstance getInstance].hideLoadingDataSource addObject:@401];
    
    NSNumber * companyID = [Utils getUserDefaultByKey:COMPANY_ID];
    
    if(!companyID) companyID = [SharedInstance getInstance].userInfo.companyId;
    
    if(!companyID) companyID = @(0);
    
    NSDictionary * param = @{COMPANY_ID:companyID,CHANNEL_ID:@(0),CLIENT_TYPE:@(1)};
    
    NSMutableDictionary * parameters = [param mutableCopy];

    [Networking postWithParameters:parameters andCmd:@401 success:^(NSDictionary *data) {
       
        NSDictionary * dic = [Utils dictionaryWithJsonString:data[DATA][DETAIL]];
        successBack(dic);

    } failure:^(NSError *error) {
    
        failureBack(error);
        
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}


//获取首页数据通过ID
+ (void)getHomePageListDataWithID:(NSString*)homePageID success:(SuccessCallBack)successBack failure:(FailureCallBack)failureBack
{
    NSDictionary * param = @{ID:@(homePageID.integerValue),CHANNEL_ID:@(0),CLIENT_TYPE:@(1)};

    NSMutableDictionary * parameters = [param mutableCopy];

    [Networking postWithParameters:parameters andCmd:@403 success:^(NSDictionary *data) {
       
        NSDictionary * dic = data[DATA];
        successBack(dic);

    } failure:^(NSError *error) {
        
        failureBack(error);
        
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
        
    }];
}

//一键登录;
+ (void)onecKeyLoginWithToken:(NSString*)token success:(SuccessCallBack)success
{ 
    NSDictionary * param = @{TOKEN:token,SYSTEM_TYPE:@2};

    
    NSMutableDictionary * parameters = [param mutableCopy];

    [Networking postWithParameters:parameters andCmd:@181 success:^(NSDictionary *data) {
       
        NSDictionary * dic = data[DATA];
        success(dic);

    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//设置免密支付金额;开关
+ (void)setNoPasswordWithAmount:(NSNumber*)amount pwd:(NSString*)pwd number:(NSNumber*)number success:(SuccessCallBack)success
{
    NSDictionary * param;
    
    if(number.integerValue == 1)
    {
        param = @{AMOUNT:amount,PASSWORD:[[RSA_Encryptor sharedRSA_Encryptor] encryptorString:pwd PublicKeyStr:RSA_PUBLIC_KEY],BUTTON:number,CID:@""};
    }else if(number.integerValue == 0){
        param = @{NUMBER:number};
    }
    
    NSMutableDictionary * parameters = [param mutableCopy];

    [Networking postWithParameters:parameters andCmd:@112 success:^(NSDictionary *data) {
       
        NSDictionary * dic = data[DATA];
        success(dic);

    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//查询查询扣款顺序;
+ (void)getUserPaymentSequence:(SuccessCallBack)success
{
    NSDictionary * param = @{};

    NSMutableDictionary * parameters = [param mutableCopy];

    [Networking postWithParameters:parameters andCmd:@162 success:^(NSDictionary *data) {
       
        NSDictionary * dic = data[DATA];
        success(dic);

    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//设置扣款顺序;

+ (void)setUserPaymentSequenceWithWalletList:(NSArray*)walletList switchX:(NSNumber*)switchX itemPayOrder:(NSNumber*)itemPayOrder success:(SuccessCallBack)success
{
    NSDictionary * param;
    
    if(switchX.integerValue == 1)
    {
        param = @{@"accountOrder":walletList,SWITCH:switchX,@"order":itemPayOrder};
    }else if(switchX.integerValue == 0){
        param = @{SWITCH:switchX,@"accountOrder":walletList,@"order":itemPayOrder};
    }
    NSMutableDictionary * parameters = [param mutableCopy];

    [Networking postWithParameters:parameters andCmd:@163 success:^(NSDictionary *data) {
       
        NSDictionary * dic = data[DATA];
        success(dic);

    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//线下付款验证支付密码回调
+ (void)qrPayVerifyPasswordWithSerialNumber:(NSString*)serialNumber pwd:(NSString*)pwd success:(SuccessCallBack)success
{
    NSDictionary * param = @{SERIAL_NUMBER:serialNumber,PASSWORD:[[RSA_Encryptor sharedRSA_Encryptor] encryptorString:pwd PublicKeyStr:RSA_PUBLIC_KEY]};

    NSMutableDictionary * parameters = [param mutableCopy];

    [Networking postWithParameters:parameters andCmd:@205 success:^(NSDictionary *data) {
       
        NSDictionary * dic = data[DATA];
        success(dic);

    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//获取账单列表
+ (void)getAccountOrderListWithPage:(NSNumber*)page pageSize:(NSNumber*)pageSize type:(NSNumber*)type year:(NSString*)year success:(SuccessCallBack)success failure:(FailureCallBack)failure
{
    
    NSString * beginDate = [NSString stringWithFormat:@"%@0101",year];
    NSString * endDate = [NSString stringWithFormat:@"%@1231",year];
    
    NSDictionary * param = @{ITEM_ID:@(-1), PAGE:page,PAGE_SIZ:pageSize,TRANS_TYPE:type,BEGIN_DATE:beginDate,END_DATE:endDate};

    NSMutableDictionary * parameters = [param mutableCopy];

    [Networking postWithParameters:parameters andCmd:@146 success:^(NSDictionary *data) {
       
        NSDictionary * dic = data[DATA];
        success(dic);
        
    } failure:^(NSError *error) {
        
        failure(error);
        
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}


//获取多笔订单
+ (void)getPayOrderWithSerialNumbers:(NSArray<NSString*>*)serialNumbers isPayInfo:(BOOL)isPayInfo isSAAS:(BOOL)isSAAS success:(SuccessCallBack)success
{
    NSDictionary * param = @{SERIAL_NUMBER:serialNumbers,IS_PAY_INFO:[NSNumber numberWithBool:isPayInfo]};

    NSMutableDictionary * parameters = [param mutableCopy];

    //新206
    NSNumber * cmd;
    
    if(isSAAS)
    {
        cmd = @209;
    }else{
        cmd = @206;
    }
    
    [Networking postWithParameters:parameters andCmd:cmd success:^(NSDictionary *data) {
       
        NSDictionary * dic = data[DATA];
        success(dic);
        
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//第三方支付下单;
+ (void)thirdPayWithSerialNumbers:(NSArray<NSString*>*)serialNumbers payType:(NSInteger)payType accountFundingType:(NSString*)accountFundingType items:(NSArray*)items rpItems:(NSArray*)rpItems isSAAS:(BOOL)isSAAS success:(SuccessCallBack)success failure:(FailureCallBack)failure
{
    
    NSString * sendType;
    if(!accountFundingType)
    {
        sendType = [SharedInstance getInstance].userInfo.defaultFundingType;
    }else{
        sendType = accountFundingType;
    }
    
    NSDictionary * param = @{SERIAL_NUMBER:serialNumbers,PAY_TYPE:@(payType),ACCOUNT_FUNDING_TYPE:sendType,ITEMS:items,METHOD:@(0)};

    NSMutableDictionary * parameters = [param mutableCopy];
    
    if(rpItems && rpItems.count > 0)
    {
        [parameters setObject:rpItems forKey:RP_ITEMS];
    }
    
    NSNumber * cmd;
    
    if(isSAAS)
    {
        cmd = @208;
    }else{
        cmd = @207;
    }
    
    [Networking postWithParameters:parameters andCmd:cmd success:^(NSDictionary *data) {
       
        NSDictionary * dic = data[DATA];
        success(dic);
        
    } failure:^(NSError *error) {
        failure(error);
    }];
}

//密码支付
+ (void)defaultPayWithSerialNumbers:(NSArray<NSString*>*)serialNumbers password:(NSString*)password accountFundingType:(NSString*)accountFundingType items:(NSArray*)items rpItems:(NSArray*)rpItems isSAAS:(BOOL)isSAAS success:(SuccessCallBack)success failure:(FailureCallBack)failure
{
    
    NSMutableDictionary * parameters = [NSMutableDictionary dictionary];
    
    [parameters setObject:serialNumbers forKey:SERIAL_NUMBER];
    if(password)
    {
        [parameters setObject:[[RSA_Encryptor sharedRSA_Encryptor] encryptorString:password PublicKeyStr:RSA_PUBLIC_KEY] forKey:PAY_PASSWORD];
    }
    
    if(!isSAAS)
    {
        [parameters setObject:accountFundingType forKey:ACCOUNT_FUNDING_TYPE];
        
        [parameters setObject:items forKey:ITEMS];
        if(rpItems && rpItems.count > 0)
        {
            [parameters setObject:rpItems forKey:RP_ITEMS];
        }
    }
   

    NSNumber * cmd;
    if(isSAAS)
    {
        cmd = @210;
    }else{
        cmd = @301;
    }
    [Networking postWithParameters:parameters andCmd:cmd success:^(NSDictionary *data) {
       
        NSDictionary * dic = data[DATA];
        success(dic);
        
    } failure:^(NSError *error) {
        
        
        
        failure(error);
        
    }];
}

//获取账户详情
+ (void)getBillDetailWithOrderNo:(NSString*)orderNo success:(SuccessCallBack)success
{
    NSDictionary * param = @{ORDER_NO:orderNo};

    NSMutableDictionary * parameters = [param mutableCopy];

    [Networking postWithParameters:parameters andCmd:@164 success:^(NSDictionary *data) {
       
        NSDictionary * dic = data[DATA];
        success(dic);
        
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//获取saas商品集
+ (void)getMerchandiseWithPageNum:(NSNumber*)pageNum pageSize:(NSNumber*)pageSize keyword:(NSString*)keyword zoneId:(NSString*)zoneId selectionCodes:(NSString*)selectionCodes success:(SuccessCallBack)success failure:(FailureCallBack)failure

{
    [[SharedInstance getInstance].hideLoadingDataSource addObject:@531];
    
    NSMutableDictionary * parameters = [NSMutableDictionary dictionary];
    
    //[parameters setObject:@"/platform/product/v2/open/selection/products" forKey:PATH];
    [parameters setObject:pageNum forKey:PAGE_NUM];
    [parameters setObject:pageSize forKey:PAGE_SIZ];
    if(keyword && keyword.length > 0)
    {
        [parameters setObject:keyword forKey:KEY_WORD];
    }
    
    if([zoneId isEqualToString:NUMBER_EQUITIES] == NO)
    {
        [parameters setObject:@"/platform/product/v2/open/selection/products" forKey:PATH];
        [parameters setObject:zoneId forKey:ZONE_CODES];
    }else{
        [parameters setObject:@"/platform/local/life/v1/h5/product/page" forKey:PATH];
    }
    [parameters setObject:selectionCodes forKey:SELECTION_CODES];
    
    [Networking postWithParameters:parameters andCmd:@531 success:^(NSDictionary *data) {
       
        NSDictionary * dic = data[DATA];
        success(dic);
        
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        failure(error);
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//查询可用余额
+ (void)getCanUseAmountItemsWithOrderNo:(NSArray*)orderNos success:(SuccessCallBack)success
{
    
    [[SharedInstance getInstance].hideLoadingDataSource addObject:@219];
    NSDictionary * param = @{SERIAL_NUMBER:orderNos};

    NSMutableDictionary * parameters = [param mutableCopy];

    [Networking postWithParameters:parameters andCmd:@219 success:^(NSDictionary *data) {
       
        NSDictionary * dic = data[DATA];
        success(dic);
        
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}


//搜索查询;
- (void)getSearchWithKeyword:(NSString*)keyword page:(NSNumber*)page pageSize:(NSNumber*)pageSize success:(SuccessCallBack)success

{
    [[SharedInstance getInstance].hideLoadingDataSource addObject:@531];
    
    NSMutableDictionary * parameters = [NSMutableDictionary dictionary];
    
    [parameters setObject:@"/platform/product/h5/search/products" forKey:PATH];
    [parameters setObject:page forKey:PAGE_NUM];
    [parameters setObject:pageSize forKey:PAGE_SIZ];
    [parameters setObject:keyword forKey:KEY_WORD];

    
    [Networking postWithParameters:parameters andCmd:@531 success:^(NSDictionary *data) {
       
        NSDictionary * dic = data[DATA];
        success(dic);
        
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}


//获取用户商品集
+ (void)getUserSectionCodes:(SuccessCallBack)success
{
    
    [[SharedInstance getInstance].hideLoadingDataSource addObject:@533];
    
    NSDictionary * param = @{};

    NSMutableDictionary * parameters = [param mutableCopy];

    [Networking postWithParameters:parameters andCmd:@533 success:^(NSDictionary *data) {
       
        NSDictionary * dic = data[DATA];
        success(dic);
        
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//获取SAAS所有URL
+ (void)getewayAllHTMLURL:(SuccessCallBack)success
{
    [[SharedInstance getInstance].hideLoadingDataSource addObject:@531];
    NSString * path = @"/api/platform/config";
    
    NSDictionary * param = @{PATH:path};

    NSMutableDictionary * parameters = [param mutableCopy];

    [Networking postWithParameters:parameters andCmd:@531 success:^(NSDictionary *data) {
       
        NSDictionary * dic = data[DATA];
        success(dic);
        
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//获取订单状态以及URL

+ (void)getH5OrderURLListCount:(SuccessCallBack)success
{
//    NSString * path = @"/api/platform/config";
    
    [[SharedInstance getInstance].hideLoadingDataSource addObject:@532];
    
    NSDictionary * param = @{};

    NSMutableDictionary * parameters = [param mutableCopy];

    [Networking postWithParameters:parameters andCmd:@532 success:^(NSDictionary *data) {
       
        NSDictionary * dic = data[DATA];
        success(dic);
        
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//查询订单状态;
+ (void)getOrderStatusWithSerialNumbers:(NSArray*)serialNumber success:(SuccessCallBack)success
{
    NSDictionary * param = @{SERIAL_NUMBER:serialNumber};

    NSMutableDictionary * parameters = [param mutableCopy];

    [Networking postWithParameters:parameters andCmd:@165 success:^(NSDictionary *data) {
       
        NSDictionary * dic = data[DATA];
        success(dic);
        
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

+ (void)getAppUnit
{
    NSDictionary * param = @{};

    [[SharedInstance getInstance].hideLoadingDataSource addObject:@107];
    NSMutableDictionary * parameters = [param mutableCopy];

    [Networking postWithParameters:parameters andCmd:@107 success:^(NSDictionary *data) {
       
        NSDictionary * dic = data[DATA];
    
        [SharedInstance getInstance].uint = dic[USER_FUND_UNIT];
        
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//领取优惠券;
+ (void)receiveCouponWithActivityID:(NSNumber*)activityID templateId:(NSNumber*)templateId templateCode:(NSString*)templateCode success:(SuccessCallBack)success
{
    NSDictionary * param = @{ACTIVITY_ID:activityID,TEMPLATE_ID:templateId,TEMPLATE_CODE:templateCode};
    
    NSMutableDictionary * parameters = [param mutableCopy];

    [Networking postWithParameters:parameters andCmd:@251 success:^(NSDictionary *data) {
       
        NSDictionary * dic = data[DATA];
    
        success(dic);
        
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//查询优惠券领取状态;
+ (void)getReceiveCouponStatsWithActivityID:(NSNumber*)activityID couponTemplateCodes:(NSArray*)couponTemplateCodes success:(SuccessCallBack)success
{
    NSDictionary * param = @{ACTIVITY_ID:activityID,COUPON_TEMPLATE_CODES:couponTemplateCodes};
    
    NSMutableDictionary * parameters = [param mutableCopy];

    [Networking postWithParameters:parameters andCmd:@253 success:^(NSDictionary *data) {
       
        NSDictionary * dic = data[DATA];
    
        success(dic);
        
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//获取我的券列表;
+ (void)getMyCouponsWithState:(NSNumber*)state page:(NSNumber*)page pageSize:(NSNumber*)pageSize success:(SuccessCallBack)success failure:(FailureCallBack)failure
{
    NSDictionary * param = @{STATE:state,PAGE:page,PAGE_SIZ:pageSize};

    NSMutableDictionary * parameters = [param mutableCopy];

    [Networking postWithParameters:parameters andCmd:@252 success:^(NSDictionary *data) {
       
        NSDictionary * dic = data[DATA];
    
        success(dic);
        
    } failure:^(NSError *error) {
        
        
        failure(error);
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//获取提货券列表; //默认itemID传0， 默认key不传; 
+ (void)getPickupCardWithPage:(NSNumber*)page pageSize:(NSNumber*)pageSize itemID:(NSNumber*)itemID key:(NSString*)key success:(SuccessCallBack)success failure:(FailureCallBack)failure
{
    NSDictionary * param;
    
    if(key)
    {
        param = @{ITEM_ID:itemID,PAGE:page,PAGE_SIZ:pageSize,KEY:key};
    }else{
        param = @{ITEM_ID:itemID,PAGE:page,PAGE_SIZ:pageSize};
    }

    NSMutableDictionary * parameters = [param mutableCopy];

    [Networking postWithParameters:parameters andCmd:@149 success:^(NSDictionary *data) {
       
        NSDictionary * dic = data[DATA];
    
        success(dic);
        
    } failure:^(NSError *error) {
        
        
        failure(error);
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//绑定提货券;
+ (void)bindPickupCardWithCardNO:(NSString*)cardNO cardPWD:(NSString*)cardPWD equityIssueInfo:(NSDictionary*)equityIssueInfo success:(SuccessCallBack)success
{
    NSDictionary * param = @{CARD_NO:cardNO,CARD_PWD:[[RSA_Encryptor sharedRSA_Encryptor] encryptorString:cardPWD PublicKeyStr:RSA_PUBLIC_KEY]};
    
    NSMutableDictionary * parameters = [param mutableCopy];
    
    if(equityIssueInfo)
    {
        [parameters setObject:equityIssueInfo forKey:@"equityIssueInfo"];
    }

    [Networking postWithParameters:parameters andCmd:@148 success:^(NSDictionary *data) {
       
        NSDictionary * dic = data[DATA];
    
        success(dic);
        
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}


//修改卡密码;
+ (void)modifyPickupCardPWDWithCardNO:(NSString*)cardNO oldPassword:(NSString*)oldPassword newPassword:(NSString*)newPassword verifycationCode:(NSString*)verifycationCode success:(SuccessCallBack)success
{
    NSDictionary * param = @{CARD_NO:cardNO,OLDPASSWORD:[[RSA_Encryptor sharedRSA_Encryptor] encryptorString:oldPassword PublicKeyStr:RSA_PUBLIC_KEY],NEWPASSWORD:[[RSA_Encryptor sharedRSA_Encryptor] encryptorString:newPassword PublicKeyStr:RSA_PUBLIC_KEY],@"verifycationCode":verifycationCode};
    
    NSMutableDictionary * parameters = [param mutableCopy];

    [Networking postWithParameters:parameters andCmd:@154 success:^(NSDictionary *data) {
       
        NSDictionary * dic = data[DATA];
    
        success(dic);
        
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//获取分类列表;
+ (void)getSortDataWithPageID:(NSNumber*)pageID  success:(SuccessCallBack)success
{
    NSDictionary * param = @{PAGE_ID:pageID};
    
    NSMutableDictionary * parameters = [param mutableCopy];

    [Networking postWithParameters:parameters andCmd:@404 success:^(NSDictionary *data) {
       
        NSDictionary * dic = data[DATA];
        
        success(dic);
        
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}


//自定义页面;
+ (void)customURLWithURL:(NSString*)URL success:(SuccessCallBack)success
{
    [Networking getWithURLString:URL parameters:@{} success:^(NSDictionary *data) {
        success(data);
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}


//充值
+ (void)userAccountChargeWithItemID:(NSNumber*)itemID amount:(NSNumber*)amount payType:(NSNumber*)payType success:(SuccessCallBack)success
{
    NSDictionary * param = @{ITEM_ID:itemID,AMOUNT:amount,PAY_TYPE:payType,@"method":@0};
    
    NSMutableDictionary * parameters = [param mutableCopy];

    [Networking postWithParameters:parameters andCmd:@212 success:^(NSDictionary *data) {
       
        NSDictionary * dic = data[DATA];
        
        success(dic);
        
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }
    }];
}
//获取权益列表;
+ (void)getEquityWithState:(NSNumber*)state page:(NSNumber*)page pageSize:(NSNumber*)pageSize success:(SuccessCallBack)success failure:(FailureCallBack)failure
{
    NSDictionary * param = @{STATE:state,PAGE:page,PAGE_SIZ:pageSize};
    NSMutableDictionary * parameters = [param mutableCopy];
    [Networking postWithParameters:parameters andCmd:@254 success:^(NSDictionary *data) {
        NSDictionary * dic = data[DATA];
        
        success(dic);
    } failure:^(NSError *error) {
        failure(error);
    }];
}

+ (void)getPayStyleWithAccountFundingType:(NSString*)accountFundingType success:(SuccessCallBack)success
{
    NSDictionary * param = @{@"accountType":accountFundingType};
    NSMutableDictionary * parameters = [param mutableCopy];
    [Networking postWithParameters:parameters andCmd:@213 success:^(NSDictionary *data) {
       
        success(data);
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//1-随机、2-不随机 随机展示的个数,isRand=1时有效
+ (void)getFlashAdveriseWithAdids:(NSArray*)adIds isRand:(NSNumber*)isRand randNumToShow:(NSNumber*)randNumToShow success:(SuccessCallBack)success
{
    NSDictionary * param = @{@"isRand":isRand,@"randNumToShow":randNumToShow};
    
    
    NSMutableDictionary * parameters = [param mutableCopy];
    
    if(adIds != nil)
    {
        [parameters setValue:adIds forKey:@"adIds"];
    }
    
    [Networking postWithParameters:parameters andCmd:@108 success:^(NSDictionary *data) {
       

        success(data);
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//获取首页shopSetURL

+ (void)getHomeH5URLWithRedirectType:(NSString*)redirectType homePageDTO:(NSDictionary*)homePageDTO success:(SuccessCallBack)success
{
    NSDictionary * param = @{@"redirectType":redirectType,@"homePageDTO":homePageDTO};
    
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [Networking postWithParameters:parameters andCmd:@405 success:^(NSDictionary *data) {
       
        success(data);
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
    
}

//获取搜索条件;
+ (void)getFilterConditionWithCityName:(NSString*)cityName blackWhiteIdList:(NSArray*)blackWhiteIdList success:(SuccessCallBack)success
{
    NSDictionary * param;
    
    if(blackWhiteIdList)
    {
        param = @{@"cityName":cityName,BLACK_WHITE_ID_LIST:blackWhiteIdList};
    }else{
        param = @{@"cityName":cityName};
    }
    
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [Networking postWithParameters:parameters andCmd:@407 success:^(NSDictionary *data) {
       
        success(data);
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//获取商户列表; //resId页码，第二页要把返回值传给他
+ (void)getMerchantListWithItems:(NSArray<NSString*>*)items word:(NSString*)word isCutWord:(BOOL)isCutWord Lng:(NSNumber*)Lng Lat:(NSNumber*)Lat resId:(NSString*)resId page:(NSNumber*)page pageSize:(NSNumber*)pageSize areaIndex:(NSString*)areaIndex merchantIndex:(NSString*)merchantIndex sortType:(NSString*)sortType blackWhiteId:(NSNumber*)blackWhiteId brandIndex:(NSString*)brandIndex blackWhiteIdList:(NSArray*)blackWhiteIdList brandIndexList:(NSArray*)brandIndexList success:(SuccessCallBack)success failure:(FailureCallBack)failure
{
    
    NSNumber * whiteListId = blackWhiteId;
    if(!whiteListId)
    {
        whiteListId = @0;
    }
    NSDictionary * param = @{@"isCutWord":@(isCutWord),@"Lng":Lng,@"Lat":Lat,@"resId":resId,@"page":page,@"pageSize":pageSize};

    NSMutableDictionary * parameters = [param mutableCopy];
    
    if(items && items.count > 0)
    {
        [parameters setValue:items forKey:@"ItemIds"];
    }
    if(word && word.length > 0)
    {
        [parameters setValue:word forKey:@"word"];
    }
    if(areaIndex && areaIndex.length)
    {
        [parameters setValue:areaIndex forKey:SEARCH_AREA_INDEX];
    }
    if(merchantIndex && merchantIndex.length > 0)
    {
        [parameters setValue:merchantIndex forKey:MERCHANT_TYPE_INDEX];
    }
    if(sortType && sortType.length > 0)
    {
        [parameters setValue:sortType forKey:SORT_TYPE_INDEX];
    }
    if(blackWhiteIdList && blackWhiteIdList.count > 0)
    {
        [parameters setValue:blackWhiteIdList forKey:BLACK_WHITE_ID_LIST];
    }
    if(brandIndexList && brandIndexList.count > 0)
    {
        [parameters setValue:brandIndexList forKey:BRAND_INDEX_LIST];
    }
    if(whiteListId.integerValue > 0)
    {
        [parameters setValue:whiteListId forKey:BLACK_WHITE_ID];
    }
    
    if(brandIndex.length > 0)
    {
        [parameters setValue:brandIndex forKey:BRAND_INDEX];
    }
    
    [Networking postWithParameters:parameters andCmd:@406 success:^(NSDictionary *data) {
       
        success(data);
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        failure(error);
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}


//408-获取商户详细信息
+ (void)getMerchantDetailWithMerchantId:(NSNumber*)merchantId items:(NSArray*)items success:(SuccessCallBack)success
{
    NSDictionary * param = @{MERCHANT_ID:merchantId,ITEMS:items};
    
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [Networking postWithParameters:parameters andCmd:@408 success:^(NSDictionary *data) {
       
        NSDictionary * dic = data[DATA];
        success(dic);
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//商户问题反馈;
+ (void)setMerchantQuestionBackWithMerhcantId:(NSNumber*)merchantId content:(NSString*)content success:(SuccessCallBack)success
{
    NSDictionary * param = @{MERCHANT_ID:merchantId,CONTENT:content};
    
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [Networking postWithParameters:parameters andCmd:@411 success:^(NSDictionary *data) {
       
        NSDictionary * dic = data[DATA];
        success(dic);
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//获取问题反馈列表问题
+ (void)getMerchantQuestionBackListWithMerhcantId:(NSNumber*)merchantId success:(SuccessCallBack)success
{
    NSDictionary * param = @{MERCHANT_ID:merchantId};
    
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [Networking postWithParameters:parameters andCmd:@410 success:^(NSDictionary *data) {
       
        NSDictionary * dic = data[DATA];
        success(dic);
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//识别卡号
+ (void)getCardWithImageBase64:(NSString*)base64 success:(SuccessCallBack)success
{
    NSDictionary * param = @{IMG:base64};
    
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [Networking postWithParameters:parameters andCmd:@109 success:^(NSDictionary *data) {
       
        NSDictionary * dic = data[DATA];
        success(dic);
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

//红包余额
+ (void)getUserRedEnvelop:(SuccessCallBack)success{

    NSDictionary * param = @{};
    
    NSMutableDictionary * parameters = [param mutableCopy];
    
    [Networking postWithParameters:parameters andCmd:@490 success:^(NSDictionary *data) {
        NSDictionary * dic = data[DATA];
        success(dic);
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}


//红包记录
+ (void)getUserRedEnvelopRecordListWithPage:(NSNumber*)page pageSize:(NSNumber*)pageSize success:(SuccessCallBack)success failure:(FailureCallBack)failure
{
    NSDictionary * param = @{PAGE:page,@"size":pageSize};
    NSMutableDictionary * parameters = [param mutableCopy];
    [Networking postWithParameters:parameters andCmd:@491 success:^(NSDictionary *data) {
        NSDictionary * dic = data[DATA];
        success(dic);
    } failure:^(NSError *error) {
        failure(error);
    }];
}

//通过卡号查询是否需要报备信息;
+ (void)getCheckUserInformtionWithCardNumber:(NSString*)cardNo success:(SuccessCallBack)success
{
    NSDictionary * param = @{CARD_NO:cardNo};
    NSMutableDictionary * parameters = [param mutableCopy];
    [Networking postWithParameters:parameters andCmd:@166 success:^(NSDictionary *data) {
        NSDictionary * dic = data[DATA];
        success(dic);
    } failure:^(NSError *error) {
        NSString * msg = error.userInfo[MSG];
        if(msg)
        {
            [Utils showToast:msg];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}
@end
