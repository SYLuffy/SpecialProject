//
//  RSA_Encryptor.h
//  HLGA
//
//  Created by 葛亮 on 2018/7/16.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <Foundation/Foundation.h>

//#define RSA_PUBLIC_KEY  @"MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC2IUXzxYudB9+AeVZRoGaRaCkUEpIGAi7pMfDv98/akGoDZXt8LOeGQDLQrXxn78YLPlrC2lBUKuDAOtdkacGZidQwzOeS8IgdU2caN0dq9IFGlZb9Ud+ryIXgyj+mfQB5Df0vsm/DGA7j6vFxqbNfv/To0Dhd0375lb5aj7yr/QIDAQAB"
//#define RSA_PRIVATE_KEY  @"MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBALYhRfPFi50H34B5VlGgZpFoKRQSkgYCLukx8O/3z9qQagNle3ws54ZAMtCtfGfvxgs+WsLaUFQq4MA612RpwZmJ1DDM55LwiB1TZxo3R2r0gUaVlv1R36vIheDKP6Z9AHkN/S+yb8MYDuPq8XGps1+/9OjQOF3TfvmVvlqPvKv9AgMBAAECgYAScoBRVprzhs6ehqu1jNeWtsQiYlckAKibuhE7XRBShPoX6fl99FZnBK2g8VF+fYzDqscqoU4tmEI3dj5Gz2dqaALz1d1m0H9z8MJyP+/oSDTDlwAq4KHhZYj38Gy0xjGxlpRRoDdWNm4hG3Ysvpx5rmINpB8HJqjbSedn5OSXiQJBAOCKf1BiE0oOGY1H7wzo3vxEEYuH5uxclOxew4nE22CrxAK8RqxywxvFp10GHzxsUO+xSx0i6da6Bgs6HMQH6KsCQQDPpaPhNS2pyHDUdA05P+rCl50FmDt3TN1XoGKxm1+1a1CvZLEBUsD6WDfJuVUsXN/2JWEk+0Gh6G8ToUAs3433AkEAg1zjUN6f1FJdZocv9kiCs+kKrqvKUHt1cLecBAyUH4E9wi/t1NOrC6Nd35FGUu43h5Mck6YqUcIw6P6Nd6380wJAByHOVi7oaZt73KA70AqU+qgQeZ+38yoNtDPLEAShLe8Ir22K8tuvyyl6iRA3j7WE78Rq6MVEhNYh8o+oT6JCEwJBALkEV98syyoQLVfSdxBY5P0dAXy7lQNgJ1enYMlxThD7HxHLN4z7wqfGUvb7V/wHYTc1jxpxKz2WzCJ10TnHBUk="


#define RSA_PUBLIC_KEY  @"MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDFxpfVhq5p3xMUV5+T9DLe78U5x04nsR9UljRqqToGstlNk8HolpO4WWM0LD5ot9WAoWGPvWUgMXNqYOOE0qCfNzOBbaNghUnJN5EWU4rhugBhhP9357Ksw77C5ySco/BZf+wgWvAFil9vvz5l5f/KRHfFBztJT+0XuDrb9A0l/QIDAQAB"


#define RSA_PRIVATE_KEY  @"MIICXQIBAAKBgQDFxpfVhq5p3xMUV5+T9DLe78U5x04nsR9UljRqqToGstlNk8HolpO4WWM0LD5ot9WAoWGPvWUgMXNqYOOE0qCfNzOBbaNghUnJN5EWU4rhugBhhP9357Ksw77C5ySco/BZf+wgWvAFil9vvz5l5f/KRHfFBztJT+0XuDrb9A0l/QIDAQABAoGBAMG+d3VEt82dKyqtX/VnrwH4LuQYG7cEa6XIc1bdqqtvPzMhAT9haxqX7nfos8aP+EZHUbSnG866ws6+VYQDdjZnUOOSDreetbT1ntIORl0OY6DuXcg2qSoD2o9z7hYF3/8FMGoBngxgrYvLzlQpLykIyAvItP9x7/dBcHkrwpfhAkEA+nJxxvMDFEfBzPJX9BDfXJEZ+GiitVQvGDh7IBj5uxTsmTZWE3DmtYKh+OCeEAPzyNJbE+codMEl07bcCsr9eQJBAMopLr3f/R0/6npiKszPwS7EOjgUaoOXrjq8iGN98QpV/i0cfKGKouPMxrg45YZK8MXNCgZWefLW9YL7p0bPP6UCQEHmrXO5bF0AyMlCF8y8R9oWwGuyNOZcAYxxCE0Y5VXKGrvyJVI2Si8G8dIIYO876wE0AQ1KrUWTsX11R497fJkCQAreCeA1IUMoQ2+OxWQ7KtRbwhFvr4YhakFID0Dh7Uoz8zTzmhOJA1ahlHEkxdnhP24ypn5OucF/IrWG16grze0CQQDnhZogWMAqQohoESMXKOzUSqYkGLgvVmAz2YFoxoRkxXAUi1dcA/vLtY5iPuczuhlygCPfAxgtlyO87Q/o/jrV"




@interface RSA_Encryptor : NSObject

#pragma mark 初始化对象
+(RSA_Encryptor *)sharedRSA_Encryptor;

#pragma mark - 使用 公钥加密、私钥解密

/**
 *  私钥 加密
 *
 *  @param string       需加密字符串
 *  @param publicKeyStr 公钥
 *
 *  @return 公钥加密 后的字符串
 */
- (NSString *)encryptorString:(NSString *)string PublicKeyStr:(NSString *)publicKeyStr;


/**
 *   私钥证书 加密
 *
 *  @param string 需加密字符串
 *  @param path   公钥证书 文件路径
 *
 *  @return 公钥证书 加密 后的字符串
 */
- (NSString *)encryptorString:(NSString *)string PublicKeyPath:(NSString *)path;


// 解密

/**
 *  私钥 解密
 *
 *  @param string        公钥 加密的字符串（需要加密字符串）
 *  @param privateKeyStr 私钥
 *
 *  @return 解密后字符串
 */
- (NSString *)decryptString:(NSString *)string PrivateKeyStr:(NSString *)privateKeyStr;


/**
 *  私钥证书 解密
 *
 *  @param string       公钥证书 加密的字符串（需要加密字符串）
 *  @param path         私钥证书文件路径
 *  @param p12Passwoerd 私钥证书密码
 *
 *  @return 解密后字符串
 */
- (NSString *)decryptString:(NSString *)string PrivateKeyPath:(NSString *)path PassWord:(NSString *)p12Passwoerd;

#pragma mark - 使用、公钥解密 （注：解密的字符串是使用私钥加密过后的）
- (NSString *)decryptString:(NSString *)string PublicKeyStr:(NSString *)publicKeyStr;

@end
