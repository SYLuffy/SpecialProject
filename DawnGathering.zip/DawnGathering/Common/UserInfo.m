//
//  UserInfo.m
//  HLGA
//
//  Created by Linus on 2018/5/17.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "UserInfo.h"

@implementation UserInfo

- (instancetype)initByDictionary:(NSDictionary*)dic
{
    self = [super init];
    if (self) {
        self.userCategory = @0;

        [self setValuesForKeysWithDictionary:dic];
        
    }
    return self;
}

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    NSLog(@"%@",value);
}


-(NSString *)hiddenPhoneString{
    return [NSString stringWithFormat:@"用户_%@",[self hiddenPhone]];
}

-(NSString *)hiddenPhone{
    if (self.telephone.length >= 11) {
        NSString *phoneFront = [self.telephone substringToIndex:3];
        NSString *phoneBack = [self.telephone substringFromIndex:7];
        return [NSString stringWithFormat:@"%@****%@", phoneFront, phoneBack];
    }
    return self.telephone;
}

- (NSNumber *)totalAmount
{
    NSInteger total = 0;
    for(NSDictionary *dic in self.accountFundingTypes)
    {
        NSArray * userAccounts = dic[USER_ACCOUNTS];
        
        for(NSDictionary * accountDic in userAccounts)
        {
            NSNumber * amount = accountDic[AMOUNT];
            
            total += amount.floatValue;
        }
    }
    
    return [NSNumber numberWithInteger:total];
}

- (NSNumber*)cardCount
{
    NSInteger total = 0;
    for(NSDictionary *dic in self.accountFundingTypes)
    {
        NSArray * userAccounts = dic[USER_ACCOUNTS];
        
        for(NSDictionary * accountDic in userAccounts)
        {
            NSArray * physicalCardNo = accountDic[PHYSICAL_CARD_NO];
            if([Utils checkObjectIsNull:physicalCardNo])
            {
                total += physicalCardNo.count;
            }
            
        }
    }
    
    return [NSNumber numberWithInteger:total];
}

- (NSNumber*)cardAmount
{
    NSInteger total = 0;
    for(NSDictionary *dic in self.accountFundingTypes)
    {
        NSArray * userAccounts = dic[USER_ACCOUNTS];
        
        for(NSDictionary * accountDic in userAccounts)
        {
            NSNumber * amount = accountDic[AMOUNT];
            
            NSNumber * itemMediumType = accountDic[ITEM_MEDIUM_TYPE];
            
            if(itemMediumType.integerValue == 2)
            {
                total += amount.floatValue;
            }
        }
    }
    
    return [NSNumber numberWithInteger:total];
}

- (NSNumber *)normalAmount
{
    NSInteger total = 0;
    for(NSDictionary *dic in self.accountFundingTypes)
    {
        NSArray * userAccounts = dic[USER_ACCOUNTS];
        
        for(NSDictionary * accountDic in userAccounts)
        {
            NSNumber * amount = accountDic[AMOUNT];
            
            NSNumber * itemType = accountDic[ACCOUNT_ITEM_TYPE];
            NSNumber * itemMediumType = accountDic[ITEM_MEDIUM_TYPE];
            
            if(itemType.integerValue == 1 && itemMediumType.integerValue == 1)
            {
                total += amount.floatValue;
            }
        }
    }
    
    return [NSNumber numberWithInteger:total];
}

- (NSNumber *)specialAmount
{
    NSInteger total = 0;
    for(NSDictionary *dic in self.accountFundingTypes)
    {
        NSArray * userAccounts = dic[USER_ACCOUNTS];
        
        for(NSDictionary * accountDic in userAccounts)
        {
            NSNumber * amount = accountDic[AMOUNT];
            
            NSNumber * itemType = accountDic[ACCOUNT_ITEM_TYPE];
            NSNumber * itemMediumType = accountDic[ITEM_MEDIUM_TYPE];
            
            if(itemType.integerValue != 1 && itemMediumType.integerValue == 1)
            {
                total += amount.floatValue;
            }
        }
    }
    
    return [NSNumber numberWithInteger:total];
}

- (NSString *)defaultFundingType
{
    NSString * type = self.accountFundingTypes.firstObject[ACCOUNT_FUNDING_TYPE];
    
    return type;
}

- (NSString *)defaultFundingName{
    
    NSString * type = self.accountFundingTypes.firstObject[ACCOUNT_FUNDING_NAME];
    
    return type;
}



@end
