//
//  StoryBoardID.h
//  HLGA
//
//  Created by Linus on 2018/5/23.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <Foundation/Foundation.h>

static NSString *const SB_ID_MESSAGE = @"MessageVC";

static NSString *const SB_ID_MESSAGE_LIST = @"MessageListVC";

static NSString *const SCAN_PAY_NAV = @"scan_pay_nav";

static NSString *const SB_ID_SCAN_CODE_VC = @"ScanCodeVC";

static NSString *const SB_ID_BONUS_POINTS_VC = @"WPBonusPointsVC";


static NSString *const SB_ID_RECHARGE_PAYMENT_LIST = @"WPRechargePaymentListVC";

static NSString *const SB_CREDIT_CARD = @"CreditCardVC";

static NSString *const SB_CREDIT_CAED_ADS = @"CreditCardAdvertisingVC";

//static NSString *const SB_ID_PHONE_RECHARGE = @"WPPhoneRechargeTVC";

static NSString *const SB_ID_LIVINGPAYMENTLIST = @"WPLivingPaymentListVC";

//static NSString *const SB_ID_CREDIT_CARD_SELECT_BANK = @"CreditCardSelectBankVC";

static NSString *const SB_ID_CREDIT_CARD_CONFIRM_BANK = @"CreditCardBankConfirmVC";


static NSString *const SB_ID_NEW_ACCOUNT = @"WPNewAccountTVC";

static NSString *const SB_ID_PAY_MENT_DETAILS = @"WPPaymentDetailsTVC";

static NSString *const SB_ID_PAY_MENT_UNIT = @"WPPaymentUnitVC";

static NSString *const SB_ID_CONVENIENT_PAY_MENT = @"WPConvenientPaymentVC";

static NSString *const SB_ID_PAY_MENT_PASS_WORD = @"WPPaymentPasswordVC";

static NSString *const SB_ID_PAY_MENT_PASSWORD_RETRIEVE = @"WPPaymentPasswordRetrieveVC";

static NSString *const SB_ID_LOGIN_VC = @"LoginVC";

static NSString *const SB_ID_SCAN_PAY_RESULT_VC = @"ScanPayResultVC";

