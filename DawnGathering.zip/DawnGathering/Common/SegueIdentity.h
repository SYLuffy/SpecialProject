 //
//  SegueIdentity.h
//  HLGA
//
//  Created by Linus on 2018/5/15.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <Foundation/Foundation.h>

static NSString *const PRESENT_LOGIN_TO_FORGET = @"PRESENT_LOGIN_TO_FORGET";

static NSString *const PRESENT_FORGET_TO_RESET = @"PRESENT_FORGET_TO_RESET";

static NSString *const PRESENT_LOGIN_TO_INITSET = @"PRESENT_LOGIN_TO_INITSET";

static NSString *const EMBED_Mine_TVC = @"EMBED_Mine_TVC";

static NSString *const EMBED_ABOUT_US_TVC = @"EMBED_ABOUT_US_TVC";


static NSString *const SHOW_MINE_TO_BONUS = @"SHOW_MINE_TO_BONUS";

static NSString *const SHOW_MINE_TO_SET = @"SHOW_MINE_TO_SET";

static NSString *const SHOW_MINE_TO_ABOUTUS = @"SHOW_MINE_TO_ABOUTUS";

static NSString *const SHOW_MINE_TO_ADDRESS = @"SHOW_MINE_TO_ADDRESS";

static NSString *const SHOW_MINE_TO_ORDERFORM = @"orderForm";

static NSString *const SELECTED_HEXIN = @"selected_hexin";
static NSString *const SELECTED_WECHAT = @"selected_wechat";
static NSString *const SELECTED_ALIPAY = @"selected_alipay";

static NSString *const TABLE_EMBED_SEGUE = @"table_embed_segue";
