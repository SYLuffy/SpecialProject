//
//  ErrorCode.h
//  HLGA
//
//  Created by Linus on 2018/6/22.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <Foundation/Foundation.h>

static NSInteger const ERROR_CODE_PAY_PASSWORD = 80049;//支付密码输入错误

static NSInteger const ERROR_CODE_GET_VERSION = 80051;//获取版本错误

static NSInteger const ERROR_CODE_SID_NOT_LOGIN = 80005;//该sid未登录

static NSInteger const ERROR_CODE_SID_EXPIRE_LOGIN = 82012;//该sid未登录

static NSInteger const ERROR_CODE_NOT_HAVE_ACCOUNT = 80003;//没有这个账号

static NSInteger const ERROR_ACCOUNT_NO_REAL_NAME = 801;//未实名无法操作;

static NSInteger const ERROR_SYSTEM_MAINTENANCE = 999000;//系统维护中;

static NSInteger const ERROR_NOT_LOGIN_GO_TO_LOGIN = 82059;//未登录需要弹出登录界面;
