//
//  StaticUserDefaultKey.h
//  DawnGathering
//
//  Created by 李冬岐 on 2024/3/4.
//

static NSString *const USER_DEFAULT_LATITUDE = @"userDefaultLatitude";

static NSString *const USER_DEFAULT_LONGITUDE = @"userDefaultLongitude";

static NSString *const USER_DEFAULT_CITY = @"userDefaultCity";
