//
//  SharedInstance.h
//  HLGA
//
//  Created by Linus on 2018/5/15.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "UserInfo.h"
#import "ShareView.h"
#import "SaaSURLModel.h"
#import <WXApi.h>
#import <AMapFoundationKit/AMapFoundationKit.h>
#import <AMapLocationKit/AMapLocationKit.h>


typedef void(^InstancelGotoPayWithPassword)(NSString * pwd);

typedef void(^RetryInputPassword)(void);

typedef void (^PaySuccessBack)(NSString * payStatus);//1为成功，0为失败，-1为取消,-2重新输入支付密码 -3需要重新启动

typedef void (^FaceIDBack)(NSString * payStatus);//1为成功，0为失败，-1为取消

typedef void (^AlertBack)(BOOL isConfirm);//是否确认.

typedef void (^CanUseTouchID)(BOOL can);//是否可以使用.

typedef void(^GetUserLocationBack)(NSDictionary * dic);

typedef void(^SelectMapWithTitleBack)(NSString * title);

//result 0 失败 1 成功;
typedef void(^WeChatPayResult)(NSInteger result);

typedef void (^ExitLoginCallback)(void);
static NSString *const SERVICE_LOGIN_PSSWORD = @"ServiceLoginPassword";
static NSString *const FACE_ID_NO = @"face_id_no";//面容支付开关;
static NSString *const FACE_ID_PASSWORD = @"face_id_password";

@interface SharedInstance : NSObject <WXApiDelegate>

+ (instancetype)getInstance;


@property (nonatomic,strong)NSString *sid;
@property (nonatomic,strong)NSString *pushToken;

@property (nonatomic,strong)NSNumber *isRememberPassword;

@property (nonatomic,strong)UserInfo * userInfo;


@property(nonatomic,assign)NSInteger travelFunction;//商旅
@property(nonatomic,assign)NSInteger indexNews;//新闻



@property(nonatomic,assign)NSInteger payPasswordEmpty;//是初始化密码
@property(nonatomic,assign)NSInteger paySwitch;//是否是免密支付

@property(nonatomic,assign)NSInteger payNoPwdAmount;//免密金额;

@property(nonatomic,strong)NSDictionary * scanPayDictionary;

@property(nonatomic,assign)CGFloat userSetScreenBrightness;

@property (nonatomic,assign)BOOL isFromPushGotoMessage;//是否是推送打开的APP

@property(nonatomic,strong)NSMutableArray * hideLoadingDataSource;

@property(nonatomic,assign)BOOL isASDUrlBool;//是否点击广告url

@property(nonatomic,assign)Class forGetClass;//忘记密码返回页面

@property (nonatomic,assign)BOOL isOpenedUnifiedPay;//是否已经打开支付控件

@property (nonatomic,assign)BOOL isOpenMessageVC;//是否已经打开message

@property(nonatomic,strong)NSString *merchantUrl;//全部商户

@property(nonatomic,strong)NSString *videoRecharge;//视频

@property(nonatomic,strong)NSString *coilsExchange;//卡卷

@property(nonatomic,strong)NSString *didiSystemUrl;//滴滴


@property(nonatomic,strong)NSString *updateVersion;//最新版本号（网络获取）
    
@property(nonatomic,strong)NSString  *updateVersionUrl;//版本url

@property(nonatomic,assign)BOOL isHomePerformOne;//只执行一次

@property(nonatomic,strong)NSString *businessTravelUrl;//商旅URL

@property(nonatomic,copy)WeChatPayResult wechatPayResult;//微信支付回调;

@property(nonatomic,assign)BOOL isHiddenNavigationAndStatusBar;

@property(nonatomic,strong)NSDictionary * transTypeMap;

@property(nonatomic,strong)NSDictionary * transTypeState;

@property(nonatomic,strong)NSDictionary * transTypeName;

@property(nonatomic,strong)SaaSURLModel * saasURLModel;

@property(nonatomic,assign)BOOL needUpdateHomePageOnce;
@property(nonatomic,strong)NSString * uint;

@property (nonatomic,assign)BOOL isEnterOpenQrCode;

@property (nonatomic,assign)BOOL isNeedUpdateHomePage;

@property (nonatomic,strong)NSNumber * currentClassifyID;

@property (nonatomic,assign)BOOL alreadySaveTempHomePageData;

@property (nonatomic,assign)BOOL alreadySaveTempBottomListData;

@property (nonatomic,assign)BOOL noInternet;


@property (nonatomic,copy)GetUserLocationBack getUserLocationBack;

@property (nonatomic,assign)CGFloat merchantWebHeight;//商户详情

@property (nonatomic,assign)BOOL isGetedWebHeight;//是否已经获取高度 ；

@property (nonatomic,strong)NSArray * sendBlackWhiteList;//当前需要传的白名单数组;

@property (nonatomic,strong)UIAlertController * netWorkNotConnectVC;


+ (void)exitLogin:(ExitLoginCallback)callback;
+ (void)clearLoginInfo;

+ (void)showPayViewController:(NSDictionary*)dataSource owner:(__kindof UIViewController *)owner payBack:(PaySuccessBack)payStatusBack;

+ (void)loadAuthentication:(FaceIDBack)faceIDBack;

- (void)saveFaceIDByPwd:(NSString*)pwd;

- (void)deleteFaceID;

+ (void)checkHasTouchID:(CanUseTouchID)canUseBack;

+ (void)checkGoToOpenFaceOrTouchID:(NSString*)payPassword;//支付完成后检测

@property (nonatomic,strong)ShareView * shareView;
@property (nonatomic,strong)UIView * shareDarkMask;
@property (nonatomic,strong)NSDictionary * showShareDictionary;

- (void)showShareView;
- (void)wechatByPayInfo:(NSDictionary*)payInfo;

- (void)showNeedRealNameView:(NSString*)contentDesc;

- (void)checkLoginAndGotoLogin:(UIViewController*)vc;

- (void)showPayPopViewWithContent:(NSString*)content amount:(NSNumber*)amount :(InstancelGotoPayWithPassword)gotoPay retryInput:(RetryInputPassword)retryInput;

//微信拉起小程序
- (void)wechantMiniProgramPath:(NSString*)path userName:(NSString*)userName miniProgramType:(WXMiniProgramType)miniProgramType;

//显示调用可地图的导航;
- (void)showNavigateMapActionViewControllerWithViewController:(UIViewController*)vc back:(SelectMapWithTitleBack)back;


@end
