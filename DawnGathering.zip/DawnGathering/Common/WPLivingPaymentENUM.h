//
//  WPLivingPaymentENUM.h
//  HLGA
//  生活缴费类型
//  Created by 葛亮 on 2018/5/25.
//  Copyright © 2018年 Linus. All rights reserved.
//


typedef NS_ENUM(NSUInteger, WPLivingPaymentType) {
    
    WPLivingPaymentTypeElectricity = 1,//电费
    WPLivingPaymentTypeGasCharge = 2,//燃气费
    WPLivingPaymentTypeIphone = 4,//手机充值记录
    WPLivingPaymentTypeConsumption = 6//水费
};



typedef NS_ENUM(NSUInteger,WPJudgeObjType) {
    
    WPJudgeObjTypeDefault = 0,//默认
    WPJudgeObjTypeArray = 1,//数组类型
    WPJudgeObjTypeDict = 2,//字典类型
    WPJudgeObjTypeString = 3//字符串类型

};

typedef NS_ENUM(NSUInteger,WPHomeModulesTyp) {
    
    WPHomeModulesTypList = 1,//商品-列表式
    WPHomeModulesTypCombination = 2,//商品组合式
    WPHomeModulesTypProject = 3,//专题活动
    WPHomeModulesTypBrand = 4//品牌专区
    
};
