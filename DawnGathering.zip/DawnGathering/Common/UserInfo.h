//
//  UserInfo.h
//  HLGA
//
//  Created by Linus on 2018/5/17.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "WPDiscountModel.h"

@interface UserInfo : NSObject

@property(nonatomic,strong)NSString *account;
@property(nonatomic,strong)NSNumber *amount;
@property(nonatomic,strong)NSNumber *asDefaultPassword;
@property(nonatomic,strong)NSString *companyLogo;
@property(nonatomic,strong)NSString *companyName;
@property(nonatomic,strong)NSNumber * companyId;
@property(nonatomic,strong)NSString *sid;
@property(nonatomic,strong)NSString *telephone;
@property(nonatomic,strong)NSNumber *userId;
@property(nonatomic,strong)NSString *userName;
@property(nonatomic,strong)NSNumber *userCategory;
@property(nonatomic,strong)NSNumber *travelFunction;//商旅
@property(nonatomic,strong)NSNumber *indexNews;//新闻
@property(nonatomic,strong)NSNumber *userStatus;
@property(nonatomic,assign)BOOL didiStatus;
@property(nonatomic,strong)NSNumber * realNameState;
@property(nonatomic,strong)NSString * headImg;
@property(nonatomic,strong)NSArray * companyList;

@property (nonatomic,strong) NSString *hiddenPhoneString;
@property (nonatomic,strong)NSString * ygflhAuthUrl;

@property (nonatomic,strong)NSArray<WPDiscountModel *> *scanDiscounts;//可以扫码支付的卡券

@property (nonatomic,strong)NSArray * accountFundingTypes;

@property (nonatomic,strong)NSNumber * totalAmount;

@property (nonatomic,strong)NSNumber * normalAmount;

@property (nonatomic,strong)NSNumber * specialAmount;

@property (nonatomic,strong)NSNumber * cardAmount;//卡总额;

@property (nonatomic,strong)NSNumber * cardCount;//卡数量;

@property (nonatomic,strong)NSString * defaultFundingType;

@property (nonatomic,strong)NSString * defaultFundingName;

@property (nonatomic,strong)NSString * saasToken;

- (instancetype)initByDictionary:(NSDictionary*)dic;

@end
