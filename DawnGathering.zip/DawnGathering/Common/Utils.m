//
//  Utils.m
//  HLGA
//
//  Created by Linus on 2018/5/14.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "Utils.h"
#import <UIImageView+WebCache.h>
#import <MBProgressHUD.h>
#import "ZXingObjC.h"
#import "WPPaymentPasswordVC.h"
#import "OpenJSWebKitController.h"
#import "UIImage+tools.h"
#import "UIDevice+StateHeight.h"


@implementation Utils


#define ARRAY_SIZE(a) sizeof(a)/sizeof(a[0])

const char* jailbreak_tool_pathes[] = {
    "/Applications/Cydia.app",
    "/Library/ MobileSubstrate/MobileSubstrate.dylib",
    "/bin/bash",
    "/usr/sbin/sshd",
    "/etc/apt"
};

+ (BOOL)isJailBreak
{
    for (int i=0; i<ARRAY_SIZE(jailbreak_tool_pathes); i++) {
        if ([[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithUTF8String:jailbreak_tool_pathes[i]]]) {
            NSLog(@"The device is jail broken!");
            return YES;
        }
    }
    NSLog(@"The device is NOT jail broken!");
    return NO;
}


+ (void) alertWithTitle:(NSString *)title msg:(NSString *)msg{
    
    UIAlertController * alertController = [UIAlertController alertControllerWithTitle:title message:msg preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction * confirmAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleCancel handler:nil];
    [alertController addAction:confirmAction];
    
    [[Utils currentWindow].rootViewController presentViewController:alertController animated:true completion:nil];
    
}

+ (void) alertWithTitle:(NSString *)title msg:(NSString *)msg confirm:(ConfirmBack)confirm
{
    UIAlertController * alertController = [UIAlertController alertControllerWithTitle:title message:msg preferredStyle:UIAlertControllerStyleAlert];
                                           
    UIAlertAction * confirmAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        confirm(true);
    }];
    [alertController addAction:confirmAction];
    
  
    [[Utils currentWindow].rootViewController presentViewController:alertController animated:true completion:nil];
}

+ (void)alertWithTitle:(NSString*)title msg:(NSString*)msg andConfirm:(ConfirmBack)confirmBack cancel:(CancelBack)cancel
{
    UIAlertController * alertController = [UIAlertController alertControllerWithTitle:title message:msg preferredStyle:UIAlertControllerStyleAlert];
                                           
    UIAlertAction * cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        cancel();
    }];
    UIAlertAction * confirmAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        confirmBack(true);
    }];
    
    [alertController addAction:cancelAction];
    [alertController addAction:confirmAction];

    
    [[Utils currentWindow].rootViewController presentViewController:alertController animated:true completion:nil];
}

+ (void)showToast:(NSString*)msg{
    

    MBProgressHUD * hud = [MBProgressHUD showHUDAddedTo:[Utils currentWindow] animated:YES];
    
    hud.detailsLabel.text = msg;
    
    hud.detailsLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size:14];
    
    hud.mode = MBProgressHUDModeText;
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [hud hideAnimated:YES];
    });
    
}


+ (void)gradualChangeBottomToTopColor:(CALayer*)layer withStartColor:(int64_t)startColor withEndColor:(int64_t)endColor{
    
    CAGradientLayer * gradientLayer = [[CAGradientLayer alloc]init];
    gradientLayer.frame = CGRectMake(0, 0, layer.frame.size.width, layer.frame.size.height);
    
    gradientLayer.colors = @[(__bridge id)UIColorFromRGB(startColor).CGColor,(__bridge id)UIColorFromRGB(endColor).CGColor];
    
    gradientLayer.startPoint = CGPointMake(0.5, 1);
    gradientLayer.endPoint = CGPointMake(0.5, 0);
    
    [layer insertSublayer:gradientLayer atIndex:0];
    
    
    layer.masksToBounds = true;
}

+ (void)gradualChangeLeftToRightColor:(CALayer*)layer withStartColor:(int64_t)startColor withEndColor:(int64_t)endColor{
    
    CAGradientLayer * gradientLayer = [[CAGradientLayer alloc]init];
    gradientLayer.frame = CGRectMake(0, 0, layer.frame.size.width, layer.frame.size.height);
    
    gradientLayer.colors = @[(__bridge id)UIColorFromRGB(startColor).CGColor,(__bridge id)UIColorFromRGB(endColor).CGColor];
    
    gradientLayer.startPoint = CGPointMake(0, 1);
    gradientLayer.endPoint = CGPointMake(1, 1);
    
    [layer insertSublayer:gradientLayer atIndex:0];
    
    layer.masksToBounds = true;
    
}

+ (void)gradualButtonLeftToRightColor:(CALayer*)layer withStartColor:(int64_t)startColor withEndColor:(int64_t)endColor{
    
    CAGradientLayer * gradientLayer = [[CAGradientLayer alloc]init];
    gradientLayer.frame = CGRectMake(0, 0, SCREEN_WIDTH - 60, layer.frame.size.height);
    
    gradientLayer.colors = @[(__bridge id)UIColorFromRGB(startColor).CGColor,(__bridge id)UIColorFromRGB(endColor).CGColor];
    
    gradientLayer.startPoint = CGPointMake(0, 1);
    gradientLayer.endPoint = CGPointMake(1, 1);
    
    [layer insertSublayer:gradientLayer atIndex:0];
    
    layer.masksToBounds = true;
    
}

+ (BOOL)getPayHasSpecialPoints{
    return false;
}

+ (NSNumber*)getGlobalPageSize{
    return @20;
}


+ (NSString*)getBaseUrl
{
    if(isProduction == true)
    {
        return @"https://bc-gateway-api.ygfuli.com/api/";
    }else{
        return @"http://192.168.2.201:8071/api/";
    }
    
}


+ (NSString*)getHost{
    if(isProduction == true)
    {
        return @"https://bc-gateway-api.ygfuli.com/";
    }else{
        return @"http://192.168.2.201:8071/";
    }
}


+ (NSString*)getNOCardPayHost{
    if(isProduction == true)
    {
        return @"182.131.1.180";
    }else{
        return @"192.168.2.201";
    }
}

+ (long)getNOCardPort{
    
    if(isProduction)
    {
        return 10060;
    }
    return 18888;
}

+ (void)setUserDefaultByKey:(NSString*)key andValue:(id)value
{
    [[NSUserDefaults standardUserDefaults] setObject:value forKey:key];
    [[NSUserDefaults standardUserDefaults]  synchronize];
}

+ (id)getUserDefaultByKey:(NSString*)key
{
    return [[NSUserDefaults standardUserDefaults] objectForKey:key];
}

+ (BOOL)accountTextRule:(UITextField*)textField
{
    if(textField.text.length < 1)
    {
        return false;
    }
    
    if(textField.text.length > 111)
    {
        textField.text = [textField.text substringToIndex:textField.text.length - 1];
    }
    
    
    return true;
}


+(BOOL)accountNumberTextRule:(UITextField *)textField{
    
    return  textField.text.length >= 1 ? true : false;
    
}

+ (BOOL)passwordTextRule:(UITextField*)textField
{
    if(textField.text.length < 1)
    {
        return false;
    }
    
    if(textField.text.length > 30)
    {
        textField.text = [textField.text substringToIndex:textField.text.length - 1];
    }
    
    return true;
}

+ (BOOL)passwordPayTextRule:(UITextField*)textField
{
    return  textField.text.length == 6 ? true : false;
}

+ (BOOL)securityCodeTextRule:(UITextField*)textField
{
    if(textField.text.length < 4)
    {
        return false;
    }
    if(textField.text.length > 4)
    {
        textField.text = [textField.text substringToIndex:textField.text.length - 1];
    }
    
    return true;
    
}

+ (NSString*)dictionaryToJson:(NSDictionary *)dic
{
    NSError *parseError = nil;
    
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:&parseError];
    
    NSString * json = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    
    return json;
    
}

+ (NSDictionary*)loadJsonWithFileName:(NSString*)fileName
{
    NSString *filePath = [[NSBundle mainBundle] pathForResource:fileName ofType:@"json"];
   
    //根据文件路径读取数据
    NSData *data = [[NSData alloc] initWithContentsOfFile:filePath];
    
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
    
    return dic;
    
}


+ (NSDictionary *)dictionaryWithJsonString:(NSString *)jsonString {
    
    if (jsonString == nil) {
        
        return nil;
        
    }
    
    NSData *jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    
    NSError *err;
    
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData
                         
                                                        options:NSJSONReadingMutableContainers
                         
                                                          error:&err];
    
    if(err) {
        
        NSLog(@"json解析失败：%@",err);
        
        return nil;
        
    }
    
    return dic;
    
}

/**
 *  @author Linus, 18-5-16 22:20:51
 *
 *  设置密码（添加密码、修改密码）
 *
 *  @param password    密码
 *  @param serviceName 服务名称
 *
 *  @return 是否设置成功
 */
+ (BOOL) setPassword:(NSString *)password forService:(NSString *)serviceName{
    NSMutableDictionary *keyChainDic = [[NSMutableDictionary alloc] init];
    //[keyChainDic setObject:account forKey:(__bridge id)kSecAttrAccount];//账户
    [keyChainDic setObject:serviceName forKey:(__bridge id)kSecAttrService];//服务名
    [keyChainDic setObject:(__bridge id)kSecClassGenericPassword forKey:(__bridge id)kSecClass];//类型
    [keyChainDic setObject:[password dataUsingEncoding:NSUTF8StringEncoding] forKey:(__bridge id)kSecValueData];//密码数据
    [keyChainDic setObject:(__bridge id)kCFBooleanTrue forKey:(__bridge id)kSecReturnAttributes];//返回数据键值对
    [keyChainDic setObject:(__bridge id)kCFBooleanTrue forKey:(__bridge id)kSecReturnData];//返回Data
    
    CFMutableDictionaryRef outDictionary = nil;
    OSStatus keychainErr = SecItemCopyMatching((__bridge CFDictionaryRef)keyChainDic,(CFTypeRef *)&outDictionary);
    
    BOOL resultState = NO;
    if (keychainErr == noErr) {
        NSMutableDictionary *returnDictionary = [NSMutableDictionary dictionaryWithDictionary:(__bridge_transfer NSMutableDictionary *)outDictionary];
        [returnDictionary setObject:(__bridge id)kSecClassGenericPassword forKey:(__bridge id)kSecClass];
        
        [keyChainDic removeObjectForKey:(__bridge id)kSecAttrAccount];
        [keyChainDic removeObjectForKey:(__bridge id)kSecAttrService];
        [keyChainDic removeObjectForKey:(__bridge id)kSecClass];
        [keyChainDic removeObjectForKey:(__bridge id)kSecReturnAttributes];
        [keyChainDic removeObjectForKey:(__bridge id)kSecReturnData];
        OSStatus errorCode = SecItemUpdate((__bridge CFDictionaryRef)returnDictionary, (__bridge CFDictionaryRef)keyChainDic);
        
        if (errorCode == noErr) {
            resultState = YES;
        }else{
            resultState = NO;
        }
    }else if (keychainErr == errSecItemNotFound) {
        //添加
        OSStatus errorCode = SecItemAdd((__bridge CFDictionaryRef)keyChainDic,NULL);
        
        if (errorCode == noErr) {
            resultState = YES;
        }else{
            resultState = NO;
        }
    }
    return resultState;
}

/**
 *  @author Linus, 18-05-16 22:21:38
 *
 *  获取密码
 *
 *  @param serviceName 服务名称
 *
 *  @return 密码
 */
+ (NSString *) passwordForService:(NSString *)serviceName
{
    NSMutableDictionary *keyChainDic = [[NSMutableDictionary alloc] init];
    [keyChainDic setObject:serviceName forKey:(__bridge id)kSecAttrService];
    [keyChainDic setObject:(__bridge id)kSecClassGenericPassword forKey:(__bridge id)kSecClass];
    [keyChainDic setObject:(__bridge id)kCFBooleanTrue forKey:(__bridge id)kSecReturnData];
    
    CFDataRef passwordData = NULL;
    OSStatus keychainError = noErr;
    keychainError = SecItemCopyMatching((__bridge CFDictionaryRef)keyChainDic,(CFTypeRef *)&passwordData);
    
    NSString *pwdStr = nil;
    if (keychainError == noErr){
        NSString *passwordString = [[NSString alloc] initWithBytes:[(__bridge_transfer NSData *)passwordData bytes]
                                                            length:[(__bridge NSData *)passwordData length] encoding:NSUTF8StringEncoding];
        NSLog(@"%@",passwordString);
        pwdStr = passwordString;
    }else if (keychainError == errSecItemNotFound) {
        pwdStr = nil;
    }
    
    return pwdStr;
}

/**
 *  @author Linus, 18-05-16 22:22:10
 *
 *  删除密码
 *
 *  @param serviceName 服务名称
 *
 *  @return 是否删除成功状态
 */
+ (BOOL) deletePasswordForService:(NSString *)serviceName{
    NSMutableDictionary *keyChainDic = [[NSMutableDictionary alloc] init];
//    [keyChainDic setObject:account forKey:(__bridge id)kSecAttrAccount];
    [keyChainDic setObject:serviceName forKey:(__bridge id)kSecAttrService];
    [keyChainDic setObject:(__bridge id)kSecClassGenericPassword forKey:(__bridge id)kSecClass];
    [keyChainDic setObject:(__bridge id)kCFBooleanTrue forKey:(__bridge id)kSecReturnAttributes];
    
    CFMutableDictionaryRef outDictionary = nil;
    
    OSStatus keychainError = SecItemCopyMatching((__bridge CFDictionaryRef)keyChainDic,(CFTypeRef *)&outDictionary);
    BOOL resultState = NO;
    
    if (keychainError == noErr){
        NSString *pwd = [Utils passwordForService:serviceName];//YMKeyChain 调用的上面的方法
        
        [keyChainDic setObject:[pwd dataUsingEncoding:NSUTF8StringEncoding] forKey:(__bridge id)kSecValueData];
        
        OSStatus keychainError =  SecItemDelete((__bridge CFDictionaryRef)keyChainDic);//密码正确才能删除成功
        if (keychainError == noErr){
            resultState = YES;
        }else{
            resultState = NO;
        }
    }
    
    return resultState;
}


+ (void)securityButtonCountDown:(UIButton*)securityCodeButton{
    __block int timeout= 60; //倒计时时间
    
    __block NSAttributedString * oldText = [securityCodeButton.titleLabel.attributedText mutableCopy];
    
    __block UIColor * oldTextColor = securityCodeButton.titleLabel.textColor;
    
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_source_t _timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0,queue);
    dispatch_source_set_timer(_timer,dispatch_walltime(NULL, 0),1.0*NSEC_PER_SEC, 0); //每秒执行
    dispatch_source_set_event_handler(_timer, ^{
        if(timeout<=0){ //倒计时结束，关闭
            dispatch_source_cancel(_timer);
            dispatch_async(dispatch_get_main_queue(), ^{
                
                [securityCodeButton setTitleColor:oldTextColor forState:UIControlStateNormal];
                
                if(oldText)
                {
                    securityCodeButton.titleLabel.attributedText = oldText;
                }
                
                [securityCodeButton setTitle:@"重新发送" forState:UIControlStateNormal];
                securityCodeButton.userInteractionEnabled = YES;
            });
        }else{
            dispatch_async(dispatch_get_main_queue(), ^{
                
                NSInteger length =  securityCodeButton.titleLabel.text.length;
                
                NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:securityCodeButton.titleLabel.text];
                
                [attributedString addAttribute:NSUnderlineStyleAttributeName value:@{} range:NSMakeRange(0, length)];
                [attributedString addAttribute:NSStrikethroughColorAttributeName value:UIColorFromRGB(0x999999) range:NSMakeRange(0, length)];
                
                securityCodeButton.titleLabel.attributedText = attributedString;
                
                [securityCodeButton setTitleColor:UIColorFromRGB(0x999999) forState:UIControlStateNormal];
                
                [securityCodeButton setTitle:[NSString stringWithFormat:@"%ds",timeout] forState:UIControlStateNormal];
                securityCodeButton.userInteractionEnabled = NO;
            });
            timeout--;
        }
    });
    dispatch_resume(_timer);
    
}

+ (void)dissmissToViewController:(Class)toClass andCurrentVC:(UIViewController*)currentVC
{
    UIViewController *vc =currentVC.presentingViewController;
    
    while (![vc isKindOfClass:toClass]) {
        vc = vc.presentingViewController;
    }
    
    [vc dismissViewControllerAnimated:YES completion:nil];
}

/**
 改变label文字中某段文字的颜色，大小
 label 传入label（传入前要有文字）
 oneW  从第一个文字开始
 twoW  到最后一个文字结束
 color 颜色
 size 尺寸
 */
+ (void)labelColorAttributedString:(UILabel*)label andRange:(NSRange)range color:(UIColor *)color size:(CGFloat)size{
    // 创建Attributed
    NSMutableAttributedString *noteStr = [[NSMutableAttributedString alloc] initWithString:label.text];
    
    // 改变颜色
    [noteStr addAttribute:NSForegroundColorAttributeName value:color range:range];
    // 改变字体大小及类型
    [noteStr addAttribute:NSFontAttributeName value:[UIFont fontWithName:label.font.fontName size:size] range:range];
    // 为label添加Attributed
    [label setAttributedText:noteStr];
}

+ (void)labelColorAttributedStripingString:(UILabel*)label andRange:(NSRange)range color:(UIColor *)color size:(CGFloat)size{
    // 创建Attributed
    NSMutableAttributedString *noteStr = [[NSMutableAttributedString alloc] initWithString:label.text];
    //划横线
    [noteStr addAttribute:NSStrikethroughStyleAttributeName value:@(NSUnderlinePatternSolid | NSUnderlineStyleSingle) range:range];
    
    // 改变颜色
    [noteStr addAttribute:NSForegroundColorAttributeName value:color range:range];
    // 改变字体大小及类型
    [noteStr addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:size] range:range];
    
    if(range.location > 0)
    {
        [noteStr addAttribute:NSFontAttributeName value:label.font range:NSMakeRange(0, range.location)];
    }
    
    // 为label添加Attributed
    [label setAttributedText:noteStr];
}

+ (void)labelColorAttributedStripingString:(UILabel*)label andRange:(NSRange)range color:(UIColor *)color size:(CGFloat)size hasUint:(BOOL)hasUint{
    // 创建Attributed
    NSMutableAttributedString *noteStr = [[NSMutableAttributedString alloc] initWithString:label.text];
    //划横线
    [noteStr addAttribute:NSStrikethroughStyleAttributeName value:@(NSUnderlinePatternSolid | NSUnderlineStyleSingle) range:range];
    
    // 改变颜色
    [noteStr addAttribute:NSForegroundColorAttributeName value:color range:range];
    // 改变字体大小及类型
    [noteStr addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:size] range:range];
    
    if(range.location > 0)
    {
         
        if(hasUint)
        {
            [noteStr addAttribute:NSFontAttributeName value:[UIFont fontWithName:label.font.fontName size:label.font.pointSize - 4] range:NSMakeRange(range.location - 2, 1)];
            [noteStr addAttribute:NSFontAttributeName value:label.font range:NSMakeRange(0, range.location - 2)];
        }else{
            [noteStr addAttribute:NSFontAttributeName value:label.font range:NSMakeRange(0, range.location)];
        }
    }
    
    // 为label添加Attributed
    [label setAttributedText:noteStr];
}

+ (__kindof UIViewController *)getViewControllerByStoryBoardName:(NSString*)storyBoardName andIdentifier:(NSString*)identifier{
    
    UIStoryboard * storyboard = [UIStoryboard storyboardWithName:storyBoardName bundle:nil];
    UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:identifier];
    
    return vc;
}

+ (UIViewController*)getInitViewControllerByStoryBoardName:(NSString*)storyBoardName
{
    UIStoryboard * storyboard = [UIStoryboard storyboardWithName:storyBoardName bundle:nil];
    UIViewController * vc = [storyboard instantiateInitialViewController];
    return vc;
}

+ (CGFloat)getNavigationBarAndStatusBarHeight:(UIViewController*)vc{
    
    CGFloat navigationHeight = [Utils getNavigationBarHeight:vc];
    
    return [Utils getStatusBarHeight:vc] + navigationHeight;
    
}

+ (CGFloat)getNavigationBarHeight:(UIViewController*)vc{
    CGRect rectOfNavigationbar = vc.navigationController.navigationBar.frame;
    return rectOfNavigationbar.size.height;
}

+ (CGFloat)getStatusBarHeight:(UIViewController*)vc{
   
    return [UIDevice dev_statusBarHeight];
}

+ (void)setHomeIndexCustomNavigationBar:(UIViewController*)vc
{
    [SharedInstance getInstance].isHiddenNavigationAndStatusBar = true;
    
    
    [vc.navigationController.navigationBar setBackgroundImage:[UIImage new] forBarMetrics:UIBarMetricsDefault];
    vc.navigationController.navigationBar.shadowImage = [UIImage new];

    [vc.navigationController.navigationBar setTranslucent:true];
}

+ (void)setNavigationBarBackgroundWithColor:(UIColor*)color titleColor:(UIColor*)titleColor vc:(UIViewController*)vc
{
    [SharedInstance getInstance].isHiddenNavigationAndStatusBar = false;
    [vc.navigationController.navigationBar setTranslucent:false];
    if (@available(iOS 13.0, *)) {
        UINavigationBarAppearance * appearance = [[UINavigationBarAppearance alloc]init];
        
        appearance.backgroundColor = color;
        UIColor *color = [UIColor clearColor];
        UIImage *image =  [UIImage imageWithColor:color size:CGSizeMake( 1, 1.0 / [UIScreen mainScreen].scale)];
        appearance.shadowImage =  image;
        appearance.shadowColor = nil;
        
        [appearance setTitleTextAttributes:@{NSForegroundColorAttributeName:titleColor}];
        
        vc.navigationController.navigationBar.standardAppearance = appearance;
        vc.navigationController.navigationBar.scrollEdgeAppearance = appearance;
        
    } else {
        // Fallback on earlier versions
        vc.navigationController.navigationBar.tintColor = color;
        NSDictionary *dic = @{NSForegroundColorAttributeName: titleColor};
        vc.navigationController.navigationBar.titleTextAttributes =dic;
    }
}

+ (void)setClearNavigationBar:(UIViewController*)vc titleColor:(UIColor*)titleColor
{
    [SharedInstance getInstance].isHiddenNavigationAndStatusBar = true;
    [vc.navigationController.navigationBar setTranslucent:true];
    
    if (@available(iOS 13.0, *)) {
        UINavigationBarAppearance * appearance = [[UINavigationBarAppearance alloc]init];
        
        appearance.backgroundColor = [UIColor clearColor];
        appearance.backgroundEffect = nil;
        appearance.shadowColor = nil;
        
        [appearance setTitleTextAttributes:@{NSForegroundColorAttributeName: titleColor}];
        
        vc.navigationController.navigationBar.standardAppearance = appearance;
        vc.navigationController.navigationBar.scrollEdgeAppearance = appearance;
        
        
        
    } else {
        // Fallback on earlier versions
        vc.navigationController.navigationBar.tintColor = titleColor;
        NSDictionary *dic = @{NSForegroundColorAttributeName: titleColor};
        vc.navigationController.navigationBar.titleTextAttributes = dic;
        
    }
    //vc.navigationController.navigationBar.userInteractionEnabled = false;
}

+ (void)setDefaultNavigationBar:(UIViewController*)vc
{
    [SharedInstance getInstance].isHiddenNavigationAndStatusBar = false;
    [vc.navigationController.navigationBar setTranslucent:false];
    if (@available(iOS 13.0, *)) {
        UINavigationBarAppearance * appearance = [[UINavigationBarAppearance alloc]init];
        
        appearance.backgroundColor = [UIColor whiteColor];
        UIColor *color = UIColorFromRGB(0xdedede);
        UIImage *image =  [UIImage imageWithColor:color size:CGSizeMake( 1, 1.0 / [UIScreen mainScreen].scale)];
        appearance.shadowImage =  image;
        appearance.shadowColor = nil;
        
        [appearance setTitleTextAttributes:@{NSForegroundColorAttributeName: [UIColor blackColor]}];
        
        vc.navigationController.navigationBar.standardAppearance = appearance;
        vc.navigationController.navigationBar.scrollEdgeAppearance = appearance;
        
    } else {
        // Fallback on earlier versions
        vc.navigationController.navigationBar.tintColor = [UIColor whiteColor];
        NSDictionary *dic = @{NSForegroundColorAttributeName: [UIColor blackColor]};
        vc.navigationController.navigationBar.titleTextAttributes =dic;
    }
}

+ (UIImage*)imageFromLayer:(CALayer*)layer
{
    UIGraphicsBeginImageContext(layer.frame.size);
    
    [layer renderInContext:UIGraphicsGetCurrentContext()];
    
    UIImage * outputImage = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    return outputImage;
}

+ (NSString*)getGlobalFontName{
    return DEFAULT_FONT_NAME;
}

+ (void)loadImage:(UIImageView*)imageView andURL:(NSString*)imageURL isLoadRepeat:(BOOL)repeat
{
    if([imageURL rangeOfString:@"https:"].location == NSNotFound && [imageURL rangeOfString:@"http:"].location == NSNotFound && imageURL.length > 0)
    {
        imageView.image = [UIImage imageNamed:@"placeholder_image"];
        return;
    }
    
    SDWebImageOptions option;
    if(repeat)
    {
        option = SDWebImageRefreshCached;
    }else{
        option = SDWebImageRetryFailed;
    }
    //option = SDWebImageRetryFailed;
    
    
    [imageView sd_setImageWithURL:[NSURL URLWithString:imageURL] placeholderImage:[UIImage imageNamed:@"placeholder_image"] options:option completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        
        if(error != nil)
        {
            NSLog(@"%@",error);
        }

//        imageView.alpha = 0.0;
//        [UIView animateWithDuration:0.3
//                         animations:^{
//                             imageView.alpha = 1.0;
//                         }];
    }];
}

+ (void)loadHomeItemCompanyLogo:(NSString*)url imageView:(UIImageView*)imageView
{
    [imageView sd_setImageWithURL:[NSURL URLWithString:url] placeholderImage:nil options:SDWebImageRetryFailed completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        
        UIImage * fixedImage =  [Utils OriginImage:image scaleToSize:CGSizeMake(30, 30)];
        imageView.image = fixedImage;
    }];
}

+ (UIImage*) OriginImage:(UIImage *)image scaleToSize:(CGSize)size

{
    
    UIGraphicsBeginImageContextWithOptions(size, YES, [UIScreen mainScreen].scale); //size 为CGSize类型，即你所需要的图片尺寸
    
    
    [image drawInRect:CGRectMake(0, 0, size.width, size.height)];
    
    
    
    UIImage* scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    
    
    
    UIGraphicsEndImageContext();
    
    
    
    return scaledImage;   //返回的就是已经改变的图片
    
}


+(void)pushWebViewControllerURL:(NSString *)url owner:(UIViewController *)owner{

    if(!url) return;
    OpenJSWebKitController * webVC = [[OpenJSWebKitController alloc]init];
    
    NSString * delEmptyURL = [url stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    NSString * encodingURL;
    
    if([Utils validateContainsChinese:delEmptyURL])
    {
        encodingURL = [delEmptyURL stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
    }else{
        encodingURL = delEmptyURL;
    }
    
    webVC.goUrl = encodingURL;
//    webVC.fromClass = [owner class];
    [owner.navigationController pushViewController:webVC animated:true];
}

+ (NSString*)getDateByTime:(NSString*)time fomatter:(NSString*)fomatter
{
    NSInteger timer = time.integerValue;
    
    NSDate * date = [NSDate dateWithTimeIntervalSince1970:timer];
    
    NSDateFormatter *yearFomatter = [[NSDateFormatter alloc] init];
    [yearFomatter setDateFormat:fomatter];
    yearFomatter.locale = [NSLocale localeWithLocaleIdentifier:@"zh_CN"];
    NSString * timeString = [NSString stringWithFormat:@"%@",[yearFomatter stringFromDate:date]];
    
    return timeString;
}

+ (NSString*)getSimpleDateByTime:(NSString*)time andHasYear:(BOOL)hasYear
{
    NSInteger timer = time.integerValue;
    
    NSDate * date = [NSDate dateWithTimeIntervalSince1970:timer];
    
    NSDateFormatter *yearFomatter = [[NSDateFormatter alloc] init] ;
    if(hasYear)
    {
        [yearFomatter setDateFormat:@"yyyy-MM-dd"];
    }else{
         [yearFomatter setDateFormat:@"MM-dd HH:mm"];
    }
    NSString * timeString = [NSString stringWithFormat:@"%@",[yearFomatter stringFromDate:date]];
    
    return timeString;
}

+ (NSString*)getComplexDateByTime:(NSString*)time
{
    NSInteger timer = time.integerValue;
    
    NSDate * date = [NSDate dateWithTimeIntervalSince1970:timer];
    
    NSDateFormatter *yearFomatter = [[NSDateFormatter alloc] init] ;
    [yearFomatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    
    NSString * timeString = [NSString stringWithFormat:@"%@",[yearFomatter stringFromDate:date]];
    
    return timeString;
}

+ (NSString*)getBonusPointsDateByTime:(NSString*)time
{
    NSInteger timer = time.integerValue;
    
    NSDate * date = [NSDate dateWithTimeIntervalSince1970:timer];
    
    NSDateFormatter *yearFomatter = [[NSDateFormatter alloc] init] ;
    [yearFomatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    
    NSString * timeString = [NSString stringWithFormat:@"%@",[yearFomatter stringFromDate:date]];
    
    return timeString;
}

+ (NSString*)getRechargePaymentDateByTime:(NSString*)time
{
    NSInteger timer = time.integerValue;
    
    NSDate * date = [NSDate dateWithTimeIntervalSince1970:timer];
    
    NSDateFormatter *yearFomatter = [[NSDateFormatter alloc] init] ;
    [yearFomatter setDateFormat:@"MM月dd日"];
    
    NSString * timeString = [NSString stringWithFormat:@"%@",[yearFomatter stringFromDate:date]];
    
    return timeString;
}

//添加下划线;
+ (NSMutableAttributedString*)attributeStringUnderLine:(NSString*)string color:(UIColor*)color{
    NSUInteger length = [string length];
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:string];
    
    [attributedString addAttribute:NSUnderlineStyleAttributeName value:@(NSUnderlineStyleSingle) range:NSMakeRange(0, length)];
    [attributedString addAttribute:NSStrikethroughColorAttributeName value:color range:NSMakeRange(0, length)];
    
    return attributedString;
}

+ (UIImage *) getImage:(NSInteger)imgtype setData:(NSString *)datas setWidth:(int)width setHeight:(int)height{
    
    UIImage  *returnImage = nil;
    NSError *error = nil;
    
    if(datas == nil || datas.length < 1)
    {
        return nil;
    }
    
    ZXMultiFormatWriter *writer = [[ZXMultiFormatWriter alloc]init];
    ZXBarcodeFormat format = kBarcodeFormatITF;
    
    
    
    if (imgtype == 1) {
        format = kBarcodeFormatCode128; //kBarcodeFormatITF;
    }else if(imgtype == 2){
        format = kBarcodeFormatQRCode;
    }
    
    ZXBitMatrix* result = [writer encode:datas
                                  format:format
                                   width:width
                                  height:height
                                   error:&error];
    
    if (result) {
        
        CGImageRef image = [[ZXImage imageWithMatrix:result] cgimage];

        returnImage = [[UIImage alloc] initWithCGImage:image];
        
        //CGImageRelease(image);
        
        return returnImage;
        
    }else{
        NSString *errorMessage = [error localizedDescription];
        
        NSLog(@"%@",errorMessage);
    }
    return returnImage;
}

+ (CGSize)getTextSizeByFont:(UIFont*)font andMaxSize:(CGSize)maxSize andText:(NSString*)text
{
    CGRect rect = [text boundingRectWithSize:maxSize options:NSStringDrawingUsesFontLeading|NSStringDrawingTruncatesLastVisibleLine|NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName : font} context:nil];
    
    return rect.size;
}


/**
 *  返回高度
 */
+(CGFloat)caculateHeightBen:(NSString *)title font:(NSInteger)font size:(CGSize)size{

    CGFloat index                         = 0;
    NSDictionary *attributes ;
    if ([UIDevice currentDevice].systemVersion.floatValue >= 9.0f){
        attributes = @{NSFontAttributeName: [UIFont fontWithName:@"PingFangSC-Regular" size:font]};
    }else{
        attributes = @{NSFontAttributeName: [UIFont systemFontOfSize:font]};
    }

    

    NSStringDrawingOptions options =
    NSStringDrawingTruncatesLastVisibleLine |
    NSStringDrawingUsesFontLeading |
    NSStringDrawingUsesLineFragmentOrigin;
    
    
    CGRect rect                             = [title boundingRectWithSize:size
                                                                  options:options
                                                               attributes:attributes                                                         context:NULL];
    index                                   += rect.size.height;
    
    return index+1;
}

/**
 ** lineView:       需要绘制成虚线的view
 ** lineLength:     虚线的宽度
 ** lineSpacing:    虚线的间距
 ** lineColor:      虚线的颜色
 **/
+ (void)drawDashLine:(UIView *)lineView lineLength:(int)lineLength lineSpacing:(int)lineSpacing lineColor:(UIColor *)lineColor
{
    CAShapeLayer *shapeLayer = [CAShapeLayer layer];
    [shapeLayer setBounds:lineView.bounds];
    [shapeLayer setPosition:CGPointMake(CGRectGetWidth(lineView.frame) / 2, CGRectGetHeight(lineView.frame))];
    [shapeLayer setFillColor:[UIColor clearColor].CGColor];
    //  设置虚线颜色为blackColor
    [shapeLayer setStrokeColor:lineColor.CGColor];
    //  设置虚线宽度
    [shapeLayer setLineWidth:CGRectGetHeight(lineView.frame)];
    [shapeLayer setLineJoin:kCALineJoinRound];
    //  设置线宽，线间距
    [shapeLayer setLineDashPattern:[NSArray arrayWithObjects:[NSNumber numberWithInt:lineLength], [NSNumber numberWithInt:lineSpacing], nil]];
    //  设置路径
    CGMutablePathRef path = CGPathCreateMutable();
    CGPathMoveToPoint(path, NULL, 0, 0);
    CGPathAddLineToPoint(path, NULL,CGRectGetWidth(lineView.frame), 0);
    [shapeLayer setPath:path];
    CGPathRelease(path);
    //  把绘制好的虚线添加上来
    [lineView.layer addSublayer:shapeLayer];
}

//获取当前屏幕显示的viewcontroller
+ (UIViewController *)getCurrentVC
{
    UIViewController *rootViewController = [Utils currentWindow].rootViewController;
    
    UIViewController *currentVC = [Utils getCurrentVCFrom:rootViewController];
    
    return currentVC;
}

+ (UIViewController *)getCurrentVCFrom:(UIViewController *)rootVC
{
    UIViewController *currentVC;
    
    if ([rootVC presentedViewController]) {
        // 视图是被presented出来的
        
        rootVC = [rootVC presentedViewController];
    }
    
    if ([rootVC isKindOfClass:[UITabBarController class]]) {
        // 根视图为UITabBarController
        
        currentVC = [self getCurrentVCFrom:[(UITabBarController *)rootVC selectedViewController]];
        
    } else if ([rootVC isKindOfClass:[UINavigationController class]]){
        // 根视图为UINavigationController
        
        currentVC = [self getCurrentVCFrom:[(UINavigationController *)rootVC visibleViewController]];
        
    } else {
        // 根视图为非导航类
        
        currentVC = rootVC;
    }
    
    return currentVC;
}

+ (BOOL)checkObjectIsNull:(id)object
{
    if([object isKindOfClass:[NSNull class]] || object == nil)
    {
        return false;
    }
    
    return true;
}

+(BOOL)checkJudgeKey:(NSString *)key Dict:(NSDictionary *)dict{
    
    if(![dict objectForKey:key]){
        return NO;
    }
    
    id obj = [dict objectForKey:key];
    
    return ![obj isEqual:[NSNull null]];
    
}

+(WPJudgeObjType)checkJudgeObjType:(id)resultObj{
    
    
    if(![Utils checkJudgeObjType:resultObj]){
        return WPJudgeObjTypeDict;
    }
    
    
    if( [resultObj isKindOfClass:[NSArray class]])
    {
        return WPJudgeObjTypeArray;
        
    }else if( [resultObj isKindOfClass:[NSDictionary class]]){
        
        return WPJudgeObjTypeDict;
        
    }else if( [resultObj isKindOfClass:[NSString class]]){
        
        return WPJudgeObjTypeString;
    }else{
        
        return WPJudgeObjTypeDict;
    }
    
}


/**
 返回指定VC

 @param target 目标VC
 @param owner 当前VC
 */
+(void) popToViewController:(Class )target owner:(__kindof UIViewController *)owner{
    
    for(UIViewController * vc in owner.navigationController.viewControllers)
    {
        if([vc isKindOfClass:target])
        {
            [owner.navigationController popToViewController:vc animated:YES];
            break;
        }
    }
    
    
}

+(BOOL)pushPaymentPasswordOwner:(__kindof UIViewController *)owner{

    WPPaymentPasswordVC *vc = [Utils getViewControllerByStoryBoardName:SB_NAME_ME andIdentifier:SB_ID_PAY_MENT_PASS_WORD];
    if( [SharedInstance getInstance].payPasswordEmpty == 0){
        vc.ppType = WPPaymentPasswordTypeInitPassword;
        [owner.navigationController pushViewController:vc animated:YES];
        return NO;
    }else{
        return YES;
    }
}
+ (BOOL)iPhoneFiveCheck
{
    if(SCREEN_WIDTH < 375)
    {
        //判断屏幕宽度获取设备
        return true;
    }
    return false;
}

+ (void)clearAppBadge
{
    NSInteger badge = [UIApplication sharedApplication].applicationIconBadgeNumber;
    if (badge>0) {
        //如果应用程序消息通知标记数（即小红圈中的数字）大于0，清除标记。
        badge = 0;
        //清除标记。清除小红圈中数字，小红圈中数字为0，小红圈才会消除。
        [UIApplication sharedApplication].applicationIconBadgeNumber = badge;
    }
}

//七鱼
+ (void)setQiYuInfo
{
    NSString * userId = [NSString stringWithFormat:@"%zd",[SharedInstance getInstance].userInfo.userId.integerValue];
    NSString * realName = [SharedInstance getInstance].userInfo.userName;
    NSString * mobilePhone = [SharedInstance getInstance].userInfo.telephone;
    NSString * avatarUrl = [SharedInstance getInstance].userInfo.headImg;
    
    
    [[QYSDK sharedSDK] customUIConfig].customerHeadImageUrl = avatarUrl;
    

    
    QYUserInfo *userInfo = [[QYUserInfo alloc] init];
    
    
    userInfo.userId = userId;
    
    NSMutableArray *array = [NSMutableArray new];
    NSMutableDictionary *dictRealName = [NSMutableDictionary new];
    [dictRealName setObject:@"real_name" forKey:@"key"];
    [dictRealName setObject:realName forKey:@"value"];
    [array addObject:dictRealName];
    NSMutableDictionary *dictMobilePhone = [NSMutableDictionary new];
    [dictMobilePhone setObject:@"mobile_phone" forKey:@"key"];
    [dictMobilePhone setObject:mobilePhone forKey:@"value"];
    [array addObject:dictMobilePhone];
    
    NSMutableDictionary *dictAvatar = [NSMutableDictionary new];
    [dictAvatar setObject:@"avatar" forKey:@"key"];
    [dictAvatar setObject:avatarUrl forKey:@"value"];
    [array addObject:dictAvatar];
    
    NSData *data = [NSJSONSerialization dataWithJSONObject:array
                                                   options:0
                                                     error:nil];
    
    
    
    
    
    if (data)
    {
        userInfo.data = [[NSString alloc] initWithData:data
                                              encoding:NSUTF8StringEncoding];
    }
    
    [[QYSDK sharedSDK] setUserInfo:userInfo];
   
}

+(NSString *)returnBankCard:(NSString *)bankCardStr
{
    NSMutableString *cardNumberStr= [[NSMutableString alloc]initWithString:bankCardStr];

    if(bankCardStr.length > 4){
        [cardNumberStr insertString:@" " atIndex:4];
    }
    if (bankCardStr.length > 8){
          [cardNumberStr insertString:@" " atIndex:9];
    }
    if (bankCardStr.length > 12){
        [cardNumberStr insertString:@" " atIndex:14];
    }
    if (bankCardStr.length > 16){
        [cardNumberStr insertString:@" " atIndex:19];
    }
    if (bankCardStr.length > 20){
        [cardNumberStr insertString:@" " atIndex:24];
    }
    if (bankCardStr.length > 24){
        [cardNumberStr insertString:@" " atIndex:29];
    }
    if (bankCardStr.length > 28){
        [cardNumberStr insertString:@" " atIndex:34];
    }
    return cardNumberStr;
}

+ (BOOL)getProduction
{
    return isProduction;
}

+ (UIView*)getXibByName:(NSString*)xibName{
    NSArray *objs = [[NSBundle mainBundle]loadNibNamed:xibName owner:nil options:nil];
    UIView *xibView = objs.firstObject;
    return xibView;
}

+ (NSData *) imageCompress:(UIImage *)sourceImage{
    
    NSData * zipImageData = UIImageJPEGRepresentation(sourceImage, 1.0);
    NSInteger originalImgSize = zipImageData.length/1024;  //获取图片大小
    if (originalImgSize>1500) {
        
        zipImageData = UIImageJPEGRepresentation(sourceImage,0.2);
        
    }else if (originalImgSize>600) {
        
        zipImageData = UIImageJPEGRepresentation(sourceImage,0.4);
    }else if (originalImgSize>400) {
        
        zipImageData = UIImageJPEGRepresentation(sourceImage,0.6);
        
    }else if (originalImgSize>300) {
        
        zipImageData = UIImageJPEGRepresentation(sourceImage,0.7);
    }else if (originalImgSize>200) {
        
        zipImageData = UIImageJPEGRepresentation(sourceImage,0.8);
    }
    
    return zipImageData;
}


#pragma mark - 拼接成中间有空格的字符串
+ (NSString *)jointWithString:(NSString *)str num:(NSInteger)num
{
    NSString *getString = @"";
    
    if(str.length < num)
    {
        return str;
    }
    
    int a = (int)str.length/num;
    int b = (int)str.length%num;
    int c = a;
    if (b>0)
    {
        c = a+1;
    }
    else
    {
        c = a;
    }
    for (int i = 0 ; i<c; i++)
    {
        NSString *string = @"";
        
        if (i == (c-1))
        {
            if (b>0)
            {
                string = [str substringWithRange:NSMakeRange(num*(c-1), b)];
            }
            else
            {
                string = [str substringWithRange:NSMakeRange(num*i, num)];
            }
            
        }
        else
        {
            string = [str substringWithRange:NSMakeRange(num*i, num)];
        }
        getString = [NSString stringWithFormat:@"%@ %@",getString,string];
    }
    return getString;
}

+ (BOOL)getPayHasSpecialPoints:(NSDictionary*)orderDic{
    
    NSNumber * specialAmount = orderDic[@"specialAmount"];
    if(specialAmount.integerValue > 0)
    {
        return true;
    }
    return false;
}

+ (void)refreshPayPasswordStatus:(RefreshPayPasswordStatus)completed
{

    [ServiceManager getPayPasswordStateSuccess:^(NSDictionary *data) {
        NSInteger payPasswordEmpty = [data[DATA][PAY_PASSWORD_EMPTY]integerValue];
        [SharedInstance getInstance].payPasswordEmpty = payPasswordEmpty;
        NSInteger paySwitch = [data[DATA][PAY_SWITCH]integerValue];
        [SharedInstance getInstance].paySwitch = paySwitch;
        
        NSNumber * paySwitchAmount = data[DATA][PAY_SWITCH_AMOUNT];
        
        [SharedInstance getInstance].payNoPwdAmount = paySwitchAmount.integerValue;
        
        completed(true);
    }];
}

+ (void)refreshUserInfo:(RefreshUserInfo)completed
{
    //判断自动登录
    NSString *sid = [Utils getUserDefaultByKey:SID];
    if (sid.length != 0) {
        [ServiceManager getUserInformationBySid:sid successBack:^(NSDictionary *data) {
            NSDictionary * result = data[DATA];
            
            UserInfo * userInfo = [[UserInfo alloc] initByDictionary:result];
            [BuglyManager setPhoneNum:userInfo.telephone];
            [SharedInstance getInstance].userInfo = userInfo;
            [SharedInstance getInstance].sid = userInfo.sid;
            [Utils setUserDefaultByKey:SID andValue:userInfo.sid];
            
            
            completed(true);
           
        } failure:^(NSError *error) {
            completed(true);
        }];
    }else{
        completed(true);
    }
}

+ (BOOL)validateContainsChinese:(NSString *)content

{
    // ^[\u4e00-\u9fa5] 以中文开头 的字符串

    // [\u4e00-\u9fa5] 包含中文

    NSRegularExpression *regularexpression = [[NSRegularExpression alloc]

    initWithPattern:@"[\u4e00-\u9fa5]"

    options:NSRegularExpressionCaseInsensitive

    error:nil];

    return ([regularexpression numberOfMatchesInString:content

    options:NSMatchingReportProgress

    range:NSMakeRange(0, content.length)] > 0);

}

+ (UIColor*)getMainColor
{
    return UIColorFromRGB(0xFDA23F);
}

+ (void)cornerRadiusTopLRWithView:(UIView*)view rect:(CGRect)rect withRadius:(CGFloat)radius
{
    UIBezierPath *cornerRadiusPath = [UIBezierPath bezierPathWithRoundedRect:view.bounds byRoundingCorners:UIRectCornerTopRight | UIRectCornerTopLeft cornerRadii:CGSizeMake(radius, radius)];

    CAShapeLayer *cornerRadiusLayer = [ [CAShapeLayer alloc ] init];

    cornerRadiusLayer.frame = rect;

    cornerRadiusLayer.path = cornerRadiusPath.CGPath;
    view.layer.mask = cornerRadiusLayer;
}

+ (void)cornerRadiusTopLRWithView:(UIView*)view withRadius:(CGFloat)radius
{
    UIBezierPath *cornerRadiusPath = [UIBezierPath bezierPathWithRoundedRect:view.bounds byRoundingCorners:UIRectCornerTopRight | UIRectCornerTopLeft cornerRadii:CGSizeMake(radius, radius)];

    CAShapeLayer *cornerRadiusLayer = [ [CAShapeLayer alloc ] init];

    cornerRadiusLayer.frame = view.bounds;

    cornerRadiusLayer.path = cornerRadiusPath.CGPath; view.layer.mask = cornerRadiusLayer;

}

+ (void)cornerRadiusBottomLRWithView:(UIView*)view withRadius:(CGFloat)radius
{
    UIBezierPath *cornerRadiusPath = [UIBezierPath bezierPathWithRoundedRect:view.bounds byRoundingCorners:UIRectCornerBottomLeft | UIRectCornerBottomRight cornerRadii:CGSizeMake(radius, radius)];

    CAShapeLayer *cornerRadiusLayer = [ [CAShapeLayer alloc ] init];

    cornerRadiusLayer.frame = view.bounds;

    cornerRadiusLayer.path = cornerRadiusPath.CGPath; view.layer.mask = cornerRadiusLayer;

}

+ (void)cornerRadiusBottomLRWithView:(UIView*)view rect:(CGRect)rect withRadius:(CGFloat)radius
{
    UIBezierPath *cornerRadiusPath = [UIBezierPath bezierPathWithRoundedRect:view.bounds byRoundingCorners:UIRectCornerBottomLeft | UIRectCornerBottomRight cornerRadii:CGSizeMake(radius, radius)];

    CAShapeLayer *cornerRadiusLayer = [ [CAShapeLayer alloc ] init];

    cornerRadiusLayer.frame = rect;

    cornerRadiusLayer.path = cornerRadiusPath.CGPath;
    view.layer.mask = cornerRadiusLayer;
}

+ (CGFloat)getLabelWidthByHeight:(CGFloat)height andContent:(NSString*)content andFont:(UIFont*)font
{
    CGSize size = [content boundingRectWithSize:CGSizeMake(MAXFLOAT, height) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:font} context:nil].size;
    
    return size.width;
    
}

+ (CGFloat)getLabelHeightByWidth:(CGFloat)width andContent:(NSString*)content andFont:(UIFont*)font
{
    CGSize size = [content boundingRectWithSize:CGSizeMake(width, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:font} context:nil].size;
    
    return size.height;
    
}

+ (BOOL)checkLoginAndGotoLogin:(UIViewController*)vc{
    if ([[SharedInstance getInstance].userInfo.sid length] == 0) {
        
        [[SharedInstance getInstance] checkLoginAndGotoLogin:vc];
        
        return NO;
    }
    
    return YES;
}

+ (UIWindow *)currentWindow {
    if (@available(iOS 15, *)) {
       __block UIScene * _Nonnull tmpSc;
        [[[UIApplication sharedApplication] connectedScenes] enumerateObjectsUsingBlock:^(UIScene * _Nonnull obj, BOOL * _Nonnull stop) {
            if (obj.activationState == UISceneActivationStateForegroundActive || obj.activationState == UISceneActivationStateForegroundInactive) {
                tmpSc = obj;
                *stop = YES;
            }
        }];
        UIWindowScene *curWinSc = (UIWindowScene *)tmpSc;
        return curWinSc.windows.firstObject;
    } else {
        return [[[UIApplication sharedApplication] windows] objectAtIndex:0];
    }
}

//获取当前时间戳 （以秒为单位）
+ (NSString *)getNowTimeTimestamp{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init] ;
    [formatter setDateStyle:NSDateFormatterMediumStyle];
    [formatter setTimeStyle:NSDateFormatterShortStyle];
    [formatter setDateFormat:@"YYYY-MM-dd HH:mm:ss SSS"]; // ----------设置你想要的格式,hh与HH的区别:分别表示12小时制,24小时制
    //设置时区,这个对于时间的处理有时很重要
    NSTimeZone* timeZone = [NSTimeZone timeZoneWithName:@"Asia/Shanghai"];
    [formatter setTimeZone:timeZone];
    NSDate *datenow = [NSDate date];//现在时间,你可以输出来看下是什么格式
    NSString *timeSp = [NSString stringWithFormat:@"%ld", (long)[datenow timeIntervalSince1970]];
    return timeSp;
}

//添加打折线；
+ (void)labelAddSaleLine:(UILabel*)label
{
    NSDictionary *attribtDic =@{NSStrikethroughStyleAttributeName: [NSNumber numberWithInteger:NSUnderlineStyleSingle]};
     
    NSMutableAttributedString *attribtStr = [[NSMutableAttributedString alloc] initWithString:label.text attributes:attribtDic];
     
    label.attributedText = attribtStr;
}



+ (void)setUintWithLabel:(UILabel*)label andText:(NSString*)text fontSize:(CGFloat)fontSize
{
    NSString * uint = [SharedInstance getInstance].uint;
    NSString * amountText;
    
    if(!uint || uint.length == 0)
    {
        amountText = text;
        label.text = amountText;
        return;
    }
    
    amountText = [NSString stringWithFormat:@"%@%@",text,uint];
    
    label.text = amountText;

    [Utils labelColorAttributedString:label andRange:NSMakeRange(amountText.length - uint.length, uint.length) color:label.textColor size:fontSize];
}

+ (void)setUintWithLabel:(UILabel*)label andText:(NSString*)text fontSize:(CGFloat)fontSize rangeLength:(NSInteger)rangeLength
{
    NSString * uint = [SharedInstance getInstance].uint;
    NSString * amountText;
    
    if(!uint || uint.length == 0)
    {
        amountText = text;
        label.text = amountText;
        return;
    }
    
    amountText = [NSString stringWithFormat:@"%@%@",text,uint];
    
    label.text = amountText;
    
    NSInteger length = uint.length + rangeLength;

    [Utils labelColorAttributedString:label andRange:NSMakeRange(amountText.length - length, length) color:label.textColor size:fontSize];
}


+ (NSString *)timeWithSecond:(NSInteger)totalSeconds
{

    NSInteger seconds = totalSeconds % 60;
    NSInteger minutes = (totalSeconds / 60) % 60;
    NSInteger hours = totalSeconds / 3600;

    return [NSString stringWithFormat:@"%02ld:%02ld:%02ld",hours, minutes, seconds];
}


 //检查是否是连续或者是相同数字
+ (BOOL)checkPincode:(NSString*)pincode
{
    BOOL isTure = NO;//不符合规则，pincode是相同的或连续的
    NSString *pincodeRegex = @"^(?=.*\\d+)(?!.*?([\\d])\1{5})[\\d]{6}$";
    NSPredicate *pincodePredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", pincodeRegex];
   
    NSMutableArray * arr = [NSMutableArray arrayWithCapacity:0];
    if ([pincodePredicate evaluateWithObject:pincode]) {
       
        // 遍历字符串，按字符来遍历。每个字符将通过block参数中的substring传出
        [pincode enumerateSubstringsInRange:NSMakeRange(0, pincode.length) options:NSStringEnumerationByComposedCharacterSequences usingBlock:^(NSString *substring, NSRange substringRange, NSRange enclosingRange, BOOL *stop) {
            //将遍历出来的字符串添加到数组中
            [arr addObject:substring];
           
        }];
       
        BOOL isInscend = [Utils judgeInscend:arr];
        BOOL isDescend = [Utils judgeDescend:arr];
        BOOL isEqual = [Utils judgeEqual:arr];
        if ( !isInscend && !isDescend && !isEqual) {
            isTure = YES;
        }
       
    }
   
    return isTure;
}


+ (BOOL)judgeInscend:(NSArray *)arr{
    //递增12345
    int j = 0;
    for (int i = 0; i<arr.count; i++) {
        if (i>0) {
            int num = [arr[i] intValue];
            int num_ = [arr[i-1] intValue] +1;
            if (num == num_) {
                j++;
            }
        }
    }
   
    if (j == arr.count - 1) {
        return YES;
    }

    return NO;
}

+ (BOOL)judgeDescend:(NSArray *)arr{
    //递减54321
    int j=0;//计数归零,用于递减判断
    for (int i = 0; i<arr.count; i++) {
        if (i>0) {
            int num = [arr[i] intValue];
            int num_ = [arr[i-1] intValue]-1;
            if (num == num_) {
                j++;
            }
        }
    }
    if (j == arr.count - 1) {
        return YES;
    }
    return NO;
}

+ (BOOL)judgeEqual:(NSArray *)arr{

    int j=0;

    int firstNum = [arr[0] intValue];

    for (int i = 0; i<arr.count; i++) {

        if (firstNum == [arr[i] intValue]) {

            j++;

        }

    }

    if (j == arr.count) {

        return YES;

    }

    return NO;

}

+ (NSString *)stringFromNumber:(NSNumber *)currencyNumber
{
    NSNumberFormatter *currencyFormatter = [[NSNumberFormatter alloc] init];
      currencyFormatter.numberStyle = NSNumberFormatterDecimalStyle;
      NSString *currenctStr = [currencyFormatter stringFromNumber:[NSNumber numberWithFloat:currencyNumber.floatValue]];
      return [NSString stringWithFormat:@"%@",currenctStr];//因为我需要的样式是￥123,456,789没有后面的.00
      /*
      NSNumberFormatterNoStyle = kCFNumberFormatterNoStyle,  // 123456789
      NSNumberFormatterDecimalStyle = kCFNumberFormatterDecimalStyle,// 123,456,789
      NSNumberFormatterCurrencyStyle = kCFNumberFormatterCurrencyStyle,//￥123,456,789.00
      NSNumberFormatterPercentStyle = kCFNumberFormatterPercentStyle, //-539,222,988%
      NSNumberFormatterScientificStyle = kCFNumberFormatterScientificStyle,//1.23456789E8
      NSNumberFormatterSpellOutStyle = kCFNumberFormatterSpellOutStyle //一亿二千三百四十五万六千七百八十九
       */

}

+ (NSString *)getNewBankNumWitOldBankNum:(NSString *)bankNum{
    NSMutableString *mutableStr;
    if (bankNum.length) {
    mutableStr = [NSMutableString stringWithString:bankNum];
//    for (int i = 0 ; i < mutableStr.length; i ++) {
//        if (i>2&&i<mutableStr.length - 3) {
//            [mutableStr replaceCharactersInRange:NSMakeRange(i, 1) withString:@"*"];
//        }
//    }
    NSString *text = mutableStr;
    NSCharacterSet *characterSet = [NSCharacterSet characterSetWithCharactersInString:@"0123456789\b"];
    text = [text stringByReplacingOccurrencesOfString:@" " withString:@""];
    NSString *newString = @"";
    while (text.length > 0) {
        NSString *subString = [text substringToIndex:MIN(text.length, 5)];
        newString = [newString stringByAppendingString:subString];
        if (subString.length == 5) {
            newString = [newString stringByAppendingString:@" "];
        }
        text = [text substringFromIndex:MIN(text.length, 5)];
    }
    newString = [newString stringByTrimmingCharactersInSet:[characterSet invertedSet]];
        return newString;
    }
    return bankNum;
}

+ (BOOL)isNumber:(NSString*)string
{
    NSScanner * scan = [[NSScanner alloc] initWithString:string];
    
    float value = 0;
    
    return [scan scanFloat:&value] && scan.isAtEnd;
}

/**
 校验身份证号码是否正确 返回 BOOL值
 
 十八位： ^[1-9]\d{5}(18|19|([23]\d))\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$
 
 十五位： ^[1-9]\d{5}\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{2}$
 
 总结：
 
 ^[1-9]\d{5}(18|19|([23]\d))\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$)|(^[1-9]\d{5}\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{2}$
 
 @param idCardString 身份证号码
 @return 返回 BOOL值 YES or NO
 */
+ (BOOL)verifyIDCardString:(NSString *)idCardString {
//    NSString *regex = @"^[1-9]\\d{5}(18|19|([23]\\d))\\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\\d{3}[0-9Xx]$";
    NSString *regex = @"^(^[1-9]\\d{7}((0\\d)|(1[0-2]))(([0|1|2]\\d)|3[0-1])\\d{3}$)|(^[1-9]\\d{5}[1-9]\\d{3}((0\\d)|(1[0-2]))(([0|1|2]\\d)|3[0-1])((\\d{4})|\\d{3}[Xx])$)$";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",regex];
    BOOL isRe = [predicate evaluateWithObject:idCardString];
    if (!isRe) {
        //身份证号码格式不对
        return NO;
    }
    //加权因子 7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2
    NSArray *weightingArray = @[@"7", @"9", @"10", @"5", @"8", @"4", @"2", @"1", @"6", @"3", @"7", @"9", @"10", @"5", @"8", @"4", @"2"];
    //校验码 1, 0, 10, 9, 8, 7, 6, 5, 4, 3, 2
    NSArray *verificationArray = @[@"1", @"0", @"10", @"9", @"8", @"7", @"6", @"5", @"4", @"3", @"2"];
    
    NSInteger sum = 0;//保存前17位各自乖以加权因子后的总和
    for (int i = 0; i < weightingArray.count; i++) {//将前17位数字和加权因子相乘的结果相加
        NSString *subStr = [idCardString substringWithRange:NSMakeRange(i, 1)];
        sum += [subStr integerValue] * [weightingArray[i] integerValue];
    }
    
    NSInteger modNum = sum % 11;//总和除以11取余
    NSString *idCardMod = verificationArray[modNum]; //根据余数取出校验码
    NSString *idCardLast = [idCardString.uppercaseString substringFromIndex:17]; //获取身份证最后一位
    
    if (modNum == 2) {//等于2时 idCardMod为10  身份证最后一位用X表示10
        idCardMod = @"X";
    }
    if ([idCardLast isEqualToString:idCardMod]) { //身份证号码验证成功
        return YES;
    } else { //身份证号码验证失败
        return NO;
    }
}

+ (void)gradualLeftToRightColor:(CALayer*)layer withColor:(UIColor*)startColor withColor:(UIColor*)endColor{
    
    CAGradientLayer * gradientLayer = [[CAGradientLayer alloc]init];
    gradientLayer.frame = CGRectMake(0, 0, SCREEN_WIDTH - layer.frame.origin.x, layer.frame.size.height);
    
    gradientLayer.colors = @[(__bridge id)startColor.CGColor,(__bridge id)endColor.CGColor];
    
    gradientLayer.startPoint = CGPointMake(0, 1);
    gradientLayer.endPoint = CGPointMake(1, 1);
    
    [layer insertSublayer:gradientLayer atIndex:0];
    
    layer.masksToBounds = true;
    
}

@end
