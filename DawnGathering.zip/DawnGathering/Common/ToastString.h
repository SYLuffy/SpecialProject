//
//  ToastString.h
//  HLGA
//
//  Created by Linus on 2018/5/18.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <Foundation/Foundation.h>


static NSString *const TOAST_NET_FAILURE = @"网络开小差!";
static NSString *const TOAST_PLEASE_INPUT_ACCOUNT = @"请输入账号";
