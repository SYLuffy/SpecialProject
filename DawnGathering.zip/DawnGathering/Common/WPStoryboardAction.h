//
//  GAStoryboardAction.h
//  GARWM
//
//  Created by 葛亮 on 2018/4/10.
//  Copyright © 2018年 葛亮. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface WPStoryboardAction : NSObject

@property (nonatomic, weak) IBOutlet UIViewController *owner;
- (IBAction)backBtnPressed:(id)sender;
- (IBAction)dismissBtnPressed:(id)sender;

@end
