//
//  WPDiscountModel.h
//  HLGA
//
//  Created by 谢丹 on 2021/10/26.
//  Copyright © 2021 Linus. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface WPDiscountModel : NSObject

@property(nonatomic,strong)NSString *account;
@property(nonatomic,assign)NSInteger accountType;
@property(nonatomic,assign)NSInteger amount;
@property(nonatomic,assign)NSInteger scanCode;//0未开通线下扫码,1开通线下扫码
@property(nonatomic,assign)NSInteger itemId;
@property(nonatomic,strong)NSString *itemName;
@property(nonatomic,strong)NSArray *itemSeq;
@property(nonatomic,strong)NSString *remark;
@property(nonatomic,strong)NSString *shopUrl;
@property(nonatomic,strong)NSString *userId;
@property(nonatomic,strong)NSString * accountFundingType;


//@property(nonatomic,strong)NSString *itemAllName;

- (instancetype)initByDictionary:(NSDictionary*)dic;


@end

NS_ASSUME_NONNULL_END
