//
//  Events.h
//  CultureChengDu
//
//  Created by Linus on 2017/12/12.
//  Copyright © 2017年 Linus. All rights reserved.
//

static NSString *const EVENT_ALIPAY_BACK = @"event_alipay_back";

static NSString *const EVENT_WECHAT_BACK = @"event_wechat_back";

static NSString *const EVENT_SCAN_PAY_SUCCESS = @"event_scan_pay_success";

static NSString *const EVENT_SCAN_PAY_FAULT = @"event_scan_pay_fault";

static NSString *const EVENT_SCAN_PAY_ING = @"event_scan_pay_ing";

static NSString *const EVENT_SCAN_PAY_CANCEL = @"event_scan_pay_cancel";

static NSString *const EVENT_GOTO_REAL_NAME = @"event_goto_real_name";

static NSString *const EVENT_UPDATE_FAILURE = @"event_update_failure";

static NSString *const EVENT_VALIDATION_SUCCESS = @"event_validation_success";

static NSString *const EVENT_UPDATE_MSG_COUNT = @"event_update_msg_cout";

static NSString *const EVENT_OPEN_OR_CLOSE_BRIGHT = @"event_open_or_close_britgh";

static NSString *const EVENT_OPEN_QR_CODE = @"event_open_qr_code";

static NSString *const EVENT_GOTO_POINTS = @"event_goto_points";

static NSString *const EVENT_UPDATE_LOCATION_STORE = @"event_update_location_store";

static NSString *const EVENT_LAUNCH_IN_APP = @"event_launch_in_app";

static NSString *const EVENT_UPDATE_CATEGORY = @"event_update_category";

static NSString *const EVENT_BUSINESS_TRAVEL = @"event_business_travel";

static NSString *const EVET_HTML_LOGIN_CALL_BACK = @"event_html_login_call_back";

static NSString *const EVET_UPDATE_BOTTOM_TABBAR_LIST = @"event_update_button_tabbar_list";

static NSString *const EVENT_SGH_LOGIN_SUCCESS = @"event_sgh_login_success";

static NSString *const EVENT_BECOME_ACTIVE = @"event_become_active";

static NSString *const EVENT_UPDATE_HOME_PAGE = @"event_update_home_page";

static NSString *const EVENT_SELECT_TABBAR_WITH_INDEX = @"event_select_tabbar_with_index";

static NSString *const EVENT_HOME_JUMP_WITH_TYPE = @"event_home_jump_with_type";

