//
//  GAStoryboardAction.m
//  GARWM
//
//  Created by 葛亮 on 2018/4/10.
//  Copyright © 2018年 葛亮. All rights reserved.
//

#import "WPStoryboardAction.h"
#import <objc/runtime.h>

@implementation WPStoryboardAction
- (void)setOwner:(id)owner
{
    if (_owner != owner) {
        [self releaseLifetimeFromObject:_owner];
        _owner = owner;
        [self bindLifetimeToObject:_owner];
    }
}

- (void)bindLifetimeToObject:(id)object
{
    objc_setAssociatedObject(object, (__bridge void *)self, self,   OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (void)releaseLifetimeFromObject:(id)object
{
    objc_setAssociatedObject(object, (__bridge void *)self, nil,    OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}


- (void)backBtnPressed:(id)sender
{
    [_owner.navigationController popViewControllerAnimated:YES];
}

- (void)dismissBtnPressed:(id)sender
{
    [_owner.navigationController dismissViewControllerAnimated:YES completion:nil];
}
@end
