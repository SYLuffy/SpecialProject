//
//  SharedInstance.m
//  HLGA
//
//  Created by Linus on 2018/5/15.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "SharedInstance.h"
#import "PayView.h"
#import "WPNavigationController.h"
#import "YZAuthID.h"
#import "RealNamePopView.h"
#import <TYRZUISDK/TYRZUISDK.h>
#import <LocalAuthentication/LocalAuthentication.h>
#import <UIImageView+WebCache.h>
#import "UIImage+tools.h"
#import "UIDevice+StateHeight.h"
#import "PayPwdPopView.h"
#import "WPUrlString.h"
#import "LoginViewController.h"
#import <MBProgressHUD.h>
#import <AFNetworkReachabilityManager.h>



#define THIRD_HEIGHT 109
#define MAX_HEIGHT 502
#define SPECIAL_HEIGHT 35
#define ONE_THIRD_PAY_CELL_H_AND_GAP 37



@implementation SharedInstance

static SharedInstance* _instance = nil;

+ (instancetype)getInstance
{
    static dispatch_once_t onceToken ;
    dispatch_once(&onceToken, ^{
        _instance = [[self alloc] init] ;
        
        _instance.hideLoadingDataSource = [NSMutableArray array];
        
        _instance.isOpenedUnifiedPay = false;
        
        _instance.noInternet = true;
        
        _instance.isFromPushGotoMessage = false;
        
        _instance.isASDUrlBool = false;
        
        _instance.isOpenMessageVC = false;
        
        _instance.merchantWebHeight = 0.0f;//默认高度;
        
        
        AFNetworkReachabilityManager* reachability = [AFNetworkReachabilityManager sharedManager];
        [reachability startMonitoring];
        
        [reachability setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
            
            
            switch (status) {
                case AFNetworkReachabilityStatusUnknown:
                    NSLog(@"未知网络!");
                    [SharedInstance getInstance].noInternet = true;
                    break;
                case AFNetworkReachabilityStatusNotReachable:
                    NSLog(@"无网络连接!");
                {
                    [SharedInstance getInstance].noInternet = true;
                    [SharedInstance showSetNetwork];
                    break;
                }
                case AFNetworkReachabilityStatusReachableViaWWAN:
                    
                    [SharedInstance getInstance].noInternet = false;
                    
                    NSLog(@"WWAN网络连接!");
                    
                    [SharedInstance hideSetNetwork];
                    break;
                case AFNetworkReachabilityStatusReachableViaWiFi:
                    
                    [SharedInstance getInstance].noInternet = false;
                    NSLog(@"WiFi网络连接!");
                    [SharedInstance hideSetNetwork];
                    break;
                default:
                    break;
            }
            if([SharedInstance getInstance].noInternet == false)
            {
                [[NSNotificationCenter defaultCenter] postNotificationName:EVENT_UPDATE_HOME_PAGE object:nil];
            }
            
        }];
        
    }) ;
    return _instance ;
}

+ (void)hideSetNetwork
{
    if([SharedInstance getInstance].netWorkNotConnectVC)
    {
        [[SharedInstance getInstance].netWorkNotConnectVC dismissViewControllerAnimated:false completion:nil];
    }
}
    

+ (void)showSetNetwork
{
    [SharedInstance getInstance].netWorkNotConnectVC = [UIAlertController alertControllerWithTitle:@"检查网络设置" message:@"如果您当前的网络环境可正常使用其他App，但是蜀光惠无法正常使用，请检查您的网络设置" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction * cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    UIAlertAction * confirm = [UIAlertAction actionWithTitle:@"设置" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        //设置支付密码界面跳转
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString] options:@{} completionHandler:nil];
        
    }];
    
    [[SharedInstance getInstance].netWorkNotConnectVC addAction:cancel];
    [[SharedInstance getInstance].netWorkNotConnectVC addAction:confirm];
    
    [[Utils getCurrentVC] presentViewController:[SharedInstance getInstance].netWorkNotConnectVC animated:true completion:nil];
}

//支付控件
+ (void)showPayViewController:(NSDictionary*)dataSource owner:(__kindof UIViewController *)owner payBack:(PaySuccessBack)payStatusBack
{

    if ([Utils pushPaymentPasswordOwner:owner] && _instance.isOpenedUnifiedPay == false) {
        
        CGFloat totalHeight = MAX_HEIGHT;
        
        if(@available(iOS 11.0,*))
        {
            if(SCREEN_HEIGHT > 736)
            {
                //NSLog(@"%lf",owner.view.safeAreaInsets.bottom);
                totalHeight = MAX_HEIGHT + owner.view.safeAreaInsets.bottom + 41;
            }
        }
        
        CGFloat height = totalHeight;
        
        //判断是否有三方支付
        
        NSNumber * otherAmount = dataSource[OTHER_AMOUNT];
        NSInteger hasThirdPay = 0;
        if(otherAmount.integerValue <= 0)
        {
            height = height - THIRD_HEIGHT;
        }else{
            
            hasThirdPay = 1;
            NSNumber * wechatEnable;
            
//            if([WXApi isWXAppInstalled] == false)
//            {
//                wechatEnable = @0;
//            }else{
                wechatEnable = dataSource[WECHAT_ENABLE];
//            }
    

            NSNumber * alipayEnable = dataSource[ALIPAY_ENABLE];
            if(wechatEnable.integerValue == 1 && alipayEnable.integerValue == 0){
                height = height - ONE_THIRD_PAY_CELL_H_AND_GAP;
            }else if(wechatEnable.integerValue == 0 && alipayEnable.integerValue == 1)
            {
                height = height - ONE_THIRD_PAY_CELL_H_AND_GAP;
            }else if(wechatEnable.integerValue == 0 && alipayEnable.integerValue == 0){
                
                height = height - THIRD_HEIGHT;
            }
        }
        
        NSArray * payItems = dataSource[@"payItems"];
        
        CGFloat showAmountHeight = 17 * (payItems.count - hasThirdPay);
        
        height += showAmountHeight;
        
        PayView * payView = [[PayView alloc]initWithPanelFrame:CGRectMake(0, 0, SCREEN_WIDTH, height) andData:dataSource];
        
        payView.PayCompeleteBlock = ^(NSString * payStatus) {
            payStatusBack(payStatus);//1为成功，0为失败，-1为取消
        };
        
        [[Utils currentWindow] addSubview:payView];
    }
}

+ (void)checkGoToOpenFaceOrTouchID:(NSString*)payPassword
{
    BOOL isNO = [[Utils passwordForService:FACE_ID_NO] isEqualToString:NO_FACE_ID_PAY];
    BOOL isEnable = [[Utils getUserDefaultByKey:DO_NOT_ENABLE_FACE_ID_PAY] isEqualToString:DO_NOT_ENABLE_FACE_ID_PAY];
    if(isNO == false && isEnable == false)
    {
        [SharedInstance checkHasTouchID:^(BOOL can) {
            if(can)
            {
                [SharedInstance showFaceOrTouchIDAlertView:payPassword];
            }
        }];
    }
}

+ (void)showFaceOrTouchIDAlertView:(NSString*)payPassword
{
    UIAlertController * alertVC = [UIAlertController alertControllerWithTitle:@"提示" message:@"您是否愿意使用指纹/面容ID,进行支付?" preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction * cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        
        [Utils setUserDefaultByKey:DO_NOT_ENABLE_FACE_ID_PAY andValue:DO_NOT_ENABLE_FACE_ID_PAY];//这只本次安装将不再提示
    }];
    UIAlertAction * confirmAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
       
        [SharedInstance loadAuthentication:^(NSString *payStatus) {
            
            switch (payStatus.integerValue) {
                case 1:
                {
                    //成功
                    
                    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                        [Utils showToast:@"设置成功!将在下一次使用 面容/指纹 进行支付!"];
                    });
                    
                    
                    [[SharedInstance getInstance] saveFaceIDByPwd:payPassword];
                    break;
                }
                case 0:
                    [Utils showToast:@"设置失败"];
                    break;
                case -1:
                {
                    [Utils showToast:@"取消设置"];
                    break;
                }
                case -2:
                {
                    [Utils showToast:@"设置失败"];
                    break;
                }
                case -3:
                {
                    [Utils showToast:@"设置失败"];
                    break;
                }
                default:
                    break;
            }
            
        }];
        
    }];
    
    [alertVC addAction:cancelAction];
    [alertVC addAction:confirmAction];
    
    [[Utils currentWindow].rootViewController presentViewController:alertVC animated:true completion:nil];
}


+ (void)clearLoginInfo
{
    [SharedInstance getInstance].isEnterOpenQrCode = false;
    
    [Utils setUserDefaultByKey:SID andValue:@""];
    [SharedInstance getInstance].userInfo = nil;
    [Utils setUserDefaultByKey:COMPANY_ID andValue:@0];
    [Utils setUserDefaultByKey:COMPANY_NAME andValue:@""];
    [[SharedInstance getInstance] deleteFaceID];
    [SharedInstance getInstance].sid = @"";
    [[NSNotificationCenter defaultCenter] postNotificationName:EVENT_UPDATE_HOME_PAGE object:nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:EVENT_SGH_LOGIN_SUCCESS object:nil];
    
    [SharedInstance getInstance].isNeedUpdateHomePage = true;
}



+ (void)exitLogin:(ExitLoginCallback)callback
{
    
    if([[Utils currentWindow].rootViewController isKindOfClass:WPNavigationController.class]){
        return;
    }
    
    [ServiceManager exitLogin:^(NSDictionary *data) {
        
        
        [Utils setUserDefaultByKey:SID andValue:@""];
        [SharedInstance getInstance].userInfo = nil;
        [Utils setUserDefaultByKey:COMPANY_ID andValue:@0];
        [Utils setUserDefaultByKey:COMPANY_NAME andValue:@""];
        [[SharedInstance getInstance] deleteFaceID];
        [SharedInstance getInstance].sid = @"";
        
        [[NSNotificationCenter defaultCenter] postNotificationName:EVENT_UPDATE_HOME_PAGE object:nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:EVENT_SGH_LOGIN_SUCCESS object:nil];
        
        [SharedInstance getInstance].isNeedUpdateHomePage = true;
        
        callback();
        
    }];
    
    
    
}

+ (void)loadAuthentication:(FaceIDBack)faceIDBack{
    // 这个属性是设置指纹输入失败之后的弹出框的选项
    [[YZAuthID alloc] yz_showAuthIDWithDescribe:nil block:^(YZAuthIDState state, NSError *error) {
        
        if (state == YZAuthIDStateNotSupport) {
            [Utils showToast:@"对不起，当前设备不支持指纹/面部ID"];
            faceIDBack(@"-2");
        } else if(state == YZAuthIDStateFail) {
            [Utils showToast:@"指纹/面部ID不正确，认证失败"];
            faceIDBack(@"-2");
        } else if(state == YZAuthIDStateTouchIDLockout) {
            [Utils showToast:@"多次错误，指纹/面部ID已被锁定，请到手机解锁界面输入密码"];
            faceIDBack(@"-2");
        } else if(state == YZAuthIDStatePasswordNotSet){
            
            [SharedInstance unSetTouchIDAlert:^(BOOL isConfirm) {
                if(isConfirm == false)
                {
                    faceIDBack(@"-2");
                }
            }];
            
        } else if(state == YZAuthIDStateTouchIDNotSet){
            [SharedInstance unSetTouchIDAlert:^(BOOL isConfirm) {
                if(isConfirm == false)
                {
                    faceIDBack(@"-2");
                }
            }];
        } else if (state == YZAuthIDStateSuccess) {
            faceIDBack(@"1");
        }else if(state == YZAuthIDStateInputPassword)
        {
            faceIDBack(@"-2");
        }
    }];
}

+ (void)checkHasTouchID:(CanUseTouchID)canUseBack{
    LAContext *context = [[LAContext alloc] init];
    NSError *error = nil;
    if ([context canEvaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics error:&error])
    {
        canUseBack(true);
    }else{
        switch (error.code) {
            case LAErrorBiometryNotEnrolled:{
                dispatch_async(dispatch_get_main_queue(), ^{
                    //[Utils showToast:@"Touch/FaceID 无法启动,因为用户没有设置Touch/FaceID"];
                    [SharedInstance unSetTouchIDAlert:^(BOOL isConfirm) {
                        
                    }];
                });
            }
                break;
            case LAErrorPasscodeNotSet:
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                    //[Utils showToast:@"Touch/FaceID 无法启动,因为用户没有设置手机密码"];
                    [SharedInstance unSetTouchIDAlert:^(BOOL isConfirm) {
                        
                    }];
                });
            }
                break;
            case LAErrorBiometryLockout:{
                dispatch_async(dispatch_get_main_queue(), ^{
                    //[Utils showToast:@"Touch/FaceID 被锁定(连续多次验证TouchID失败,系统需要用户手动输入密码)"];
                    canUseBack(false);
                });
                break;
            }
            default:
                dispatch_async(dispatch_get_main_queue(), ^{
                   // [Utils showToast:@"当前设备不支持Touch/FaceID"];
                    canUseBack(false);
                });
                break;
        }
    }
}

+ (void)unSetTouchIDAlert:(AlertBack)alertBack
{
    UIAlertController * alertVC = [UIAlertController alertControllerWithTitle:@"提示" message:@"您未设置指纹/面容ID,是否跳转去设置?" preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction * cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        
        alertBack(false);
        
    }];
    UIAlertAction * confirmAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        NSURL *url = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
        if ([[UIApplication sharedApplication] canOpenURL:url])
        {
            [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:nil];
        }
    }];
    
    [alertVC addAction:cancelAction];
    [alertVC addAction:confirmAction];
    
    [[Utils currentWindow].rootViewController presentViewController:alertVC animated:true completion:nil];
}

- (void)saveFaceIDByPwd:(NSString*)pwd
{
    [Utils setPassword:NO_FACE_ID_PAY forService:FACE_ID_NO];//设置免密支付状态为开启;
    [Utils setPassword:pwd forService:FACE_ID_PASSWORD];//设置免密支付密码保存;
}
- (void)deleteFaceID
{
    [Utils setPassword:OFF_FACE_ID_PAY forService:FACE_ID_NO];//这只免密支付状态为关闭;
    [Utils deletePasswordForService:FACE_ID_PASSWORD];//删除密码
}


//share
- (void)showShareView
{
    if([WXApi isWXAppInstalled])
    {
        [_instance shareFadeIn];
    }else{
        [Utils showToast:@"暂时只支持微信分享，未安装无法分享!"];
    }
}

- (void)shareFadeIn
{
    self.shareDarkMask.alpha = 0;
    
    [[Utils currentWindow] addSubview:self.shareDarkMask];
    [[Utils currentWindow] addSubview:self.shareView];
    
    self.shareView.frame = CGRectMake(0, SCREEN_HEIGHT, self.shareView.frame.size.width, self.shareView.frame.size.height);
    
    
    [UIView animateWithDuration:0.3 animations:^{
        
        self.shareView.frame = CGRectMake(self.shareView.frame.origin.x, SCREEN_HEIGHT - self.shareView.frame.size.height, self.shareView.frame.size.width, self.shareView.frame.size.height);
        self.shareDarkMask.alpha = 0.4;
    }];
}
-(void)shareFadeOut
{
    [UIView animateWithDuration:0.3 animations:^{
        
        self.shareView.center = CGPointMake(self.shareView.center.x, SCREEN_HEIGHT + self.shareView.bounds.size.height/2);
        self.shareDarkMask.alpha = 0;
        
    } completion:^(BOOL finished) {
        [self.shareDarkMask removeFromSuperview];
        [self.shareView removeFromSuperview];
    }];
}
- (ShareView*)shareView{
    
    if(_shareView == nil)
    {
        _shareView = (ShareView*)[Utils getXibByName:@"ShareView"];
        _shareView.bounds = CGRectMake(0, 0, SCREEN_WIDTH, 110);
        _shareView.blockShareFriends = ^{
            
        };
        _shareView.blockShareMoments = ^{
            [_instance wxMediaMessageShareStatus:1];
        };
        _shareView.blockShareFriends = ^{
            [_instance wxMediaMessageShareStatus:0];
        };
    }
    
    return _shareView;
}

- (void)wxMediaMessageShareStatus:(NSInteger)status
{
    if(self.showShareDictionary == nil)
    {
        return;
    }
    
    NSString * webURL = self.showShareDictionary[@"url"];
    NSString * imageURL = self.showShareDictionary[@"imgUrl"];
    NSString * title = self.showShareDictionary[TITLE];
    NSString * content = self.showShareDictionary[CONTENT];
    
    UIImageView * loadImage = [[UIImageView alloc]init];
    [loadImage sd_setImageWithURL:[NSURL URLWithString:imageURL] completed:^(UIImage * _Nullable image, NSError * _Nullable error, SDImageCacheType cacheType, NSURL * _Nullable imageURL) {
        
        WXMediaMessage * message = [WXMediaMessage message];
        message.title = title;
        message.description = content;
        
        [message setThumbImage:[_instance thumbnailWithImageWithoutScale:image size:CGSizeMake(100, 100)]];
        
        WXWebpageObject * webPageObject = [WXWebpageObject object];
        webPageObject.webpageUrl = webURL;
        message.mediaObject = webPageObject;
        
        SendMessageToWXReq * req = [[SendMessageToWXReq alloc] init];
        req.bText = false;
        req.message = message;
        
        int scene;
        
        if(status == 0)
        {
            scene = WXSceneSession;
        }else{
            scene = WXSceneTimeline;
        }
        req.scene = scene;
        dispatch_async(dispatch_get_main_queue(), ^{
            [WXApi sendReq:req completion:nil];
        });
    }];
    
}


//微信拉起小程序
- (void)wechantMiniProgramPath:(NSString*)path userName:(NSString*)userName miniProgramType:(WXMiniProgramType)miniProgramType
{
    WXLaunchMiniProgramReq *launchMiniProgramReq = [WXLaunchMiniProgramReq object];
    launchMiniProgramReq.userName = userName;  //拉起的小程序的username
    launchMiniProgramReq.path = path;    ////拉起小程序页面的可带参路径，不填默认拉起小程序首页，对于小游戏，可以只传入 query 部分，来实现传参效果，如：传入 "?foo=bar"。
    launchMiniProgramReq.miniProgramType = miniProgramType; //拉起小程序的类型
    [WXApi sendReq:launchMiniProgramReq completion:^(BOOL success) {
        
    }];;
}

- (UIImage *)thumbnailWithImageWithoutScale:(UIImage *)image size:(CGSize)asize{
    
    UIImage *newimage;
    
    if (nil == image)
    {
        
        newimage = nil;
        
    } else {
        
        CGSize oldsize = image.size;
        
        CGRect rect;
        
        if (asize.width/asize.height > oldsize.width/oldsize.height)
            
        {
            
            rect.size.width = asize.height*oldsize.width/oldsize.height;
            
            rect.size.height = asize.height;
            
            rect.origin.x = (asize.width - rect.size.width)/2;
            
            rect.origin.y = 0;
            
        } else {
            
            rect.size.width = asize.width;
            
            rect.size.height = asize.width*oldsize.height/oldsize.width;
            
            rect.origin.x = 0;
            
            rect.origin.y = (asize.height - rect.size.height)/2;
            
        }
        
        UIGraphicsBeginImageContext(asize);
        
        CGContextRef context = UIGraphicsGetCurrentContext();
        
        CGContextSetFillColorWithColor(context, [[UIColor clearColor] CGColor]);
        
        UIRectFill(CGRectMake(0, 0, asize.width, asize.height));//clear background
        
        [image drawInRect:rect];
        
        newimage = UIGraphicsGetImageFromCurrentImageContext();
        
        UIGraphicsEndImageContext();
        
    }
    
    return newimage;
    
}

- (UIView*)shareDarkMask{
    if(_shareDarkMask == nil)
    {
        _shareDarkMask = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
        _shareDarkMask.backgroundColor = [UIColor blackColor];
        
        _shareDarkMask.alpha = 0.4;
        
        _shareDarkMask.userInteractionEnabled = true;
        
        UITapGestureRecognizer * tapMask = [[UITapGestureRecognizer alloc]initWithTarget:_instance action:@selector(shareFadeOut)];
        
        [_shareDarkMask addGestureRecognizer:tapMask];
    }
    
    return _shareDarkMask;
}


- (void)wechatByPayInfo:(NSDictionary*)payInfo
{
    NSString * prePayId = payInfo[@"prepayId"];
    NSNumber * timeStamp = payInfo[@"timeStamp"];
    //调起微信支付
    PayReq* req             = [[PayReq alloc] init];
    req.partnerId           = payInfo[@"partnerId"];
    req.prepayId            = prePayId;
    req.nonceStr            = payInfo[@"nonceStr"];
    req.timeStamp           = timeStamp.intValue;
    req.package             = payInfo[@"package"];
    req.sign                = payInfo[@"sign"];
    
    [WXApi sendReq:req completion:^(BOOL success) {
        
    }];
}

- (void)showNeedRealNameView:(NSString*)contentDesc{
    
    RealNamePopView * popView = (RealNamePopView*)[Utils getXibByName:@"RealNamePopView"];
    
    popView.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
    
    popView.contentDesc = contentDesc;
    
    [popView fadeIn];
    
    [[Utils currentWindow] addSubview:popView];
    
}

- (void)showPayPopViewWithContent:(NSString*)content amount:(NSNumber*)amount :(InstancelGotoPayWithPassword)gotoPay retryInput:(RetryInputPassword)retryInput
{
    
    PayPwdPopView * popView = (PayPwdPopView*)[Utils getXibByName:@"PayPwdPopView"];
    
    
    if(amount.integerValue == 0)
    {
        [popView hiddenAmountLabel:true];
    }else{
        NSString * amountText = [NSString stringWithFormat:@"%.2lf",amount.floatValue * 0.01];
        popView.amountLabel.text = amountText;
        
        [Utils setUintWithLabel:popView.amountLabel andText:amountText fontSize:16];
    }
    popView.contentLabel.text = content;
    
    popView.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
    
    popView.popGotoPayWithPassword = ^(NSString * _Nonnull password) {
        
        gotoPay(password);
        
    };
    
    popView.passwordError = ^{
        retryInput();
    };
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [popView fadeIn];
    });
    
    [[Utils currentWindow] addSubview:popView];
}


- (void) onResp:(BaseResp*)resp
{
    if([resp isKindOfClass:[PayResp class]])
    {
        NSLog(@"支付信息");
        if(resp.errCode == 0)
        {
            NSLog(@"支付成功");
            if([SharedInstance getInstance].wechatPayResult)
            {
                [SharedInstance getInstance].wechatPayResult(1);
            }
        }else{
            if([SharedInstance getInstance].wechatPayResult)
            {
                [SharedInstance getInstance].wechatPayResult(0);
            }
        }
    }
}

- (void)checkLoginAndGotoLogin:(UIViewController*)vc
{
    UAFCustomModel * model = [[UAFCustomModel alloc]init];
    
    model.currentVC = vc;//必传
    model.logBtnOriginLR = @[@30,@30];
    model.logBtnHeight = 40;
    model.uncheckedImg = [UIImage imageNamed:@"ic_weixuan"];
    model.checkedImg = [UIImage imageNamed:@"ic_gouxuan"];
    model.checkboxWH = @(15);
    
    model.appPrivacyDemo = [[NSAttributedString alloc]initWithString:@"未注册手机号验证后自动注册，且代表您已阅读并同意《&&默认&&》平台《平台服务协议》和《隐私协议》" attributes:@{NSFontAttributeName:[UIFont systemFontOfSize: 12],NSForegroundColorAttributeName:UIColorFromRGB(0x666666)}];
    NSAttributedString *str1 = [[NSAttributedString alloc]initWithString:@"平台服务协议" attributes:@{NSLinkAttributeName:[NSString stringWithFormat:@"%@%@",BASE_WEB_URL,SERVICE_AGREEMENT]}];
    NSAttributedString *str2 = [[NSAttributedString alloc]initWithString:@"隐私协议" attributes:@{NSLinkAttributeName:[NSString stringWithFormat:@"%@%@",BASE_WEB_URL,PRIVATE_AGREEMENT]}];
    model.appPrivacy = @[str1,str2];
    
    
    UIImage * normalImage = [UIImage imageWithColor:[Utils getMainColor] size:CGSizeMake(SCREEN_WIDTH - 60, 40)];
    
    normalImage = [normalImage imageWithSize:normalImage.size radius:20];
    UIImage * highlightImage = [UIImage imageWithColor:[Utils getMainColor] size:CGSizeMake(SCREEN_WIDTH - 60, 40)];
    highlightImage = [highlightImage imageWithSize:highlightImage.size radius:20];
    UIImage * selectedImage = [UIImage imageWithColor:[Utils getMainColor] size:CGSizeMake(SCREEN_WIDTH - 60, 40)];
    selectedImage = [selectedImage imageWithSize:selectedImage.size radius:20];
    
    
    model.logBtnImgs = @[normalImage,highlightImage,selectedImage];
    
    model.privacyOffsetY = @([UIDevice dev_statusBarHeight] + 395);
    
    model.numberOffsetY = @([UIDevice dev_statusBarHeight] + 250);
    
    model.logBtnOffsetY = @([UIDevice dev_statusBarHeight] + 347);
    
    model.checkTipText = @"请勾选并阅读协议";
   
    model.authViewBlock = ^(UIView *customView, CGRect numberFrame , CGRect loginBtnFrame,CGRect checkBoxFrame, CGRect privacyFrame) {
        
        
        
        UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(20,  [Utils getStatusBarHeight:vc], 40, 40)];
        [btn setImage:[UIImage imageNamed:@"close_button_img"] forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(sssssdismiss) forControlEvents:(UIControlEventTouchUpInside)];
        [customView addSubview:btn];
        
        UILabel * descLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, [Utils getStatusBarHeight:vc] + 20, customView.frame.size.width - 30, 40)];
        
        descLabel.text = @"请使用企业登记的福利发放手机号";
        descLabel.textColor = UIColorFromRGB(0x222222);
        descLabel.font = [UIFont fontWithName:MEDIUM_FONT_NAME size:18];
        
        descLabel.textAlignment = NSTextAlignmentCenter;
        
        [customView addSubview:descLabel];
        
    
        
        UIImageView * logoView = [[UIImageView alloc] initWithFrame:CGRectMake((SCREEN_WIDTH - 80) * 0.5, [UIDevice dev_statusBarHeight] + 140, 80, 80)];
        
        logoView.image = [UIImage imageNamed:@"icon_logo"];
        
        [customView addSubview:logoView];
        
        
        UILabel * otherLabel = [[UILabel alloc] initWithFrame:CGRectMake((SCREEN_WIDTH - 84) * 0.5, SCREEN_HEIGHT - 128, 84, 20)];
        
        otherLabel.font = [UIFont fontWithName:DEFAULT_FONT_NAME size:14];
        
        otherLabel.textColor = UIColorFromRGB(0x999999);
        
        otherLabel.text = @"其他登录方式";
        
        [customView addSubview:otherLabel];
        
        
        
        UIView * lineLeft = [[UILabel alloc] initWithFrame:CGRectMake(otherLabel.frame.origin.x - 65, otherLabel.frame.origin.y + 10, 50, 1)];
        
        lineLeft.backgroundColor = UIColorFromRGB(0xEEEEEE);
        
        [customView addSubview:lineLeft];
        
        UIView * lineRight = [[UILabel alloc] initWithFrame:CGRectMake(otherLabel.frame.origin.x + otherLabel.frame.size.width + 15, lineLeft.frame.origin.y, 50, 1)];
        
        lineRight.backgroundColor = UIColorFromRGB(0xEEEEEE);
        
        [customView addSubview:lineRight];
        
        
        UIButton * otherLoginBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        
        otherLoginBtn.frame = CGRectMake((SCREEN_WIDTH - 40) * 0.5, SCREEN_HEIGHT - 88, 40, 40);
        
        [otherLoginBtn setImage:[UIImage imageNamed:@"ic_other_login"] forState:UIControlStateNormal];
        
        [otherLoginBtn addTarget:self action:@selector(gotoTelMsgLogin) forControlEvents:UIControlEventTouchUpInside];
        [customView addSubview:otherLoginBtn];
        
        UILabel * telLoginLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT - 38, SCREEN_WIDTH, 18)];
        
        telLoginLabel.textAlignment = NSTextAlignmentCenter;
        
        telLoginLabel.font = [UIFont fontWithName:DEFAULT_FONT_NAME size:12];
        
        telLoginLabel.textColor = UIColorFromRGB(0x666666);
        
        telLoginLabel.text = @"手机登录";
        
        [customView addSubview:telLoginLabel];
        
    };
    
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:vc.view animated:true];
    
    [UAFSDKLogin.shareLogin getAuthorizationWithModel:model complete:^(id  _Nonnull sender) {
        
        [hud hideAnimated:true];
        
        NSString * token = sender[TOKEN];
        
        NSString * resultCode = sender[@"resultCode"];
        
        if ([resultCode isEqualToString:@"200087"]) {
            NSLog(@"预取号成功");
        } else if(token == nil){
            NSLog(@"预取号失败");
            [_instance presentTelMsgLogin];
        }
        
        if(token && token.length > 0)
        {
            [ServiceManager onecKeyLoginWithToken:token success:^(NSDictionary *data) {
                
                NSDictionary * result = data;
                
                
                [self saveUserInfo:result];
                
            }];
            
            [UAFSDKLogin.shareLogin ua_dismissViewControllerAnimated:true completion:nil];
        }
        
    }];
}

- (void)presentTelMsgLogin{
    LoginViewController *loginVC = [Utils getViewControllerByStoryBoardName:@"User_Storyboard" andIdentifier:@"LoginVC"];
    [[Utils getCurrentVC] presentViewController:loginVC animated:true completion:nil];
}

- (void)gotoTelMsgLogin{
    LoginViewController *loginVC = [Utils getViewControllerByStoryBoardName:@"User_Storyboard" andIdentifier:@"LoginVC"];
    [[Utils getCurrentVC].navigationController pushViewController:loginVC animated:true];
}

- (void)saveUserInfo:(NSDictionary*)result
{
    UserInfo * userInfo = [[UserInfo alloc] initByDictionary:result];
    [BuglyManager setPhoneNum:userInfo.telephone];
    [SharedInstance getInstance].userInfo = userInfo;
    [SharedInstance getInstance].sid = userInfo.sid;
    [Utils setUserDefaultByKey:SID andValue:userInfo.sid];
    
    [Utils setUserDefaultByKey:COMPANY_ID andValue:[SharedInstance getInstance].userInfo.companyId];
    [Utils setUserDefaultByKey:COMPANY_NAME andValue:[SharedInstance getInstance].userInfo.companyName];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:EVET_HTML_LOGIN_CALL_BACK object:nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:EVENT_SGH_LOGIN_SUCCESS object:nil];
    
    [SharedInstance getInstance].isNeedUpdateHomePage = true;
}
- (void)sssssdismiss{
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [UAFSDKLogin.shareLogin ua_dismissViewControllerAnimated:true completion:nil];
    });
    
    
}


- (NSDictionary *)transTypeMap
{
    NSDictionary * dic = @{@"CAD":@"+",@"TAF":@"+",@"TAG":@"+",@"PRF":@"+",@"CAF":@"-",@"DAD":@"-",@"TAR":@"-",@"TAH":@"-"};
    
    return dic;
}

- (NSDictionary *)transTypeState
{
    NSDictionary * dic = @{@"CAD":@(2),@"TAF":@(3),@"TAG":@(3),@"PRF":@(2),@"CAF":@(1),@"DAD":@(1),@"TAR":@(1),@"TAH":@(4)};
    
    return dic;
}

- (NSDictionary *)transTypeName
{
    NSDictionary * dic = @{@"CAD":@"充值",@"TAF":@"企业转账",@"TAG":@"福利发放",@"PRF":@"消费退款",@"CAF":@"充值撤销",@"DAD":@"消费",@"TAR":@"福利过期",@"TAH":@"福利回收"};
    
    return dic;
}

//显示调用可地图的导航;
- (void)showNavigateMapActionViewControllerWithViewController:(UIViewController*)vc back:(SelectMapWithTitleBack)back
{
    //判断是否能打开百度地图
    NSMutableArray * maps = [NSMutableArray array];
    
    NSURL * baidu_App = [NSURL URLWithString:@"baidumap://"];
    if([[UIApplication sharedApplication] canOpenURL:baidu_App]) {
        [maps addObject:@"百度地图"];
    }

    //判断是否能打开高德地图
    NSURL * gaode_App = [NSURL URLWithString:@"iosamap://"];
    if ([[UIApplication sharedApplication] canOpenURL:gaode_App]) {
        [maps addObject:@"高德地图"];
    }
    
    //判断是否能打开腾讯地图；
    NSURL * qq_App = [NSURL URLWithString:@"qqmap://"];
    if([[UIApplication sharedApplication] canOpenURL:qq_App]){
        [maps addObject:@"腾讯地图"];
    }

    //判断是否能打开苹果地图
    NSURL * apple_App = [NSURL URLWithString:@"http://maps.apple.com/"];
    if ([[UIApplication sharedApplication] canOpenURL:apple_App]) {
        [maps addObject:@"Apple地图"];
    }
    
    
    UIAlertController * alert = [UIAlertController alertControllerWithTitle:@"选择" message:@"选择导航的地图" preferredStyle:UIAlertControllerStyleActionSheet];
    
    for(NSString * title in maps)
    {
        UIAlertAction * action = [UIAlertAction actionWithTitle:title style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            
            back(action.title);
            
        }];
        
        [alert addAction:action];
    }
    
    UIAlertAction * cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        //取消
//        [self dismissViewControllerAnimated:true completion:nil];
    }];
    
    
    [alert addAction:cancel];
    [vc presentViewController:alert animated:true completion:nil];
}



@end
