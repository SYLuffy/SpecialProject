//
//  StoryboardNames.h
//  HLGA
//
//  Created by Linus on 2018/5/23.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <Foundation/Foundation.h>

static NSString *const SB_NAME_USER = @"User_Storyboard";

static NSString *const SB_NAME_MAIN = @"Main_Storyboard";

static NSString *const SB_NAME_ME = @"Me_Storyboard";

static NSString *const SB_NAME_SORT = @"Sort_Storyboard";

static NSString *const SB_NAME_HOME = @"Home_Storyboard";

static NSString *const SB_NAME_MESSAGE = @"Message_Storyboard";

static NSString *const SB_NAME_CONVENIENTPAY = @"ConvenientPay_Storyboard";

static NSString *const SCAN_CODE = @"ScanCode";

static NSString *const SB_NAME_SETTING = @"Setting_Storyboard";

static NSString *const SB_NMAE_PAY = @"Pay_Storyboard";

static NSString *const SB_NAME_MERCHAT = @"Merchant_Storyboard";
