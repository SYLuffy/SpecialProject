//
//  WPDiscountModel.m
//  HLGA
//
//  Created by 谢丹 on 2021/10/26.
//  Copyright © 2021 Linus. All rights reserved.
//

#import "WPDiscountModel.h"

@implementation WPDiscountModel


- (instancetype)initByDictionary:(NSDictionary*)dic{
    self = [super init];
    if (self) {
        
        self.account = dic[@"account"];
        self.accountType = [dic[@"accountType"] integerValue];
        self.amount = [dic[@"amount"] integerValue];
        self.itemId = [dic[@"itemId"] integerValue];
        self.itemName = dic[@"itemName"];
        
        self.remark = dic[@"remark"];
        self.shopUrl = dic[@"shopUrl"];
        self.userId = dic[@"userId"];
        self.scanCode = [dic[@"scanCode"] integerValue];
        self.accountFundingType = dic[@"accountFundingType"];
        
        if ([dic[@"itemSeq"] isKindOfClass:[NSArray class]]) {
            self.itemSeq = dic[@"itemSeq"];
        }else{
            self.itemSeq = @[];
        }
    }
    return self;
    
    
}



@end
