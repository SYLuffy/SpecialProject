//
//  ServicesKey.h
//  CultureChengDu
//
//  Created by Linus on 2017/11/30.
//  Copyright © 2017年 Linus. All rights reserved.
//
#import <Foundation/Foundation.h>

static NSString *const DATE = @"date";

static NSString *const KEY_CODE = @"keycode";

static NSString *const KEY_WORD = @"keyword";

static NSString *const ZONE_CODES = @"zoneCodes";

static NSString *const ZONE_ID = @"zoneId";

static NSString *const SELECTION_CODES = @"selectionCodes";

static NSString *const SELECTION_CODE = @"selectionCode";

static NSString *const SELECTION_TYPE = @"selectionType";

static NSString *const RESULTS = @"results";

static NSString *const RESULT = @"result";

static NSString *const SYSTEM_TYPE = @"systemType";

static NSString *const PASSWORD = @"password";

static NSString *const LOGIN_PASSWORD = @"loginPassword";

static NSString *const SECURITY_CODE = @"verificationCode";

static NSString *const PUSH_TOKEN = @"usercid";

static NSString *const SID = @"sid";

static NSString *const PICTURE = @"picture";

static NSString *const BALANCE = @"balance";

static NSString *const CARD = @"card";

static NSString *const USER_AVATAR = @"head_portrait";

static NSString *const NICK_NAME = @"nickname";

static NSString *const CONDITION = @"condition";

static NSString *const AVOID_CLOSE = @"avoidClose";

static NSString *const PAY_PASSWORD = @"payPassword";

static NSString *const OLD_PWD = @"oldpassword";

static NSString *const NEW_PWD = @"newpassword";

static NSString *const STR = @"str";

static NSString *const CARD_NO = @"cardNo";

static NSString *const CARD_TYPE = @"cardType";

static NSString *const CARD_PWD = @"cardPwd";

static NSString *const OLD_PASSWORD = @"oldPassword";

static NSString *const NEW_PASSWORD = @"newPassword";

static NSString *const MONEY = @"money";

static NSString *const ORDER_INFO = @"orderInfo";

static NSString *const WECHAT_ID = @"token_id";

static NSString *const STATUS = @"status";

static NSString *const USER_ID = @"userId";

static NSString *const PHONE = @"phone";

static NSString *const FLAG = @"flag";

static NSString *const PAGE_SZ = @"PageSize";

static NSString *const PAGE_ID = @"pageId";

static NSString *const PAGE_INDEX = @"Page";

static NSString *const PAGE = @"page";

static NSString *const KEY = @"key";

static NSString *const PAGE_NUM = @"pageNum";

static NSString *const PAGE_SIZ = @"pageSize";

static NSString *const TYPE = @"type";

static NSString *const AMOUNT = @"amount";

static NSString *const BILL_DATE = @"date1";
static NSString *const BILL_TIME = @"date2";

static NSString *const MERCHANT_NAME = @"merchantName";

static NSString *const PAY_TYPE = @"payType";

static NSString *const OTHER_ORDER_ID = @"otherOrderId";

static NSString *const USE_MONEY = @"useMoney";

static NSString *const STATE = @"state";

static NSString *const BACK_URL = @"backUrl";

static NSString *const POINTS = @"points";

static NSString *const INTEGRAL = @"integral";

static NSString *const EXPIRY = @"expiry";

static NSString *const EXPIRY_TIME = @"expiryTime";

static NSString *const OPEN_TIME = @"openTime";

static NSString *const RETURN_POINTS = @"returnPoints";

static NSString *const ORDER_ID = @"orderId";

static NSString *const ORDER_NO = @"orderNo";

static NSString *const TYPE_ID = @"typeId";

static NSString *const TYPE_LOGO = @"typeLogo";

static NSString *const ID_LIST = @"idList";

static NSString *const ERROR_MSG = @"errorMsg";

static NSString *const TITLE = @"title";

static NSString *const CREATE_TIME = @"createTime";

static NSString *const CONTENT = @"content";

static NSString *const MERCHANT_AREA = @"merchant_area";
static NSString *const MERCHANTS = @"merchants";
static NSString *const MERCHANT = @"merchant";
static NSString *const MERCHANT_LIST = @"merchantList";
static NSString *const MERCHANT_PAGE = @"merchantPage";
static NSString *const MERCHANT_MAP = @"merchantMap";
static NSString *const MY_EQUITY = @"myEquity";
static NSString *const BIND_CARD = @"bindCard";

static NSString *const ID = @"id";

static NSString *const DECORATION_PAGE_ID = @"decorationPageId";

static NSString *const SYSTEM_MESSAGE = @"systemMessage";

static NSString *const HOT_MESSAGE_NUM = @"hotMessageNum";

static NSString *const HOT_NEW_MESSAGE = @"hotNewMessage";

static NSString *const READ_STATE = @"readState";

static NSString *const LATITUDE = @"latitude";
static NSString *const LONGITUDE = @"longitude";
static NSString *const AREA = @"area";
static NSString *const TOTAL = @"total";

static NSString *const ADDRESS = @"address";

static NSString *const DISTANCE = @"distance";

static NSString *const IMG = @"img";

static NSString *const MERCHANT_ID = @"merchantId";

static NSString *const MERCHANT_WHITE_LIST = @"merchantWhiteList";

static NSString *const INFORMATION = @"information";

static NSString *const TRANSACT = @"transact";

static NSString *const DEDUCTION_INTEGRAL = @"deduction_integral";

static NSString *const HEAD_PORTRAIT = @"head_portrait";

static NSString *const IS_AUTHENTICATE = @"is_authenticate";

static NSString *const CARD_BALANCE = @"cardBalance";

static NSString *const IN_THE_ACTIVITY = @"in_the_activity";

static NSString *const URL = @"url";

static NSString *const H5_URL = @"h5Url";

static NSString *const URL_TYPE = @"urlType";

static NSString *const ADVERTISING_ID_LIST = @"advertisingIdList";

static NSString *const IS_RANDOM = @"isRandom";

static NSString *const RANDOM_NUM = @"randomNum";

static NSString *const IMG_URL = @"imgUrl";

static NSString *const MAIN_IMAGE = @"mainImage";

static NSString *const TRAN_DATE = @"tranDate";
static NSString *const TRAN_TIME = @"traTime";
static NSString *const TRAN_TYPE = @"tranType";
static NSString *const TRAN_POINT = @"tranPoint";
static NSString *const ORDER_TYPE = @"orderType";
static NSString *const GO_TYPE = @"go_type";
static NSString *const REAL_NAME = @"realname";
static NSString *const ID_CARD = @"idcard";
static NSString *const TIME = @"time";
static NSString *const CMD = @"cmd";
static NSString *const ACCOUNT = @"account";
static NSString *const DATA = @"data";
static NSString *const PARAMS = @"params";
static NSString *const CODE = @"code";
static NSString *const RECORDS = @"records";
static NSString *const REMAINING_SECONDS = @"remainingSeconds";
static NSString *const PATH = @"path";
static NSString *const LIST_DATA = @"listData";
static NSString *const MODULE = @"module";
static NSString *const CID = @"cid";


static NSString *const CODE_MODEL_INIT_PASSWORD = @"updateInitialPassword";//发送初始密码验证码
static NSString *const CODE_MODEL_FORGET_PASSWORD = @"retrievePassword";//忘记密码验证码
static NSString *const CODE_MODEL_PAY_PASSWORD = @"retrievePayPassword";//忘记支付密码验证码
static NSString *const CODE_MODEL_UPDATE_CARD_PWD = @"updateCardPassword";//修改提货券密码；

static NSString *const IS_REMEBER_PASSWORD = @"isRemeberPassword";

static NSString *const NEWPASSWORD = @"newPassword";
static NSString *const OLDPASSWORD = @"oldPassword";
static NSString *const UNREAD_NUM = @"unreadNum";

static NSString *const TYPE_IMG = @"typeImg";
static NSString *const TYPE_NAME = @"typeName";
static NSString *const MESSAGE = @"message";
static NSString *const LIST = @"list";
static NSString *const BUTTON = @"button";
static NSString *const TOKEN = @"token";
static NSString *const CONTENT_TYPE = @"contentType";

static NSString *const LIMIT = @"limit";
static NSString *const OFFSET = @"offset";
static NSString *const BILLKEY = @"billkey";
static NSString *const REMARK = @"remark";
static NSString *const COMPANYID = @"companyid";
static NSString *const VERSION = @"version";
static NSString *const OTHER_ODER_ID = @"otherOrderId";

static NSString *const ACCOUNT_AMOUNT = @"accountAmount";
static NSString *const DESCRIPTION = @"description";
static NSString *const TIME_OUT = @"timeOut";
static NSString *const OTHER_AMOUNT = @"otherAmount";
static NSString *const TELEPHONE = @"telephone";
static NSString *const ORDER_NUMBER = @"orderNumber";

static NSString *const OTHER_SERIAL_NUMBER = @"otherSerialNumber";
static NSString *const PAY_ORDER_INFO = @"payOrderInfo";
static NSString *const VERSION_S = @"versions";
static NSString *const CREATE_TIMES = @"create_time";

static NSString *const ALIPAY_ENABLE = @"aliPay";//支付宝0关闭，1开启
static NSString *const WECHAT_ENABLE = @"weChatPay";//微信0关闭,1开启

static NSString *const ALIPAY_UNENABLE_TOAST = @"aliCloseDesc";//微信关闭描述
static NSString *const WECHAT_UNEANBLE_TOAST = @"weChatPayDesc";//支付宝关闭描述

static NSString *const OFF_FACE_ID_PAY = @"off_face_id_pay";
static NSString *const NO_FACE_ID_PAY = @"open_face_id_pay";

static NSString *const DO_NOT_ENABLE_FACE_ID_PAY = @"do_not_enable_face_id_pay";//用户选择不适用faceID进行支付，本次安装将不再提示开启.

static NSString *const NAME = @"name";

static NSString *const ENABLE = @"enable";

static NSString *const CAT_NAME = @"catName";

static NSString *const ITEM_NAME = @"itemName";

static NSString *const SHOW_NAME = @"showName";

static NSString *const ITEM_TYPE = @"itemType";

static NSString *const NAVIGATION = @"navigation";

static NSString *const NAVIGATION_LIST = @"navigationList";

static NSString *const ADVERTISE = @"advertise";

static NSString *const TOPIC = @"topic";

static NSString *const ADVERTISE_SLIDER = @"advertiseSlider";

static NSString *const ADVERTISE_RAMDOM = @"advertiseRandom";

static NSString *const BANNER = @"banner";

static NSString *const BANNER_LIST = @"bannerList";

static NSString *const HOME_PAGE = @"homePage";

static NSString *const SECTION = @"section";

static NSString *const APPLICATION_ID = @"applicationId";

static NSString *const IS_NAVTABS = @"isNavTabs";

static NSString *const NAVTABS_LIST = @"navTabsList";

static NSString *const LINE = @"line";

static NSString *const COLUMN = @"column";

static NSString *const HREF_URL = @"hrefUrl";

static NSString *const DESCRIPTION_URL = @"descriptionUrl";

static NSString *const JUMP_TYPE= @"jumpType";

static NSString *const TARGET = @"target";

static NSString *const SHOP_SET = @"shopSet";

static NSString *const WIDTH = @"width";

static NSString *const HEIGHT= @"height";

static NSString *const TOPIC_LIST = @"topicList";

static NSString *const TOPIC_LAYOUT = @"topicLayout";

static NSString *const TITLE_IMG_URL = @"titleImgUrl";

static NSString *const MAGIC_CUBE = @"magicCube";

static NSString *const LAYOUT = @"layout";

static NSString *const ELEMENT_WIDTH = @"elementWidth";

static NSString *const ELEMENT_HEIGHT = @"elementHeight";

static NSString *const CLASSIFY_LIST = @"classifyList";

static NSString *const CLASSIFY = @"classify";

static NSString *const CLASSIFY_ID = @"classifyId";

static NSString *const CURRENT_PAGE = @"currentPage";

static NSString *const CURRENT_OFFSET_X = @"currentOffsetX";

static NSString *const SUB_TITLE = @"subtitle";

static NSString *const IS_SUBTITLE = @"isSubtitle";

static NSString *const ACCOUNT_FUNDING_TYPE = @"accountFundingType";

static NSString *const ACCOUNT_ITEM_TYPE = @"accountItemType";

static NSString *const ITEM_MEDIUM_TYPE = @"itemMediumType";

static NSString *const PHYSICAL_CARD_NO = @"physicalCardNo";

static NSString *const BACKGROUND_COLOR = @"backgroundColor";

static NSString *const TEXT_COLOR = @"textColor";

static NSString *const SEL_TABS_COLOR = @"selTabsColor";

static NSString *const SEL_COLOR = @"selColor";

static NSString *const NOT_SEL_COLOR = @"notSelColor";

static NSString *const BG_COLOR_OPACITY = @"bgColorOpacity";

static NSString *const NUMBER = @"number";

static NSString *const MAX_NUMBER = @"maxNum";

static NSString *const PAY_PASSWORD_EMPTY = @"payPasswordEmpty";

static NSString *const PAY_SWITCH = @"paySwitch";

static NSString *const PAY_SWITCH_AMOUNT = @"paySwitchAmount";

static NSString *const SERIAL_NUMBER = @"serialNumber";

static NSString *const SWITCH = @"switch";

static NSString *const ITEM_PAY_ORDER = @"itemPayOrder";

static NSString *const WALLET_LIST = @"walletList";

static NSString *const WALLET_ID = @"walletId";

static NSString *const WALLET_NAME = @"walletName";

static NSString *const IS_PAY_INFO = @"isPayInfo";

static NSString *const PAY_INFO = @"payInfo";

static NSString *const PAY_SAAS_INFO = @"paySaasInfo";

static NSString *const IS_OPEN = @"isOpen";

static NSString *const PLATFORM_AMOUNT = @"platformAmount";

static NSString *const EXPIRATION_TIME = @"expirationTime";

static NSString *const USER_ACCOUNTS = @"userAccounts";

static NSString *const DETAILS = @"details";

static NSString *const EXPIRE_TIME = @"expireTime";

static NSString *const EXPIRED_TOTAL = @"expiredTotal";

static NSString *const ACCOUNT_FUNDING_TYPES = @"accountFundingTypes";

static NSString *const ACCOUNT_FUNDING_NAME = @"accountFundingName";

static NSString *const METHOD = @"method";

static NSString *const APP_ID = @"appId";

static NSString *const ITEMS = @"items";

static NSString *const SERVICE = @"service";

static NSString *const ITEM_ID = @"itemId";

static NSString *const TRANS_TYPE = @"transType";

static NSString *const MERCHANT_NUMBER = @"merchantNumber";

static NSString *const COMPANY_ID = @"companyId";

static NSString *const COMPANY_NAME = @"companyName";

static NSString *const LOGO = @"logo";

static NSString *const CHANNEL_ID = @"channelId";

static NSString *const CLIENT_TYPE = @"clientType";

static NSString *const DETAIL = @"detail";

static NSString *const BOTTOM_DETAIL = @"bottomDetail";

static NSString *const TX_TIME = @"txTime";

static NSString *const PLATE_TYPE = @"plateType";

static NSString *const MARKET_PRICE = @"marketPrice";

static NSString *const SALE_PRICE = @"salePrice";

static NSString *const BEGIN_DATE = @"beginDate";

static NSString *const END_DATE = @"endDate";

static NSString *const END_TIME = @"endTime";

static NSString *const C_SUM_AMOUNT = @"cSumAmount";

static NSString *const D_SUM_AMOUNT = @"dSumAmount";

static NSString *const GOODS_ZONE = @"goodsZone";

static NSString *const COUPON = @"coupon";

static NSString *const COUPON_LIST = @"couponList";

static NSString *const COUPON_ID = @"couponId";

static NSString *const BG_IMAGE = @"bgImage";

static NSString *const BG_COLOR = @"bgColor";

static NSString *const SEARCH_BG_COLOR = @"searchBgColor";

static NSString *const ICON_URL = @"iconUrl";

static NSString *const ICON_JUMP = @"iconJump";

static NSString *const MSG = @"msg";

static NSString *const NORMAL_IMG = @"normalImg";

static NSString *const SELECTED_IMG = @"selectedImg";

static NSString *const INATIVE_COLOR = @"inactiveColor";

static NSString *const ACTIVE_COLOR = @"activeColor";

static NSString *const INACTIVE = @"inactive";

static NSString *const ACTIVE = @"active";

static NSString *const GOODS_SELECTION_LIST = @"goodsSelectionList";

static NSString *const HISTORY_USER_SEARCH_DATAS = @"historyUerSearchDatas";

static NSString *const CARD_EXCHANGE_URL = @"cardExchangeUrl";

static NSString *const CARD_EXCHANGE = @"cardExchange";

static NSString *const OFFLINE_MERCHANT_URL = @"offlineMerchantUrl";

static NSString *const GUIDE_TEXT_URL = @"guideTextUrl";

static NSString *const CARDS = @"cards";

static NSString *const CARD_ITEMS = @"cardItems";

static NSString *const GUIDE_TEXT_TYPE = @"guideTextType";

static NSString *const GUIDE_TEXT = @"guideText";

static NSString *const SHOP_URL = @"shopUrl";

static NSString *const SHOP_URL_TYPE = @"shopUrlType";

static NSString *const SKU_NO = @"skuNo";

static NSString *const SPU_NO = @"spuNo";

static NSString *const IS_SHOW_MORE = @"isShowMore";

static NSString *const IS_SHOW_TITLE = @"isShowTitle";

static NSString *const IS_COUNT_DOWN = @"isCountdown";

static NSString *const USER_FUND_UNIT = @"userFundUnit";

static NSString *const PAY_NAME = @"payName";

static NSString *const SUM_AMOUNT = @"sumAmount";

static NSString *const ACTIVITY_ID = @"activityId";

static NSString *const TEMPLATE_ID = @"templateId";

static NSString *const TEMPLATE_CODE = @"templateCode";

static NSString *const NO_RECEIVE_WIDTH = @"noReceiveImgWidth";

static NSString *const NO_RECEIVE_HEIGHT = @"noReceiveImgHeight";

static NSString *const COUPON_ACTIVITY_ID = @"couponActivityId";

static NSString *const COUPON_TEMPLATE_CODES = @"couponTemplateCodes";

static NSString *const COUPONS = @"coupons";

static NSString *const TIPS = @"tips";

static NSString *const DESC_TYPE = @"descType";

static NSString *const DESC_CONTENT = @"descContent";

static NSString *const TITLE_IMG = @"titleImg";

static NSString *const PRODUCT_SET = @"productSet";

static NSString *const CHILDREN = @"children";

static NSString *const CATEGORIES = @"categories";

static NSString *const LEVEL = @"level";

static NSString *const CATEGROY = @"category";

static NSString *const PLATFORM_CATEGORIES = @"platformCategories";

static NSString *const TEMP_DEFAULT_HOME_PAGE = @"tempDefaultHomePage";

static NSString *const TEMP_DEFAULT_BOTTOM_LIST = @"tempDefaultBottomList";

static NSString *const TAG = @"tag";

static NSString *const OTHER_DATA = @"otherData";

static NSString *const MERCHANT_DATA = @"merchantData";

static NSString *const RES_ID = @"resId";

static NSString *const NOTICE = @"notice";

static NSString *const ALBUMS = @"albums";

static NSString *const PAY_TEXT = @"payText";

static NSString *const BUSINESS_TIME = @"businessTime";

static NSString *const BRAND_INFO = @"brandInfo";

static NSString *const BRAND_LOGO = @"brandLogo";

static NSString *const BRAND_INDEX = @"brandIndex";

static NSString *const BRAND_INDEX_LIST = @"brandIndexList";

static NSString *const BRAND_NOTICE = @"brandNotice";

static NSString *const BRAND_NAME = @"brandName";

static NSString *const MERCHANT_DESC = @"merchantDesc";

static NSString *const MERCHANT_COUNT = @"merchantCount";

static NSString *const BRAND_INTRODUCTION = @"brandIntroduction";

static NSString *const CAPITA = @"capita";

static NSString *const SHOPPING_LIST = @"shoppingList";

static NSString *const SHOPPING_AREA_NAME = @"shoppingAreaName";

static NSString *const SEARCH_AREA_INDEX = @"searchAreaIndex";

static NSString *const MERCHANT_TYPE_INDEX = @"merchantTypeIndex";

static NSString *const SORT_TYPE_INDEX = @"sortTypeIndex";

static NSString *const BLACK_WHITE_ID_LIST = @"blackWhiteIdList";

static NSString *const CHILD_LIST = @"childList";

static NSString *const AREA_NAME = @"areaName";

static NSString *const BLACK_WHITE_ID = @"blackWhiteId";

static NSString *const COUNT = @"count";

static NSString *const CORRECTION = @"correction";

static NSString *const IS_SELECTED = @"isSelected";

static NSString *const NUMBER_EQUITIES = @"numberEquities";

static NSString *const IMAGE = @"image";

static NSString *const IS_TITLE = @"isTitle";

static NSString *const DISCOUNT = @"discount";

static NSString *const SLIDES_SHOW = @"slideshow";

static NSString *const IS_WHITE_LIST = @"isWhitelist";

static NSString *const WHITE_IDS = @"whiteIds";

static NSString *const USE_RP_AMOUNT = @"useRpAmount";

static NSString *const RP_AMOUNT = @"rpAmount";

static NSString *const RP_ITEM_NAME = @"rpItemName";

static NSString *const RP_ITEMS = @"rpItems";

static NSString *const RP_ITEM_ID = @"rpItemId";

static NSString *const FIXED_BOTTOM = @"fixedBottom";

