//
//  WPUrlString.h
//  HLGA
//
//  Created by 葛亮 on 2018/6/26.
//  Copyright © 2018年 Linus. All rights reserved.
//

#ifdef DEBUG

#define BASE_WEB_URL @"https://h5dev.heleguanai.com/"

/**
 蜀光惠平台服务协议
 */

#define SERVICE_AGREEMENT @"/cdn/html/20230828/2a8222a89a9b5f2f93cdf261371f54f1.html"

/**
 蜀光惠隐私政策服务协议
 */

#define PRIVATE_AGREEMENT @"/cdn/html/20230828/60cb37eb8098c2b2fc891dc99bc8309c.html"
/**
免密支付服务协议
 */

#define SECRET_PAYMEMT_SERVICE_AGREEMENT @"/cdn/html/20230828/267c5ff5afed392982a1d9e2f2da5fd5.html"

/**
 生活服务缴费协议
 */

#define LIFE_PAYMEMT_SERVICE_AGREEMENT @"/service_protocol/livingExpenses_service_protocol.html"



/**
 可绑定福利地址
 */
#define WATCH_CAN_USE_WELFARE_URL @"https://bc-cdn.ygfuli.com/html/20240416/b204ddcf3076544e40f72439a6030828.html"


#else

#define BASE_WEB_URL @"https://bc-cdn.ygfuli.com"


/**
 蜀光惠平台服务协议
 */

#define SERVICE_AGREEMENT @"/html/20230831/2c3f0338427e686082fd8b90ff5f2bc8.html"

/**
 蜀光惠隐私政策服务协议
 */

#define PRIVATE_AGREEMENT @"/html/20230831/24cdb744e33bebffaad830efbb59050c.html"
/**
免密支付服务协议 
 */

#define SECRET_PAYMEMT_SERVICE_AGREEMENT @"/html/20230831/055ad26d134403156ce3ddb3baafdc47.html"

/**
 生活服务缴费协议
 */

#define LIFE_PAYMEMT_SERVICE_AGREEMENT @"/service_protocol/livingExpenses_service_protocol.html"


/**
 可绑定福利地址
 */
#define WATCH_CAN_USE_WELFARE_URL @"https://bc-cdn.ygfuli.com/html/20240416/b204ddcf3076544e40f72439a6030828.html"

#endif










 





