//
//  Utils.h
//  HLGA
//
//  Created by Linus on 2018/5/14.
//  Copyright © 2018年 Linus. All rights reserved.
//-

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "WPLivingPaymentENUM.h"

typedef void(^RefreshUserInfo)(BOOL isCompleted);
typedef void(^RefreshPayPasswordStatus)(BOOL isCompleted);

static bool isProduction = true;

@interface Utils : NSObject

typedef void(^ConfirmBack)(BOOL isConfirm);
typedef void(^CancelBack)(void);

+ (void)showToast:(NSString*)msg;

+ (void) alertWithTitle:(NSString *)title msg:(NSString *)msg;


+ (void)gradualChangeBottomToTopColor:(CALayer*)layer withStartColor:(int64_t)startColor withEndColor:(int64_t)endColor;
+ (void)gradualChangeLeftToRightColor:(CALayer*)layer withStartColor:(int64_t)startColor withEndColor:(int64_t)endColor;

+ (NSString*)getBaseUrl;


+ (NSString*)getHost;


+ (NSString*)getNOCardPayHost;

+ (long)getNOCardPort;

+ (void)setUserDefaultByKey:(NSString*)key andValue:(id)value;

+ (id)getUserDefaultByKey:(NSString*)key;

+(BOOL)accountTextRule:(UITextField *)textField;

+ (BOOL)passwordTextRule:(UITextField*)textField;

+ (BOOL)passwordPayTextRule:(UITextField*)textField;

+ (BOOL)accountNumberTextRule:(UITextField*)textField;

+ (BOOL)securityCodeTextRule:(UITextField*)textField;

+ (NSString*)dictionaryToJson:(NSDictionary *)dic;

+ (NSDictionary *)dictionaryWithJsonString:(NSString *)jsonString;

+ (NSDictionary*)loadJsonWithFileName:(NSString*)fileName;

+ (BOOL) setPassword:(NSString *)password forService:(NSString *)serviceName;

+ (NSString *) passwordForService:(NSString *)serviceName;

+ (BOOL) deletePasswordForService:(NSString *)serviceName;

+ (void)securityButtonCountDown:(UIButton*)securityCodeButton;//倒计时

+ (void)dissmissToViewController:(Class)toClass andCurrentVC:(UIViewController*)currentVC;

+ (void)labelColorAttributedString:(UILabel*)label andRange:(NSRange)range color:(UIColor *)color size:(CGFloat)size;
+ (void)labelColorAttributedStripingString:(UILabel*)label andRange:(NSRange)range color:(UIColor *)color size:(CGFloat)size;

+ (void)labelColorAttributedStripingString:(UILabel*)label andRange:(NSRange)range color:(UIColor *)color size:(CGFloat)size hasUint:(BOOL)hasUint;

+ (__kindof UIViewController *)getViewControllerByStoryBoardName:(NSString*)storyBoardName andIdentifier:(NSString*)identifier;

+ (UIViewController*)getInitViewControllerByStoryBoardName:(NSString*)storyBoardName;

+ (CGFloat)getNavigationBarAndStatusBarHeight:(UIViewController*)vc;

+ (CGFloat)getNavigationBarHeight:(UIViewController*)vc;

+ (CGFloat)getStatusBarHeight:(UIViewController*)vc;

+ (UIImage*)imageFromLayer:(CALayer*)layer;

+ (void)setHomeIndexCustomNavigationBar:(UIViewController*)vc;

+ (void)setDefaultNavigationBar:(UIViewController*)vc;

+ (void)setNavigationBarBackgroundWithColor:(UIColor*)color titleColor:(UIColor*)titleColor vc:(UIViewController*)vc;

+ (void)setClearNavigationBar:(UIViewController*)vc titleColor:(UIColor*)titleColor;



+ (NSString*)getGlobalFontName;

+ (void)loadImage:(UIImageView*)imageView andURL:(NSString*)imageUrl isLoadRepeat:(BOOL)repeat;
+(void)pushWebViewControllerURL:(NSString *)url owner:(UIViewController *)owner;

+ (NSNumber*)getGlobalPageSize;

+ (NSString*)getDateByTime:(NSString*)time fomatter:(NSString*)fomatter;

+ (NSString*)getSimpleDateByTime:(NSString*)time andHasYear:(BOOL)hasYear;

+ (NSString*)getBonusPointsDateByTime:(NSString*)time;

+ (NSString*)getRechargePaymentDateByTime:(NSString*)time;

+(CGFloat)caculateHeightBen:(NSString *)title font:(NSInteger)font size:(CGSize)size;

+ (NSMutableAttributedString*)attributeStringUnderLine:(NSString*)string color:(UIColor*)color;

+ (UIImage *) getImage:(NSInteger)imgtype setData:(NSString *)datas setWidth:(int)width setHeight:(int)height;

+ (void)drawDashLine:(UIView *)lineView lineLength:(int)lineLength lineSpacing:(int)lineSpacing lineColor:(UIColor *)lineColor;

+ (UIViewController *)getCurrentVC;

+ (UIViewController *)getCurrentVCFrom:(UIViewController *)rootVC;

+ (BOOL)checkObjectIsNull:(id)object;

+(BOOL)checkJudgeKey:(NSString *)key Dict:(NSDictionary *)dict;

+(WPJudgeObjType)checkJudgeObjType:(id)resultObj;
+(void)popToViewController:(Class )target owner:(__kindof UIViewController *)owner;

+ (void)loadHomeItemCompanyLogo:(NSString*)url imageView:(UIImageView*)imageView;

+ (NSString*)getComplexDateByTime:(NSString*)time;

+(BOOL)pushPaymentPasswordOwner:(__kindof UIViewController *)owner;

+ (BOOL)getPayHasSpecialPoints;
+ (BOOL)iPhoneFiveCheck;

+ (void)alertWithTitle:(NSString*)title msg:(NSString*)msg andConfirm:(ConfirmBack)confirmBack cancel:(CancelBack)cancel;

+ (void) alertWithTitle:(NSString *)title msg:(NSString *)msg confirm:(ConfirmBack)confirm;

+ (void)clearAppBadge;

+ (void)gradualButtonLeftToRightColor:(CALayer*)layer withStartColor:(int64_t)startColor withEndColor:(int64_t)endColor;

+ (void)setQiYuInfo;

+(NSString *)returnBankCard:(NSString *)bankCardStr;

+ (CGSize)getTextSizeByFont:(UIFont*)font andMaxSize:(CGSize)maxSize andText:(NSString*)text;

+ (BOOL)isJailBreak;

+ (BOOL)getProduction;
+ (UIView*)getXibByName:(NSString*)xibName;

+ (NSData *) imageCompress:(UIImage *)sourceImage;

+ (NSString *)jointWithString:(NSString *)str num:(NSInteger)num;

+ (BOOL)getPayHasSpecialPoints:(NSDictionary*)orderDic;

+ (void)refreshUserInfo:(RefreshUserInfo)completed;

+ (void)refreshPayPasswordStatus:(RefreshPayPasswordStatus)completed;


+ (BOOL)validateContainsChinese:(NSString *)content;

+ (UIColor*)getMainColor;

+ (void)cornerRadiusTopLRWithView:(UIView*)view withRadius:(CGFloat)radius;

+ (void)cornerRadiusTopLRWithView:(UIView*)view rect:(CGRect)rect withRadius:(CGFloat)radius;

+ (void)cornerRadiusBottomLRWithView:(UIView*)view withRadius:(CGFloat)radius;

+ (void)cornerRadiusBottomLRWithView:(UIView*)view rect:(CGRect)rect withRadius:(CGFloat)radius;


+ (CGFloat)getLabelWidthByHeight:(CGFloat)height andContent:(NSString*)content andFont:(UIFont*)font;

+ (CGFloat)getLabelHeightByWidth:(CGFloat)width andContent:(NSString*)content andFont:(UIFont*)font;
+ (BOOL)checkLoginAndGotoLogin:(UIViewController*)vc;


+ (UIWindow *)currentWindow;

//获取当前时间戳 （以秒为单位）
+ (NSString *)getNowTimeTimestamp;

//添加打折线；
+ (void)labelAddSaleLine:(UILabel*)label;

//添加样式;
+ (void)setUintWithLabel:(UILabel*)label andText:(NSString*)text fontSize:(CGFloat)fontSize;

//添加样式范围
+ (void)setUintWithLabel:(UILabel*)label andText:(NSString*)text fontSize:(CGFloat)fontSize rangeLength:(NSInteger)rangeLength;

//返回时分秒
+ (NSString *)timeWithSecond:(NSInteger)totalSeconds;

//检查是否是连续或者是相同数字
+ (BOOL)checkPincode:(NSString*)pincode;

//货币格式转换;
+ (NSString *)stringFromNumber:(NSNumber *)currencyNumber;

//银行卡加空格;
+ (NSString *)getNewBankNumWitOldBankNum:(NSString *)bankNum;

+ (BOOL)isNumber:(NSString*)string;

+ (BOOL)verifyIDCardString:(NSString *)idCardString;

+ (void)gradualLeftToRightColor:(CALayer*)layer withColor:(UIColor*)startColor withColor:(UIColor*)endColor;


@end
