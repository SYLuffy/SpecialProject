//
//  UIView+WPRadius.h
//  WisdomPension
//
//  Created by 苏凡 on 2019/9/1.
//  Copyright © 2019 谢丹. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIView (WPRadius)



- (void)hw_maskViewWithRoundingCorners:(UIRectCorner)corners cornerRadii:(CGSize)cornerRadii;

- (void)hw_maskTop;
- (void)hw_maskBottom;
- (void)hw_maskAll;

- (void)hw_maskLeftTopRadius:(CGFloat)radius;
- (void)hw_maskRightTopRadius:(CGFloat)radius;
- (void)hw_maskLeftBottomRadius:(CGFloat)radius;
- (void)hw_maskRightBottomRadius:(CGFloat)radius;


- (void)hw_maskTopRadius:(CGFloat)radius;
- (void)hw_maskBottomRadius:(CGFloat)radius;
- (void)hw_maskAllRadius:(CGFloat)radius;
- (void)hw_maskRightRadius:(CGFloat)radius;
- (void)hw_maskLeftRadius:(CGFloat)radius;


- (void)hw_shadowWithCornerdius:(CGFloat)cornerdius color:(UIColor *)shadowColor shadowOffset:(CGSize)shadowOffset;



@end


@interface UITableView (WPRadius)

- (void)hw_changeToCardStyle;

@end


NS_ASSUME_NONNULL_END
