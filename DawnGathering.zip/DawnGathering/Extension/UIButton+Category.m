//
//  UIButton+Category.m
//  HLGA
//
//  Created by Linus on 2018/5/15.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "UIButton+Category.h"

@implementation UIButton (Category)

- (void)gradualDefaultButton{
    [Utils gradualButtonLeftToRightColor:self.layer withStartColor:0xFDA23F withEndColor:0xFDA23F];

}

- (void)securityStyleButton{
    
    self.layer.masksToBounds = true;
    self.layer.borderWidth = 1;
    self.layer.borderColor = [Utils getMainColor].CGColor;
    self.layer.cornerRadius = 5;
    
}

//设置按钮变灰
- (void)setGrayEnable:(BOOL)enable
{
    if(enable == false)
    {
        self.userInteractionEnabled = true;
        self.alpha = 1;
    }else{
        self.userInteractionEnabled = false;
        self.alpha = 0.5;
    }
}

@end
