//
//  CALayer+GALayerColor.h
//  GARWM
//
//  Created by 葛亮 on 2018/4/11.
//  Copyright © 2018年 葛亮. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import <UIKit/UIKit.h>

@interface CALayer (GALayerColor)
- (void)setBorderColorFromUIColor:(UIColor *)color;

@end
