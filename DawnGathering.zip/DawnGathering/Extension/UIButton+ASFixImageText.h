//
//  UIButton+ASFixImageText.h
//  SellSignName
//
//  Created by xiedan-PuHui on 2017/5/23.
//  Copyright © 2017年 谢丹. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, ASImageTextPostionStyle) {
    ASImageTextPostionStyleImageTop = 0,
    ASImageTextPostionStyleImageLeft,
    ASImageTextPostionStyleImageBottom,
    ASImageTextPostionStyleImageRight
};

@interface UIButton (ASFixImageText)

/**
 图文排列

 @param imageTextStyle 图片在的位置，默认 margin为0
 */
- (void)setImageTextStyle:(ASImageTextPostionStyle)imageTextStyle;

/**
 图文排列
 
 @param imageTextStyle 图片在的位置
 @param insertSpace 图文中间间隔距离
 */
- (void)setImageTextStyle:(ASImageTextPostionStyle)imageTextStyle insertSpace:(CGFloat)insertSpace;

/**
 图文排列
 
 @param imageTextStyle 图片在的位置
 @param margin 图文到button边缘距离
 */

- (void)setImageTextStyle:(ASImageTextPostionStyle)imageTextStyle margin:(CGFloat )margin;




@end
