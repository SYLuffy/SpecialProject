//
//  MBProgressHUD+Add.m
//  视频客户端
//
//  Created by mj on 13-4-18.
//  Copyright (c) 2013年 itcast. All rights reserved.
//

#import "MBProgressHUD+Add.h"

@implementation MBProgressHUD (Add)

#pragma mark 显示信息

+ (void)show:(NSString *)text icon:(NSString *)icon view:(UIView *)view
{
    if (view == nil) view = [UIApplication sharedApplication].keyWindow;
    // 快速显示一个提示信息
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view animated:YES];
    hud.label.text = text;
    // 设置图片
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:[NSString stringWithFormat:@"MBProgressHUD.bundle/%@", icon]]];
    hud.customView = imageView;
    // 再设置模式
    hud.mode = MBProgressHUDModeCustomView;
    
    // 隐藏时候从父控件中移除
    hud.removeFromSuperViewOnHide = YES;
    
    // 1秒之后再消失
    [hud hideAnimated:YES afterDelay:1.2];
}

#pragma mark 显示错误信息
+ (void)showError:(NSString *)error toView:(UIView *)view{
    [self show:error icon:@"error.png" view:view];
}

+ (void)showSuccess:(NSString *)success toView:(UIView *)view
{
    [self show:success icon:@"success.png" view:view];
}

+ (void)showWaring:(NSString *)waring toView:(UIView *)view
{
    [self show:waring icon:@"" view:view];
}


#pragma mark 显示一些信息
+ (MBProgressHUD *)showMessag:(NSString *)message toView:(UIView *)view {
    if (view == nil) view = [UIApplication sharedApplication].keyWindow;
     [MBProgressHUD hideHUDForView:view animated:NO];
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view animated:YES];
    hud.label.text = message;
    hud.removeFromSuperViewOnHide = YES;
    return hud;
}

+ (MBProgressHUD *)creatHUDWithProgress:(NSString *)message toView:(UIView *)view
{
    if (view == nil) view = [UIApplication sharedApplication].keyWindow;
    
    MBProgressHUD *hud = [[MBProgressHUD alloc] initWithView:view];
    hud.label.text = message;
    // 隐藏时候从父控件中移除
    hud.removeFromSuperViewOnHide = YES;
    hud.mode = MBProgressHUDModeDeterminateHorizontalBar;
    hud.progress = 0;
    
    return hud;
}

+ (void)showAutoHidenMessag:(NSString *)success toView:(UIView *)view afterDelay:(NSTimeInterval)delay dismissed:(MBProgressHUDCompletionBlock)block {
    if (view == nil) view = [UIApplication sharedApplication].keyWindow;
    // 快速显示一个提示信息
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view animated:YES];
    hud.label.text = success;
    hud.backgroundView.backgroundColor = [UIColor redColor];
    success.length<=6 ? : [hud.label setFont:[UIFont systemFontOfSize:14]];
    // 再设置模式
    hud.mode = MBProgressHUDModeText;
    
    // 隐藏时候从父控件中移除
    hud.removeFromSuperViewOnHide = YES;
    hud.completionBlock = block;
    // 1秒之后再消失
    //    [hud hide:YES afterDelay:delay];
    [hud hideAnimated:YES afterDelay:delay];
}

+ (void)showAutoHidenMessag:(NSString *)message toView:(UIView *)view {
    [self showAutoHidenMessag:message toView:view afterDelay:1.f];
}

+ (void)showAutoHidenMessag:(NSString *)message toView:(UIView *)view afterDelay:(NSTimeInterval)delay {
    if (view == nil) view = [UIApplication sharedApplication].keyWindow;
    // 快速显示一个提示信息
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view animated:YES];
    hud.label.text = message;
    hud.label.numberOfLines = 0;
    message.length<=6 ? : [hud.label setFont:[UIFont systemFontOfSize:14]];
    // 再设置模式
    hud.mode = MBProgressHUDModeText;
    
    // 隐藏时候从父控件中移除
    hud.removeFromSuperViewOnHide = YES;
    [hud hideAnimated:YES afterDelay:delay];
}

+ (void)showAutoHidenMessag:(NSString *)success toView:(UIView *)view dismissed:(MBProgressHUDCompletionBlock)block {
    if (view == nil) view = [UIApplication sharedApplication].keyWindow;
    // 快速显示一个提示信息
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view animated:YES];
    hud.label.text = success;
    success.length<=6 ? : [hud.label setFont:[UIFont systemFontOfSize:14]];
    // 再设置模式
    hud.mode = MBProgressHUDModeText;
    
    // 隐藏时候从父控件中移除
    hud.removeFromSuperViewOnHide = YES;
    hud.completionBlock = block;
    // 1秒之后再消失
    //    [hud hide:YES afterDelay:delay];
    [hud hideAnimated:YES afterDelay:1.5];

}

@end
