//
//  NSHTTPCookie+Extension.m
//  HLGA
//
//  Created by 葛亮 on 2018/6/11.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "NSHTTPCookie+Extension.h"

@implementation NSHTTPCookie (Extension)
- (NSString *)da_javascriptString
{
    NSString *string = [NSString stringWithFormat:@"%@=%@;domain=%@;path=%@",
                        self.name,
                        self.value,
                        self.domain,
                        self.path ?: @"/"];
    if (self.secure) {
        string = [string stringByAppendingString:@";secure=true"];
    }
    return string;
}
@end
