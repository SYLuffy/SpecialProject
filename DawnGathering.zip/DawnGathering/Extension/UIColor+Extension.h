//
//  UIColor+Extension.h
//  HLGA
//
//  Created by 葛亮 on 2018/5/22.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (Extension)
+ (UIColor *)colorWithHexString:(NSString *)hexString; //String like "e85a5a" as rgb
+ (UIColor *)colorWithHexString:(NSString *)hexString alpha:(CGFloat)alpha;
@end
