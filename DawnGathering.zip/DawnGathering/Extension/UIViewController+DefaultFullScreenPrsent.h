//
//  UIViewController+DefaultFullScreenPrsent.h
//  TIFamily
//
//  Created by 李冬岐 on 2019/9/30.
//  Copyright © 2019 葛亮. All rights reserved.
//

#import <objc/runtime.h>


#import <UIKit/UIKit.h>


void VC_Swizzle(Class c, SEL orig, SEL new)
{
    Method origMethod = class_getInstanceMethod(c, orig);
    Method newMethod = class_getInstanceMethod(c, new);
    if(class_addMethod(c, orig, method_getImplementation(newMethod), method_getTypeEncoding(newMethod)))
        class_replaceMethod(c, new, method_getImplementation(origMethod), method_getTypeEncoding(origMethod));
    else
        method_exchangeImplementations(origMethod, newMethod);
}


NS_ASSUME_NONNULL_BEGIN

@interface UIViewController (DefaultFullScreenPrsent)

@end

NS_ASSUME_NONNULL_END
