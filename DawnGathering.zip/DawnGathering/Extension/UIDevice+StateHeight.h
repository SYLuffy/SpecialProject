//
//  UIDevice+StateHeight.h
//  DawnGathering
//
//  Created by 李冬岐 on 2023/7/14.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIDevice (StateHeight)


/**顶部安全区高度*/
+(CGFloat)dev_safeDistanceTop;
/**底部安全区高度*/
+ (CGFloat) dev_safeDistanceBottom;
/**顶部状杰栏高度（包括安全区）*/
+ (CGFloat) dev_statusBarHeight;


@end

NS_ASSUME_NONNULL_END
