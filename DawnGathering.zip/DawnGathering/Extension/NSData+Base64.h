//
//  NSData+Base64.h
//  HLGA
//
//  Created by 葛亮 on 2018/7/16.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSData (Base64)
+ (NSData *)dataWithBase64EncodedString:(NSString *)string;
- (NSString *)base64EncodedStringWithWrapWidth:(NSUInteger)wrapWidth;
- (NSString *)base64EncodedString;

@end
