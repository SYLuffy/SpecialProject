//
//  UIView+WPRadius.m
//  WisdomPension
//
//  Created by 苏凡 on 2019/9/1.
//  Copyright © 2019 谢丹. All rights reserved.
//

#import "UIView+WPRadius.h"

@implementation UIView (WPRadius)


- (void)hw_maskViewWithRoundingCorners:(UIRectCorner)corners cornerRadii:(CGSize)cornerRadii {
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:self.bounds byRoundingCorners:corners cornerRadii:cornerRadii];
        CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
        maskLayer.frame = self.bounds;
        maskLayer.path = maskPath.CGPath;
        self.layer.mask = maskLayer;
    });
    
}

- (void)hw_shadowWithCornerdius:(CGFloat)cornerdius color:(UIColor *)shadowColor shadowOffset:(CGSize)shadowOffset{
    
    self.layer.shadowColor = shadowColor.CGColor;
    self.layer.shadowOffset = shadowOffset;
    self.layer.shadowOpacity = 0.5;
    self.layer.shadowRadius = cornerdius;
    
    float shadowPathWidth = self.layer.shadowRadius;
    CGRect shadowRect = CGRectMake(0, 0 - shadowPathWidth/2.0, self.bounds.size.width, shadowPathWidth);
    UIBezierPath *path = [UIBezierPath bezierPathWithRect:shadowRect];
    self.layer.shadowPath = path.CGPath;
}

//默认半径为5
- (void)hw_maskTop {
    [self hw_maskViewWithRoundingCorners:UIRectCornerTopLeft | UIRectCornerTopRight cornerRadii:CGSizeMake(5, 5)];
}
- (void)hw_maskBottom {
    [self hw_maskViewWithRoundingCorners:UIRectCornerBottomLeft | UIRectCornerBottomRight cornerRadii:CGSizeMake(5, 5)];
}

- (void)hw_maskAll {
    [self hw_maskViewWithRoundingCorners:UIRectCornerAllCorners  cornerRadii:CGSizeMake(5, 5)];
}


//设置单边

- (void)hw_maskLeftTopRadius:(CGFloat)radius{
    [self hw_maskViewWithRoundingCorners:UIRectCornerTopLeft cornerRadii:CGSizeMake(radius, radius)];
}


- (void)hw_maskRightTopRadius:(CGFloat)radius{
    [self hw_maskViewWithRoundingCorners: UIRectCornerTopRight cornerRadii:CGSizeMake(radius, radius)];
}

- (void)hw_maskLeftBottomRadius:(CGFloat)radius{
     [self hw_maskViewWithRoundingCorners:UIRectCornerBottomLeft cornerRadii:CGSizeMake(radius, radius)];
}

- (void)hw_maskRightBottomRadius:(CGFloat)radius{
     [self hw_maskViewWithRoundingCorners:UIRectCornerBottomRight cornerRadii:CGSizeMake(radius, radius)];
}



//
- (void)hw_maskTopRadius:(CGFloat)radius{
    [self hw_maskViewWithRoundingCorners:UIRectCornerTopLeft | UIRectCornerTopRight cornerRadii:CGSizeMake(radius, radius)];
}

- (void)hw_maskBottomRadius:(CGFloat)radius{
    [self hw_maskViewWithRoundingCorners:UIRectCornerBottomLeft | UIRectCornerBottomRight cornerRadii:CGSizeMake(radius, radius)];
}

- (void)hw_maskLeftRadius:(CGFloat)radius{
    [self hw_maskViewWithRoundingCorners:UIRectCornerTopLeft | UIRectCornerBottomLeft cornerRadii:CGSizeMake(radius, radius)];
}

- (void)hw_maskRightRadius:(CGFloat)radius{
    [self hw_maskViewWithRoundingCorners:UIRectCornerTopRight | UIRectCornerBottomRight cornerRadii:CGSizeMake(radius, radius)];
}


- (void)hw_maskAllRadius:(CGFloat)radius{
    [self hw_maskViewWithRoundingCorners:UIRectCornerAllCorners  cornerRadii:CGSizeMake(radius, radius)];
}

@end


@implementation UITableView (WPRadius)

- (void)hw_changeToCardStyle {
    
    
    UITableViewCell *first = self.visibleCells.firstObject;
    UITableViewCell *last = self.visibleCells.lastObject;
    
    [first hw_maskTop];
    [last hw_maskBottom];
    
}

@end
