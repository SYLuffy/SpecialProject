//
//  UICollectionViewLeftAlignedLayout.h
//  SCST
//
//  Created by 葛亮 on 2019/5/16.
//  Copyright © 2019 葛亮. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UICollectionViewLeftAlignedLayout : UICollectionViewFlowLayout
@end
/**
 *  Just a convenience protocol to keep things consistent.
 *  Someone could find it confusing for a delegate object to conform to UICollectionViewDelegateFlowLayout
 *  while using UICollectionViewLeftAlignedLayout.
 */
@protocol UICollectionViewDelegateLeftAlignedLayout <UICollectionViewDelegateFlowLayout>

@end
NS_ASSUME_NONNULL_END
