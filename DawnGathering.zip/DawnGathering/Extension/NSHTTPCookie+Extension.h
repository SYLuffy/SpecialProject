//
//  NSHTTPCookie+Extension.h
//  HLGA
//
//  Created by 葛亮 on 2018/6/11.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSHTTPCookie (Extension)
- (NSString *)da_javascriptString;

@end
