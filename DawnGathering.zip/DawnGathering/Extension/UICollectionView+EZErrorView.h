//
//  UICollectionView+EZErrorView.h
//  HLGA
//
//  Created by 葛亮 on 2018/7/5.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef NS_ENUM(NSUInteger, EZErrorCollectionViewType) {
    EZErrorCollectionViewTypeDefault,
    EZErrorCollectionViewTypeNetwork,
    EZErrorCollectionViewTypeEmpty,
    EZErrorCollectionViewTypeProgress
};

@protocol UICollectionViewErrorViewDataSource <UICollectionViewDataSource>
@optional
- (EZErrorCollectionViewType)collectionViewTypeOfErrorViewToShow:(UICollectionView *)collectionView;
@end

@interface UICollectionView (EZErrorView)

- (void)setErrorView:(UIView *)view ForType:(EZErrorCollectionViewType)errorType;
- (void)showErrorViewWithType:(EZErrorCollectionViewType)errorType;
- (void)dismissErrorView;

@end
