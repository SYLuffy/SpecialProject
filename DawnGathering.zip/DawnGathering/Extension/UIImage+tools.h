//
//  UIImage+tools.h
//  bashiBus
//
//  Created by ye on 15/12/2.
//  Copyright © 2015年 4GInter. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (tools)
+ (UIImage *)imageWithColor:(UIColor *)color size:(CGSize)size;
+(UIImage*)OriginImage:(UIImage *)image scaleToSize:(CGSize)size;
//画出带圆角矩形

- (UIImage *)imageWithSize:(CGSize)size radius:(CGFloat)radius;
@end
