//
//  UITableView+EZErrorView.m
//  HLGA
//
//  Created by 葛亮 on 2018/6/1.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "UITableView+EZErrorView.h"
#import <objc/runtime.h>

static const NSString *EZErrorViewDictionaryAssociatedKey = @"EZErrorViewDictionaryAssociatedKey";

@interface UITableView (EZErrorViewPrivate)
@property (nonatomic, readonly) NSMutableDictionary *viewDict;
@end

void EZ_Swizzle(Class c, SEL orig, SEL new)
{
    Method origMethod = class_getInstanceMethod(c, orig);
    Method newMethod = class_getInstanceMethod(c, new);
    if(class_addMethod(c, orig, method_getImplementation(newMethod), method_getTypeEncoding(newMethod)))
        class_replaceMethod(c, new, method_getImplementation(origMethod), method_getTypeEncoding(origMethod));
    else
        method_exchangeImplementations(origMethod, newMethod);
}

@implementation UITableView (EZErrorViewPrivate)
- (NSMutableDictionary *)viewDict
{
    NSMutableDictionary *dict = objc_getAssociatedObject(self, &EZErrorViewDictionaryAssociatedKey);
    
    if (!dict) {
        dict = [[NSMutableDictionary alloc] init];
        UIView *view = [UIView new];
        view.backgroundColor = [UIColor whiteColor];
        [dict setObject:view forKey:@(EZErrorViewTypeDefault)];
        objc_setAssociatedObject(self, &EZErrorViewDictionaryAssociatedKey, dict, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        
    }
    return dict;
}
@end


@implementation UITableView (EZErrorView)
+ (void)load
{
    Class class = [UITableView class];
    EZ_Swizzle(class, @selector(reloadData), @selector(EZ_ReloadData));
}

- (void)setErrorView:(UIView *)view ForType:(EZErrorViewType)errorType
{
    UIView *oldView = self.viewDict[@(errorType)];
    if (oldView && oldView.superview) {
        [oldView removeFromSuperview];
    }
    self.viewDict[@(errorType)] = view;
}

- (void)EZ_ReloadData
{
    [self EZ_ReloadData];
    NSUInteger numberOfRows = 0;
    for (NSInteger sectionIndex = 0; sectionIndex < self.numberOfSections; sectionIndex++) {
        numberOfRows += [self numberOfRowsInSection:sectionIndex];
    }
    EZErrorViewType type = EZErrorViewTypeEmpty;
    if ([self.dataSource respondsToSelector:@selector(tableViewTypeOfErrorViewToShow:)]) {
        type = [(id<UITableViewErrorViewDataSource>)self.dataSource tableViewTypeOfErrorViewToShow:self];
    }
    if (numberOfRows <= 0) {
        [self showErrorViewWithType:type];
    } else {
        [self dismissErrorView];
    }
}

- (void)showErrorViewWithType:(EZErrorViewType)errorType
{
    for (id key in self.viewDict.allKeys) {
        if (errorType == [key unsignedIntegerValue]) {
            UIView *view = self.viewDict[@(errorType)];
            
            
            view.frame = CGRectMake(0, self.tableHeaderView.frame.size.height, self.bounds.size.width, self.bounds.size.height - self.tableHeaderView.frame.size.height);
            [self addSubview:view];
            
        } else {
            UIView *oldView = self.viewDict[key];
            if (oldView && oldView.superview) {
                [oldView removeFromSuperview];
            }
        }
    }
}

- (void)dismissErrorView
{
    for (id key in self.viewDict.allKeys) {
        UIView *oldView = self.viewDict[key];
        if (oldView && oldView.superview) {
            [oldView removeFromSuperview];
        }
    }
}
@end
