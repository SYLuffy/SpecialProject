//
//  UINavigationController+StatusBarStyle.m
//  HLGA
//
//  Created by 谢丹 on 2021/11/5.
//  Copyright © 2021 Linus. All rights reserved.
//

#import "UINavigationController+StatusBarStyle.h"

@implementation UINavigationController (StatusBarStyle)

-(UIViewController *)childViewControllerForStatusBarStyle{
    return self.visibleViewController;
}

-(UIViewController *)childViewControllerForStatusBarHidden{
    return  self.visibleViewController;
}


@end
