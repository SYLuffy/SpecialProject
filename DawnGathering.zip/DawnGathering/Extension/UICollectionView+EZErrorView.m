//
//  UICollectionView+EZErrorView.m
//  HLGA
//
//  Created by 葛亮 on 2018/7/5.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "UICollectionView+EZErrorView.h"
#import <objc/runtime.h>

static const NSString *EZErrorCollectionViewDictionaryAssociatedKey = @"EZErrorCollectionViewDictionaryAssociatedKey";

@interface UICollectionView (EZErrorViewPrivate)

@property (nonatomic, readonly) NSMutableDictionary *viewDict;

@end

void EZC_Swizzle(Class c, SEL orig, SEL new)
{
    Method origMethod = class_getInstanceMethod(c, orig);
    Method newMethod = class_getInstanceMethod(c, new);
    if(class_addMethod(c, orig, method_getImplementation(newMethod), method_getTypeEncoding(newMethod)))
        class_replaceMethod(c, new, method_getImplementation(origMethod), method_getTypeEncoding(origMethod));
    else
        method_exchangeImplementations(origMethod, newMethod);
}

@implementation UICollectionView (EZErrorViewPrivate)

- (NSMutableDictionary *)viewDict
{
    NSMutableDictionary *dict = objc_getAssociatedObject(self, &EZErrorCollectionViewDictionaryAssociatedKey);
    
    if (!dict) {
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:[UIView new] forKey:@(EZErrorCollectionViewTypeDefault)];
        objc_setAssociatedObject(self, &EZErrorCollectionViewDictionaryAssociatedKey, dict, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    return dict;
}
@end

@implementation UICollectionView (EZErrorView)
+ (void)load
{
    Class class = [UICollectionView class];
    EZC_Swizzle(class, @selector(reloadData), @selector(EZC_ReloadData));
}

- (void)setErrorView:(UIView *)view ForType:(EZErrorCollectionViewType)errorType
{
    UIView *oldView = self.viewDict[@(errorType)];
    if (oldView && oldView.superview) {
        [oldView removeFromSuperview];
    }
    self.viewDict[@(errorType)] = view;
}

- (void)EZC_ReloadData
{
    [self EZC_ReloadData];
    NSUInteger numberOfRows = 0;
    for (NSInteger sectionIndex = 0; sectionIndex < self.numberOfSections; sectionIndex++) {
        numberOfRows += [self numberOfItemsInSection:sectionIndex];
    }
    EZErrorCollectionViewType type = EZErrorCollectionViewTypeEmpty;
    if ([self.dataSource respondsToSelector:@selector(collectionViewTypeOfErrorViewToShow:)]) {
        type = [(id<UICollectionViewErrorViewDataSource>)self.dataSource collectionViewTypeOfErrorViewToShow:self];
    }
    
    if (numberOfRows <= 0) {
        [self showErrorViewWithType:type];
    } else {
        [self dismissErrorView];
    }
}

- (void)showErrorViewWithType:(EZErrorCollectionViewType)errorType
{
    for (id key in self.viewDict.allKeys) {
        if (errorType == [key unsignedIntegerValue]) {
            UIView *view = self.viewDict[@(errorType)];
            view.frame = CGRectMake(0, 0, self.bounds.size.width, self.bounds.size.height);
            [self addSubview:view];
            
        } else {
            UIView *oldView = self.viewDict[key];
            if (oldView && oldView.superview) {
                [oldView removeFromSuperview];
            }
        }
    }
}

- (void)dismissErrorView
{
    for (id key in self.viewDict.allKeys) {
        UIView *oldView = self.viewDict[key];
        if (oldView && oldView.superview) {
            [oldView removeFromSuperview];
        }
    }
}
@end
