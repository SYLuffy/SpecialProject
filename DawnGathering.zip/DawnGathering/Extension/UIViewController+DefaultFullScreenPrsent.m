//
//  UIViewController+DefaultFullScreenPrsent.m
//  TIFamily
//
//  Created by 李冬岐 on 2019/9/30.
//  Copyright © 2019 葛亮. All rights reserved.
//

#import "UIViewController+DefaultFullScreenPrsent.h"



@implementation UIViewController (DefaultFullScreenPrsent)

+ (void)load{
    
    Class class = [UIViewController class];
    VC_Swizzle(class,  @selector(presentViewController:animated:completion:),  @selector(default_PresentedViewController:animated:completion:));
    
}

- (void)default_PresentedViewController:(UIViewController*)viewControllerToPresent animated: (BOOL)flag completion:(void (^ __nullable)(void))completion
{
    if (viewControllerToPresent.modalPresentationStyle != 4 ) {
        viewControllerToPresent.modalPresentationStyle = UIModalPresentationFullScreen;
        [self default_PresentedViewController:viewControllerToPresent animated:flag completion:completion];
    }else{
        [self default_PresentedViewController:viewControllerToPresent animated:flag completion:completion];
    }
}

@end
