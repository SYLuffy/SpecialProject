//
//  UINavigationController+SGProgress.h
//  bashiBus
//
//  Created by 葛亮 on 16/3/15.
//  Copyright © 2016年 4GInter. All rights reserved.
//

#import <UIKit/UIKit.h>
#define kSGProgressTitleChanged @"kSGProgressTitleChanged"
#define kSGProgressOldTitle @"kSGProgressOldTitle"
#define WEBTimeoutInterval 15.0

@interface UINavigationController (SGProgress)

- (void)showSGProgress;
- (void)showSGProgressWithDuration:(float)duration;
- (void)showSGProgressWithDuration:(float)duration andTintColor:(UIColor *)tintColor;
- (void)showSGProgressWithDuration:(float)duration andTintColor:(UIColor *)tintColor andTitle:(NSString *)title;
- (void)showSGProgressWithMaskAndDuration:(float)duration;
- (void)showSGProgressWithMaskAndDuration:(float)duration andTitle:(NSString *) title;


- (void)setSGProgressPercentage:(float)percentage;
- (void)setSGProgressPercentage:(float)percentage andTitle:(NSString *)title;
- (void)setSGProgressPercentage:(float)percentage andTintColor:(UIColor *)tintColor;
- (void)setSGProgressMaskWithPercentage:(float)percentage;
- (void)setSGProgressMaskWithPercentage:(float)percentage andTitle:(NSString *)title;


- (void)finishSGProgress;
- (void)cancelSGProgress;
@end
