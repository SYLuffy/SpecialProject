//
//  UIColor+Extension.m
//  HLGA
//
//  Created by 葛亮 on 2018/5/22.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "UIColor+Extension.h"

@implementation UIColor (Extension)
+ (UIColor *)colorWithHexString:(NSString *)hexString
{
    return [UIColor colorWithHexString:hexString alpha:1];
}


+ (UIColor *)colorWithHexString:(NSString *)hexString alpha:(CGFloat)alpha
{
    if (!hexString || hexString.length < 6) {
        return nil;
    }
    
    
    NSString * tempString = [hexString stringByReplacingOccurrencesOfString:@"#" withString:@""];
    
    NSString *upperStr = tempString.uppercaseString;
    NSString *redStr = [@"0x" stringByAppendingString:[upperStr substringWithRange:NSMakeRange(0, 2)]];
    NSString *greenStr = [@"0x" stringByAppendingString:[upperStr substringWithRange:NSMakeRange(2, 2)]];
    NSString *blueStr = [@"0x" stringByAppendingString:[upperStr substringWithRange:NSMakeRange(4, 2)]];
    NSInteger red = strtoul([redStr UTF8String], 0, 16);
    NSInteger green = strtoul([greenStr UTF8String], 0, 16);
    NSInteger blue = strtoul([blueStr UTF8String], 0, 16);
    
    UIColor *color = [UIColor colorWithRed:(CGFloat)red/255.0 green:(CGFloat)green/255.0 blue:(CGFloat)blue/255.0 alpha:alpha];
    return color;
}


@end
