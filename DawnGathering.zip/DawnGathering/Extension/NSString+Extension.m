//
//  NSString+AccountInfoCheck.m
//  ButlerCard
//
//  Created by johnny tang on 4/11/14.
//  Copyright (c) 2014 johnny tang. All rights reserved.
//

#import "NSString+Extension.h"
#import <CommonCrypto/CommonDigest.h>

#define phonePredicate @"^[0-9]{11}$" // 手机号码
#define fixedPhone @"(\\(\\d{3,4}\\)|\\d{3,4}-|\\s)?\\d{6,14}" //固话测试
#define nickNamePredicate @"^[a-zA-Z0-9_\\u4E00-\\u9FA5\\w]{2,10}$" // 中文，数字，字母，2-10位
#define numberPredicate @"^[0-9]*$"//是否为数字 3位

#define emailPredicate @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
#define passwordPredicate @"^[a-zA-Z0-9_]{6,12}$" // 字母数字或下划线 6-12位
#define payPasswordPredicate @"^[0-9]{6}$" // 数字，6位
#define verificationcodePredicate @"^[0-9]{4}$" // 数字，6位
#define cardNumberPredicate @"^[0-9]{19}$" // 和信通卡号
#define cardNumberSpacePredicate @"^[0-9\x20]{22}$" // 和信通卡号(带空格格式的)
//#define moneyPredicate @"^([0-9]+|[0-9]{1,3}(,[0-9]{3})*)(.[0-9]{1,2})?$" // 金额，小数点后两位，允许逗号分割
#define moneyPredicate @"^[0-9]{0,5}$" // 金额，小数点后两位，允许逗号分割
#define identifyPredicate @"^(\\d{14}|\\d{17})(\\d|[xX])$" // 身份证,第一代身份证都是15位
#define identifyChinese @"^[\u4E00-\u9FA5]{2,8}$" // 匹配中文
#define identifyEnglish @"^[a-zA-Z\/ ]{2,20}$" // 匹配中文
#define identifyID @"^([0-9]{17}[0-9X]{1})|([0-9]{15})$"
#define moneyPredicatecharge @"^(([1-9]{1}\\d*)|([0]{1}))(\\.(\\d){0,2})?$"// 金额，小数点后两位，允许逗号分割

@implementation NSString (AccountInfoCheck)

- (BOOL)isValidMoneyCharge {
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", moneyPredicatecharge];
    return [pred evaluateWithObject:self];
}
- (BOOL)isVaildNumber {
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", numberPredicate];
    return [pred evaluateWithObject:self];
}

- (BOOL)isValidFixedPhone {
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", fixedPhone];
    
    return [pred evaluateWithObject:self];
    
}

- (BOOL)isValidPhone {
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", phonePredicate];
    
    return [pred evaluateWithObject:self];
}

- (BOOL)isValidPassword {
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", passwordPredicate];
    
    return [pred evaluateWithObject:self];
}

- (BOOL)isValidPayPassword {
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", payPasswordPredicate];
    
    return [pred evaluateWithObject:self];
}

- (BOOL)isValidEmail{
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailPredicate];
    
    return [pred evaluateWithObject:self];
}

- (BOOL)isValidNickName{
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", nickNamePredicate];
    
    return [pred evaluateWithObject:self];
}

- (BOOL)isVaildVerificationCode{
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", verificationcodePredicate];
    
    return [pred evaluateWithObject:self];
}

- (BOOL)isValidMyShopAccount {
    //    NSLog(@"isValidMyShopAccount self = %@ %@",self, (self.length > 3 && [self hasPrefix:@"sh"])? @"YES":@"NO");
    return self.length > 3 && [self hasPrefix:@"sh"];
}

- (BOOL)isValidCardNumber {
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", cardNumberPredicate];
    
    return [pred evaluateWithObject:self];
}

- (BOOL)isValidSpaceCardNumber {
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", cardNumberSpacePredicate];
    
    return [pred evaluateWithObject:self];
}

- (BOOL)isValidMoney {
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", moneyPredicate];
    
    return [pred evaluateWithObject:self];
}

- (BOOL)isValidIdentify {
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", identifyPredicate];
    
    return [pred evaluateWithObject:self];
}

- (BOOL)isValidChinese {
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", identifyChinese];
    
    return [pred evaluateWithObject:self];
}
- (BOOL)isValidID {
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", identifyID];
    
    return [pred evaluateWithObject:self];
}

- (BOOL)isValidEnglish {
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", identifyEnglish];
    
    return [pred evaluateWithObject:self];
}
- (BOOL)containsString4Seven:(NSString *)aString{
    if ([self rangeOfString:aString].location != NSNotFound) {
        return YES;
    }
    return NO;

}

+ (NSString *)bankCardSpaceFormat:(NSString *)string
{
    NSMutableString *carString = [NSMutableString stringWithString:string];
    if (carString.length == 19 ) {
        
        [carString insertString:@" " atIndex:5];
        [carString insertString:@" " atIndex:11];
        [carString insertString:@" " atIndex:17];
        
    }
    return carString;

}

+ (NSString *)bankPasswordFormat:(NSString *)string {
    NSMutableString *carString = [NSMutableString stringWithString:string];
    if (carString.length == 19 ) {
        [carString replaceCharactersInRange:NSMakeRange(0, 5)   withString:@"***** "];
        [carString replaceCharactersInRange:NSMakeRange(6, 5)   withString:@"***** "];
        [carString replaceCharactersInRange:NSMakeRange(12, 5)  withString:@"***** "];
        
    }
    return carString;

}
@end

@implementation NSString (md5)

-(NSString *)md5 {
    const char *cStr = [self UTF8String];
    unsigned char result[16];
    CC_MD5(cStr, (CC_LONG)strlen(cStr), result); // This is the md5 call
    return [NSString stringWithFormat:
            @"%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x",
            result[0], result[1], result[2], result[3],
            result[4], result[5], result[6], result[7],
            result[8], result[9], result[10], result[11],
            result[12], result[13], result[14], result[15]
            ];
}

@end


@implementation NSString (TextFieldText)
// 调用textField(textField: UITextField, shouldChangeCharactersInRange时，第一个输入的字符不会进入前面一个方法，此方法就是将第一个字符插入[futureString insertString:string atIndex:range.location]
- (NSString *) changeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    NSMutableString * futureString = [NSMutableString stringWithString:self];
    if (range.length == 0) {
        [futureString insertString:string atIndex:range.location];
    } else {
        [futureString deleteCharactersInRange:range];
    }
    
    return futureString;
}

/**
 转码为中文
 
 @param TransformUnicodeString 转码前
 @return 转码后
 */
-(NSString*)replaceUnicode:(NSString*)TransformUnicodeString

{
    
    NSString*tepStr1 = [TransformUnicodeString stringByReplacingOccurrencesOfString:@"\\u"withString:@"\\U"];
    NSString*tepStr2 = [tepStr1 stringByReplacingOccurrencesOfString:@"\""withString:@"\\\""];
    NSString*tepStr3 = [[@"\""  stringByAppendingString:tepStr2]stringByAppendingString:@"\""];
    NSData*tepData = [tepStr3  dataUsingEncoding:NSUTF8StringEncoding];
    NSString*axiba = [NSPropertyListSerialization propertyListWithData:tepData options:NSPropertyListMutableContainers format:NULL error:NULL];
    
    return  [axiba stringByReplacingOccurrencesOfString:@"\\r\\n"withString:@"\n"];
    
}

- (NSString*)convertToJSONData:(id)infoDict
{
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:infoDict
                                                       options:NSJSONWritingPrettyPrinted // Pass 0 if you don't care about the readability of the generated string
                                                         error:&error];
    NSString *jsonString = @"";
    
    if (! jsonData)
    {
        NSLog(@"Got an error: %@", error);
    }else
    {
        jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    }
    
    jsonString = [jsonString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];  //去除掉首尾的空白字符和换行字符
    
    [jsonString stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    
    [jsonString stringByReplacingOccurrencesOfString:@"\\" withString:@""];
    
    return jsonString;
}
@end
