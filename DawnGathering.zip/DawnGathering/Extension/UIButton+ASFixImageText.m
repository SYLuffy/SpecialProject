//
//  UIButton+ASFixImageText.m
//  SellSignName
//
//  Created by xiedan-PuHui on 2017/5/23.
//  Copyright © 2017年 谢丹. All rights reserved.
//

#import "UIButton+ASFixImageText.h"

@implementation UIButton (ASFixImageText)

- (void)setImageTextStyle:(ASImageTextPostionStyle)imageTextStyle {
    [self setImageTextStyle:imageTextStyle margin:0];
}

- (void)setImageTextStyle:(ASImageTextPostionStyle)imageTextStyle insertSpace:(CGFloat)insertSpace {

    
    CGFloat imageWith = self.imageView.image.size.width;
    CGFloat imageHeight = self.imageView.image.size.height;
    CGFloat labelWidth = [self.titleLabel.text sizeWithAttributes:@{NSFontAttributeName:self.titleLabel.font}].width;
    CGFloat labelHeight = [self.titleLabel.text sizeWithAttributes:@{NSFontAttributeName:self.titleLabel.font}].height;
    
    //image中心移动的x距离
    CGFloat imageOffsetX = labelWidth / 2 ;
    //image中心移动的y距离
    CGFloat imageOffsetY = labelHeight / 2 + insertSpace / 2;
    //label中心移动的x距离
    CGFloat labelOffsetX = imageWith/2;
    //label中心移动的y距离
    CGFloat labelOffsetY = imageHeight / 2 + insertSpace / 2;
    
    switch (imageTextStyle) {
        case ASImageTextPostionStyleImageTop:
            self.imageEdgeInsets = UIEdgeInsetsMake(-imageOffsetY, imageOffsetX, imageOffsetY, -imageOffsetX);
            self.titleEdgeInsets = UIEdgeInsetsMake(labelOffsetY, -labelOffsetX, -labelOffsetY, labelOffsetX);
            break;
            
        case ASImageTextPostionStyleImageLeft:
            self.imageEdgeInsets = UIEdgeInsetsMake(0, -insertSpace/2, 0, insertSpace/2);
            self.titleEdgeInsets = UIEdgeInsetsMake(0, insertSpace/2, 0, -insertSpace/2);
            break;
            
        case ASImageTextPostionStyleImageBottom:
            self.imageEdgeInsets = UIEdgeInsetsMake(imageOffsetY, imageOffsetX, -imageOffsetY, -imageOffsetX);
            self.titleEdgeInsets = UIEdgeInsetsMake(-labelOffsetY, -labelOffsetX, labelOffsetY, labelOffsetX);
            break;
            
        case ASImageTextPostionStyleImageRight:
            self.imageEdgeInsets = UIEdgeInsetsMake(0, labelWidth + insertSpace/2, 0, -(labelWidth + insertSpace/2));
            self.titleEdgeInsets = UIEdgeInsetsMake(0, -(imageHeight + insertSpace/2), 0, imageHeight + insertSpace/2);
            break;
            
        default:
            break;
    }
}

- (void)setImageTextStyle:(ASImageTextPostionStyle)imageTextStyle margin:(CGFloat )margin {
    CGFloat imageWith = self.imageView.image.size.width;
    CGFloat labelWidth = [self.titleLabel.text sizeWithAttributes:@{NSFontAttributeName:self.titleLabel.font}].width;
    CGFloat spacing = self.bounds.size.width - imageWith - labelWidth - 2*margin;
    
    [self setImageTextStyle:imageTextStyle insertSpace:spacing];
}



@end
