//
//  UIImage+tools.m
//  bashiBus
//
//  Created by ye on 15/12/2.
//  Copyright © 2015年 4GInter. All rights reserved.
//

#import "UIImage+tools.h"

@implementation UIImage (tools)
+ (UIImage *)imageWithColor:(UIColor *)color size:(CGSize)size
{
    CGRect rect = CGRectMake(0,  0, size.width, size.height );
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextSetFillColorWithColor (context, color.CGColor);
    CGContextFillRect (context, rect);
    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return img;
}

//画出带圆角矩形

- (UIImage *)imageWithSize:(CGSize)size radius:(CGFloat)radius
{
    CGRect rect = CGRectMake(0,  0, size.width, size.height );
    UIGraphicsBeginImageContextWithOptions(size, NO, UIScreen.mainScreen.scale);
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    // 根据radius的值画出路线

    CGContextAddPath(context, [UIBezierPath bezierPathWithRoundedRect:rect cornerRadius:radius].CGPath);

    // 裁剪
    CGContextClip(UIGraphicsGetCurrentContext());
    
    [self drawInRect:rect];
    
    
    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
    
    
    UIGraphicsEndImageContext();
    
    return img;
}

+(UIImage*)OriginImage:(UIImage *)image scaleToSize:(CGSize)size
{
    UIGraphicsBeginImageContext(size);
    [image drawInRect:CGRectMake(0, 0, size.width, size.height)];
    UIImage* scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return scaledImage;
}
@end
