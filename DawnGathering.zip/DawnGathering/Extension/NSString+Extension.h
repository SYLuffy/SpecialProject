//
//  NSString+Extension.h
//  ButlerCard
//
//  Created by johnny tang on 4/11/14.
//  Copyright (c) 2014 johnny tang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (AccountInfoCheck)

- (BOOL)isValidMoneyCharge;
- (BOOL)isValidFixedPhone;
- (BOOL)isValidPhone;
- (BOOL)isValidPassword;
- (BOOL)isValidPayPassword;
- (BOOL)isValidEmail;
- (BOOL)isValidNickName;
- (BOOL)isVaildVerificationCode;
- (BOOL)isValidMyShopAccount;
- (BOOL)isValidCardNumber;
- (BOOL)isValidSpaceCardNumber;
- (BOOL)isValidMoney;
- (BOOL)isValidIdentify;
- (BOOL)isValidChinese;
- (BOOL)isValidEnglish;
- (BOOL)isVaildNumber;
- (BOOL)isValidID;
- (BOOL)containsString4Seven:(NSString *)aString;

// Formart
// 62424 12341 12344 1234
+ (NSString *)bankCardSpaceFormat:(NSString *)string;

// ***** ***** ***** 1234
+ (NSString *)bankPasswordFormat:(NSString *)string;
@end


@interface NSString (md5)

-(NSString *)md5;

@end

@interface NSString (TextFieldText)

- (NSString *) changeCharactersInRange:(NSRange)range replacementString:(NSString *)string;

-(NSString*)replaceUnicode:(NSString*)TransformUnicodeString;

- (NSString*)convertToJSONData:(id)infoDict;
@end
