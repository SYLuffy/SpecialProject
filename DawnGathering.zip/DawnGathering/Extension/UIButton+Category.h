//
//  UIButton+Category.h
//  HLGA
//
//  Created by Linus on 2018/5/15.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (Category)

- (void)gradualDefaultButton;
- (void)securityStyleButton;
- (void)setGrayEnable:(BOOL)enable;
@end
