//
//  UIDevice+StateHeight.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/7/14.
//

#import "UIDevice+StateHeight.h"

@implementation UIDevice (StateHeight)

//顶部安全区域高度
+ (CGFloat)dev_safeDistanceTop
{
    if(@available(iOS 13.0 , *)){
        
        NSSet *set = [UIApplication sharedApplication].connectedScenes;
        UIWindowScene *windowScene = [set anyObject];
        UIWindow *window = windowScene.windows.firstObject;
        return window.safeAreaInsets.top;
    }else if(@available(iOS 11.0, *))
    {
        UIWindow * window = [UIApplication sharedApplication].windows.firstObject;
        return window.safeAreaInsets.top;
    }
    return 0;
}

//底部安全区域
+ (CGFloat)dev_safeDistanceBottom
{
    if(@available(iOS 13.0 , *)){
        
        NSSet *set = [UIApplication sharedApplication].connectedScenes;
        UIWindowScene *windowScene = [set anyObject];
        UIWindow *window = windowScene.windows.firstObject;
        return window.safeAreaInsets.bottom;
    }else if(@available(iOS 11.0, *))
    {
        UIWindow * window = [UIApplication sharedApplication].windows.firstObject;
        return window.safeAreaInsets.bottom;
    }
    return 0;
}

//顶部状态栏高度
+ (CGFloat)dev_statusBarHeight{
    if(@available(iOS 13.0 , *)){
        
        NSSet *set = [UIApplication sharedApplication].connectedScenes;
        UIWindowScene *windowScene = [set anyObject];
        UIStatusBarManager *statusBarManager = windowScene.statusBarManager;
        
        return statusBarManager.statusBarFrame.size.height;
    }else
    {
        return [UIApplication sharedApplication].statusBarFrame.size.height;
    }
}



@end
