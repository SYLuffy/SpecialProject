//
//  MBProgressHUD+Add.h
//  视频客户端
//
//  Created by mj on 13-4-18.
//  Copyright (c) 2013年 itcast. All rights reserved.
//

#import "MBProgressHUD.h"

@interface MBProgressHUD (Add)



+ (void)show:(NSString *)text icon:(NSString *)icon view:(UIView *)view;
+ (void)showError:(NSString *)error toView:(UIView *)view;
+ (void)showSuccess:(NSString *)success toView:(UIView *)view;
+ (void)showWaring:(NSString *)waring toView:(UIView *)view;

+ (MBProgressHUD *)creatHUDWithProgress:(NSString *)message toView:(UIView *)view;



/**自动消失**/

+ (void)showAutoHidenMessag:(NSString *)message toView:(UIView *)view dismissed:(MBProgressHUDCompletionBlock)block;
+ (void)showAutoHidenMessag:(NSString *)message toView:(UIView *)view;
+ (void)showAutoHidenMessag:(NSString *)message toView:(UIView *)view afterDelay:(NSTimeInterval)delay;

//手动消失 带 indicator
+ (MBProgressHUD *)showMessag:(NSString *)message toView:(UIView *)view;



@end
