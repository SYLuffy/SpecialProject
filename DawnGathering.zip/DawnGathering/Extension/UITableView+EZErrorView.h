//
//  UITableView+EZErrorView.h
//  HLGA
//
//  Created by 葛亮 on 2018/6/1.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, EZErrorViewType) {
    EZErrorViewTypeDefault,
    EZErrorViewTypeNetwork,
    EZErrorViewTypeEmpty,
    EZErrorViewTypeProgress
};

@protocol UITableViewErrorViewDataSource <UITableViewDataSource>
@optional
- (EZErrorViewType)tableViewTypeOfErrorViewToShow:(UITableView *)tableView;
@end

@interface UITableView (EZErrorView)
- (void)setErrorView:(UIView *)view ForType:(EZErrorViewType)errorType;
- (void)showErrorViewWithType:(EZErrorViewType)errorType;
- (void)dismissErrorView;
@end
