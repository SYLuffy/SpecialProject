//
//  HXTOpenJSWebViewController.m
//  HeXinPass
//
//  Created by 谢丹 on 2020/7/20.
//  Copyright © 2020 Ran Meng. All rights reserved.
//

#import "OpenJSWebKitController.h"
#import <LJContactManager/LJContactManager.h>
#import <IQKeyboardManager.h>
#import <WebKit/WKNavigationDelegate.h>
#import <WebKit/WKNavigationAction.h>
#import <AMapFoundationKit/AMapFoundationKit.h>
#import <AMapLocationKit/AMapLocationKit.h>
#import "PayViewController.h"
#import <WXApi.h>

@interface OpenJSWebKitController ()<WKScriptMessageHandler>


@property (nonatomic,strong)NSString *ruleURL;
@property (nonatomic,strong)NSDictionary * shareDictionary;
@property (nonatomic,strong)AMapLocationManager * locationManager;

@property (nonatomic,strong)NSString * saveBackURL;

@property (nonatomic,assign)BOOL isSaas;

@end

@implementation OpenJSWebKitController

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    

}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    
    
}

- (void)loginCallBackHandler{
    
    [self.webView evaluateJavaScript:@"appLoginCallback()" completionHandler:^(id _Nullable xx, NSError * _Nullable error) {
        
        NSLog(@"%@",error);
        
    }];
    
    [self.webView reload];
    
}

- (void)dealloc{
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:EVET_HTML_LOGIN_CALL_BACK object:nil];
    [self.webView evaluateJavaScript:@"closeWebView()" completionHandler:nil];
    
    if(self.webTitle.length != 0)
    {
        [self.webView removeObserver:self forKeyPath:@"title" context:nil];
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loginCallBackHandler) name:EVET_HTML_LOGIN_CALL_BACK object:nil];
//    self.navigationController.navigationBar.translucent = NO;
//    self.tabBarController.tabBar.backgroundColor = [UIColor whiteColor];
    
    [self.webView evaluateJavaScript:@"document.dispatchEvent(new CustomEvent('appReady', {detail: 0,bubbles: true,cancelable: true}))" completionHandler:nil];

    
    if (self.webTitle.length != 0) {
        self.title = self.webTitle;
    }
    
    if ([self.goUrl containsString:@"jd"]) {
        //        self.webView.scrollView.bounces = false;
        
    }
    
    // 带逆地理信息的一次定位（返回坐标和地址信息）
    self.locationManager = [[AMapLocationManager alloc] init];
    
    [self.locationManager setDesiredAccuracy:kCLLocationAccuracyHundredMeters];
    //   定位超时时间，最低2s，此处设置为2s
    self.locationManager.locationTimeout = 2;
    //   逆地理请求超时时间，最低2s，此处设置为2s
    self.locationManager.reGeocodeTimeout = 2;
    
    if(!self.webTitle || self.webTitle.length == 0)
    {
        //添加监听
        [self.webView addObserver:self forKeyPath:@"title" options:NSKeyValueObservingOptionNew context:NULL];
    }
}

// 根据监听 实时修改title
- (void)observeValueForKeyPath:(NSString *)keyPath
                      ofObject:(id)object
                        change:(NSDictionary<NSString *,id> *)change
                       context:(void *)context
{
    if ([keyPath isEqualToString:@"title"]) {
        if (object == self.webView)
        {
            self.title = self.webView.title;
        }
        else {
            [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
        }
        
    }
    
}

#pragma mark - WKScriptMessageHandler

- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message {
    NSString * parameter = message.body;
    NSData *jsonData = [parameter dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:nil];
    
    NSString *method = dic[@"method"];
    NSString *param = dic[@"params"];
    if ([method isEqualToString:@"startPay"]) {
        NSDictionary *dic = [Utils dictionaryWithJsonString:param];
        [self showPayView:dic isSaas:false];
    }else if([method isEqualToString:@"startSaasPay"]) {
        NSDictionary *dic = [Utils dictionaryWithJsonString:param];
        [self showPayView:dic isSaas:true];
    }else if ([method isEqualToString:@"openView"]) {
        dispatch_async(dispatch_get_main_queue(), ^{
            OpenJSWebKitController * webVC = [[OpenJSWebKitController alloc]init];
            NSDictionary * json = [Utils dictionaryWithJsonString:param];
            webVC.goUrl = json[URL];
            [self.navigationController pushViewController:webVC animated:true];
            
        });
    }else if ([method isEqualToString:@"getRuleURL"]) {
        self.ruleURL = param;
    }else if ([method isEqualToString:@"showRightItem"]) {
        if(param != nil && param.length > 0){
            dispatch_async(dispatch_get_main_queue(), ^{
                self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:param style:UIBarButtonItemStylePlain target:self action:@selector(clickRightItemHandler:)];
            });
            
        }
    }else if ([method isEqualToString:@"getMobilePhoneNo"]) {
        
        [[LJContactManager sharedInstance] selectContactAtController:self complection:^(NSString *name, NSString *phone) {
            phone = [phone stringByReplacingOccurrencesOfString:@" " withString:@""];
            phone = [phone stringByReplacingOccurrencesOfString:@"-" withString:@""];
            [self.webView evaluateJavaScript:[NSString stringWithFormat:@"mhx.mobilePhoneNoBack(%@)",phone] completionHandler:nil];
            
        }];
    }else if ([method isEqualToString:@"finish"]) {
        [self onBack:nil];
        
    }else if([method isEqualToString:@"goBack"]){
        if([self.webView canGoBack])
        {
            [self.webView goBack];
        }
    }else if ([method isEqualToString:@"startCustomService"]) {
        [self gotoCustomService:param];
    }else if ([method isEqualToString:@"showShare"]) {
        self.shareDictionary = [Utils dictionaryWithJsonString:param];
        if ([self.title isEqualToString:@"企业圈"]) {
            UIButton *rightItemButton = [UIButton buttonWithType:UIButtonTypeCustom];
            rightItemButton.frame = CGRectMake(0, 0, 34, 20);
            rightItemButton.titleLabel.font = [UIFont fontWithName:[Utils getGlobalFontName] size:14];
            [rightItemButton setTitle:@"分享" forState:UIControlStateNormal];
            [rightItemButton setTitleColor:UIColorFromRGB(0x222222) forState:UIControlStateNormal];
            [rightItemButton addTarget:self action:@selector(clickRightItemHandler:) forControlEvents:UIControlEventTouchUpInside];
            
            UIBarButtonItem * rightItem = [[UIBarButtonItem alloc]initWithCustomView:rightItemButton];
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.navigationItem setRightBarButtonItem:rightItem];
            });
        }else{
            [self clickRightItemHandler:nil];
        }
        
    }else if ([method isEqualToString:@"login"]) {
        [[SharedInstance getInstance] checkLoginAndGotoLogin:self];
    }else if([method isEqualToString:@"exitLogin"]){
        
        [SharedInstance clearLoginInfo];
        
        [self.navigationController popToRootViewControllerAnimated:true];
    }else if([method isEqualToString:@"getUserByChannelId"]){

        [ServiceManager getUserInfoWithChannelID:param success:^(NSDictionary *data) {
            
            NSString * json = [Utils dictionaryToJson:data];
            [self.webView evaluateJavaScript:[NSString stringWithFormat:@"getUserCallBack(%@)",json] completionHandler:nil];

        }];
        
    }else if([method isEqualToString:@"setHtmlTitle"])
    {
        self.title = param;
    }else if([method isEqualToString:@"getPosition"])
    {
        WS(weakSelf);
        
        // 带逆地理（返回坐标和地址信息）。将下面代码中的 YES 改成 NO ，则不会返回地址信息。
        [self.locationManager requestLocationWithReGeocode:YES completionBlock:^(CLLocation *location, AMapLocationReGeocode *regeocode, NSError *error) {
                
            if (error)
            {
                NSLog(@"locError:{%ld - %@};", (long)error.code, error.localizedDescription);
                
                if (error.code == AMapLocationErrorLocateFailed)
                {
                    //[Utils showToast:@"定位失败!"];
                    
                    [weakSelf.webView evaluateJavaScript:[NSString stringWithFormat:@"positionCallback(%lf,%lf)",30.663356,104.072506] completionHandler:nil];
                    return;
                }
            }
            
            NSLog(@"location:%@", location);
        
            NSString * jsSend = [NSString stringWithFormat:@"positionCallback(%.7lf,%.7lf)",location.coordinate.latitude,location.coordinate.longitude];
            [weakSelf.webView evaluateJavaScript:jsSend completionHandler:nil];
            
            if (regeocode)
            {
                NSLog(@"reGeocode:%@", regeocode);
            }
        }];
    }else if([method isEqualToString:@"getContacts"])
    {
        [[LJContactManager sharedInstance] selectContactAtController:self complection:^(NSString *name, NSString *phone) {
            phone = [phone stringByReplacingOccurrencesOfString:@" " withString:@""];
            phone = [phone stringByReplacingOccurrencesOfString:@"-" withString:@""];
            [self.webView evaluateJavaScript:[NSString stringWithFormat:@"contactsTelBack(%@)",phone] completionHandler:nil];
        }];
    }
    
}


- (void)webView:(WKWebView *)webView runJavaScriptTextInputPanelWithPrompt:(NSString *)prompt defaultText:(NSString *)defaultText initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(NSString * _Nullable))completionHandler {
    if (prompt) {
        if ([prompt isEqualToString: @"getUserToken"]) {
            NSString * sid = [SharedInstance getInstance].sid;
            NSString * phone = [SharedInstance getInstance].userInfo.telephone;
            
//            [SharedInstance getInstance].userInfo.scanDiscounts
            NSString * userId = [NSString stringWithFormat:@"%ld",[SharedInstance getInstance].userInfo.userId.integerValue];
            NSDictionary* dic = @{TOKEN:sid,PHONE:phone,USER_ID:userId};
            NSString * jsonString = [Utils dictionaryToJson:dic];
            NSLog(@"%@",jsonString);
            completionHandler(jsonString);
        }else if ([prompt isEqualToString: @"getUserId"]) {
            NSString * userId = [NSString stringWithFormat:@"%ld",[SharedInstance getInstance].userInfo.userId.integerValue];
            completionHandler(userId);
            
        }else if ([prompt isEqualToString: @"getPhone"]) {
            NSString * phone = [SharedInstance getInstance].userInfo.telephone;
            completionHandler(phone);
            
        }else if ([prompt isEqualToString: @"getChannel"]) {
            completionHandler(@"10");
            
        }else if ([prompt isEqualToString: @"isLogin"]) {
            completionHandler([SharedInstance getInstance].userInfo.sid.length != 0 ? @"1":@"");
        }else if([prompt isEqualToString:@"getSaasToken"])
        {
            completionHandler([SharedInstance getInstance].userInfo.saasToken);
        }else if([prompt isEqualToString:@"getUserFundUnit"])
        {
            
            if([SharedInstance getInstance].uint)
            {
                completionHandler([SharedInstance getInstance].uint);
            }else{
                completionHandler(@"");
            }
        }else if([prompt isEqualToString:@"getCommonInfo"])
        {
            NSDictionary * info = @{@"applicationName":@"蜀光惠",CLIENT_TYPE:@1,@"t":[SharedInstance getInstance].userInfo.saasToken,@"userFundUnit":[SharedInstance getInstance].uint};
            
            NSString * infoJsonString = [Utils dictionaryToJson:info];
            
            completionHandler(infoJsonString);
        }else if([prompt isEqualToString:@"goBack"])
        {
            if([self.webView canGoBack])
            {
                [self.webView goBack];
            }
            completionHandler(@"");
        }
            
    }else{
        completionHandler(@"");
    }
}

#pragma mark - other methods

- (void)clickRightItemHandler:(UIBarButtonItem*)barButtonItem{
    
    if(self.ruleURL != nil && self.ruleURL.length > 0){
        [self showRuleDesHandler];
    }
    
    if(self.shareDictionary != nil){
        [SharedInstance getInstance].showShareDictionary = self.shareDictionary;
        [[SharedInstance getInstance] showShareView];
    }
}

- (void)showRuleDesHandler{
    //显示说明
    OpenJSWebKitController * webVC = [[OpenJSWebKitController alloc]init];
    webVC.goUrl = self.ruleURL;
    [self.navigationController pushViewController:webVC animated:true];
}

- (void)showPayView:(NSDictionary*)dic isSaas:(BOOL)isSaas
{
    self.isSaas = isSaas;
    
    NSArray * serialNumbers = dic[SERIAL_NUMBER];
    NSString * saveURL = dic[BACK_URL];
    
    self.saveBackURL = saveURL;
    
    PayViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NMAE_PAY andIdentifier:@"PayViewController"];
    vc.serialNumbers = serialNumbers;
    vc.isSaas = isSaas;

    
    WS(weakSelf);
    vc.payViewControllerCallBack = ^(NSInteger status) {
        
        [weakSelf setPayStatus:[NSString stringWithFormat:@"%ld",status]];
    };
    
    [self.navigationController pushViewController:vc animated:true];
    
}

- (void)setPayStatus:(NSString*)status
{
    
    [self.webView evaluateJavaScript:[NSString stringWithFormat:@"getPayResult(%d)",status.intValue] completionHandler:nil];
   
}

- (void)gotoCustomService:(NSString*)title{
    
    //联系客服
    //获取当前版本号
    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
    NSString *app_Version = [infoDictionary objectForKey:@"CFBundleShortVersionString"];
    NSString * sendTitle = [NSString stringWithFormat:@"设备:iOS;应用名称:蜀光惠;版本号:%@;%@",app_Version,title];
    
    [IQKeyboardManager sharedManager].enable = false;
    [Utils setQiYuInfo];
    
    QYSource *source = [[QYSource alloc] init];
    source.title = sendTitle;
    source.urlString = @"";
    QYSessionViewController *sessionViewController = [[QYSDK sharedSDK] sessionViewController];
    sessionViewController.robotWelcomeTemplateId = 6655338;
    sessionViewController.robotId = 5401983;
//    sessionViewController.groupId = 1070381;
    sessionViewController.openRobotInShuntMode = NO;
    sessionViewController.commonQuestionTemplateId = 4494027;
    sessionViewController.sessionTitle = @"蜀光惠客服";
    sessionViewController.source = source;
    dispatch_async(dispatch_get_main_queue(), ^{
        
        [self.navigationController pushViewController:sessionViewController animated:true];
    });
    
    UIBarButtonItem * leftBackButton = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"ic_title_back"] style:UIBarButtonItemStylePlain target:self action:@selector(onBack:)];
    leftBackButton.tintColor = [UIColor blackColor];
    sessionViewController.navigationItem.leftBarButtonItem = leftBackButton;
}

- (void)onBack:(id)sender{
    
    [IQKeyboardManager sharedManager].enable = true;
    [self.navigationController popViewControllerAnimated:true];
    
}

- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler
{
    NSURL * URL = navigationAction.request.URL;
    
    NSString * urlStr = [[URL absoluteString] stringByRemovingPercentEncoding];
    if([urlStr containsString:@"weixin://wap/pay"] || [urlStr containsString:@"alipay://alipayclient"])
    {
        [[UIApplication sharedApplication] openURL:navigationAction.request.URL options:@{} completionHandler:nil];
        decisionHandler(WKNavigationActionPolicyCancel);
        return;
    }
    
    NSString * scheme = [URL scheme];
    if([scheme isEqualToString:@"tel"])
    {
        NSString * resourceSpecifier = [URL resourceSpecifier];
        
        NSString * callPhone = [NSString stringWithFormat:@"telprompt://%@",resourceSpecifier];
        
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:callPhone] options:@{} completionHandler:nil];
        decisionHandler(WKNavigationActionPolicyCancel);
        return;
    }
    
    decisionHandler(WKNavigationActionPolicyAllow);
    
}

@end
