
//无返回值方法转换
//会将jsCallNative.toLogin()的调用方式，转换成window.webkit.messageHandlers.jsCallNative.postMessage()
function calliOSFunction(namespace, functionName, args, callback) {
    if (!window.webkit.messageHandlers[namespace]) return;
    var wrap = {
        "method": functionName,
        "params": args
    };
    window.webkit.messageHandlers[namespace].postMessage(JSON.stringify(wrap));
}

var app = {};


//跳转界面
app.openView = function (jsonString) {
    calliOSFunction("app","openView",jsonString);
}

//调用原生支付
app.startPay = function (jsonString) {
    calliOSFunction("app","startPay",jsonString);
}

//调用原生SAAS支付
app.startSaasPay = function (jsonString) {
    calliOSFunction("app","startSaasPay",jsonString);
}

//显示说明
app.getRuleURL = function (ruleURL) {
    calliOSFunction("app","getRuleURL",ruleURL);
}

//显示导航栏rightItem
app.showRightItem = function (rightItemString) {
    calliOSFunction("app","showRightItem",rightItemString);
}
//打开客服
app.startCustomService = function (title) {
    calliOSFunction("app","startCustomService",title);
}
//打开微信分享
app.showShare = function (jsonString) {
    calliOSFunction("app","showShare",jsonString);
}
//调用用户渠道接口
app.getUserByChannelId = function (jsonString){
    calliOSFunction("app","getUserByChannelId",jsonString);
}

//获取用户电话号码
app.getMobilePhoneNo = function () {
    calliOSFunction("app","getMobilePhoneNo");
}

//完成关闭页面
app.finish = function () {
    calliOSFunction("app","finish");
}

//去登录
app.login = function () {
    calliOSFunction("app","login");
}

//退出用户登录状态
app.exitLogin = function () {
    calliOSFunction("app","exitLogin");
}
//返回用户是否登录
app.isLogin = function () {
    var result = window.prompt("isLogin");
    return result;
}
//页面返回上一级
app.goBack = function () {
    var result = window.prompt("goBack")
}
//获取用户sid
app.getUserToken = function () {
    var result = window.prompt("getUserToken");
    return result;
}
//获取用户UserId
app.getUserId = function () {
    var result = window.prompt("getUserId");
    return result;
}
//获取用户电话
app.getPhone = function () {
    var result = window.prompt("getPhone");
    return result;
}
//获取用户渠道
app.getChannel = function () {
    var result = window.prompt("getChannel");
    return result;
}
//设置网页title
app.setHtmlTitle = function (jsonString){
    calliOSFunction("app","setHtmlTitle",jsonString);
}
//获取用户定位经纬度
app.getPosition = function () {
    calliOSFunction("app","getPosition");
}
//获取用户SAAS Token
app.getSaasToken = function () {
    var result = window.prompt("getSaasToken");
    return result;
}
//获取用户金额单位
app.getUserFundUnit = function () {
    var result = window.prompt("getUserFundUnit");
    return result;
}
//获取用户SAAS信息合集
app.getCommonInfo = function () {
    var result = window.prompt("getCommonInfo");
    return result;
}
//获取用户通讯录
app.getContacts = function () {
    calliOSFunction("app","getContacts");
}






