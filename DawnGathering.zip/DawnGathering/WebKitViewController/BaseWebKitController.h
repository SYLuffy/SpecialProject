//
//  HXTBaseWebViewController.h
//  HeXinPass
//
//  Created by 谢丹 on 2020/7/15.
//  Copyright © 2020 Ran Meng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>
#import <Masonry/Masonry.h>

typedef enum : NSUInteger {
    OpenContentTypeURL,  // url链接
    OpenContentTypeIMG   // 图片链接
} OpenContentType;



NS_ASSUME_NONNULL_BEGIN

@interface BaseWebKitController : UIViewController<WKNavigationDelegate, WKUIDelegate>


@property(nonatomic, strong) WKWebView *webView;
@property (nonatomic,strong)NSString * goUrl;
@property (nonatomic,assign) OpenContentType contentType;


-(void)goBack;

@end

NS_ASSUME_NONNULL_END
