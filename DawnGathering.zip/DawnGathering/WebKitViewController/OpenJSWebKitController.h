//
//  HXTOpenJSWebViewController.h
//  HeXinPass
//
//  Created by 谢丹 on 2020/7/20.
//  Copyright © 2020 Ran Meng. All rights reserved.
//

#import "BaseWebKitController.h"



NS_ASSUME_NONNULL_BEGIN

@interface OpenJSWebKitController : BaseWebKitController

@property(nonatomic,strong)NSString *webTitle;//设置了title，就不会从网页去获取title
//@property (nonatomic,assign)Class fromClass;


@end

NS_ASSUME_NONNULL_END
