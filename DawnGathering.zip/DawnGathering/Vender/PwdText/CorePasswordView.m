//
//  CorePasswordView.m
//  CorePasswordView
//
//  Created by 廖马林 on 16/1/6.
//  Copyright © 2016年 廖马林. All rights reserved.
//

#import "CorePasswordView.h"


@interface CorePasswordView ()<UITextFieldDelegate>



@property (nonatomic,strong) NSMutableArray *btns;

@end


@implementation CorePasswordView

- (instancetype)initWithSecureTextEntry:(BOOL)secureTextEntry frame:(CGRect)frame{
    
    self = [super initWithFrame:frame];
    
    if(self){
        
        //视图准备
        self.secureTextEntry = secureTextEntry;
        [self viewPrepare];
    }
    
    return self;
}


-(id)initWithCoder:(NSCoder *)aDecoder{
    
    self=[super initWithCoder:aDecoder];
    
    if(self){
        
        //视图准备
        [self viewPrepare];
    }
    
    return self;
}

- (UIButton*)getShowButton{
    
    UIButton * button = [[UIButton alloc]init];
    
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    if(self.secureTextEntry)
    {
        button.titleLabel.font = [UIFont fontWithName:[Utils getGlobalFontName] size:100];
        [button setTitleEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 0)];
    }else{
        button.titleLabel.font = [UIFont fontWithName:MEDIUM_FONT_NAME size:22];
        [button setTitleEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 0)];
    }
    
    button.titleLabel.textAlignment = NSTextAlignmentCenter;
    
    [button.titleLabel setTintColor:UIColorFromRGB(0x222222)];
    
    button.layer.borderWidth = 1.0 / [UIScreen mainScreen].scale;
    button.layer.borderColor = UIColorFromRGB(0x999999).CGColor;
    
    button.layer.masksToBounds = true;
    
    button.layer.cornerRadius = 3.0f;
    button.backgroundColor = [UIColor whiteColor];
    button.userInteractionEnabled = NO;
    [button addGestureRecognizer:[[UILongPressGestureRecognizer alloc] initWithTarget:nil action:nil]];
    
    return button;
}



/*
 *  视图准备
 */
-(void)viewPrepare{
    
    //添加一个UITextField
    self.passwordLength = 6;
}



-(CorePasswordTF *)tf{

    if(_tf == nil){
    
        _tf = [[CorePasswordTF alloc] init];
        _tf.keyboardType = UIKeyboardTypeNumberPad;
        _tf.clearsOnBeginEditing = false;
        _tf.textColor = [UIColor clearColor];
        [self addSubview:_tf];
        _tf.delegate = self;
        [_tf addTarget:self action:@selector(textDidChange) forControlEvents:UIControlEventEditingChanged];
    }
    
    return _tf;
}







-(void)setPasswordLength:(NSInteger)passwordLength {

    

    NSAssert(passwordLength >= 1, @"Charlin Feng: passwordLength must greater than 1");
    
    if(_passwordLength == 0){ //默认
    
        for (NSUInteger i = 0; i< passwordLength; i++) {
            
            UIButton *btn = [self getShowButton];
            [self addSubview:btn];
        }
        
    }else {
    
        if(passwordLength == _passwordLength) return;
        
        if(passwordLength > _passwordLength){ //新的更多
        
            for (NSUInteger i = 0; i< passwordLength - _passwordLength; i++) {
                
                UIButton *btn = [self getShowButton];
                [self addSubview:btn];
            }
            
        }else{ // 新的更少
        
            __block NSInteger count = 0;
            
            [self.subviews enumerateObjectsUsingBlock:^(__kindof UIView * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                
                if([obj isKindOfClass:[UIButton class]]){
                
                    if(count < passwordLength){
                        
                        count++;
                        
                    }else{
                        [obj removeFromSuperview];
                    }
                }
            }];
            
        }
    }
    

    
    _passwordLength = passwordLength;
}




-(void)layoutSubviews{
    
    [super layoutSubviews];
    
    [self.btns removeAllObjects];
    
    
    CGFloat width = self.bounds.size.width;
    CGFloat height = self.bounds.size.height;
    
    CGFloat gap = (width - (height * self.passwordLength)) / (self.passwordLength - 1);
    
//    if(self.secureTextEntry == false)
//    {
//        gap = 0;
//    }
    
    CGFloat h_each = height;
    CGFloat w_each = height;
    
//    if(self.secureTextEntry == false)
//    {
//        w_each = width / 6;
//    }
    
    __block NSInteger count = 0;
    
    [self.subviews enumerateObjectsUsingBlock:^(__kindof UIView * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        
        if([obj isKindOfClass:[UIButton class]]){
            
            CGFloat x_each = count * gap + count * w_each;
            CGFloat y_each = 0;
            
            CGRect frame = CGRectMake(x_each, y_each, w_each, h_each);
            
            obj.frame = frame;
        
            [self.btns addObject:obj];
            
            count++;
        }
    }];
    
    self.tf.frame = CGRectMake(0, 0, 0, 0);
    
}


-(NSMutableArray *)btns{

    if(_btns == nil){
    
        _btns = [NSMutableArray array];
    }
    
    return _btns;
}

/** 开始输入 */
-(void)beginInput{
    [self.tf becomeFirstResponder];
    
    [self judgeShowCursor];
    
}

- (void)clearCursor
{
    for(NSInteger i = 0 ;i < self.btns.count;i ++)
    {
        UIButton * button = self.btns[i];
        button.layer.borderWidth = 1.0f / [UIScreen mainScreen].scale;
        button.layer.borderColor = UIColorFromRGB(0x999999).CGColor;
    }
}

- (void)judgeShowCursor
{
    NSString *str = self.tf.text;
    
    for(NSInteger i = 0 ;i < self.btns.count;i ++)
    {
        UIButton * button = self.btns[i];
        if(str.length == i)
        {
            button.layer.borderWidth = 2.0f / [UIScreen mainScreen].scale;
            button.layer.borderColor = [UIColor systemBlueColor].CGColor;
        }else{
            button.layer.borderWidth = 1.0f / [UIScreen mainScreen].scale;
            button.layer.borderColor = UIColorFromRGB(0x999999).CGColor;
        }
    }
}

/** 结束输入 */
-(void)endInput{
    
    [self clearCursor];
    
    [self.tf resignFirstResponder];
    
    
}


- (void)textFieldDidEndEditing:(UITextField *)textField{
    
    [self endInput];
    
}


//-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
//   
//    if(string.length == 0) return YES;
//    return textField.text.length < self.passwordLength;
//}


-(void)textDidChange{

    
    if(self.tf.text.length > 6)
    {
        self.tf.text = [self.tf.text substringToIndex:6];
    }
    
    NSString *str = self.tf.text;
    
    for (NSUInteger i = 0; i< self.btns.count; i++) {

        NSString * c;
        if(self.secureTextEntry)
        {
            c = i < str.length ? @"·" : nil;
        }else{
            c = i < str.length ? [str substringWithRange:NSMakeRange(i, 1)] : nil;
        }
        

        [self.btns[i] setTitle:c forState:UIControlStateNormal];
    }
    
    
    
    
    [self judgeShowCursor];
    
    if(self.passwordLength > str.length) return;
    
    if(self.PasswordCompeleteBlock != nil) {self.PasswordCompeleteBlock(str); [self endInput];}
}


-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{

    [self beginInput];
}


-(NSString *)password{

    return self.tf.text;
}

/** 清空密码 */
-(void)clearPassword{

    self.tf.text = @"";
    [self textDidChange];
}

@end
