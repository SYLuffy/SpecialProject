//
//  CorePasswordView.h
//  CorePasswordView
//
//  Created by 廖马林 on 16/1/6.
//  Copyright © 2016年 廖马林. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CorePasswordTF.h"

@interface CorePasswordView : UIView

/** 密码长度： 默认为6位 */
@property (nonatomic,assign) NSInteger passwordLength;

@property (nonatomic,copy) NSString *password;


@property (nonatomic,copy) void(^PasswordCompeleteBlock)(NSString *password);


@property (nonatomic,strong) CorePasswordTF *tf;

@property (nonatomic,assign)BOOL secureTextEntry;

- (instancetype)initWithSecureTextEntry:(BOOL)secureTextEntry frame:(CGRect)frame;

/** 开始输入 */
-(void)beginInput;

/** 结束输入 */
-(void)endInput;

/** 清空密码 */
-(void)clearPassword;


@end
