//
//  CorePasswordTF.h
//  CorePasswordView
//
//  Created by ldl on 2017/5/2.
//  Copyright © 2017年 廖马林. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CorePasswordTF : UITextField

@end

