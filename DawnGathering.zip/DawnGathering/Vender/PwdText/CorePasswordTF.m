//
//  CorePasswordTF.m
//  CorePasswordView
//
//  Created by ldl on 2017/5/2.
//  Copyright © 2017年 廖马林. All rights reserved.
//

#import "CorePasswordTF.h"

@implementation CorePasswordTF

//- (BOOL)canPerformAction:(SEL)action withSender:(id)sender
//{
//    if (action == @selector(paste:) || action == @selector(select:) || action == @selector(selectAll:)) {
//        return NO;
//    }
//    return [super canPerformAction:action withSender:sender];
//}

@end
