//
//  BaseTextField.h
//  WelfarePlatform
//
//  Created by 葛亮 on 2018/7/23.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseTextField : UITextField

@end
