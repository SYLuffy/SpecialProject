//
//  MessageListTableViewCell.h
//  HLGA
//
//  Created by Linus on 2018/5/23.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MessageListTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *dateLabel;
@property (weak, nonatomic) IBOutlet UIImageView *contentImageView;
@property (weak, nonatomic) IBOutlet UILabel *descLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *contentImageViewHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *descLabelHeight;

@end
