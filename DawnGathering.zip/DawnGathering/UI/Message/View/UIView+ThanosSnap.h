//
//  UIView+ThanosSnap.h
//  ThanosSnap_OC
//
//  Created by DR_Kun on 2019/5/8.
//  Copyright © 2019 DR_Kun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (ThanosSnap)

- (nullable UIImage *)renderToImage;

@end

