//
//  MessageCell.h
//  HLGA
//
//  Created by Linus on 2018/5/22.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MessageCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *iconImageView;//图标
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;//标题
@property (weak, nonatomic) IBOutlet UILabel *descLabel;//描述
@property (weak, nonatomic) IBOutlet UILabel *dateLabel;//时间

@end
