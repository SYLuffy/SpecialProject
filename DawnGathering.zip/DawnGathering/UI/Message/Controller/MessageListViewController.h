//
//  MessageListViewController.h
//  HLGA
//
//  Created by Linus on 2018/5/23.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MessageListViewController : UIViewController

@property(nonatomic,strong)NSArray * listDataSource;

@property(nonatomic,strong)NSString * messageType;

@end
