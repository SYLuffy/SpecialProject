//
//  MessageListViewController.m
//  HLGA
//
//  Created by Linus on 2018/5/23.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "MessageListViewController.h"
#import "MessageListTableViewCell.h"
#import "QuickRefresh.h"
#import "UITableView+EZErrorView.h"
#import "DustEffectView.h"
#import "UIView+ThanosSnap.h"

#define GAP 15
#define DEFAULT_CELL_HEIGHT 276

#define IMAGE_HEIGHT 160
#define DESC_HEIGHT 44

@interface MessageListViewController ()<UITableViewDataSource,UITableViewDelegate,DustEffectViewDelegate>
{
    
}
@property(nonatomic,assign)EZErrorViewType errorType;
@property (weak, nonatomic) IBOutlet UITableView *messageListTableView;
@property(nonatomic,assign)NSInteger page;
@property (nonatomic, strong) DustEffectView *dustView;
@property (nonatomic, strong) UITableViewCell *dustCell;
@property (nonatomic,assign)NSInteger removeIndex;

@property (nonatomic,strong)QuickRefresh * refresh;

@end

@implementation MessageListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.listDataSource = @[];
    
    self.page = 1;
    
    self.messageListTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    self.messageListTableView.tableFooterView = [UIView new];
    
    
    __weak MessageListViewController *weakSelf = self;

    
    self.refresh = [[QuickRefresh alloc]init];
               
    [self.refresh gifModelRefresh:self.messageListTableView refreshType:RefreshTypeDouble firstRefresh:NO timeLabHidden:YES stateLabHidden:YES dropDownBlock:^{
        //刷新
        //NSLog(@"111");
        weakSelf.page = 1;
        
        [weakSelf refreshMessageHandler];
        
    } upDropBlock:^{
        //翻页
        weakSelf.page += 1;
       [weakSelf refreshMessageHandler];
    }];
    
    NoDataView *noDataView = [NoDataView xibView];
    [noDataView setImageOrTitileNoDataViewType:NoDataViewTypeNoMessage];
    
    NoNetworkView *noNetworkView = [NoNetworkView xibView];
    noNetworkView.reloadBlk = ^{
        weakSelf.errorType = EZErrorViewTypeProgress;
        [weakSelf.messageListTableView reloadData];
        [weakSelf refreshMessageHandler];
    };
    
    TableViewProgressView *tProgressView = [TableViewProgressView xibView];

    [_messageListTableView setErrorView:noDataView ForType:EZErrorViewTypeEmpty];
    [_messageListTableView setErrorView:noNetworkView ForType:EZErrorViewTypeNetwork];
    [_messageListTableView setErrorView:tProgressView ForType:EZErrorViewTypeProgress];

    self.errorType = EZErrorViewTypeProgress;
    [self refreshMessageHandler];
    
    self.dustView = [[DustEffectView alloc] initWithFrame:CGRectZero];
    self.dustView.translatesAutoresizingMaskIntoConstraints = NO;
    self.dustView.delegate = self;
    [self.messageListTableView addSubview:self.dustView];

}


#pragma mark -- DustEffectViewDelegate

- (void)dustEffectViewDidCompleted {
    
    NSMutableArray * tempData = [self.listDataSource mutableCopy];
    [tempData removeObjectAtIndex:_removeIndex];
    self.listDataSource = [tempData copy];
    
    NSIndexPath *indexPath=[NSIndexPath indexPathForRow:_removeIndex inSection:0];

    dispatch_async(dispatch_get_main_queue(), ^{
        [self.messageListTableView deleteRowsAtIndexPaths:[NSArray arrayWithObjects:indexPath,nil] withRowAnimation:UITableViewRowAnimationFade];
    });
    
    
    [self.dustView removeFromSuperview];
    self.dustView = [[DustEffectView alloc] initWithFrame:CGRectZero];
    self.dustView.translatesAutoresizingMaskIntoConstraints = NO;
    self.dustView.delegate = self;
    [self.messageListTableView addSubview:self.dustView];
    
    self.messageListTableView.userInteractionEnabled = true;
    
}

- (void)refreshMessageHandler
{
    __weak MessageListViewController *weakSelf = self;

    CGPoint contentOffset = weakSelf.messageListTableView.contentOffset;
    [ServiceManager getMessageListByType:self.messageType andPageIndex:[NSNumber numberWithInteger:weakSelf.page] andPageSize:[Utils getGlobalPageSize] success:^(NSDictionary *data) {
        
        NSDictionary * results = data[DATA];
        
        NSArray * list = results[LIST];
        
        if([Utils checkObjectIsNull:list] == true)
        {
            if(weakSelf.page > 1)
            {
                if(list != nil && list.count > 0)
                {
                    weakSelf.listDataSource = [weakSelf.listDataSource arrayByAddingObjectsFromArray:list];
                }else{
                    //没有更多数据
                    [self.refresh noMoreData];
                }
            }else{
                weakSelf.listDataSource = list;
            }
            
            weakSelf.errorType = EZErrorViewTypeEmpty;
            
            [weakSelf.messageListTableView reloadData];

            weakSelf.messageListTableView.contentOffset = contentOffset;
        }
        
        [self.refresh endRefreshing];
        
    } failure:^(NSError *error) {
        [self.refresh endRefreshing];
        if(weakSelf.listDataSource.count == 0)
        {
            weakSelf.errorType = EZErrorViewTypeNetwork;
            [weakSelf.messageListTableView reloadData];

        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
    }];
}

- (void)turnCellsToDust {
    
    
//    self.dustCell.alpha = 0;
//
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        [self dustEffectViewDidCompleted];
//    });
    
    
    if (self.dustCell) {
        self.dustView.frame = self.dustCell.frame;
        [self.dustView refreshImage:[self.dustCell renderToImage]];
        self.dustCell.hidden = true;
    }
}

- (void)removeCell:(NSInteger)index
{
    
    self.messageListTableView.userInteractionEnabled = false;
    
    self.removeIndex = index;
    
    self.dustCell = [self.messageListTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:index inSection:0]];
//    [self turnCellsToDust];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self turnCellsToDust];
    });
}



//- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    if (editingStyle == UITableViewCellEditingStyleDelete)
//    {
//        [self removeCell:indexPath.row]; // 在此处自定义删除行为
//    }
//    else
//    {
//        //DEBUG_OUT(@"Unhandled editing style: %ld", (long) editingStyle);
//    }
//}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;
{
    return self.listDataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    static NSString * messageListCellIdentifier = @"messageListCellIdentifier";
    
    MessageListTableViewCell * cell = (MessageListTableViewCell*)[tableView dequeueReusableCellWithIdentifier:messageListCellIdentifier];
    
    if(!cell)
    {
        cell = (MessageListTableViewCell*)[[[NSBundle mainBundle] loadNibNamed:@"MessageListTableViewCell" owner:nil options:nil] firstObject];
    }
    
    NSDictionary * data = self.listDataSource[indexPath.row];
    
    NSString * title = data[TITLE];
    NSString * date = data [CREATE_TIME];
    NSString * imageUrl = data[IMG];
    NSString * desc = data[CONTENT];
    
    cell.titleLabel.text = title;
    cell.dateLabel.text = [Utils getSimpleDateByTime:date andHasYear:false];
    
    //判断高度
    if(imageUrl != nil && imageUrl.length > 0)
    {
        [Utils loadImage:cell.contentImageView andURL:imageUrl isLoadRepeat:false];
    }else{
        cell.contentImageViewHeight.constant = 0;
    }
    
    if(desc != nil && desc.length > 0)
    {
        cell.descLabel.text = desc;
        
        CGSize labelSize = [Utils getTextSizeByFont:cell.descLabel.font andMaxSize:CGSizeMake(SCREEN_WIDTH - 50,MAXFLOAT) andText:desc];
        
        NSLog(@"%lf",labelSize.height);
        
        cell.descLabelHeight.constant = labelSize.height + 5;
        
    }else{
        cell.descLabelHeight.constant = 0;
    }
    
    return cell;
}

//动态计算高度；
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSDictionary * data = self.listDataSource[indexPath.row];
    
    CGFloat cellHeight = DEFAULT_CELL_HEIGHT + GAP;
    
    NSString * imageUrl = data[IMG];
    
    if(imageUrl == nil || imageUrl.length < 1)
    {
        cellHeight -= IMAGE_HEIGHT;
    }
    
    NSString * desc = data[CONTENT];
    
    if(desc == nil || desc.length < 1)
    {
        cellHeight -= DESC_HEIGHT;
    }else{
        
        UIFont * font = [UIFont fontWithName:[Utils getGlobalFontName] size:14];
        
        CGSize labelSize = [Utils getTextSizeByFont:font andMaxSize:CGSizeMake(SCREEN_WIDTH - 50,MAXFLOAT) andText:desc];
        cellHeight += (labelSize.height - DESC_HEIGHT + 5);
    }
    
    return cellHeight;
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    //跳转详情;
    NSDictionary * data = self.listDataSource[indexPath.row];
    NSString * type = data[CONTENT_TYPE];
    NSString * title = data[TITLE];
    
    if(type.integerValue != 0)
    {
        NSString * url = data[URL];
        
        if([Utils checkObjectIsNull:url] && url.length > 0)
        {
            //打开网页
            [Utils pushWebViewControllerURL:url owner:self];
        }
        
    }

}
- (EZErrorViewType)tableViewTypeOfErrorViewToShow:(UITableView *)tableView
{
    return _errorType;
}

-(void)dealloc{
    [_messageListTableView dismissErrorView];
    
}
@end
