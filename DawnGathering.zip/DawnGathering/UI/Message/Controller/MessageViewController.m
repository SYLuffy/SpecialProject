//
//  MessageViewController.m
//  HLGA
//
//  Created by Linus on 2018/5/22.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "MessageViewController.h"
#import "MessageListViewController.h"
#import "MessageCell.h"
#import <UIView+WZLBadge.h>
#import "UITableView+EZErrorView.h"

# define GAP 15

@interface MessageViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *messageTableView;
@property(nonatomic,assign)EZErrorViewType errorType;

@end

@implementation MessageViewController

- (void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    
    [SharedInstance getInstance].isOpenMessageVC = true;
    
    [Utils clearAppBadge];//清除APP红圈
    
    [Utils setDefaultNavigationBar:self];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.messageTableView.rowHeight = 75 + GAP;
    
    self.messageTableView.tableFooterView = [UIView new];
    
    self.messageTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    NoDataView *noDataView = [NoDataView xibView];
    [noDataView setImageOrTitileNoDataViewType:NoDataViewTypeNoMessage];
    [_messageTableView setErrorView:noDataView ForType:EZErrorViewTypeEmpty];
    self.errorType = EZErrorViewTypeEmpty;

}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSDictionary * data = self.messageDataSource[indexPath.row];
    
    self.messageDataSource[indexPath.row][UNREAD_NUM] = @0;
    
    MessageCell * cell = (MessageCell*)[tableView cellForRowAtIndexPath:indexPath];
    
    [cell.iconImageView clearBadge];
    
    NSString * messageType = data[TYPE_ID];
    NSString * title = data[TYPE_NAME];
    MessageListViewController * listVC = (MessageListViewController*)[Utils getViewControllerByStoryBoardName:SB_NAME_MESSAGE andIdentifier:SB_ID_MESSAGE_LIST];
    listVC.messageType = messageType;
    listVC.title = title;
    [self.navigationController showViewController:listVC sender:self];
    
    
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;
{
    return self.messageDataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    static NSString* const messageCellIdentifier = @"messageCell";

    MessageCell * cell = (MessageCell*)[tableView dequeueReusableCellWithIdentifier:messageCellIdentifier];

    if(!cell)
    {
        cell = (MessageCell*)[[NSBundle mainBundle] loadNibNamed:@"MessageCell" owner:nil options:nil].firstObject;
    }
    
    NSDictionary * data = self.messageDataSource[indexPath.row];
    
    NSString * imageUrl = data[TYPE_IMG];
    NSString * cellTitle = data[TYPE_NAME];
    NSString * cellDesc = data[MESSAGE];
    NSNumber * unReadNum = data[UNREAD_NUM];
    NSString * timeString = data[CREATE_TIMES];
    
    
    if(unReadNum.integerValue > 0)
    {
        [cell.iconImageView showBadgeWithStyle:WBadgeStyleNumber value:unReadNum.integerValue animationType:WBadgeAnimTypeNone];
        
    }
    cell.titleLabel.text = cellTitle;
    cell.descLabel.text = cellDesc;
    cell.dateLabel.text = [Utils getSimpleDateByTime:timeString andHasYear:true];
    [Utils loadImage:cell.iconImageView andURL:imageUrl isLoadRepeat:false];
    
    return cell;
    
}

- (EZErrorViewType)tableViewTypeOfErrorViewToShow:(UITableView *)tableView
{
    return _errorType;
}
-(void)dealloc{
    [_messageTableView dismissErrorView];
    
    [SharedInstance getInstance].isOpenMessageVC = false;
    
    
}

@end
