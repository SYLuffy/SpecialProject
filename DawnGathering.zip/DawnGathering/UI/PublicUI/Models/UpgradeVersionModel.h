//
//  UpgradeVersionModel.h
//  HLGA
//
//  Created by 葛亮 on 2018/6/15.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UpgradeVersionModel : NSObject

@property(nonatomic,assign)NSInteger uvid;
@property(nonatomic,strong)NSString *version;
@property(nonatomic,strong)NSString *path;
@property(nonatomic,assign)NSInteger createTime;
@property(nonatomic,assign)NSInteger asmanda;
@property(nonatomic,assign)NSInteger versionCode;
@property(nonatomic,strong)NSString *content;
@property(nonatomic,assign)NSInteger systemType;

- (instancetype)initByDictionary:(NSDictionary*)dic;

@end
