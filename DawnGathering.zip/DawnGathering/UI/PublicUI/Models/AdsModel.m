//
//  AdsViewModels.m
//  HLGA
//
//  Created by 葛亮 on 2018/6/15.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "AdsModel.h"

@implementation AdsModel

- (instancetype)initByDictionary:(NSDictionary*)dic
{
    self = [super init];
    if (self) {
        _adsId = [dic[@"id"]integerValue];
        _title = dic[@"adName"];
        _imgUrl = dic[@"img"];
        _status = [dic[@"status"]integerValue];
        _type = [dic[@"urlType"]integerValue];
        _url = dic[@"url"];
    }
    return self;
}
@end
