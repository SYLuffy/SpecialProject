//
//  UpgradeVersionModel.m
//  HLGA
//
//  Created by 葛亮 on 2018/6/15.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "UpgradeVersionModel.h"

@implementation UpgradeVersionModel

- (instancetype)initByDictionary:(NSDictionary*)dic
{
    self = [super init];
    if (self) {
        _uvid = [dic[@"id"]integerValue];
        _version = dic[@"version"];
        _path = dic[@"path"];
        _createTime = [dic[@"createTime"]integerValue];
        _asmanda = [dic[@"asmanda"]integerValue];
        _versionCode = [dic[@"versionCode"]integerValue];
        _content = dic[@"content"];
        _systemType =[dic[@"systemType"]integerValue];
    }
    return self;
}

@end
