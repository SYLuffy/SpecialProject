//
//  AdsViewModels.h
//  HLGA
//
//  Created by 葛亮 on 2018/6/15.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AdsModel : NSObject

@property(nonatomic,assign)NSInteger adsId;
@property(nonatomic,strong)NSString *title;
@property(nonatomic,strong)NSString *imgUrl;
@property(nonatomic,assign)NSInteger status;
@property(nonatomic,assign)NSInteger type;
@property(nonatomic,strong)NSString *url;

- (instancetype)initByDictionary:(NSDictionary*)dic;

@end
