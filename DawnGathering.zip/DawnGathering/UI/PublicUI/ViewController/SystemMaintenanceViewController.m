//
//  SystemMaintenanceViewController.m
//  HLGA
//
//  Created by 李冬岐 on 2023/5/19.
//  Copyright © 2023 Linus. All rights reserved.
//

#import "SystemMaintenanceViewController.h"

@interface SystemMaintenanceViewController ()

@end

@implementation SystemMaintenanceViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"蜀光惠";
    
    UIBarButtonItem * backBarButton = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"ic_title_back"] style:UIBarButtonItemStylePlain target:self action:@selector(backAndPopHandler:)];
    
    self.navigationItem.leftBarButtonItem.tintColor = [UIColor blackColor];
    
    self.navigationItem.leftBarButtonItem = backBarButton;
}

- (void)backAndPopHandler:(UIBarButtonItem*)sender
{
    [self.navigationController popViewControllerAnimated:true];
}

@end
