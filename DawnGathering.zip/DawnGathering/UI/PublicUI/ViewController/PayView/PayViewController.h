//
//  PayViewController.h
//  DawnGathering
//
//  Created by 李冬岐 on 2023/8/3.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

//支付状态;
typedef void(^PayViewControllerCallBack)(NSInteger status);

@interface PayViewController : UIViewController
@property (nonatomic,strong)NSArray * serialNumbers;

@property (nonatomic,assign)BOOL isSaas;

@property (nonatomic,copy)PayViewControllerCallBack payViewControllerCallBack;

@end

NS_ASSUME_NONNULL_END
