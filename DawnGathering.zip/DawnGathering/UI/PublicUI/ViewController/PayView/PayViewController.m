//
//  PayViewController.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/8/3.
//

#import "PayViewController.h"
#import "PayViewHeader.h"
#import "PayViewFooter.h"
#import "PayViewCell.h"
#import "PayModel.h"
#import "GCDTimer.h"
#import "PayViewSection.h"
#import "RpPayViewSection.h"
#import "PaySuccessView.h"
#import "BillingInfoViewController.h"
#import <WXApi.h>
#import "RpPayViewSection.h"


#define SECTION_TAG 600

@interface PayViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *listTableView;
@property (weak, nonatomic) IBOutlet UIButton *confirmButton;

@property (nonatomic,strong)NSMutableArray <NSNumber*>* selectIndexs;

@property (nonatomic,strong)NSMutableArray <NSNumber*>* enableIndexs;

@property (nonatomic,strong)NSMutableArray * dataSource;

@property (nonatomic,strong)NSArray <NSNumber*>* footerDataSource;

@property (nonatomic,strong)PayModel * model;

@property (nonatomic,strong)GCDTimer * timer;

@property (nonatomic,assign)NSInteger expireTime;

@property (nonatomic,strong)PayViewHeader * payHeader;
@property (nonatomic,strong)PayViewFooter * payFooter;
@property (nonatomic,strong)NSArray * headerDataSource;

@property (nonatomic,assign)BOOL hasThirdPay;

@property (nonatomic,strong)NSMutableArray <NSNumber*>* openCloseIndexArray;

@property (nonatomic,strong)NSString * accountFundingType;

@property (nonatomic,strong)NSMutableArray * currentItems;

@property (nonatomic,strong)NSMutableArray * currentRpItems;

@property (nonatomic,strong)NSString * orderNumber;
@property (nonatomic,assign)BOOL isNoPasswordEnable;

@property (nonatomic,assign)NSInteger payStatus;//支付状态;

@property (nonatomic,strong)NSString * defaultAccountFundingType;

@property (nonatomic,strong)RpPayViewSection * rpPayViewSection;//红包模块

@end

@implementation PayViewController


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(eventRefreshaOrderStatusHandler) name:EVENT_BECOME_ACTIVE object:nil];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.isNoPasswordEnable = false;
    self.hasThirdPay = false;
    [self.confirmButton gradualDefaultButton];
    self.payStatus = -1;
    self.dataSource = [NSMutableArray array];
    
    self.listTableView.dataSource = self;
    self.listTableView.delegate = self;
    self.listTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    self.payFooter = (PayViewFooter*)[Utils getXibByName:@"PayViewFooter"];
//    1691496263462050000000017145
//    1691496263476050000000017221
//    1691496263489050000000017164
    
    self.listTableView.hidden = true;
    
    [ServiceManager getPayOrderWithSerialNumbers:self.serialNumbers isPayInfo:YES isSAAS:self.isSaas success:^(NSDictionary *data) {
        
        self.self.listTableView.hidden = false;
        
        self.model = [[PayModel alloc] initByDictionary:data];
        
        self.expireTime = self.model.expirationTime.integerValue;
        //@{CONTENT:@"蜀光惠",IMG:@"ic_pay_shuguanghui"}
        self.openCloseIndexArray = [NSMutableArray array];
        
        self.selectIndexs = [NSMutableArray array];
        self.enableIndexs = [NSMutableArray array];
        
        
        if(self.model.paySaasInfo)
        {
            if([Utils checkObjectIsNull:self.model.items])
            {
                self.dataSource = self.model.items.mutableCopy;
            }else{
                self.dataSource = @[].mutableCopy;
            }
            
            CGFloat headerHeight;
            if(self.dataSource.count == 0)
            {
                headerHeight = 140;
            }else{
                headerHeight = 192;
            }
            
            UIView * header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, headerHeight)];
            self.payHeader = (PayViewHeader*)[Utils getXibByName:@"PayViewHeader"];
            
            self.payHeader.frame = header.bounds;
            
            [header addSubview:self.payHeader];
            
            self.listTableView.tableHeaderView = header;
            
            //所有的选中状态为选中
            for(NSInteger i = 0;i < self.dataSource.count;i++)
            {
                [self.openCloseIndexArray addObject:[NSNumber numberWithBool:true]];
                [self.selectIndexs addObject:[NSNumber numberWithBool:true]];
                [self.enableIndexs addObject:@(true)];
                
            }
            
            //判断是否显示第三方支付;
            if(self.model.otherAmount.integerValue > 0)
            {
                NSArray * items = self.model.items;
                
                self.defaultAccountFundingType = items.firstObject[ACCOUNT_FUNDING_TYPE];
                
                [self updatePayStyleWithAmount:self.model.otherAmount];
                
                self.hasThirdPay = true;
                
                self.listTableView.tableFooterView.hidden = false;
            }else{
                self.hasThirdPay = false;
                
                self.listTableView.tableFooterView.hidden = true;
            }
            
            [self judgeNoPasswordSwitchPay];
            
        }else if(self.model.payInfo){
            
            //组装可识别数据;
            NSArray * accountFundingTypes = self.model.accountFundingTypes;
            
            CGFloat headerHeight;
            if([Utils checkObjectIsNull:accountFundingTypes] == false || accountFundingTypes.count == 0)
            {
                headerHeight = 140;
            }else{
                headerHeight = 192;
            }
            
            UIView * header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, headerHeight)];
            self.payHeader = (PayViewHeader*)[Utils getXibByName:@"PayViewHeader"];
            
            self.payHeader.frame = header.bounds;
            
            [header addSubview:self.payHeader];
            
            self.listTableView.tableHeaderView = header;
            
            if([Utils checkObjectIsNull:accountFundingTypes])
            {
                NSDictionary * firstDic = self.model.accountFundingTypes.firstObject;
                
                self.accountFundingType = firstDic[ACCOUNT_FUNDING_TYPE];
                
                for(NSDictionary * dic in self.model.accountFundingTypes)
                {
                    NSString * name = dic[ACCOUNT_FUNDING_NAME];
                    NSString * type = dic[ACCOUNT_FUNDING_TYPE];
                    NSArray * userAccounts = dic[USER_ACCOUNTS];

                    
                    [self.dataSource addObject:@{ACCOUNT_FUNDING_TYPE:type, CONTENT:name,IMG:@"ic_pay_shuguanghui"}];
                    
                    
                    for(NSMutableDictionary * dic in userAccounts)
                    {
                        [dic setObject:type forKey:ACCOUNT_FUNDING_TYPE];
                        
                        
                        [self.dataSource addObject:dic];
                    }

                }
            }
            NSInteger rpAmount = [self getRpAmountTotalAmount];
            NSArray * rpItems = self.model.payInfo[RP_ITEMS];
            
            if(rpAmount > 0)
            {
                [self.dataSource addObject:@{ACCOUNT_FUNDING_TYPE:USE_RP_AMOUNT,ITEMS:rpItems}];
            }
            
            NSDictionary * defaultFundingType = self.model.accountFundingTypes.firstObject;
            
            self.defaultAccountFundingType = defaultFundingType[ACCOUNT_FUNDING_TYPE];
            
            //计算选中的专项或者通用;//默认服务器排序;
            NSInteger totalPay = self.model.amount.integerValue;
            
            totalPay -= rpAmount;
            
            for(NSInteger i = 0;i < self.dataSource.count;i++)
            {
                NSDictionary * dic = self.dataSource[i];
                
                NSNumber * itemType = dic[ACCOUNT_ITEM_TYPE];
                
                NSNumber * amount = dic[AMOUNT];
                NSArray * details = dic[DETAILS];
                if(itemType.integerValue == 1)
                {
                    self.dataSource[i][DETAILS] = @[];
                }else{
                    if(details)
                    {
                        self.dataSource[i][DETAILS] = [self filterDetails:details];
                    }
                }
                
                if(details.count > 2)
                {
                    [self.openCloseIndexArray addObject:[NSNumber numberWithBool:false]];
                }else{
                    [self.openCloseIndexArray addObject:[NSNumber numberWithBool:true]];
                    
                }
                
                if(amount)
                {
                    if(totalPay >=0)
                    {
                        [self.selectIndexs addObject:[NSNumber numberWithBool:true]];
                    }else{
                        [self.selectIndexs addObject:[NSNumber numberWithBool:false]];
                    }
                    
                }else{
                    [self.selectIndexs addObject:[NSNumber numberWithBool:false]];
                }
                
                [self.enableIndexs addObject:@(true)];
                
                totalPay -= amount.integerValue;
            }
            
            //判断选中的所有专项orderId;
            
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [self judgeCurrentSelectedItemsHandler];
            });
            
        }
        
        
        [self startTimer];
        
        
        self.orderNumber = self.model.orderInfo.firstObject[ORDER_NUMBER];
        
        NSString * amountText = [NSString stringWithFormat:@"%.2lf",self.model.amount.floatValue * 0.01];
        
        [Utils setUintWithLabel:self.payHeader.amountLabel andText:amountText fontSize:16];
        
        self.payHeader.orderNoLabel.text = self.model.merchantName;
        
        
        [self.listTableView reloadData];
        
        
        
        
    }];
}

- (void)startTimer
{
    if (self.timer) {
        return;
    }
    //开启定时器
    WS(weakSelf);
    self.timer = [GCDTimer scheduleTimer:1 actionBlock:^{
        [weakSelf handleEvent];
    } willRepeat:YES];
}

- (void)handleEvent
{
    NSInteger nowTime = [Utils getNowTimeTimestamp].integerValue;
    NSInteger expireTime = self.expireTime;
    NSInteger countDown = expireTime - nowTime;
    
    
    NSString * showTime = [Utils timeWithSecond:countDown];
    
    self.payHeader.countDownLabel.text = [NSString stringWithFormat:@"交易剩余时间 %@",showTime];
    
    if(countDown <= 0)
    {
        [self stopTimer];
    }
    
}

- (void)eventRefreshaOrderStatusHandler
{
    [ServiceManager getPayOrderWithSerialNumbers:self.serialNumbers isPayInfo:YES isSAAS:self.isSaas success:^(NSDictionary *data) {
        
        self.model = [[PayModel alloc] initByDictionary:data];
        self.expireTime = self.model.expirationTime.integerValue;
    }];
}

- (void)stopTimer
{
    if (!self.timer) {
        return;
    }
    
    [self.timer stop];
    self.timer = nil;
}


- (void)dealloc{
    [self stopTimer];
}

- (IBAction)confirmPayHandler:(UIButton *)sender {
    //确认交易
    if(self.model.payInfo)
    {
       
        [self judgeCurrentSelectedItemsHandler];
        
    }
    
    
    if(self.hasThirdPay)
    {
        
        if(self.footerDataSource.count == 0)
        {
            [Utils showToast:@"可用余额不足！"];
            return;
        }
        
        [ServiceManager thirdPayWithSerialNumbers:self.serialNumbers payType:self.payFooter.selectedType accountFundingType:self.accountFundingType items:self.currentItems rpItems:self.currentRpItems isSAAS:self.isSaas success:^(NSDictionary *data) {
            
            NSString * jsonStr = data[PAY_ORDER_INFO];
            NSDictionary * payOrderInfo = [Utils dictionaryWithJsonString:jsonStr];
            [self wechantPayWithDic:payOrderInfo ];
            
        } failure:^(NSError *error) {
            NSString * msg = error.userInfo[MSG];
            [Utils showToast:msg];
        }];
    }else{
        
        if(self.isNoPasswordEnable == true)
        {
            [self verifypwd:nil];
        }else{
            
            [self gotoPayWithPassword];
        }

    }
}


- (void)gotoPayWithPassword
{
    BOOL isNO = [[Utils passwordForService:FACE_ID_NO] isEqualToString:NO_FACE_ID_PAY];
    
    if(isNO)
    {
        
        WS(weakSelf);
        [SharedInstance loadAuthentication:^(NSString *payStatus) {
            
            switch (payStatus.integerValue) {
                case 1:
                {
                    //成功
                    NSString *payPWD = [Utils passwordForService:FACE_ID_PASSWORD];
                    [weakSelf verifypwd:payPWD];
                    break;
                }
                case 0:
                    [Utils showToast:@"支付失败"];
                    break;
                case -1:
                {
                    [Utils showToast:@"支付取消"];
                    break;
                }
                case -2:
                {
                    [weakSelf showVertifyPassword];
                    break;
                }
                default:
                    break;
            }
            
        }];
    }else{
        [self showVertifyPassword];
    }
}

- (void)showVertifyPassword{
    WS(weakSelf);
    [[SharedInstance getInstance] showPayPopViewWithContent:@"请输入支付密码" amount:self.model.amount :^(NSString *pwd) {
        [weakSelf verifypwd:pwd];
    } retryInput:^{
        [weakSelf showVertifyPassword];
    }];
}

- (NSArray*)filterDetails:(NSArray*)details{
    
    NSMutableArray * canUseDetails = [NSMutableArray array];
    NSInteger totalCount = 5;
    for(NSDictionary * dic in details)
    {
        NSNumber * expireTime = dic[EXPIRE_TIME];
        
        NSString * nowTime = [Utils getNowTimeTimestamp];
        
        NSInteger expiredTime = expireTime.integerValue - nowTime.integerValue;
        
        NSInteger days = expiredTime / 86400;
        
        if(days <= 30 && totalCount > 0)
        {
            [canUseDetails addObject:dic];
            totalCount --;
            if(totalCount <= 0)
            {
                break;
            }
        }
    }
    
    return canUseDetails.copy;
    
}

- (void)verifypwd:(NSString*)pwd
{

    [ServiceManager defaultPayWithSerialNumbers:self.serialNumbers password:pwd accountFundingType:self.accountFundingType items:self.currentItems rpItems:self.currentRpItems isSAAS:self.isSaas success:^(NSDictionary *data) {
        
        NSString * content = [NSString stringWithFormat:@"%.2lf",self.model.amount.integerValue * 0.01];
        
        [self showResultView:self.serialNumbers showContent:content];
        
    } failure:^(NSError *error) {
        
        NSString * msg = error.userInfo[MSG];
        
        [Utils showToast:msg];
        
    }];
}

- (void)wechantPayWithDic:(NSDictionary*)payOrderInfo
{
    [[SharedInstance getInstance] wechatByPayInfo:payOrderInfo];
    
    
    [SharedInstance getInstance].wechatPayResult = ^(NSInteger result) {
        NSString * content = [NSString stringWithFormat:@"%.2lf",self.model.amount.integerValue * 0.01];
        if(result == 1)
        {
            //支付成功
            self.payStatus = 1;
            
            [self showResultView:self.serialNumbers showContent:content];
        }else{
            //支付失败
            self.payStatus = -1;
            [Utils showToast:@"支付取消"];
        }
        
    };
}

- (void)showResultView:(NSArray*)serialNumbers showContent:(NSString*)showContent
{
    
    [ServiceManager getCanUseAmountItemsWithOrderNo:serialNumbers success:^(NSDictionary *data) {
        
        NSArray * items = data[ITEMS];
        NSMutableArray * list = items.mutableCopy;
        NSNumber * useRpAmount = data[USE_RP_AMOUNT];
        NSNumber * rpAmount = data[RP_AMOUNT];
        if(useRpAmount.integerValue > 0)
        {
            [list addObject:@{ITEM_NAME:@"红包抵扣",AMOUNT:useRpAmount}];
        }
        
        NSNumber * state = data[STATE];
        
        NSString * payStatus;
        if(state.integerValue == 1)
        {
            self.payStatus = 1;
            payStatus = @"支付成功：";
        }else if(state.integerValue == 0){
            self.payStatus = 2;
            payStatus = @"支付中：";
        } else{
            self.payStatus = 0;
            payStatus = @"支付失败：";
        }
        
        PaySuccessView * resultView = (PaySuccessView*)[Utils getXibByName:@"PaySuccessView"];
        
        resultView.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
        
        NSString * amountText = [NSString stringWithFormat:@"%@%@",payStatus,showContent];
        
        
        
        WS(weakSelf);
        resultView.tapWatchBillDetailHandler = ^{
            
            NSString * orderNo = weakSelf.model.orderNumber;
            
            [weakSelf getBillDetailWithOrderNo:orderNo];
        };
        
        resultView.paySuccessViewClosedCompleted = ^{
            [weakSelf backAndPopHandler:nil];
        };
        
        if(self.payStatus == 1)
        {
            [resultView updateDataSource:list.copy];
            [Utils setUintWithLabel:resultView.amountLabel andText:amountText fontSize:16];
            
            if(rpAmount.integerValue > 0)
            {
                resultView.rpView.hidden = false;
                resultView.rpAmountLabel.text = [NSString stringWithFormat:@"获得红包：%.2lf",rpAmount.floatValue * 0.01];
            }else{
                resultView.rpView.hidden = true;
            }
            
            
        }else if(self.payStatus == 2){
            resultView.amountLabel.text = @"付款结果查询中";
            resultView.titleTopDistance.constant = 160;
            resultView.descLabel.hidden = false;
            resultView.serialNumbers = serialNumbers;
            resultView.payStatus = self.payStatus;
            resultView.amount = self.model.amount;
            [resultView updateDataSource:@[]];
            [resultView updateStatus];
        }else{
            [Utils setUintWithLabel:resultView.amountLabel andText:amountText fontSize:16];
            [resultView updateDataSource:@[]];
        }
        
        [[Utils currentWindow] addSubview:resultView];
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [resultView fadeIn];
        });
        
    }];
}

- (void)getBillDetailWithOrderNo:(NSString*)orderNo
{
    [ServiceManager getBillDetailWithOrderNo:orderNo success:^(NSDictionary *data) {
        
        BillingInfoViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_ME andIdentifier:@"BillingInfoViewController"];
        
        vc.dataDic = data;
        [self.navigationController pushViewController:vc animated:true];
        
    }];
}

- (IBAction)backAndPopHandler:(UIBarButtonItem *)sender {
    [self.navigationController popViewControllerAnimated:true];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.4 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if(self.payViewControllerCallBack)
        {
            self.payViewControllerCallBack(self.payStatus);
        }
    });
}

#pragma mark -- UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.dataSource.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;
{

    NSDictionary * dic = self.dataSource[section];
    
    NSArray * details = dic[DETAILS];
    
    return details.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    PayViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"PayViewCell"];
    
    if(!cell)
    {
        cell = (PayViewCell*)[Utils getXibByName:@"PayViewCell"];
    }
    NSArray * details = self.dataSource[indexPath.section][DETAILS];
    NSDictionary * dic = details[indexPath.row];
    NSDictionary * itemDic = self.dataSource[indexPath.section];
    NSNumber * itemType = itemDic[ACCOUNT_ITEM_TYPE];
    NSNumber * amount = dic[AMOUNT];
    NSNumber * expireTime = dic[EXPIRE_TIME];
    NSString * showContent;
    if(itemType.integerValue == 1)
    {
        showContent = @"长期有效";
    }else{
        showContent = [NSString stringWithFormat:@"%.2lf将在%@过期",amount.floatValue * 0.01,[Utils getDateByTime:[NSString stringWithFormat:@"%ld",expireTime.integerValue] fomatter:@"yyyy年MM月dd日"]];
    }
    
    
    cell.contentLabel.text = showContent;
    
    if(indexPath.section == self.dataSource.count - 1 && indexPath.row == details.count - 1)
    {
        cell.isCornerRidausBottom = true;
        
    }
    
    if(self.openCloseIndexArray[indexPath.section].boolValue == NO)
    {
        //如果是未选中状态
        if(self.model.payInfo && details.count > 2)
        {
            if(indexPath.row == 1)
            {
                cell.isCornerRidausBottom = true;
            }
        }
    }
    
    
    return cell;
}


- (NSInteger)getRpAmountTotalAmount{
    
    NSNumber * rpAmount = self.model.payInfo[RP_AMOUNT];
    
    return rpAmount.integerValue;
    
}

#pragma mark -- UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    
    [self.listTableView reloadData];
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSArray * details = self.dataSource[indexPath.section][DETAILS];
    
    if(self.openCloseIndexArray[indexPath.section].boolValue == NO)
    {
        
        if(self.model.payInfo && details.count > 2)
        {
            if(indexPath.row < 2)
            {
                return 35;
            }
        }
        
        return 0;
    }else{
        
        return 35;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    NSDictionary * dic = self.dataSource[section];
    
    NSString * type = dic[ACCOUNT_FUNDING_TYPE];
    NSArray * items = dic[ITEMS];
    
    if([type isEqualToString:USE_RP_AMOUNT])
    {
        CGFloat height = 52 + 55 * items.count;
        
        return height;
        
    }
    
    return 55.0f;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0.01;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    
    NSDictionary * dic = self.dataSource[section];
    
    NSString * type = dic[ACCOUNT_FUNDING_TYPE];
    
    if([type isEqualToString:USE_RP_AMOUNT])
    {
        
        NSArray * items = dic[ITEMS];
        
        RpPayViewSection * rpSectionView = self.rpPayViewSection;
        
        if(!rpSectionView)
        {
            rpSectionView = (RpPayViewSection*)[Utils getXibByName:@"RpPayViewSection"];
            [rpSectionView setDataSource:items];
            self.rpPayViewSection = rpSectionView;
        }
        
        
        WS(weakSelf)
        rpSectionView.tapSelectedRpItemHandler = ^(NSNumber * _Nonnull selectAmount) {
            
            if(selectAmount.integerValue > weakSelf.model.amount.integerValue)
            {
                weakSelf.currentItems = [NSMutableArray array];
                [weakSelf clearSelectIndexs];
            }
            
            [weakSelf judgeCurrentSelectedItemsHandler];
            
        };
        
        return rpSectionView;
    }
    
    
    PayViewSection * sectionView = (PayViewSection*)[Utils getXibByName:@"PayViewSection"];
    

    NSNumber * isOpen = self.openCloseIndexArray[section];
    NSNumber * isSelected = self.selectIndexs[section];
    NSNumber * enable = self.enableIndexs[section];
    if(section == 0 && self.model.payInfo)
    {
        NSString * content = dic[CONTENT];
        NSString * imgURL = dic[IMG];
        
        sectionView.contentLabel.text = content;
        
        sectionView.selectButton.hidden = true;
        
        sectionView.logoImageView.image = [UIImage imageNamed:imgURL];
        
        sectionView.expandFlagImageView.hidden = true;
        sectionView.isCornerRidausTop = true;
        
        return sectionView;
    }
    
    if(section == self.dataSource.count - 1)
    {
        sectionView.line.hidden = true;
    }else{
        sectionView.line.hidden = false;
    }
    
    NSArray * details = dic[DETAILS];
    NSString * itemName = dic[ITEM_NAME];
    NSNumber * amount = dic[AMOUNT];
    NSNumber * itemType = dic[ITEM_TYPE];
    
    if(itemType.integerValue == 1)
    {
        sectionView.expandFlagImageView.hidden = true;
    }

    [sectionView.selectButton setSelected:isSelected.boolValue];
    
    [sectionView setSelectButtonEnable:enable.boolValue];
    
    //如果只有2个就不显示箭头
    
    if(details.count == 0)
    {
        sectionView.isCornerRidausBottom = true;
    }
    if(details.count <= 2)
    {
        sectionView.expandFlagImageView.hidden = true;
    }else{
        if(isOpen.integerValue == true)
        {
            sectionView.expandFlagImageView.image = [UIImage imageNamed:@"ic_xiala"];
        }else{
            sectionView.expandFlagImageView.image = [UIImage imageNamed:@"ic_shangla"];
        }
    }
    
    //NSString * logoURL = [SharedInstance getInstance].userInfo.companyLogo;
    //[Utils loadImage:sectionView.logoImageView andURL:logoURL isLoadRepeat:true];
    
//    sectionView.contentLabel.text = [NSString stringWithFormat:@"%@(%.2lf可用)",itemName,amount.floatValue * 0.01];
    
    sectionView.contentLabel.text = [NSString stringWithFormat:@"%@(%.2lf)",itemName,amount.floatValue * 0.01];
    
    sectionView.tag = SECTION_TAG + section;
    
    sectionView.index = section;
    
    if(self.model.payInfo)
    {
        WS(weakSelf);
        sectionView.tapPayViewSectionSelectButton = ^(NSInteger index , BOOL isSelected , UIButton * _Nullable button) {
    
            if(!isSelected)
            {
                BOOL enough = [weakSelf judgeEnough];
                
                if(button.alpha == 1)
                {
                    if(enough)
                    {
                        
                        NSInteger currentAmount = [self getCurrentItemAmountWithIndex:index];
                        
                        NSInteger totalCount = self.currentItems.count + self.currentRpItems.count;
                        
                        if(totalCount == 1 && currentAmount > self.model.amount.integerValue)
                        {
                            
                            //如果之前选的已足够并且只有一个，当前选的金额也足够执行单选;
                            
                            //先取消
                            [self clearSelectIndexs];
                            
                            //只勾选当前选中的
                            button.selected = !isSelected;
                
                            weakSelf.selectIndexs[index] = [NSNumber numberWithBool:!isSelected];
                            
                            
                            //如果只选择了一个红包
                            if(self.currentRpItems.count == 1 && self.currentItems.count == 0)
                            {
                                //清空所有选中的红包
                                self.currentRpItems = [NSMutableArray array];
                                [self.rpPayViewSection clearAllIndexAndUnSelectedAll];
                            }
                            
                        }else{
                            //如果现在选的小于订单金额，提示;
                            
                            [Utils showToast:@"已选金额充足，请取消后重选"];
                            return;
                        }
                       
                        

                    }else{
                        
                        
                        button.selected = !isSelected;
            
                        weakSelf.selectIndexs[index] = [NSNumber numberWithBool:!isSelected];
            
                        [weakSelf.listTableView reloadData];
                    
                        
                    }
                }else{
                    [Utils showToast:@"已选金额充足，请取消后重选"];
                    
                    return;
                }
                
               
            }else{
                button.selected = !isSelected;
    
                weakSelf.selectIndexs[index] = [NSNumber numberWithBool:!isSelected];
    
                [weakSelf.listTableView reloadData];
            }
            
            [weakSelf judgeCurrentSelectedItemsHandler];
            
        };
    }
    
    
    
    //添加手势
   if(self.model.payInfo && itemType.integerValue != 1 && details.count > 2)
   {
       UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(openlist:)];
       [sectionView addGestureRecognizer:tap];

       sectionView.frame = CGRectMake(0, 0, SCREEN_WIDTH, 55);
   }
    
    return sectionView;
    
}


- (NSInteger)getCurrentItemAmountWithIndex:(NSInteger)index
{
    NSDictionary * dic = self.dataSource[index];
    NSNumber * amount = dic[AMOUNT];
    
    return amount.integerValue;
}
- (void)updatePayStyleWithAmount:(NSNumber*)amount
{
    if(self.footerDataSource != nil)
    {
        [self.payFooter updateWithDatas:self.footerDataSource payAmount:amount];
        return;
    }
    
    [ServiceManager getPayStyleWithAccountFundingType:self.defaultAccountFundingType success:^(NSDictionary *data) {
        
        
        NSArray * list = data[DATA];
        
        self.footerDataSource = list;
        
        [self.payFooter updateWithDatas:list payAmount:amount];
        
        [self updateTableViewFooter];
        
    }];
}

- (BOOL)judgeEnough
{
    NSInteger totalSelectAmount = 0;
    
    totalSelectAmount += [self.rpPayViewSection getSelectedAllRpAmount].integerValue;
    
    if(totalSelectAmount >= self.model.amount.integerValue)
    {
        return true;
    }
    
    for(NSInteger i = 0;i< self.selectIndexs.count;i++){
        NSNumber * select = self.selectIndexs[i];
        
        if(select.boolValue == true)
        {
            NSDictionary * dic = self.dataSource[i];
            
            NSNumber * amount = dic[AMOUNT];
            totalSelectAmount += amount.integerValue;
        }
    }
    
    if(totalSelectAmount >= self.model.amount.integerValue)
    {
        return true;
    }
    
    return false;
}


- (void)clearSelectIndexs{
    for(NSInteger i = 0;i < self.selectIndexs.count;i++)
    {
        self.selectIndexs[i] = [NSNumber numberWithBool:false];
        
    }
}


- (void)judgeCurrentSelectedItemsHandler{
    
    [self judgeRpAmountSelectItemHandler];
    
    NSInteger totalSelectAmount = [self.rpPayViewSection getSelectedAllRpAmount].integerValue;

    self.currentItems = [NSMutableArray array];
    //如果选中红包小于支付金额才 执行选中通用或者专项;
    if(totalSelectAmount < self.model.amount.integerValue)
    {
        [self allSelectButtonEnable:true];
        for(NSInteger i = 0;i < self.selectIndexs.count;i++)
        {
            NSNumber * select = self.selectIndexs[i];
            
            if(select.boolValue == true)
            {
                NSDictionary * dic = self.dataSource[i];
                
                NSString * accountFundingType = dic[ACCOUNT_FUNDING_TYPE];
                NSNumber * itemId = dic[ITEM_ID];
                NSNumber * amount = dic[AMOUNT];
                
                [self.currentItems addObject:@{ITEM_ID:itemId,AMOUNT:amount}];
                
                
                if(self.accountFundingType != accountFundingType && self.accountFundingType != nil)
                {
                    //如果选中的钱包不一样清除所有选中
                    [self clearSelectIndexs];
                    
                    //只选中当前钱包的index
                    self.selectIndexs[i] = [NSNumber numberWithBool:true];
                    
                    break;
                }
                self.accountFundingType = accountFundingType;
                
                
                totalSelectAmount += amount.integerValue;
                
                if(totalSelectAmount >= self.model.amount.integerValue)
                {
                    //此时已足够判断是否是只选择了一个
                    
                    NSInteger totalCount = self.currentItems.count + self.currentRpItems.count;
                    
                    if(totalCount == 1)
                    {
                        //执行除了大于订单金额的其余至灰
                        [self enableThanSmallAmount];
                    }
                    break;
                }
                
            }
        }
        NSInteger totalCount = self.currentItems.count + self.currentRpItems.count;
        
        if(totalCount > 1 && totalSelectAmount >= self.model.amount.integerValue)
        {
            //如果所选账户大于1并且金额足够时候
            [self enableUnSelected];
        }
        
    
    }else{
        
        //此时红包已足够,禁用所有比订单金额小的ITEMS
        [self enableThanSmallAmount];
        
        
    }
    
    
    if(self.model.payInfo){
        
        if(totalSelectAmount >= self.model.amount.integerValue)
        {
            self.hasThirdPay = false;
            
            self.listTableView.tableFooterView.hidden = true;
            
        }else{
            self.hasThirdPay = true;
            
            self.listTableView.tableFooterView.hidden = false;
            
            NSInteger thirdPayAmount = self.model.amount.integerValue - totalSelectAmount;
            
            [self updatePayStyleWithAmount:@(thirdPayAmount)];
            
        }
    }
    
    [self judgeNoPasswordSwitchPay];
    
    [self.listTableView reloadData];
    
}

//执行除了所选其余至灰
- (void)enableUnSelected
{
    for(NSInteger i = 0;i < self.enableIndexs.count;i++)
    {
        NSNumber * selected = self.selectIndexs[i];
        
        if(!selected.boolValue)
        {
            self.enableIndexs[i] = @(false);
        }else{
            self.enableIndexs[i] = @(true);
        }
        
    }
}
//执行禁用比订单金额小的至灰
- (void)enableThanSmallAmount
{
    for(NSInteger i = 0;i < self.enableIndexs.count;i++)
    {
        NSDictionary * dic = self.dataSource[i];
        NSNumber * amount = dic[AMOUNT];
        if(amount.integerValue < self.model.amount.integerValue)
        {
            self.enableIndexs[i] = @(false);
        }else{
            self.enableIndexs[i] = @(true);
        }
        
    }
}

//全部禁用或开起;
- (void)allSelectButtonEnable:(BOOL)enable
{
    for(NSInteger i = 0;i < self.enableIndexs.count;i++)
    {
        self.enableIndexs[i] = @(enable);
    }
}

//判断红包选中的参数
- (void)judgeRpAmountSelectItemHandler
{
    self.currentRpItems = [self.rpPayViewSection getSelectItems];
}
    

- (void)judgeNoPasswordSwitchPay
{
    if([SharedInstance getInstance].paySwitch == 1)
    {
        //开起免密支付;
        if(self.model.amount.integerValue <= [SharedInstance getInstance].payNoPwdAmount && self.hasThirdPay == false)
        {
            self.isNoPasswordEnable = true;
            
            [self.confirmButton setTitle:@"免密支付" forState:UIControlStateNormal];
        }else{
            self.isNoPasswordEnable = false;
            
            [self.confirmButton setTitle:@"确认付款" forState:UIControlStateNormal];
        }
    }
}

#pragma 手势
-(void)openlist:(UITapGestureRecognizer *)tap
{
    PayViewSection * view = (PayViewSection*)tap.view;
    NSInteger index = view.tag - SECTION_TAG;
    
    NSMutableArray *indexArray = [NSMutableArray array];
    NSArray *arr = self.dataSource[index][DETAILS];
    
    if(arr.count == 0 || !arr) return;

    for (NSInteger i = 0; i < arr.count; i++) {
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:i inSection:index];
        [indexArray addObject:indexPath];
    }
    if (self.openCloseIndexArray[index].boolValue == false) {
        self.openCloseIndexArray[index] = @(true);
        [self.listTableView reloadRowsAtIndexPaths:indexArray withRowAnimation:UITableViewRowAnimationBottom];
        
        view.expandFlagImageView.image = [UIImage imageNamed:@"ic_xiala"];
    }else
    {
        self.openCloseIndexArray[index] = @(false);
        [self.listTableView reloadRowsAtIndexPaths:indexArray withRowAnimation:UITableViewRowAnimationTop];
        
        view.expandFlagImageView.image = [UIImage imageNamed:@"ic_shangla"];
    }
}

- (void)updateTableViewFooter
{
    CGFloat footerHeight = self.footerDataSource.count * 55 + 67;
    
    if(footerHeight == 0)
    {
        footerHeight = 122;
    }
    
    UIView * footer = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, footerHeight)];
    
    self.payFooter.frame = footer.bounds;
    
    [footer addSubview:self.payFooter];
    
    self.listTableView.tableFooterView = footer;
    
    [self.listTableView reloadData];
}

@end
