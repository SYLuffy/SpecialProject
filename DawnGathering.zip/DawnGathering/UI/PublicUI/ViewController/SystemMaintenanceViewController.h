//
//  SystemMaintenanceViewController.h
//  HLGA
//
//  Created by 李冬岐 on 2023/5/19.
//  Copyright © 2023 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SystemMaintenanceViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
