//
//  ShareView.m
//  GJTakeout
//
//  Created by 李冬岐 on 2018/11/25.
//  Copyright © 2018年 葛亮. All rights reserved.
//

#import "ShareView.h"

@implementation ShareView


- (IBAction)shareWXFriendsHandler:(UIButton *)sender {
    //分享给朋友
    if(self.blockShareFriends)
    {
        self.blockShareFriends();
    }
}

- (IBAction)shareWXMonmentsHandler:(UIButton *)sender {
    //分享至朋友圈
    if(self.blockShareMoments)
    {
        self.blockShareMoments();
    }
}

@end
