//
//  ShareView.h
//  GJTakeout
//
//  Created by 李冬岐 on 2018/11/25.
//  Copyright © 2018年 葛亮. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^BlockShareFriends)(void);
typedef void(^BlockShareMoments)(void);

NS_ASSUME_NONNULL_BEGIN

@interface ShareView : UIView

@property (nonatomic,copy)BlockShareFriends blockShareFriends;
@property (nonatomic,copy)BlockShareMoments blockShareMoments;

@end

NS_ASSUME_NONNULL_END
