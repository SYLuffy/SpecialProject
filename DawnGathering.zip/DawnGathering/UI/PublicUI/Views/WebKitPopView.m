//
//  WebKitPopView.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/9/26.
//

#import "WebKitPopView.h"
#import <WebKit/WebKit.h>
#define INIT_Y -500
@interface WebKitPopView()
@property (weak, nonatomic) IBOutlet UIView *darkMask;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *popBottomDistance;

@property (nonatomic,strong)WKWebView * webView;
@property (weak, nonatomic) IBOutlet UIView *popView;

@end

@implementation WebKitPopView

- (void)awakeFromNib
{
    [super awakeFromNib];
    
    self.darkMask.alpha = 0;
    self.popBottomDistance.constant = INIT_Y;
    WKWebViewConfiguration *config = [[WKWebViewConfiguration alloc] init];
    self.webView = [[WKWebView alloc] initWithFrame:CGRectMake(0, 60, SCREEN_WIDTH, 420) configuration:config];
    
    [self.popView addSubview:_webView];
    
    
    
}

- (void)setWebURL:(NSString *)webURL
{
    _webURL = webURL;
    
    NSString *URL = [_webURL stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    [_webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:URL]]];
}

- (IBAction)closeHandler:(UIButton *)sender {
    [self fadeOut];
}

- (void)fadeIn
{
    self.popBottomDistance.constant = 0;
    self.darkMask.alpha = 0;
    
    [UIView animateWithDuration:0.4 animations:^{
        [self layoutIfNeeded];
        self.darkMask.alpha = 0.4;
    }];
}

- (void)fadeHide
{
    self.popBottomDistance.constant = INIT_Y;
    self.darkMask.alpha = 0.4;
    
    [UIView animateWithDuration:0.4 animations:^{
        [self layoutIfNeeded];
        self.darkMask.alpha = 0;
    } completion:^(BOOL finished) {
        
    }];
}

- (void)fadeOut
{
    self.popBottomDistance.constant = INIT_Y;
    self.darkMask.alpha = 0.4;
    
    [UIView animateWithDuration:0.4 animations:^{
        [self layoutIfNeeded];
        self.darkMask.alpha = 0;
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
        
    }];
}

@end
