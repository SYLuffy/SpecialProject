//
//  ImageTtitleView.h
//  DawnGathering
//
//  Created by 李冬岐 on 2023/8/16.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ImageTtitleView : UIView
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *imageWH;


- (void)setSelected:(BOOL)selected;
@property (nonatomic,strong)NSDictionary * dataDic;

@property (nonatomic,strong)UIColor * normalColor;
@property (nonatomic,strong)UIColor * selectedColor;

@end

NS_ASSUME_NONNULL_END
