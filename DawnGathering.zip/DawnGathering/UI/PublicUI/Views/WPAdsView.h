//
//  WPAdsView.h
//  HLGA
//
//  Created by 葛亮 on 2018/5/28.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AdsModel.h"
typedef void(^WPAdsViewBlock)(void);
typedef void(^WPAdsViewDismissBlock)(void);

@interface WPAdsView : UIView
@property (weak, nonatomic) IBOutlet UIImageView *bgImageView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *contentViewCenterYConstraint;
@property (nonatomic, strong) NSString *imgUrl;
@property (nonatomic, copy) WPAdsViewBlock btnBlk;
@property (nonatomic,copy)WPAdsViewDismissBlock dismissBlk;
+ (instancetype)xibView;
- (void)showOnView:(UIView *)view;
- (void)dismiss;

@end
