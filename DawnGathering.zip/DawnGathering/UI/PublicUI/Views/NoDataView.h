//
//  NoDataView.h
//  HLGA
//
//  Created by 葛亮 on 2018/6/1.
//  Copyright © 2018年 Linus. All rights reserved.
//




#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, NoDataViewType) {
    NoDataViewTypeDefault,
    NoDataViewTypeNoMessage,
    NoDataViewTypeNoContent,
    NoDataViewTypeRedEnvelope
};

@interface NoDataView : UIView

@property (weak, nonatomic) IBOutlet UIImageView *headImageView;
@property (weak, nonatomic) IBOutlet UILabel *titileLable;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topIndex;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *wIndex;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *hIndex;


+ (instancetype)xibView;
-(void)setImageOrTitileNoDataViewType:(NoDataViewType)type;

-(void)setZoomView:(CGFloat )zoom topIndex:(CGFloat )topIndex titileFont:(NSInteger )titileFont;


@end
