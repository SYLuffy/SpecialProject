//
//  TableViewProgressView.m
//  HLGA
//
//  Created by 葛亮 on 2018/6/20.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "TableViewProgressView.h"

@implementation TableViewProgressView

+ (instancetype)xibView{
    
    return [[[NSBundle mainBundle] loadNibNamed:@"TableViewProgressView" owner:nil options:nil] lastObject];
    
}

-(void)awakeFromNib{
    [super awakeFromNib];
    
    NSMutableArray *imageArray = [NSMutableArray array];
    for (int i = 0; i < 2; i ++) {
        NSString *imageName = [NSString stringWithFormat:@"img_loading_bee_%d",i + 1];
        UIImage *image = [UIImage imageNamed:imageName];
        [imageArray addObject:image];
    }
    _imageView.animationImages = imageArray;
    _imageView.animationDuration = 0.25f;
    _imageView.animationRepeatCount = 0;
    [_imageView startAnimating];
    NSLog(@"TableViewProgressView init!");

}

-(void)dealloc{
    
    [_imageView stopAnimating];
    [_imageView removeFromSuperview];
    _imageView = nil;
    NSLog(@"TableViewProgressView dealloc!");
    
}

@end
