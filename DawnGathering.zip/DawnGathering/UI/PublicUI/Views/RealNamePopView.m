//
//  RealNamePopView..m
//  HLGA
//
//  Created by 李冬岐 on 2021/11/18.
//  Copyright © 2021 Linus. All rights reserved.
//

#import "RealNamePopView.h"
#import "RealNameViewController.h"

@implementation RealNamePopView


- (void)awakeFromNib{
    [super awakeFromNib];
    
    
    
    
}


- (void)fadeIn
{
    self.popView.alpha = 0;
    self.darkMask.alpha = 0;
    
    [UIView animateWithDuration:0.6 animations:^{
        self.popView.alpha = 1;
        self.darkMask.alpha = 0.4;
    }];
    
    if([Utils checkObjectIsNull:self.contentDesc] && self.contentDesc.length > 0)
    {
        self.contentLabel.text = self.contentDesc;
    }
}

- (void)fadeOut
{
    self.popView.alpha = 1;
    self.darkMask.alpha = 0.4;
    
    [UIView animateWithDuration:0.6 animations:^{
        self.popView.alpha = 0;
        self.darkMask.alpha = 0;
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
        
        
        if(self.isGoToRealName)
        {
            self.isGoToRealName = false;
            UIViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_ME andIdentifier:@"RealNameViewController"];
            
            [[Utils getCurrentVC].navigationController pushViewController:vc animated:true];
        }
        
    }];
}


- (IBAction)closePopHandler:(UIButton *)sender {
    [self fadeOut];
}


- (IBAction)gotoRealNameHandler:(UIButton *)sender {
    
    self.isGoToRealName = true;
    [self fadeOut];
    
}

@end
