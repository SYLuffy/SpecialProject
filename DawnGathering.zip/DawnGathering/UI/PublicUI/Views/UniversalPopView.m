//
//  UniversalPopView.m
//  DawnGathering
//
//  Created by 李冬岐 on 2024/1/17.
//

#import "UniversalPopView.h"

@implementation UniversalPopView


- (void)awakeFromNib
{
    [super awakeFromNib];
    
}

- (void)fadeIn
{
    self.popView.alpha = 0;
    self.darkMask.alpha = 0;
    
    [UIView animateWithDuration:0.6 animations:^{
        self.popView.alpha = 1;
        self.darkMask.alpha = 0.4;
    }];
    
    if([Utils checkObjectIsNull:self.contentDesc] && self.contentDesc.length > 0)
    {
        self.contentLabel.text = self.contentDesc;
    }
}


- (void)fadeOut
{
    self.popView.alpha = 1;
    self.darkMask.alpha = 0.4;
    
    [UIView animateWithDuration:0.6 animations:^{
        self.popView.alpha = 0;
        self.darkMask.alpha = 0;
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
        
    }];
}

- (IBAction)confirmHandler:(UIButton *)sender {
    //点击确定;
    [self fadeOut];
}

@end
