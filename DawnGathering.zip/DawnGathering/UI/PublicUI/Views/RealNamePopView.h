//
//  RealNamePopView..h
//  HLGA
//
//  Created by 李冬岐 on 2021/11/18.
//  Copyright © 2021 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface RealNamePopView : UIView
@property (weak, nonatomic) IBOutlet UIView *darkMask;
@property (weak, nonatomic) IBOutlet UIView *popView;
@property (weak, nonatomic) IBOutlet UILabel *contentLabel;

@property (nonatomic,strong)NSString * contentDesc;

@property (nonatomic,assign)BOOL isGoToRealName;

- (void)fadeIn;


@end

NS_ASSUME_NONNULL_END
