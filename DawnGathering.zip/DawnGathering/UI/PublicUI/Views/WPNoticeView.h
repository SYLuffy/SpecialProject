//
//  BBNoticeView.h
//  bashiBus
//
//  Created by ye on 15/12/30.
//  Copyright © 2015年 4GInter. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^BBNoticeViewImageButtonBlock)(void);

@interface WPNoticeView : UIView

@property (weak, nonatomic) IBOutlet UIView *bgView;
@property (weak, nonatomic) IBOutlet UIButton *closeBtn;
@property (weak, nonatomic) IBOutlet UIView *contentView;
@property (weak, nonatomic) IBOutlet UIImageView *noticeImageView;
@property (weak, nonatomic) IBOutlet UIButton *noticeBtn;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *imageViewTopConstraint;
@property (nonatomic, strong) NSString *imgUrl;
@property (nonatomic, copy) BBNoticeViewImageButtonBlock btnBlk;

+ (instancetype)xibView;
- (void)showOnView:(UIView *)view animated:(BOOL)animated;
- (void)dismiss;
@end
