//
//  NoNetworkView.h
//  HLGA
//
//  Created by 葛亮 on 2018/6/1.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void(^NoNetworkViewReloadBlock)(void);

@interface NoNetworkView : UIView

+ (instancetype)xibView;

@property (weak, nonatomic) IBOutlet UILabel *titileLabel;
@property (nonatomic, copy) NoNetworkViewReloadBlock reloadBlk;
@property (weak, nonatomic) IBOutlet UIButton *reloadButton;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topIndex;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *wIndex;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *hIndex;

-(void)setZoomView:(CGFloat )zoom topIndex:(CGFloat )topIndex titileFont:(NSInteger )titileFont buttonFont:(NSInteger )buttonFont;

@end
