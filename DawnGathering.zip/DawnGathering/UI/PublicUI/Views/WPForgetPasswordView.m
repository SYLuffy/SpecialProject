//
//  WPForgetPasswordView.m
//  HLGA
//
//  Created by 葛亮 on 2018/5/29.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "WPForgetPasswordView.h"

@implementation WPForgetPasswordView

+ (instancetype)xibView{
    
    return [[[NSBundle mainBundle] loadNibNamed:@"WPForgetPasswordView" owner:nil options:nil] lastObject];
    
}
-(void)awakeFromNib{
    [super awakeFromNib];
    [self.forgetButton setTitleColor:[Utils getMainColor] forState:UIControlStateNormal];
    [self.retryButton setTitleColor:[Utils getMainColor] forState:UIControlStateNormal];
    
}

- (void)showOnView:(UIView *)view
{
    self.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height);
    [view addSubview:self];
}

- (IBAction)closeBtnPressed:(id)sender {
    [self dismiss];
}

- (IBAction)noticeBtnPressed:(id)sender {
    if (_btnBlk) {
        _btnBlk();
    }
}

- (void)dismiss
{
    if (_dismissBlk) {
        _dismissBlk();
    }
    [self removeFromSuperview];
}

-(void)dealloc{
    
    NSLog(@"WPUpgradeVersionView dealloc!");
}
@end
