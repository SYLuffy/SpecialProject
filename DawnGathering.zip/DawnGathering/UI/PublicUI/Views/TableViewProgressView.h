//
//  TableViewProgressView.h
//  HLGA
//
//  Created by 葛亮 on 2018/6/20.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewProgressView : UIView
+ (instancetype)xibView;
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topIndex;

@end
