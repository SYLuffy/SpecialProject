//
//  SubTitleView.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/8/3.
//

#import "SubTitleView.h"

@implementation SubTitleView


- (void)setSelected:(BOOL)selected
{
    self.subTitleLabel.layer.cornerRadius = 10;
    if(selected)
    {
        self.titleLabel.font = [UIFont fontWithName:MEDIUM_FONT_NAME size:16];
        self.titleLabel.textColor = [Utils getMainColor];
        
        self.subTitleLabel.backgroundColor = [Utils getMainColor];
        self.subTitleLabel.textColor = [UIColor whiteColor];
    }else{
        self.titleLabel.font = [UIFont fontWithName:DEFAULT_FONT_NAME size:16];
        self.titleLabel.textColor = UIColorFromRGB(0x222222);
        
        self.subTitleLabel.backgroundColor = [UIColor clearColor];
        self.subTitleLabel.textColor = UIColorFromRGB(0x666666);
    }
}

@end
