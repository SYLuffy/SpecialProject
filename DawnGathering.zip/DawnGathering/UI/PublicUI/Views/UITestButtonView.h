//
//  UITestButtonView.h
//  DawnGathering
//
//  Created by 李冬岐 on 2023/8/16.
//

#import <UIKit/UIKit.h>
#import "ImageTtitleView.h"
#import "SubTitleView.h"

NS_ASSUME_NONNULL_BEGIN


typedef void(^TapSelectViewButtonWithIndex)(NSInteger index ,NSInteger cellIndex);

@interface UITestButtonView : UIScrollView

- (void)updateRefreshViewWith:(NSArray*)dataSource curentPage:(NSInteger)curentPage;
- (void)updateRefreshWithImagesTitles:(NSArray*)dataSource currentPage:(NSInteger)currentPage;

- (void)updateRefreshViewWithSubTitle:(NSArray*)dataSource curentPage:(NSInteger)curentPage;

@property (nonatomic,strong)NSArray * dataSource;

@property (nonatomic,strong)NSMutableArray <UIButton*>* buttons;
@property (nonatomic,strong)NSMutableArray <ImageTtitleView*>*imageTitles;
@property (nonatomic,strong)NSMutableArray <SubTitleView*>*subviewTitles;

@property (nonatomic,strong)NSMutableArray <UIView *>* gapLines;
@property (nonatomic,assign)NSInteger currentIndex;

@property (nonatomic,assign)NSInteger cellIndex;

@property (nonatomic,strong)UIColor * normalColor;
@property (nonatomic,strong)UIColor * selectedColor;

@property (nonatomic,copy)TapSelectViewButtonWithIndex tapSelectViewButtonWithIndex;

@end

NS_ASSUME_NONNULL_END
