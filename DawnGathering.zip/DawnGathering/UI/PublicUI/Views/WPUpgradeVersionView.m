//
//  WPUpgradeVersionView.m
//  HLGA
//
//  Created by 葛亮 on 2018/5/28.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "WPUpgradeVersionView.h"
@interface WPUpgradeVersionView()
{
    NSInteger asmanda;
}
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *contentWide;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *contentBottom;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *lineOne;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *lineTow;
@property (weak, nonatomic) IBOutlet UILabel *connectLable;

@end
@implementation WPUpgradeVersionView

+ (instancetype)xibView{
    
    return [[[NSBundle mainBundle] loadNibNamed:@"WPUpgradeVersionView" owner:nil options:nil] lastObject];
    
}
-(void)awakeFromNib{
    [super awakeFromNib];
    
    asmanda = 0;
    
    self.lineOne.constant = 1.0 / [UIScreen mainScreen].scale;
    self.lineTow.constant = 1.0 / [UIScreen mainScreen].scale;
    
    CGFloat indexWide =  315.0 / 375.0;
    self.contentWide.constant = [UIScreen mainScreen].bounds.size.width  * indexWide;
    //适配iPhone X
    CGFloat statusHeight = CGRectGetHeight([UIApplication sharedApplication].statusBarFrame);
    if (statusHeight == 20.0) {
        CGFloat indexHBottom = 33.0 / 667.0;
        self.contentBottom.constant = [UIScreen mainScreen].bounds.size.height  *  indexHBottom;
    }
}

-(void)setModel:(UpgradeVersionModel *)model{
    asmanda = model.asmanda;
    self.connectLable.text = model.content;
    if (model.asmanda == 1) {
        _cancelButton.hidden = YES;
        _lineView.hidden = YES;
        CGFloat indexWide =  315.0 / 375.0;
        self.lineIndex.constant = -(([UIScreen mainScreen].bounds.size.width  * indexWide)/2);
    }

}

- (void)showOnView:(UIView *)view
{
    self.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height);
    [view addSubview:self];
}

- (IBAction)closeBtnPressed:(id)sender {

    if (asmanda == 1) {
        [self exitApplication];
    }else{
    
        if(_dismmisBlk){
            _dismmisBlk();
        }
        [self dismiss];
    }

}

- (IBAction)noticeBtnPressed:(id)sender {
    
        if (_btnBlk) {
            _btnBlk();
        }
}

- (void)dismiss
{
    [UIView animateWithDuration:0.35 animations:^{
        self.alpha = 0;
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
}

-(void)dealloc{
    
    NSLog(@"WPUpgradeVersionView dealloc!");
}


- (void)exitApplication {
    
    UIWindow *window = [UIApplication sharedApplication].delegate.window;
    
    [UIView animateWithDuration:1.0f animations:^{
        
        window.alpha = 0;
        
        window.frame = CGRectMake(0, window.bounds.size.width, 0, 0);
        
    } completion:^(BOOL finished) {
        
        exit(0);
        
    }];
    
}


@end
