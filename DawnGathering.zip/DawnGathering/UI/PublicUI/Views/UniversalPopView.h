//
//  UniversalPopView.h
//  DawnGathering
//
//  Created by 李冬岐 on 2024/1/17.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UniversalPopView : UIView
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *contentLabel;
@property (weak, nonatomic) IBOutlet UIButton *confirmButton;
@property (weak, nonatomic) IBOutlet UIView *popView;
@property (weak, nonatomic) IBOutlet UIView *darkMask;

@property (nonatomic,strong)NSString * contentDesc;

- (void)fadeIn;

@end

NS_ASSUME_NONNULL_END
