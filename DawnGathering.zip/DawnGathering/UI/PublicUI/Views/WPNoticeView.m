//
//  BBNoticeView.m
//  bashiBus
//
//  Created by ye on 15/12/30.
//  Copyright © 2015年 4GInter. All rights reserved.
//

#import "WPNoticeView.h"
#import <SDWebImage/UIImageView+WebCache.h>
#import "WPAdsView.h"
#import "WPUpgradeVersionView.h"
@interface WPNoticeView ()
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *contentViewCenterYConstraint;

@end

@implementation WPNoticeView


+ (instancetype)xibView{
    
    return [[[NSBundle mainBundle] loadNibNamed:@"WPNoticeView" owner:nil options:nil] lastObject];
    
}

- (void)awakeFromNib
{
    [super awakeFromNib];
    [ServiceManager popUpAdssuccess:^(NSDictionary *data) {

    }];

}

-(void)setImgUrl:(NSString *)imgUrl{
    
    if (_imgUrl != imgUrl) {
        _imgUrl = imgUrl;
        [_noticeImageView sd_setImageWithURL:[NSURL URLWithString:imgUrl] placeholderImage:[UIImage imageNamed:@"img_pic"]];
    }    
}

- (IBAction)closeBtnPressed:(id)sender {
    [self dismiss];
}

- (IBAction)noticeBtnPressed:(id)sender {
    if (_btnBlk) {
        _btnBlk();
    }
}

- (void)showOnView:(UIView *)view animated:(BOOL)animated
{
    if (animated) {
        
        NSInteger showViewLocationBgIndex = 0;
        
        NSInteger index = [[view subviews] count];
        for (int i = 0;  i < index; i++) {
            UIView *v = [view subviews][i];
            if ([v isKindOfClass:[WPAdsView class]]) {
                showViewLocationBgIndex += 1;
            }
         
            if ([v isKindOfClass:[WPUpgradeVersionView class]]) {
                showViewLocationBgIndex += 1;
            }
        }
        [view insertSubview:self atIndex:index-showViewLocationBgIndex];
  
        _bgView.alpha = 0;
        __block CGRect frame = _contentView.frame;
        frame.size.height = 0;
        _contentView.frame = frame;
        [UIView animateWithDuration:1 animations:^{
            CGFloat height = [UIScreen mainScreen].bounds.size.height / 2 + _noticeImageView.frame.size.height / 2 - 25 - _closeBtn.frame.size.height;
            frame.size.height = height;
            _contentView.frame = frame;
            _bgView.alpha = 1;
        }];
    } else {
        NSInteger showViewLocationBgIndex = 0;
        
        NSInteger index = [[view subviews] count];
        for (int i = 0;  i < index; i++) {
            UIView *v = [view subviews][i];
            if ([v isKindOfClass:[WPAdsView class]]) {
                showViewLocationBgIndex += 1;
            }
            
            if ([v isKindOfClass:[WPUpgradeVersionView class]]) {
                showViewLocationBgIndex += 1;
            }
        }
        [view insertSubview:self atIndex:index-showViewLocationBgIndex];
        
    }
}

- (void)dismiss
{
    [self removeFromSuperview];
}

-(void)dealloc{
    
    NSLog(@"WPNoticeView dealloc!");
}

@end
