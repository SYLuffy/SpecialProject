//
//  UITestButtonView.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/8/16.
//

#import "UITestButtonView.h"

#define BUTTON_TAG 400
#define IMAGE_TAG 300

#define SUBVIEW_TAG 200

#define SHOW_ALL_COUNT 5

@implementation UITestButtonView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        self.imageTitles = [NSMutableArray array];
        self.buttons = [NSMutableArray array];
        self.gapLines = [NSMutableArray array];
        self.subviewTitles = [NSMutableArray array];
    }
    return self;
}


- (void)updateRefreshViewWith:(NSArray*)dataSource curentPage:(NSInteger)curentPage
{
   self.currentIndex = curentPage;
   self.dataSource = dataSource;
   //刷新视图;
   CGFloat buttonWidth;
   
   if(self.dataSource.count <= SHOW_ALL_COUNT)
   {
       buttonWidth = self.frame.size.width / self.dataSource.count;
   }else{
       buttonWidth = self.frame.size.width / 4 - 10;
   }
    
    if(self.buttons.count > 0)
    {
        for(UIButton * view in self.buttons)
        {
            [view removeFromSuperview];
        }
    }
   
   CGFloat totalWidth = 0;
   
   for(NSInteger i = 0; i < self.dataSource.count; i++)
   {
       UIButton * button = self.buttons[i];
       
       NSString * title = self.dataSource[i][NAME];
       
       NSNumber * enable = self.dataSource[i][ENABLE];
   
       if(!button)
       {
           button = [self createButtonWithTitle:title];
           [self.buttons addObject:button];
       }
       
       if(enable)
       {
           if(enable.integerValue == 0)
           {
               button.alpha = 0.4;
           }else{
               button.alpha = 1;
           }
           button.userInteractionEnabled = enable.boolValue;
       }else{
           button.userInteractionEnabled = true;
       }
       
       button.tag = BUTTON_TAG + i;
       
       if(i == self.currentIndex)
       {
           [button setTitleColor:self.selectedColor forState:UIControlStateNormal];
       }else{
           [button setTitleColor:self.normalColor forState:UIControlStateNormal];
       }
       
       [button setTitle:title forState:UIControlStateNormal];
       
       
       button.frame = CGRectMake(i * buttonWidth, 0, buttonWidth, self.frame.size.height);
       
       UIView * gapLine = self.gapLines[i];
       
       if(!gapLine)
       {
           gapLine = [[UIView alloc] initWithFrame:CGRectMake(button.frame.origin.x + button.frame.size.width - 1, 10, 1, self.frame.size.height - 20)];
           gapLine.backgroundColor = UIColorFromRGB(0xEEEEEE);
           [self.gapLines addObject:gapLine];
       }
       
       [self addSubview:gapLine];
       
       if(i == self.dataSource.count - 1)
       {
           gapLine.hidden = true;
       }else{
           gapLine.hidden = false;
       }
       
       [self addSubview:button];
       
       [button addTarget:self action:@selector(tapButtonHandler:) forControlEvents:UIControlEventTouchUpInside];
       
       totalWidth += buttonWidth;
       
       
   }
   
    self.contentSize = CGSizeMake(totalWidth, self.frame.size.height);
   
}

- (void)tapButtonHandler:(UIButton*)sender{
    
    NSInteger index = sender.tag - BUTTON_TAG;
    self.currentIndex = index;
    for(UIButton * button in self.buttons)
    {
        [button setTitleColor:self.normalColor forState:UIControlStateNormal];
    }
    UIButton *  currentButton = self.buttons[index];
    [currentButton setTitleColor:self.selectedColor forState:UIControlStateNormal];
    
    if(self.dataSource.count > SHOW_ALL_COUNT)
    {
        CGFloat totalOffsetX = self.contentSize.width - SCREEN_WIDTH;

        CGFloat centerX = [self getItemCenterWithIndex:index list:self.buttons].x;
        CGFloat moveX = centerX - SCREEN_WIDTH/2;

        if(moveX < 0) moveX = 0;
        if(moveX > totalOffsetX) moveX = totalOffsetX;

        [UIView animateWithDuration:0.2 animations:^{

            [self setContentOffset:CGPointMake(moveX, 0)];
        } completion:^(BOOL finished) {
            if(self.tapSelectViewButtonWithIndex){
                self.tapSelectViewButtonWithIndex(index,self.cellIndex);
            }
        }];
    }else{
        if(self.tapSelectViewButtonWithIndex){
            self.tapSelectViewButtonWithIndex(index,self.cellIndex);
        }
    }
    
}


- (UIButton*)createButtonWithTitle:(NSString*)title
{
    UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
    
    [button setTitle:title forState:UIControlStateNormal];
    
    button.titleLabel.font = [UIFont fontWithName:DEFAULT_FONT_NAME size:12];

    return button;
    
}


- (void)updateRefreshWithImagesTitles:(NSArray*)dataSource currentPage:(NSInteger)currentPage{
    self.currentIndex = currentPage;
    self.dataSource = dataSource;
    
    //刷新视图;
    CGFloat buttonWidth;
    
    if(self.dataSource.count <= SHOW_ALL_COUNT)
    {
        buttonWidth = self.frame.size.width / self.dataSource.count;
    }else{
        buttonWidth = self.frame.size.width / 5 - 10;
    }
    
    if(self.imageTitles.count > 0)
    {
        for(ImageTtitleView * view in self.imageTitles)
        {
            [view removeFromSuperview];
        }
    }
    
    CGFloat totalWidth = 0;
    
    for(NSInteger i = 0; i < self.dataSource.count; i++)
    {
        ImageTtitleView * imageView = self.imageTitles[i];
        
        NSDictionary * dic = self.dataSource[i];
        
        if(!imageView)
        {
            imageView = [self createImageTitleView:CGRectMake(i * buttonWidth, 0, buttonWidth, self.frame.size.height)];
            
            [self.imageTitles addObject:imageView];
        }
        imageView.tag = IMAGE_TAG + i;
        
        imageView.frame = CGRectMake(i * buttonWidth, 0, buttonWidth, 49);
        
        imageView.dataDic = dic;
        
        imageView.selectedColor = self.selectedColor;
        imageView.normalColor = self.normalColor;
        if(i == self.currentIndex)
        {
            [imageView setSelected:true];
        }else{
            [imageView setSelected:false];
        }
        
        [self addSubview:imageView];
        
        
        
        totalWidth += buttonWidth;
        
    }
    
    self.contentSize = CGSizeMake(totalWidth, self.bounds.size.height);
}

- (ImageTtitleView*)createImageTitleView:(CGRect)rect
{
    ImageTtitleView * view = (ImageTtitleView*)[Utils getXibByName:@"ImageTtitleView"];
    
    view.frame = rect;
    
    view.userInteractionEnabled = true;
       
    UITapGestureRecognizer * tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapImageViewHandler:)];
    
    [view addGestureRecognizer:tapGesture];
    
    
    return view;
}

- (void)tapImageViewHandler:(UITapGestureRecognizer*)gesture
{
    NSInteger index = gesture.view.tag - IMAGE_TAG;
    
    NSDictionary * dic = self.dataSource[index];
    
    NSNumber * jumpType = dic[JUMP_TYPE];
    NSString * hrefURL = dic[HREF_URL];
    
    if(jumpType.integerValue == 0)
    {
        if([hrefURL isEqualToString:@"homePage"] || [hrefURL isEqualToString:@"personCenter"])
        {
            self.currentIndex = index;
            for(ImageTtitleView * subview in self.imageTitles)
            {
                [subview setSelected:false];
            }
            
            ImageTtitleView *  selectedView = self.imageTitles[index];
            
            [selectedView setSelected:true];
        }
       
    }
    
    if(self.dataSource.count > SHOW_ALL_COUNT)
    {
        CGFloat totalOffsetX = self.contentSize.width - SCREEN_WIDTH;

        CGFloat centerX = [self getItemCenterWithIndex:index list:self.imageTitles].x;
        CGFloat moveX = centerX - SCREEN_WIDTH/2;

        if(moveX < 0) moveX = 0;
        if(moveX > totalOffsetX) moveX = totalOffsetX;

        [UIView animateWithDuration:0.2 animations:^{

            [self setContentOffset:CGPointMake(moveX, 0)];
        } completion:^(BOOL finished) {
            if(self.tapSelectViewButtonWithIndex){
                self.tapSelectViewButtonWithIndex(index,self.cellIndex);
            }
        }];
    }else{
        if(self.tapSelectViewButtonWithIndex){
            self.tapSelectViewButtonWithIndex(index,self.cellIndex);
        }
    }
}


- (void)updateRefreshViewWithSubTitle:(NSArray*)dataSource curentPage:(NSInteger)curentPage{
   self.currentIndex = curentPage;;
   self.dataSource = dataSource;
   //刷新视图;
   CGFloat buttonWidth;

   if(self.dataSource.count <= SHOW_ALL_COUNT)
   {
       buttonWidth = self.frame.size.width / self.dataSource.count;
   }else{
       buttonWidth = self.frame.size.width / 4 - 10;
   }
   
    
    
    if(self.subviewTitles.count > 0)
    {
        for(SubTitleView * view in self.subviewTitles)
        {
            [view removeFromSuperview];
        }
    }
   CGFloat totalWidth = 0;

   for(NSInteger i = 0; i < self.dataSource.count; i++)
   {
       SubTitleView * subview = self.subviewTitles[i];

       NSString * title = self.dataSource[i][NAME];
       NSString * subTitle = self.dataSource[i][SUB_TITLE];

       if(!subview)
       {
           subview = [self createSubViewWithTitle:title subTitle:subTitle rect:CGRectMake(i * buttonWidth, 0, buttonWidth, self.frame.size.height)];
           [self.subviewTitles addObject:subview];
       }
       subview.tag = SUBVIEW_TAG + i;

       subview.frame = CGRectMake(i * buttonWidth, 0, buttonWidth, self.frame.size.height);

       if(i == self.currentIndex)
       {
           [subview setSelected:true];
       }else{
           [subview setSelected:false];
       }

       subview.titleLabel.text = title;
       subview.subTitleLabel.text = subTitle;

       [self addSubview:subview];

       

       totalWidth += buttonWidth;

   }

    self.contentSize = CGSizeMake(totalWidth, self.frame.size.height);
}


- (SubTitleView*)createSubViewWithTitle:(NSString*)title subTitle:(NSString*)subTitle rect:(CGRect)rect
{
    SubTitleView * view = (SubTitleView*)[Utils getXibByName:@"SubTitleView"];

    view.frame = rect;

    view.userInteractionEnabled = true;

    UITapGestureRecognizer * tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapSubviewHandler:)];

    [view addGestureRecognizer:tapGesture];

    return view;
}


- (void)tapSubviewHandler:(UITapGestureRecognizer*)gesture
{
    NSInteger index = gesture.view.tag - SUBVIEW_TAG;
    self.currentIndex = index;
    for(SubTitleView * subview in self.subviews)
    {
        [subview setSelected:false];
    }
    
    SubTitleView *  selectedView = self.subviews[index];
    
    [selectedView setSelected:true];
    
    if(self.dataSource.count > SHOW_ALL_COUNT)
    {
        CGFloat totalOffsetX = self.contentSize.width - SCREEN_WIDTH;

        CGFloat centerX = [self getItemCenterWithIndex:index list:self.subviewTitles].x;
        CGFloat moveX = centerX - SCREEN_WIDTH/2;

        if(moveX < 0) moveX = 0;
        if(moveX > totalOffsetX) moveX = totalOffsetX;

        [UIView animateWithDuration:0.2 animations:^{

            [self setContentOffset:CGPointMake(moveX, 0)];
        } completion:^(BOOL finished) {
            if(self.tapSelectViewButtonWithIndex){
                self.tapSelectViewButtonWithIndex(index,self.cellIndex);
            }
        }];
    }else{
        if(self.tapSelectViewButtonWithIndex){
            self.tapSelectViewButtonWithIndex(index,self.cellIndex);
        }
    }

}

- (CGPoint)getItemCenterWithIndex:(NSInteger)index list:(NSMutableArray*)list
{
    if(list.count > 0)
    {
        UIView * view = list[index];
        
        return view.center;
    }
    
    return CGPointMake(0, 0);
}

@end
