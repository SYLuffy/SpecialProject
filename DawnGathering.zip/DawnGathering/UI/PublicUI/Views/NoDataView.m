//
//  NoDataView.m
//  HLGA
//
//  Created by 葛亮 on 2018/6/1.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "NoDataView.h"

@implementation NoDataView

+ (instancetype)xibView{
    
    return [[[NSBundle mainBundle] loadNibNamed:@"NoDataView" owner:nil options:nil] lastObject];
    
}

-(void)setImageOrTitileNoDataViewType:(NoDataViewType)type{
    
    if (type == NoDataViewTypeDefault) {
        _headImageView.image = [UIImage imageNamed:@"not_data_img"];
        _titileLable.text = @"暂无内容";
        
    }else if (type == NoDataViewTypeNoMessage){
        _headImageView.image = [UIImage imageNamed:@"not_data_img"];
        _titileLable.text = @"没有消息";
        
    }else if (type == NoDataViewTypeNoContent){
        _headImageView.image = [UIImage imageNamed:@"not_data_img"];
        _titileLable.text = @"暂无内容";
    }else if(type == NoDataViewTypeRedEnvelope)
    {
        _headImageView.image = [UIImage imageNamed:@"img_no_red_envelop"];
        _titileLable.text = @"暂无红包";
    }
}
-(void)setZoomView:(CGFloat )zoom topIndex:(CGFloat )topIndex titileFont:(NSInteger )titileFont{
    
    _topIndex.constant = topIndex;
    _wIndex.constant =  _wIndex.constant * zoom;
    _hIndex.constant =  _hIndex.constant * zoom;
    _titileLable.font =  [UIFont fontWithName:@"PingFangSC-Regular" size:titileFont];
}
-(void)awakeFromNib{
    [super awakeFromNib];
    NSLog(@" %@  == NoDataView init!",self);
}

-(void)dealloc{
    NSLog(@"NoDataView dealloc!");
}

@end
