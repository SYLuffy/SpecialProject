//
//  NoNetworkView.m
//  HLGA
//
//  Created by 葛亮 on 2018/6/1.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "NoNetworkView.h"

@implementation NoNetworkView

+ (instancetype)xibView{
    
    return [[[NSBundle mainBundle] loadNibNamed:@"NoNetworkView" owner:nil options:nil] lastObject];
    
}

-(void)awakeFromNib{
    
    [super awakeFromNib];
    _reloadButton.hidden = NO;
    NSLog(@" %@  == NoNetworkView init!",self);

}

-(void)setZoomView:(CGFloat )zoom topIndex:(CGFloat )topIndex titileFont:(NSInteger )titileFont buttonFont:(NSInteger )buttonFont{
    
    _topIndex.constant = topIndex;
    _wIndex.constant =  _wIndex.constant * zoom;
    _hIndex.constant =  _hIndex.constant * zoom;
    _titileLabel.font =  [UIFont fontWithName:@"PingFangSC-Regular" size:titileFont];
    _reloadButton.titleLabel.font =  [UIFont fontWithName:@"PingFangSC-Regular" size:buttonFont];
    _reloadButton.layer.cornerRadius = 200 * 0.11 * zoom;
    
}




- (IBAction)reloadBtnPressed:(id)sender {
    if (_reloadBlk) {
        _reloadBlk();
    }
}
-(void)dealloc{
    NSLog(@"NoNetworkView dealloc!");
}
@end
