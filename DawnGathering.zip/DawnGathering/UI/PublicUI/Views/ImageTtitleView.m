//
//  ImageTtitleView.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/8/16.
//

#import "ImageTtitleView.h"

@implementation ImageTtitleView

- (void)setSelected:(BOOL)selected
{
    
    if(selected)
    {
        self.titleLabel.font = [UIFont fontWithName:MEDIUM_FONT_NAME size:11];
        self.titleLabel.textColor = self.selectedColor;
        
        NSString * selectedImg = self.dataDic[ACTIVE];
        [Utils loadImage:self.imageView andURL:selectedImg isLoadRepeat:false];
       
    }else{
        self.titleLabel.font = [UIFont fontWithName:DEFAULT_FONT_NAME size:11];
        self.titleLabel.textColor = self.normalColor;
        NSString * normalImg = self.dataDic[INACTIVE];
        [Utils loadImage:self.imageView andURL:normalImg isLoadRepeat:false];
    }
}

- (void)drawRect:(CGRect)rect
{
    [super drawRect:rect];
    
    self.imageWH.constant = SCREEN_WIDTH / 375 * 20;
    
}
- (void)setDataDic:(NSDictionary *)dataDic
{
    _dataDic = dataDic;
    
    NSString * title = _dataDic[TITLE];
    
    self.titleLabel.text = title;
    
    NSString * normalImg = self.dataDic[INACTIVE];
    [Utils loadImage:self.imageView andURL:normalImg isLoadRepeat:false];
    
}
@end
