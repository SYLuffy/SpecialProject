//
//  WPAdsView.m
//  HLGA
//
//  Created by 葛亮 on 2018/5/28.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "WPAdsView.h"
#import <SDWebImage/UIImageView+WebCache.h>

@interface WPAdsView()

@property (weak, nonatomic) IBOutlet UIButton *timeButton;

@end
@implementation WPAdsView

+ (instancetype)xibView{
    
    return [[[NSBundle mainBundle] loadNibNamed:@"WPAdsView" owner:nil options:nil] lastObject];
    
}


-(void)setImgUrl:(NSString *)imgUrl{
    
    if (_imgUrl != imgUrl) {
        _imgUrl = imgUrl;
        [_bgImageView sd_setImageWithURL:[NSURL URLWithString:imgUrl]];
        
        _bgImageView.contentMode = UIViewContentModeScaleAspectFill;
        
    }
}
-(void)awakeFromNib{
    [super awakeFromNib];
    //适配iPhone X
    CGFloat statusHeight = CGRectGetHeight([UIApplication sharedApplication].statusBarFrame);
    if (statusHeight == 20.0) {
        _contentViewCenterYConstraint.constant = 38;
    } else {
        _contentViewCenterYConstraint.constant = 38 + 24;
    }
    [self securityButtonCountDown:_timeButton];
}

- (void)showOnView:(UIView *)view
{
    
    self.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height);
    [view addSubview:self];
}

- (void)dismiss
{
    if (_dismissBlk) {
        _dismissBlk();
    }
    
    [UIView animateWithDuration:0.35 animations:^{
        self.alpha = 0;
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
}


- (IBAction)closeBtnPressed:(id)sender {
    
    [self dismiss];
}

- (IBAction)noticeBtnPressed:(id)sender {
    if (_btnBlk) {
        _btnBlk();
    }
}


- (void)securityButtonCountDown:(UIButton*)securityCodeButton{
    __weak WPAdsView *weakSelf = self;
    __block int timeout= 5; //倒计时时间
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_source_t _timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0,queue);
    dispatch_source_set_timer(_timer,dispatch_walltime(NULL, 0),1.0*NSEC_PER_SEC, 0); //每秒执行
    dispatch_source_set_event_handler(_timer, ^{
        if(timeout<=0){ //倒计时结束，关闭
            dispatch_source_cancel(_timer);
            dispatch_async(dispatch_get_main_queue(), ^{
                [weakSelf dismiss];
            });
        }else{
            dispatch_async(dispatch_get_main_queue(), ^{
                [securityCodeButton setTitle:[NSString stringWithFormat:@"跳过%ds",timeout+1] forState:UIControlStateNormal];
            });
            timeout--;
        }
    });
    dispatch_resume(_timer);
}

-(void)dealloc{
    
    NSLog(@"WPAdsView dealloc!");
}


@end
