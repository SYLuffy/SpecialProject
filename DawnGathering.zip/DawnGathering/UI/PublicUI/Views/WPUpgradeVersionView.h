//
//  WPUpgradeVersionView.h
//  HLGA
//
//  Created by 葛亮 on 2018/5/28.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UpgradeVersionModel.h"
typedef void(^WPUpgradeVersionViewBlock)(void);
typedef void(^WPUpgradeVersionViewDismissBlock)(void);

@interface WPUpgradeVersionView : UIView
@property (nonatomic, copy) WPUpgradeVersionViewBlock btnBlk;
@property(nonatomic,copy)WPUpgradeVersionViewDismissBlock dismmisBlk;
@property(nonatomic,strong)UpgradeVersionModel *model;
+ (instancetype)xibView;
- (void)showOnView:(UIView *)view;
- (void)dismiss;
@property (weak, nonatomic) IBOutlet UIButton *cancelButton;
@property (weak, nonatomic) IBOutlet UIView *lineView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *lineIndex;

@end
