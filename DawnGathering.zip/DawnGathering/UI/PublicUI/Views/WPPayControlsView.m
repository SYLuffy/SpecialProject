//
//  WPPayControlsView.m
//  HLGA
//
//  Created by 葛亮 on 2018/6/6.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "WPPayControlsView.h"
#import <IQKeyboardManager.h>

@interface WPPayControlsView()<UITextFieldDelegate>
{
    UIView *_view;
    
}
@property (weak, nonatomic) IBOutlet UILabel *pwdLable1;//第一个密码框
@property (weak, nonatomic) IBOutlet UILabel *pwdLable2;//第二个密码框
@property (weak, nonatomic) IBOutlet UILabel *pwdLable3;//第三个密码框
@property (weak, nonatomic) IBOutlet UILabel *pwdLable4;//第四个密码框
@property (weak, nonatomic) IBOutlet UILabel *pwdLable5;//第五个密码框
@property (weak, nonatomic) IBOutlet UILabel *pwdLable6;//第六个密码框
@property (weak, nonatomic) IBOutlet UIButton *TFButton;
@property (nonatomic,strong) UITextField *TF;
@end



@implementation WPPayControlsView

+ (instancetype)xibView{
    return [[[NSBundle mainBundle] loadNibNamed:@"WPPayControlsView" owner:nil options:nil] lastObject];
}

-(void)awakeFromNib{
    
    [super awakeFromNib];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillHide:)
                                                 name:UIKeyboardWillHideNotification
                                               object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeContentViewPoint:) name:UIKeyboardWillShowNotification object:nil];
 

}

-(UITextField *)TF{
    
    if (!_TF) {
        _TF = [[UITextField alloc]init];
        _TF.frame = CGRectMake(0, 0, 0, 0);
        _TF.delegate = self;
        _TF.keyboardType=UIKeyboardTypeNumberPad;
        [_TF setSecureTextEntry:YES];
        [_TF addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
        [self addSubview:_TF];
    }
    return _TF;
}


-(void)setupUITextF{
    
    if (![self.TF becomeFirstResponder])
    {
        [self.TF becomeFirstResponder];
    }
}

- (void)textFieldDidChange:(id) sender
{
    UITextField *_field = (UITextField *)sender;
    
    if (_field.text.length > 6)
    {
        _field.text = [_field.text substringToIndex:6];
    }
    
    switch (_field.text.length) {
        case 0:
        {
            _pwdLable1.hidden=YES;
            _pwdLable2.hidden=YES;
            _pwdLable3.hidden=YES;
            _pwdLable4.hidden=YES;
            _pwdLable5.hidden=YES;
            _pwdLable6.hidden=YES;
        }
            break;
        case 1:
        {
            _pwdLable1.hidden=NO;
            _pwdLable2.hidden=YES;
            _pwdLable3.hidden=YES;
            _pwdLable4.hidden=YES;
            _pwdLable5.hidden=YES;
            _pwdLable6.hidden=YES;
        }
            break;
        case 2:
        {
            _pwdLable1.hidden=NO;
            _pwdLable2.hidden=NO;
            _pwdLable3.hidden=YES;
            _pwdLable4.hidden=YES;
            _pwdLable5.hidden=YES;
            _pwdLable6.hidden=YES;
        }
            break;
        case 3:
        {
            _pwdLable1.hidden=NO;
            _pwdLable2.hidden=NO;
            _pwdLable3.hidden=NO;
            _pwdLable4.hidden=YES;
            _pwdLable5.hidden=YES;
            _pwdLable6.hidden=YES;
        }
            break;
        case 4:
        {
            _pwdLable1.hidden=NO;
            _pwdLable2.hidden=NO;
            _pwdLable3.hidden=NO;
            _pwdLable4.hidden=NO;
            _pwdLable5.hidden=YES;
            _pwdLable6.hidden=YES;
        }
            break;
        case 5:
        {
            _pwdLable1.hidden=NO;
            _pwdLable2.hidden=NO;
            _pwdLable3.hidden=NO;
            _pwdLable4.hidden=NO;
            _pwdLable5.hidden=NO;
            _pwdLable6.hidden=YES;
        }
            break;
        case 6:
        {
            _pwdLable1.hidden=NO;
            _pwdLable2.hidden=NO;
            _pwdLable3.hidden=NO;
            _pwdLable4.hidden=NO;
            _pwdLable5.hidden=NO;
            _pwdLable6.hidden=NO;
        }
            break;
            
        default:
            break;
    }
    
    if (_field.text.length==6)
    {
        if (_btnBlk) {
            _btnBlk(self.TF.text);
        }
    }
}
- (void)showOnView:(UIView *)view
{
    [view addSubview:self];
    self.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 184);
    [self setupUITextF];
}

- (IBAction)clickPayTFPressed:(id)sender {
    [self setupUITextF];
}

- (IBAction)closeBtnPressed:(UIBarButtonItem *)sender {
    
    [self dismiss];
    
}
- (void)clearTFText{
    
    _TF.text = @"";

}

- (void)dismiss
{
    [self removeFromSuperview];
}

-(void)dealloc{
    
    NSLog(@"WPPayControlsView dealloc!");
    [[NSNotificationCenter defaultCenter] removeObserver:self];

}


- (void) changeContentViewPoint:(NSNotification *)notification{
    
    NSDictionary *userInfo = [notification userInfo];
    
    NSValue *value = [userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
    
    CGFloat keyBoardEndY = value.CGRectValue.origin.y;
    // 得到键盘弹出后的键盘视图所在y坐标
    NSNumber *duration = [userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey];
    
    NSNumber *curve = [userInfo objectForKey:UIKeyboardAnimationCurveUserInfoKey];
   
    // 添加移动动画，使视图跟随键盘移动
    [UIView animateWithDuration:duration.doubleValue animations:^{
        [UIView setAnimationBeginsFromCurrentState:YES];
        [UIView setAnimationCurve:[curve intValue]];
    
        self.center = CGPointMake(self.center.x, keyBoardEndY  - self.bounds.size.height/2.0);
    }];
}

- (void)keyboardWillHide:(NSNotification *)notification
{
    [self dismiss];
}

@end
