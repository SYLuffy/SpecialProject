//
//  WPForgetPasswordView.h
//  HLGA
//
//  Created by 葛亮 on 2018/5/29.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void(^WPForgetPasswordViewBlock)(void);
typedef void(^WPForgetPasswordViewDismissBlock)(void);

@interface WPForgetPasswordView : UIView
@property (weak, nonatomic) IBOutlet UIButton *forgetButton;
@property (weak, nonatomic) IBOutlet UIButton *retryButton;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bottomIndex;
@property (nonatomic, copy) WPForgetPasswordViewBlock btnBlk;
@property (nonatomic, copy) WPForgetPasswordViewDismissBlock dismissBlk;

+ (instancetype)xibView;
- (void)showOnView:(UIView *)view;
- (void)dismiss;

@end
