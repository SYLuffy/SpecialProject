//
//  PayView.m
//  HLGA
//
//  Created by Linus on 2018/6/6.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "PayView.h"
#import "UnifiedPayView.h"
#import "WPPaymentPasswordRetrieveVC.h"
@interface PayView()
{
    CGRect panelFrame;
    UnifiedPayView * panel;
    NSDictionary * data;
}

@property(nonatomic,strong)UIView * darkMask;
@property(nonatomic,strong)NSString * closeStatus;

@end

@implementation PayView


- (instancetype)initWithPanelFrame:(CGRect)frame andData:(NSDictionary*)dataSource
{
    self = [super init];
    if (self) {
        
        self.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
        
        self.backgroundColor = [UIColor clearColor];
        
        data = dataSource;
        panelFrame = frame;
    }
    return self;
}

- (void)drawRect:(CGRect)rect{
    [super drawRect:rect];
    
    if([SharedInstance getInstance].isOpenedUnifiedPay)
    {
        return;
    }
    
    [SharedInstance getInstance].isOpenedUnifiedPay = true;
    
    self.closeStatus = @"0";//默认为正常关闭;
    
    self.darkMask = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
    
    self.darkMask.backgroundColor = [UIColor blackColor];
    
    self.darkMask.alpha = 0;
    
    [self addSubview:_darkMask];
    
    self.darkMask.userInteractionEnabled = true;
    
    UITapGestureRecognizer * tapMask = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapMaskCloseHandler:)];
    
    [self.darkMask addGestureRecognizer:tapMask];
    
    panel = [[UnifiedPayView alloc]initWithFrame:panelFrame andData:data];
    
    panel.backgroundColor = UIColorFromRGB(0xF6F6F6);
    
    panel.center = CGPointMake(panel.frame.size.width/2, self.frame.size.height + panel.frame.size.height/2);
    
    __weak typeof(self) weakSelf = self;
    
    panel.CloseBackBlock = ^(NSString * status) {
        
        weakSelf.closeStatus = status;
        
        [weakSelf fadeOut];
    };
    
    [self addSubview:panel];
    [self fadeIn];
    
}

- (void)tapMaskCloseHandler:(UITapGestureRecognizer*)gesture
{
    [self fadeOut];
}

- (void)fadeIn{
    self.darkMask.alpha = 0;
    
    [UIView animateWithDuration:0.4 animations:^{
        self.darkMask.alpha = 0.5;
        panel.center = CGPointMake(panel.frame.size.width/2, self.frame.size.height - panel.frame.size.height/2);
    }];
}

- (void)fadeOut{
    
    if(panel.payStatus.integerValue == -1)
    {
        __weak typeof(self) weakSelf = self;
        //取消需要弹窗询问;
        [Utils alertWithTitle:@"提示" msg:@"确定要取消支付？" andConfirm:^(BOOL isConfirm) {
            
            [weakSelf closePanelView];
        } cancel:^{
            
        }];
        return;
    }
    
    [self closePanelView];
    
}

- (void)closePanelView{
    self.darkMask.alpha = 0.5;
    [UIView animateWithDuration:0.4 animations:^{
        self.darkMask.alpha = 0;
        panel.center = CGPointMake(panel.frame.size.width/2, self.frame.size.height + panel.frame.size.height/2);
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
        
        if(self.closeStatus.integerValue == 0)
        {
            if(self.PayCompeleteBlock != nil)
            {
                self.PayCompeleteBlock(panel.payStatus);
            }
        }else if(self.closeStatus.integerValue == 1)
        {
            //关闭后打开忘记支付密码页;
            UIViewController * vc =  [Utils getCurrentVC];
            
            WPPaymentPasswordRetrieveVC *retrieveVC = (WPPaymentPasswordRetrieveVC *)[Utils getViewControllerByStoryBoardName:SB_NAME_ME andIdentifier:SB_ID_PAY_MENT_PASSWORD_RETRIEVE];
            
            [SharedInstance getInstance].forGetClass = [[Utils getCurrentVC] class];
            
            [vc.navigationController pushViewController:retrieveVC animated:YES];
            
        }
        
        [SharedInstance getInstance].isOpenedUnifiedPay = false;
    }];
}


@end
