//
//  UnifiedPayView.h
//  HLGA
//
//  Created by Linus on 2018/6/6.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UnifiedPayView : UIView

- (instancetype)initWithFrame:(CGRect)frame andData:(NSDictionary*)data;

@property (nonatomic,copy) void(^CloseBackBlock)(NSString * status);//status 0正常关闭,status1关闭后打开找回支付密码

@property (nonatomic,assign)NSString * payStatus;


@end
