//
//  UnifiedPayView.m
//  HLGA
//
//  Created by Linus on 2018/6/6.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "UnifiedPayView.h"
#import "CorePasswordView.h"
#import "PayTableViewCell.h"
#import "ThirdPayView.h"
#import "WPForgetPasswordView.h"
#import "WPPaymentPasswordRetrieveVC.h"
#import <AlipaySDK/AlipaySDK.h>
#import <WXApi.h>

#define ITEM_HEIGHT 44
#define CELL_HEIGHT 55
#define THIRD_TAG 300
#define THIRD_HEIGHT 109

#define SHOW_AMOUNT_HEIGHT 17
#define FOOTER_HEIGHT 266

typedef NS_ENUM(NSInteger, PayLastFootStyle) {
    PayLastFootStyleDefault, //只有通用支付(可能没有第隐藏第二条高度不变)
    PayLastFootStyleThirdPay, //通用支付和专项支付(可能隐藏微信或者支付宝高度不变)
};


@interface UnifiedPayView()<UITableViewDelegate,UITableViewDataSource>
{
    UILabel * detailTitle;
    UILabel * validationTitle;
    NSInteger thirdPayStatus;//0:都有,1:没有支付宝,2:没有微信,3:都没有
    NSInteger thirdPayType;//1:微信，2:支付宝；
    
    BOOL hasThirdPay;//是否有三方支付；
    ThirdPayView * wxPayView;
    ThirdPayView * aliPayView;
    
    NSDictionary * dataSource;
    BOOL isAlreadyClose;
}

@property(nonatomic,strong)UIView * containerPanel;

@property(nonatomic,strong)UITableView *payTableView;

@property(nonatomic,strong)UIImageView * payResultImageView;//支付结果Image;

@property(nonatomic,strong)UILabel * payResultLabel;//支付结果Label;

@property(nonatomic,strong)UIView * detailView;//订单详情页面
@property(nonatomic,strong)UIView * detailItem;//订单详情title
@property(nonatomic,strong)UIView * validationView;//验证密码页面
@property(nonatomic,strong)UIView * validationItem;//验证密码title
@property(nonatomic,strong)NSArray * payItems;

@property(nonatomic,strong)CorePasswordView * pv;//密码键盘

@end

@implementation UnifiedPayView

- (instancetype)initWithFrame:(CGRect)frame andData:(NSDictionary*)data
{
    self = [super initWithFrame:frame];
    if (self) {
        dataSource = data;
        [self initDetailView];
    }
    return self;
}

- (void)initDetailView{
    
    isAlreadyClose = false;
    
    self.payStatus = @"-1";
    
    self.payItems = dataSource[@"payItems"];
    
    thirdPayStatus = 0;
    
    self.detailItem = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.frame.size.width, ITEM_HEIGHT)];
    
    UIButton * closeButton = [[UIButton alloc]initWithFrame:CGRectMake(self.frame.size.width - ITEM_HEIGHT, 0, ITEM_HEIGHT, ITEM_HEIGHT)];
    
    [closeButton setImage:[UIImage imageNamed:@"close_button_img"] forState:UIControlStateNormal];
    
    [closeButton addTarget:self action:@selector(closeHandler:) forControlEvents:UIControlEventTouchUpInside];
    
    detailTitle = [self createLabel:@"付款详情" andFontName:@"PingFangSC-Medium" andFontSize:16 andTextAlign:NSTextAlignmentCenter andTextColor:UIColorFromRGB(0x323232) andFrame:CGRectMake(0, 0,self.detailItem.frame.size.width,self.detailItem.frame.size.height)];
    [self.detailItem addSubview:detailTitle];
    
    self.detailItem.backgroundColor = [UIColor whiteColor];
    self.detailView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
    [self addSubview:self.detailView];
    [self.detailView addSubview:self.detailItem];
    
    //支付结果组件初始化
    self.payResultImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 68, 68)];
    self.payResultImageView.contentMode = UIViewContentModeScaleAspectFit;
    self.payResultImageView.center = CGPointMake(self.frame.size.width/2, self.frame.size.height/2);
    [self.detailView addSubview:self.payResultImageView];
    
    self.payResultLabel = [self createLabel:@"付款成功" andFontName:[Utils getGlobalFontName] andFontSize:16 andTextAlign:NSTextAlignmentCenter andTextColor:UIColorFromRGB(0x323232) andFrame:CGRectMake(0, 0,self.frame.size.width,22)];
     
    self.payResultLabel.center = CGPointMake(self.payResultImageView.center.x, self.payResultImageView.center.y + self.payResultImageView.frame.size.height/2 + 20);
    
    [self.detailView addSubview:self.payResultLabel];
    
    _payTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, ITEM_HEIGHT + 10,self.frame.size.width,self.frame.size.height - (ITEM_HEIGHT + 10)) style:UITableViewStylePlain];
    [_payTableView setSeparatorColor:UIColorFromRGB(0xdedede)];
    PayLastFootStyle style = PayLastFootStyleDefault;
    
    
    NSNumber * otherAmount = dataSource[OTHER_AMOUNT];
    
    hasThirdPay = false;
    
    if(otherAmount.integerValue <= 0){
        hasThirdPay = false;
    }else{
        hasThirdPay = true;
    }
    
    NSNumber * wechatEnable;
    wechatEnable = dataSource[WECHAT_ENABLE];
    NSNumber * alipayEnable = dataSource[ALIPAY_ENABLE];
    if(wechatEnable.integerValue == 1 && alipayEnable.integerValue == 1){
        thirdPayStatus = 0;
    }else if(wechatEnable.integerValue == 1 && alipayEnable.integerValue == 0){
        thirdPayStatus = 1;
    }else if(wechatEnable.integerValue == 0 && alipayEnable.integerValue == 1){
        thirdPayStatus = 2;
    }else{
        thirdPayStatus = 3;
        hasThirdPay = false;
    }
    if(hasThirdPay == true){
        style = PayLastFootStyleThirdPay;
    }
    
    _payTableView.tableFooterView = [self createFootViewWithStyle:style];
    _payTableView.delegate = self;
    _payTableView.dataSource = self;
    
    [self.detailView addSubview:_payTableView];
    
    [self.detailItem addSubview:closeButton];
    
}


- (void)initValidationView{
    
    self.validationItem = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.frame.size.width, ITEM_HEIGHT)];
    
    self.validationItem.backgroundColor = [UIColor whiteColor];
    
    UIButton * backButton = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, ITEM_HEIGHT, ITEM_HEIGHT)];
    [backButton setImage:[UIImage imageNamed:@"ic_title_back"] forState:UIControlStateNormal];
    [backButton addTarget:self action:@selector(backDetailHandler:) forControlEvents:UIControlEventTouchUpInside];
    
    validationTitle = [self createLabel:@"请输入支付密码" andFontName:@"PingFangSC-Medium" andFontSize:16 andTextAlign:NSTextAlignmentCenter andTextColor:UIColorFromRGB(0x323232) andFrame:CGRectMake(0, 0,self.detailItem.frame.size.width,self.detailItem.frame.size.height)];
    [self.validationItem addSubview:validationTitle];
    [self.validationItem addSubview:backButton];
    
    self.validationView = [[UIView alloc]initWithFrame:CGRectMake(self.frame.size.width, 0, self.frame.size.width, self.frame.size.height)];
    self.validationView.backgroundColor = UIColorFromRGB(0xf6f6f6);
    [self.validationView addSubview:self.validationItem];
    
    //添加密码键盘
    _pv = [[CorePasswordView alloc]initWithSecureTextEntry:true frame:CGRectMake(16, ITEM_HEIGHT + 30, self.frame.size.width - 32, 49)];
    [self.pv endInput];
    
    __weak typeof(self) weakSelf = self;
    self.pv.PasswordCompeleteBlock = ^(NSString *password) {
        
        [weakSelf.pv.tf resignFirstResponder];
        [weakSelf payDefaultByPassword:password];
        [weakSelf backDetailHandler:nil];
    };
    
    [self.validationView addSubview:self.pv];
    [self addSubview:self.validationView];
}

- (void)closeHandler:(UIButton*)sender{
    [self closePanelHandler:@"0"];
}

- (void)backDetailHandler:(UIButton*)sender{
    
    [_pv endInput];
    [UIView animateWithDuration:0.4 animations:^{
        
        self.detailView.center = CGPointMake(self.frame.size.width/2, self.detailView.center.y);
        self.validationView.center = CGPointMake(self.frame.size.width/2 + self.frame.size.width, self.validationView.center.y);
        
    }];
}


- (void)drawRect:(CGRect)rect {
    [super drawRect:rect];
    
    
    [self initValidationView];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(alipayNotificationHandler:) name:EVENT_ALIPAY_BACK object:nil];
}

- (void)alipayNotificationHandler:(NSNotification*)notification{
    
    NSDictionary *statusDictionary = [notification userInfo];
    NSString *status = [statusDictionary objectForKey:@"status"];
    [self alipayResultByStatus:status];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    NSNumber * time = dataSource[TIME_OUT];
    if(time.integerValue == 0){
        return 2;
    }
    return 3;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * const cellIdentifier = @"payCell";
    
    PayTableViewCell *  cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if(!cell){
        cell = [[PayTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    
    if(indexPath.row == 0)
    {
        cell.leftLabel.text = @"订单详情";
        cell.rightLabel.font = [UIFont fontWithName:@"PingFangSC-Semibold" size:18];
        cell.rightLabel.textColor = UIColorFromRGB(0xff595a);
        
        NSNumber * amount = dataSource[AMOUNT];
        CGFloat money = amount.floatValue * 0.01;
        
        NSString * showMoney = [NSString stringWithFormat:@"￥%.2lf",money];
        cell.rightLabel.text = showMoney;
    }else if(indexPath.row == 1)
    {
        cell.leftLabel.text = @"订单信息";
        NSString * description = dataSource[DESCRIPTION];
        cell.rightLabel.text = description;
    }else if(indexPath.row == 2)
    {
        
        NSNumber * time = dataSource[TIME_OUT];
        
        NSString * timeString = [Utils getComplexDateByTime:[NSString stringWithFormat:@"%ld",time.integerValue]];
        
        NSString * showTimeOutString = [NSString stringWithFormat:@"请在%@前完成支付",timeString];
        
        cell.leftLabel.text = showTimeOutString;
        
        [Utils labelColorAttributedString:cell.leftLabel andRange:NSMakeRange(2, timeString.length) color:UIColorFromRGB(0xFF595A) size:cell.leftLabel.font.pointSize];
        
        cell.rightLabel.text = @"";
    }
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if(indexPath.row < 2){
        //前三排固定、、订单金额、订单信息、付款时间
        return CELL_HEIGHT;
    }
    return CELL_HEIGHT;//不固定
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.row == 2) {
        
        UIView * lastLine = [[UIView alloc]initWithFrame:CGRectMake(15, CELL_HEIGHT-0.5, SCREEN_WIDTH - 15, 0.5)];
        lastLine.backgroundColor = UIColorFromRGB(0xdedede);
        [cell.contentView addSubview:lastLine];
        
    }
}


- (UILabel*)createLabel:(NSString*)content andFontName:(NSString*)fontName andFontSize:(CGFloat)size andTextAlign:(NSTextAlignment)align andTextColor:(UIColor*)color andFrame:(CGRect)frame
{
    UILabel * label = [[UILabel alloc]initWithFrame:frame];
    
    label.text = content;
    label.font = [UIFont fontWithName:fontName size:16];
    label.textColor = color;
    label.textAlignment = align;
    
    return label;
}

- (UIView*)createFootViewWithStyle:(PayLastFootStyle)style{
    
    UIView * footView;
    CGFloat height = 189;
    CGFloat gapH = 15;
    CGFloat startX = 15;
    
    NSInteger hasThirdPay = 0;
    
    if(style == PayLastFootStyleThirdPay)
    {
        hasThirdPay = 1;
    }
    
    height = FOOTER_HEIGHT +  SHOW_AMOUNT_HEIGHT * (self.payItems.count - hasThirdPay);
    
    footView =  [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, height)];
    
    UILabel * titleLabel = [self createLabel:@"付款方式" andFontName:[Utils getGlobalFontName] andFontSize:14 andTextAlign:NSTextAlignmentLeft andTextColor:UIColorFromRGB(0x323232) andFrame:CGRectMake(startX, gapH,self.frame.size.width - startX * 2 ,20)];
    
    [footView addSubview:titleLabel];
    
    UILabel * lastLabel;
    
    
    
    for(NSInteger i = 0;i < (self.payItems.count - hasThirdPay); i++)
    {
        NSDictionary * dic = self.payItems[i];
        
        NSString * itemName = dic[@"itemName"];
        
        NSNumber * amount = dic[@"amount"];
        UILabel * pointsTitle = [self createLabel:itemName andFontName:[Utils getGlobalFontName] andFontSize:14 andTextAlign:NSTextAlignmentLeft andTextColor:UIColorFromRGB(0x999999) andFrame:CGRectMake(startX, titleLabel.frame.origin.y + titleLabel.frame.size.height + gapH * (i + 1) + 20 * i,self.frame.size.width - startX * 2 ,20)];
        [footView addSubview:pointsTitle];
        
        NSString * showMoney = [NSString stringWithFormat:@"-%.2lf积分",amount.floatValue * 0.01];
        
        
        UILabel * pointsCostLabel = [self createLabel:showMoney andFontName:[Utils getGlobalFontName] andFontSize:14 andTextAlign:NSTextAlignmentRight andTextColor:UIColorFromRGB(0xff595a) andFrame:CGRectMake(startX,pointsTitle.frame.origin.y,self.frame.size.width - startX * 2 ,20)];
        
        if(i == 0)
        {
            //变色
            [Utils labelColorAttributedString:pointsCostLabel andRange:NSMakeRange(0, showMoney.length - 2) color:UIColorFromRGB(0xFF595A) size:pointsCostLabel.font.pointSize];
        }
        
        [footView addSubview:pointsCostLabel];
        
        lastLabel = pointsCostLabel;
            
    }
    
    
//    UILabel * pointsTitle = [self createLabel:@"通用积分" andFontName:[Utils getGlobalFontName] andFontSize:14 andTextAlign:NSTextAlignmentLeft andTextColor:UIColorFromRGB(0x999999) andFrame:CGRectMake(startX, titleLabel.frame.origin.y + titleLabel.frame.size.height + gapH,self.frame.size.width - startX * 2 ,20)];
//
//    [footView addSubview:pointsTitle];
//
//    NSNumber * accountAmount = dataSource[@"accountAmount"];
//
//    NSString * showMoney = [NSString stringWithFormat:@"-%.2lf积分",accountAmount.floatValue * 0.01];
    
//    UILabel * pointsCostLabel = [self createLabel:showMoney andFontName:[Utils getGlobalFontName] andFontSize:14 andTextAlign:NSTextAlignmentRight andTextColor:UIColorFromRGB(0xff595a) andFrame:CGRectMake(startX,pointsTitle.frame.origin.y,self.frame.size.width - startX * 2 ,20)];
//
//    //变色
//    [Utils labelColorAttributedString:pointsCostLabel andRange:NSMakeRange(0, showMoney.length - 2) color:UIColorFromRGB(0xFF595A) size:pointsCostLabel.font.pointSize];
//
//    [footView addSubview:pointsCostLabel];
//
//    if(accountAmount.integerValue <= 0)
//    {
//        pointsTitle.hidden = true;
//        pointsCostLabel.hidden = true;
//    }
//
//    CGFloat pointsY = pointsTitle.frame.origin.y + pointsTitle.frame.size.height + gapH;
//
//    UILabel * specialPointsTitle = [self createLabel:@"专项积分" andFontName:[Utils getGlobalFontName] andFontSize:14 andTextAlign:NSTextAlignmentLeft andTextColor:UIColorFromRGB(0x999999) andFrame:CGRectMake(startX, pointsY,self.frame.size.width - startX * 2 ,20)];
//
//    [footView addSubview:specialPointsTitle];
//
//    UILabel * specialPointsCostLabel = [self createLabel:@"-500.00积分" andFontName:[Utils getGlobalFontName] andFontSize:1 andTextAlign:NSTextAlignmentRight andTextColor:UIColorFromRGB(0xff595a) andFrame:CGRectMake(startX,specialPointsTitle.frame.origin.y,self.frame.size.width - startX * 2 ,20)];
//
//    [footView addSubview:specialPointsCostLabel];
    
    
//    if([Utils getPayHasSpecialPoints:dataSource] == false)
//    {
//        [specialPointsTitle setHidden:true];//暂时没有
//        [specialPointsCostLabel setHidden:true];//暂时没有
//
//        pointsY = specialPointsTitle.frame.origin.y;
//    }else{
//        NSNumber * specialAmount = dataSource[@"specialAmount"];
//
//        NSString * specialName = dataSource[@"itemName"];
//
//        specialPointsTitle.text = specialName;
//
//        specialPointsCostLabel.text = [NSString stringWithFormat:@"-%.2lf积分",specialAmount.floatValue * 0.01];
//
//        [specialPointsTitle setHidden:false];
//        [specialPointsCostLabel setHidden:false];
//
//    }
    
    
    
//    NSNumber * amount = dataSource[AMOUNT];
//    CGFloat money = amount.floatValue * 0.01;
    
//    if(hasThirdPay)
//    {
//        NSNumber * otherAmount = dataSource[OTHER_AMOUNT];
//        NSInteger resultAmount = amount.integerValue - otherAmount.integerValue;
//        money = [NSNumber numberWithInteger:resultAmount].floatValue * 0.01;
//    }
    
    
    CGFloat endY = lastLabel.frame.origin.y + lastLabel.frame.size.height + gapH;
    
    
    if(style == PayLastFootStyleThirdPay)
    {
        UILabel * thirdPayTitle = [self createLabel:@"第三方支付" andFontName:[Utils getGlobalFontName] andFontSize:14 andTextAlign:NSTextAlignmentLeft andTextColor:UIColorFromRGB(0x999999) andFrame:CGRectMake(startX,  endY,self.frame.size.width - startX * 2 ,20)];
        
        [footView addSubview:thirdPayTitle];
        
        wxPayView = (ThirdPayView*)[[[NSBundle mainBundle]loadNibNamed:@"ThirdPayView" owner:nil options:nil] firstObject];
        
        wxPayView.userInteractionEnabled = true;
        wxPayView.tag = THIRD_TAG + 1;
        
        NSNumber * wechatEnable = @(0);
        
//        if([WXApi isWXAppInstalled] == false)
//        {
//            wechatEnable = @0;
//        }else{
        wechatEnable = dataSource[WECHAT_ENABLE];
//        }
        
        wxPayView.frame = CGRectMake(0, thirdPayTitle.frame.origin.y + thirdPayTitle.frame.size.height + gapH, self.frame.size.width, 22 * wechatEnable.integerValue);
        wxPayView.thridIconImage.image = [UIImage imageNamed:@"wx_icon"];
        
        
        NSNumber * amount = dataSource[OTHER_AMOUNT];
        CGFloat money = amount.floatValue * 0.01;
        NSString * wxMoney = [NSString stringWithFormat:@"(￥%.2lf)",money];
        wxPayView.payTitleLabel.text = @"微信支付";
        
        wxPayView.payMoneyLabel.text = wxMoney;
        
        if(wechatEnable.integerValue == 1)
        {
            [footView addSubview:wxPayView];
            UITapGestureRecognizer * tapWx = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapPayTypHandler:)];
            [wxPayView addGestureRecognizer:tapWx];
        }
        
        
        aliPayView = (ThirdPayView*)[[[NSBundle mainBundle]loadNibNamed:@"ThirdPayView" owner:nil options:nil] firstObject];
        
        aliPayView.userInteractionEnabled = true;
        aliPayView.tag = THIRD_TAG + 2;
        
        NSNumber * alipayEnable = dataSource[ALIPAY_ENABLE];
        
        aliPayView.frame = CGRectMake(0, wxPayView.frame.origin.y + wxPayView.frame.size.height + gapH * wechatEnable.integerValue * alipayEnable.integerValue, self.frame.size.width, 22 * alipayEnable.integerValue);
        
        aliPayView.thridIconImage.image = [UIImage imageNamed:@"ali_icon"];
        
        NSString * aliMoney = [NSString stringWithFormat:@"(￥%.2lf)",money];
        
        aliPayView.payMoneyLabel.text = aliMoney;
        aliPayView.payTitleLabel.text = @"支付宝支付";
        
        if(alipayEnable.integerValue == 1)
        {
            [footView addSubview:aliPayView];
            
            UITapGestureRecognizer * tapAli = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapPayTypHandler:)];
            
            [aliPayView addGestureRecognizer:tapAli];
        }
        
        if(thirdPayStatus == 0 || thirdPayStatus == 1)
        {
            [wxPayView setSelectedImage:true];
            [aliPayView setSelectedImage:false];
            thirdPayType = 1;
        }else if(thirdPayStatus == 2)
        {
            [wxPayView setSelectedImage:false];
            [aliPayView setSelectedImage:true];
            thirdPayType = 2;
        }
        
        endY = aliPayView.frame.size.height + aliPayView.frame.origin.y;
    }
    
    UIButton * confirmPayButton = [[UIButton alloc]initWithFrame:CGRectMake(30, endY + 25, self.frame.size.width - 60, 44)];
    
    confirmPayButton.layer.cornerRadius = 22;
    
    confirmPayButton.titleLabel.font = [UIFont fontWithName:[Utils getGlobalFontName] size:16];
    
    NSString * confirmText = @"确认支付";
    
    [confirmPayButton setTitle:confirmText forState:UIControlStateNormal];
    [confirmPayButton setTitleColor:UIColorFromRGB(0xffffff) forState:UIControlStateNormal];
    [confirmPayButton gradualDefaultButton];
    [confirmPayButton addTarget:self action:@selector(confirmPayHandler:) forControlEvents:UIControlEventTouchUpInside];
    [footView addSubview:confirmPayButton];
    
    return footView;
    
}

- (void)tapPayTypHandler:(UITapGestureRecognizer*)gesture
{
    NSInteger index = gesture.view.tag - THIRD_TAG;
    [wxPayView setSelectedImage:false];
    [aliPayView setSelectedImage:false];
    
    thirdPayType = index;
    
    if(index == 1)
    {
        //微信
        [wxPayView setSelectedImage:true];
    }else if(index == 2)
    {
        //支付宝
        [aliPayView setSelectedImage:true];
    }
}

- (void)confirmPayHandler:(UIButton*)sender{
    //确认支付;判断是否跳入密码界面
    BLOCK_OBJC(self, weakSelf);
    if(hasThirdPay)
    {
        //跳转支付宝和微信
        [self payThirdByType:[NSNumber numberWithInteger:thirdPayType]];
    }else{
        //跳转密码界面
        
//        CGFloat accountAmount = [dataSource[@"accountAmount"] floatValue];
//        CGFloat amount = [dataSource[@"amount"] floatValue];
//        if (amount > accountAmount) {
//            [Utils showToast:@"账户通用积分不足"];
//            return;
//        }
        
        BOOL isNO = [[Utils passwordForService:FACE_ID_NO] isEqualToString:NO_FACE_ID_PAY];
        
        if(isNO)
        {
            [SharedInstance loadAuthentication:^(NSString *payStatus) {
                
                switch (payStatus.integerValue) {
                    case 1:
                    {
                        //成功
                        NSString *payPWD = [Utils passwordForService:FACE_ID_PASSWORD];
                        [weakSelf payDefaultByPassword:payPWD];
                        break;
                    }
                    case 0:
                        [Utils showToast:@"支付失败"];
                        break;
                    case -1:
                    {
                        [Utils showToast:@"支付取消"];
                        break;
                    }
                    case -2:
                    {
                        [weakSelf showVlidationPasswordView];
                        break;
                    }
                    case -3:
                    {
                        [weakSelf confirmPayHandler:nil];
                        break;
                    }
                    default:
                        break;
                }
                
            }];
        }else{
            [self showVlidationPasswordView];
        }
    }
}

- (void)showVlidationPasswordView
{
    [_pv clearPassword];
    
    [UIView animateWithDuration:0.4 animations:^{
        self.detailView.center = CGPointMake(-self.frame.size.width/2, self.detailView.center.y);
        self.validationView.center = CGPointMake(self.frame.size.width/2, self.validationView.center.y);
    } completion:^(BOOL finished) {
        //弹出键盘
        [_pv beginInput];
    }];
}

//type 1微信 2支付宝
- (void)payThirdByType:(NSNumber*)type
{
    NSString * orderId = dataSource[ORDER_ID];
    
    NSString * otherOrderId = dataSource[OTHER_ODER_ID];
    
    if(type.integerValue == 1)
    {
        NSNumber * wechatEnable;
        
//        if([WXApi isWXAppInstalled] == false)
//        {
//            wechatEnable = @0;
//        }else{
            wechatEnable = dataSource[WECHAT_ENABLE];
//        }
        
//        wechatEnable = @1;
        
        if(wechatEnable.integerValue == 0)
        {
            NSString * wechatDesc = dataSource[WECHAT_UNEANBLE_TOAST];
            
            [Utils showToast:wechatDesc];
            
            return;
            
        }
    }
    
    if(type.integerValue == 2)
    {
        NSNumber * alipayEnable = dataSource[ALIPAY_ENABLE];
        
        if(alipayEnable.integerValue == 0)
        {
            NSString * alipayDesc = dataSource[ALIPAY_UNENABLE_TOAST];
            
            [Utils showToast:alipayDesc];
            return;
        }
        
    }
    
    __weak typeof(self) weakSelf = self;
    [ServiceManager combinationPayByOrderId:orderId andOtherOrderId:otherOrderId andPayType:type successBack:^(NSDictionary *data) {
        
        if(type.integerValue == 1)
        {
            //微信
            NSDictionary * payData = data[DATA];
            NSString * infoString = payData[@"payOrderInfo"];
            
            NSDictionary * orderInfo = [Utils dictionaryWithJsonString:infoString];
            
            [self wechatByOrderInfo:orderInfo];
            
        }else if(type.integerValue == 2){
            //支付宝
            NSDictionary * payData = data[DATA];
            
            NSString * orderInfo = payData[PAY_ORDER_INFO];
            
            [[AlipaySDK defaultService] payOrder:orderInfo fromScheme:@"hexinpass_sgh" callback:^(NSDictionary *resultDic) {
                NSString * status = [resultDic objectForKey:@"resultStatus"];
                [self alipayResultByStatus:status];
            }];
            
        }
        
    } failure:^(NSError *error) {
        NSLog(@"%@",error);
        if(error.code == ERROR_CODE_PAY_PASSWORD)
        {
            //支付密码错误
            self.payStatus = @"0";
            //弹出支付密码框
            
            WPForgetPasswordView *view = [WPForgetPasswordView xibView];
            __weak WPForgetPasswordView *weakView = view;
            view.btnBlk = ^{
                //关闭并打开忘记支付密码
                [weakView dismiss];
                [self closePanelHandler:@"1"];
            };
            [view showOnView:[weakSelf superview]];
        }
    }];
}

- (void)wechatByOrderInfo:(NSDictionary*)orderInfo
{
    
    [[SharedInstance getInstance] wechatByPayInfo:orderInfo];
    
    
    [SharedInstance getInstance].wechatPayResult = ^(NSInteger result) {
        
        if(result == 1)
        {
            //支付成功
            self.payStatus = @"1";
            [self closePanelHandler:@"0"];
        }else{
            //支付失败
            self.payStatus = @"0";
        }
        
    };
    
        
}

- (void)alipayResultByStatus:(NSString*)status
{
    if(status.integerValue == 9000)
    {
        //支付成功
        self.payStatus = @"1";
        [self closePanelHandler:@"0"];
        
        
    }else if(status.integerValue == 6001)
    {
        //取消支付
        self.payStatus = @"0";
    }else{
        //支付失败
        self.payStatus = @"0";
    }
}
- (void)closePanelHandler:(NSString*)status
{
    
    [SharedInstance getInstance].wechatPayResult = nil;
    [[NSNotificationCenter defaultCenter] removeObserver:self name:EVENT_ALIPAY_BACK object:nil];
    self.CloseBackBlock(status);
}

- (void)payDefaultByPassword:(NSString*)password
{
    NSString * orderId = dataSource[ORDER_ID];
    
    NSNumber * type = [NSNumber numberWithInteger:0];
    
    __weak typeof(self) weakSelf = self;
    [ServiceManager payByOrderId:orderId andPassword:password andPayType:type successBack:^(NSDictionary *data) {
        
        [self.payTableView setHidden:true];
        
        self.payResultImageView.image = [UIImage imageNamed:@"pay_success_image"];
        
        self.payResultLabel.text = @"付款成功";
        
        self.payStatus = @"1";
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            
            [self closePanelHandler:@"0"];
            
        });
        
        //[SharedInstance checkGoToOpenFaceOrTouchID:password];
        
    } failure:^(NSError *error) {
        NSLog(@"%@",error);
        if(error.code == ERROR_CODE_PAY_PASSWORD)
        {
            //支付密码错误
            self.payStatus = @"0";
            //弹出支付密码框
            
            WPForgetPasswordView *view = [WPForgetPasswordView xibView];
            __weak WPForgetPasswordView *weakView = view;
            view.btnBlk = ^{
                //关闭并打开忘记支付密码
                [weakView dismiss];
                [self closePanelHandler:@"1"];
            };
            [view showOnView:[weakSelf superview]];
            return;
        }
        
        self.payStatus = @"0";
        [Utils showToast:@"支付失败"];
        [self closePanelHandler:@"0"];
    }];
}


@end
