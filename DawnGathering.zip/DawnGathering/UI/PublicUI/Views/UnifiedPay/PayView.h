//
//  PayView.h
//  HLGA
//
//  Created by Linus on 2018/6/6.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PayView : UIView

@property (nonatomic,copy) void(^PayCompeleteBlock)(NSString * payStatus);

- (instancetype)initWithPanelFrame:(CGRect)frame andData:(NSDictionary*)dataSource;

@end
