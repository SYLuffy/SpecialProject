//
//  WPPayControlsView.h
//  HLGA
//
//  Created by 葛亮 on 2018/6/6.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void(^WPPayControlsViewButtonBlock)(NSString *tf);

@interface WPPayControlsView : UIView

@property (nonatomic, copy) WPPayControlsViewButtonBlock btnBlk;
+ (instancetype)xibView;
- (void)clearTFText;
- (void)showOnView:(UIView *)view;
- (void)dismiss;
@end
