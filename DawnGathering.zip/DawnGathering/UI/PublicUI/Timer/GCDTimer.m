//
//  GCDTimer.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/8/8.
//

#import "GCDTimer.h"

@interface GCDTimer()
@property (nonatomic, strong) dispatch_source_t dispatchTimer;//计时器
@property (nonatomic, assign) NSTimeInterval interval;//时间间隔
@property (nonatomic, assign) BOOL isSuspended;//是否暂停
@property (nonatomic, assign) BOOL willRepeat;//是否循环
@end

@implementation GCDTimer

+ (GCDTimer *)scheduleTimer:(NSTimeInterval)anInterval
                  actionBlock:(void(^)(void))anActionBlock
                   willRepeat:(BOOL)willRepeat
{
    GCDTimer *timer = [[GCDTimer alloc] initWithInterval:anInterval
                                             actionBlock:anActionBlock
                                              willRepeat:willRepeat];
    [timer start];
    return timer;
}

+ (GCDTimer *)scheduleTimer:(NSTimeInterval)anInterval
                  actionBlock:(void(^)(void))anActionBlock
                   willRepeat:(BOOL)willRepeat
                dispatchQueue:(dispatch_queue_t)aDispatchQueue
{
    GCDTimer *timer = [[GCDTimer alloc] initWithInterval:anInterval
                                             actionBlock:anActionBlock
                                              willRepeat:willRepeat
                                           dispatchQueue:aDispatchQueue];
    [timer start];
    return timer;
}

- (void)start:(NSTimeInterval)anInterval
{
    if (NO == self.isValid || NO == self.isSuspended) {
        return;
    }
    self.interval = anInterval;
    [self start];
}

- (void)start
{
    if (NO == self.isValid || NO == self.isSuspended) {
        return;
    }
    self.isSuspended = NO;
    uint64_t anInterval = self.interval * NSEC_PER_SEC;
    dispatch_time_t aStartTime = dispatch_time(DISPATCH_TIME_NOW,
                                               anInterval);
    if (YES == self.willRepeat) {
        dispatch_source_set_timer(self.dispatchTimer,
                                  aStartTime, anInterval, 0);
    } else {
        dispatch_source_set_timer(self.dispatchTimer,
                                  aStartTime, DISPATCH_TIME_FOREVER, 0);
    }
    dispatch_resume(self.dispatchTimer);
}

- (void)stop
{
    if (YES == self.isValid) {
        dispatch_source_cancel(self.dispatchTimer);
    }
}

- (void)suspend
{
    if (YES == self.isValid && NO == self.isSuspended) {
        dispatch_suspend(self.dispatchTimer);
        self.isSuspended = YES;
    }
}

- (BOOL)isValid
{
    return (nil != self.dispatchTimer
            && 0 == dispatch_source_testcancel(self.dispatchTimer));
}

#pragma mark - initialization

- (id)init
{
    if (self = [super init]) {
        _dispatchTimer = nil;
        _isSuspended   = NO;
        _willRepeat    = NO;
        _interval      = 0;
    }
    return self;
}

- (id)initWithInterval:(NSTimeInterval)anInterval
           actionBlock:(void(^)(void))anActionBlock
            willRepeat:(BOOL)willRepeat
{
    return [self initWithInterval:anInterval
                      actionBlock:anActionBlock
                       willRepeat:willRepeat
                    dispatchQueue:dispatch_get_main_queue()];
}

- (id)initWithInterval:(NSTimeInterval)anInterval
           actionBlock:(void(^)(void))anActionBlock
            willRepeat:(BOOL)willRepeat
         dispatchQueue:(dispatch_queue_t)aDispatchQueue
{
    if (self = [super init]) {
        [self initDispatchTimer:anActionBlock
                     willRepeat:willRepeat
                  dispatchQueue:aDispatchQueue];
        
        _isSuspended = YES;
        _willRepeat  = willRepeat;
        _interval    = anInterval;
    }
    return self;
}

- (void)initDispatchTimer:(void(^)(void))anActionBlock
               willRepeat:(BOOL)willRepeat
            dispatchQueue:(dispatch_queue_t)aDispatchQueue
{
    _dispatchTimer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER,
                                            0, 0, aDispatchQueue);
                                            
    dispatch_source_t aDispatchTimer = _dispatchTimer;
    dispatch_source_set_timer(aDispatchTimer, DISPATCH_TIME_NOW, 1.0 * NSEC_PER_SEC, 0);
    dispatch_source_set_event_handler(aDispatchTimer, ^{
        if (NO == willRepeat) {
            dispatch_source_cancel(aDispatchTimer);
        }
        if (anActionBlock) {
            anActionBlock();
        };
    });
}

- (void)dealloc
{
    if (self.isValid && self.isSuspended) {
        dispatch_resume(self.dispatchTimer);
    }
    [self stop];
}

@end

