//
//  GCDTimer.h
//  DawnGathering
//
//  Created by 李冬岐 on 2023/8/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface GCDTimer : NSObject

+ (GCDTimer *)scheduleTimer:(NSTimeInterval)anInterval
                  actionBlock:(void(^)(void))anActionBlock
                   willRepeat:(BOOL)willRepeat;

+ (GCDTimer *)scheduleTimer:(NSTimeInterval)anInterval
                  actionBlock:(void(^)(void))anActionBlock
                   willRepeat:(BOOL)willRepeat
                dispatchQueue:(dispatch_queue_t)aDispatchQueue;

- (void)start:(NSTimeInterval)anInterval;

- (void)start;

- (void)stop;

- (void)suspend;

- (BOOL)isValid;

@end

NS_ASSUME_NONNULL_END
