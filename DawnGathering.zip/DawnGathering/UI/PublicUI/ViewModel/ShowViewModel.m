//
//  showViewModel.m
//  HLGA
//
//  Created by 葛亮 on 2018/6/15.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "ShowViewModel.h"
#import "WPAdsView.h"
#import "WPUpgradeVersionView.h"
#import "WPNoticeView.h"
#import <SDWebImageManager.h>
#import <SDWebImageDownloader.h>
#import "UIImage+tools.h"
#import "UpgradeVersionModel.h"
#import "WPNavigationController.h"
@implementation ShowViewModel


//闪屏广告
- (void)showAdsViewOwner:(__kindof UIViewController *)owner;
{   
    __weak ShowViewModel *weakSelf = self;
    NSDictionary *dict = [[NSUserDefaults standardUserDefaults] objectForKey:@"AdsView"];
    
    if ([Utils checkObjectIsNull:dict]) {
        
        if ([dict isKindOfClass:[NSDictionary class]]) {
            self.asdModel = [[AdsModel alloc]initByDictionary:dict];
        }else{
            self.asdModel = [[AdsModel alloc]initByDictionary:@{}];
        }
        
        
        [[SDWebImageManager sharedManager] loadImageWithURL:[NSURL URLWithString:self.asdModel.imgUrl] options:0 progress:^(NSInteger receivedSize, NSInteger expectedSize, NSURL * _Nullable targetURL) {
                    
        } completed:^(UIImage * _Nullable image, NSData * _Nullable data, NSError * _Nullable error, SDImageCacheType cacheType, BOOL finished, NSURL * _Nullable imageURL) {
                    
            if(cacheType == SDImageCacheTypeDisk)
            {
                WPAdsView *view = [WPAdsView xibView];
                __weak WPAdsView *weakView = view;
                view.imgUrl = self.asdModel.imgUrl;
                view.btnBlk = ^{
                    
                    [owner.navigationController setNavigationBarHidden:NO animated:YES];
                    
                    if (weakSelf.asdModel.url.length > 0) {
                       
                        [[NSNotificationCenter defaultCenter] postNotificationName:EVENT_HOME_JUMP_WITH_TYPE object:self userInfo:@{JUMP_TYPE:@(weakSelf.asdModel.type),TARGET:weakSelf.asdModel.url}];
                        [SharedInstance getInstance].isASDUrlBool = YES;
                        [weakView dismiss];
                    }
                };
                view.dismissBlk = ^{
                    [weakSelf showUpgradeVersionView:owner];
                };
                 [view showOnView:owner.view];
            }
        }];
        
    }else{
        [weakSelf showUpgradeVersionView:owner];

    }
}





- (void)showUpgradeVersionView:(__kindof UIViewController *)owner{
    
    __weak ShowViewModel *weakSelf = self;
    
    [ServiceManager getVersionSuccess:^(NSDictionary *data) {
        NSDictionary *dict = data[@"data"];
         if ([Utils checkObjectIsNull:dict] ) {
            if ([dict isKindOfClass:[NSDictionary class]]) {
                self.uvModel = [[UpgradeVersionModel alloc]initByDictionary:dict];
                [SharedInstance getInstance].updateVersion = self.uvModel.version;
                [SharedInstance getInstance].updateVersionUrl = self.uvModel.path;
                NSDate *now = [NSDate date];
                NSDate *agoDate = [[NSUserDefaults standardUserDefaults] objectForKey:@"upgradeVersionView"];
                NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                [dateFormatter setDateFormat:@"yyyy-MM-dd"];
                NSString *ageDateString = [dateFormatter stringFromDate:agoDate];
                NSString *nowDateString = [dateFormatter stringFromDate:now];
                
                BOOL showBool = YES;
                
                if ([ageDateString isEqualToString:nowDateString]) {
                    showBool = NO;
                }else{
                    showBool = YES;
                }
                
                if (self.uvModel.asmanda == 1) {
                    showBool = YES;
                }
                
                if (showBool == YES) {
                    WPUpgradeVersionView *view = [WPUpgradeVersionView xibView];
                    
                    __weak WPUpgradeVersionView *weakView = view;
                    
                    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
                    NSString *app_Version = [infoDictionary objectForKey:@"CFBundleShortVersionString"];
                    
                    if (weakSelf.uvModel.version == nil || weakSelf.uvModel.version.length == 0) {
                        [weakSelf autoGetInformation:owner];
                    }else{
                        if (![weakSelf.uvModel.version isEqualToString: app_Version]) {
                            weakView.model = weakSelf.uvModel;
                            view.btnBlk = ^{
                                [weakSelf goAppStoreInOutside:[SharedInstance getInstance].updateVersionUrl];
                            };
                            view.dismmisBlk = ^{
                                [weakSelf autoGetInformation:owner];
                            };
                            [view showOnView:owner.view];

                            //记录弹窗时间
                            NSDate *nowDate = [NSDate date];
                            NSUserDefaults *dataUser = [NSUserDefaults standardUserDefaults];
                            [dataUser setObject:nowDate forKey:@"upgradeVersionView"];
                            [dataUser synchronize];
                        }else{
                            [weakSelf autoGetInformation:owner];
                        }
                    }
                
                }else{
                    [weakSelf autoGetInformation:owner];
                }
               
            }else{
                [weakSelf autoGetInformation:owner];
            }
        }
    } failure:^(NSError *error) {
        [weakSelf autoGetInformation:owner];
    }];
}

- (void)autoGetInformation:(UIViewController*)owner
{

}

- (void)goAppStoreInOutside:(NSString *)urlString
{
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlString] options:@{} completionHandler:^(BOOL success) {
        
    }];

}

-(void)showNoticeData{
    
}

//弹框广告
- (void)showNoticeView:(__kindof UIViewController *)owner
{
    
    NSDate *now = [NSDate date];
    NSDate *agoDate = [[NSUserDefaults standardUserDefaults] objectForKey:@"noticeView"];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    NSString *ageDateString = [dateFormatter stringFromDate:agoDate];
    NSString *nowDateString = [dateFormatter stringFromDate:now];

    if ([ageDateString isEqualToString:nowDateString]) {
    }else{
        
        
        [ServiceManager popUpAdssuccess:^(NSDictionary *data) {
            NSDictionary *dict = data[@"data"];
            if ([Utils checkObjectIsNull:dict]) {
                if ([dict isKindOfClass:[NSDictionary class]]) {
                  
                    self.nModel = [[NoticeModel alloc]initByDictionary:dict];
                    WPNoticeView *view = [WPNoticeView xibView];
                    if (self.nModel.imgUrl.length > 0) {
                        view.imgUrl = self.nModel.imgUrl;
                        view.frame = owner.tabBarController.view.bounds;
                        __weak ShowViewModel *weakSelf = self;
                        __weak WPNoticeView *weakView = view;
                        view.btnBlk = ^{
                            if (weakSelf.nModel.url.length > 0) {
                                
                                [Utils pushWebViewControllerURL:weakSelf.nModel.url owner:owner];
                                [weakView dismiss];
                            }
                        };
                        [view showOnView:owner.tabBarController.view animated:YES];
                        
                        //记录弹窗时间
                        NSDate *nowDate = [NSDate date];
                        NSUserDefaults *dataUser = [NSUserDefaults standardUserDefaults];
                        [dataUser setObject:nowDate forKey:@"noticeView"];
                        [dataUser synchronize];
                    }
                }
            }
        }];
    }
}
@end
