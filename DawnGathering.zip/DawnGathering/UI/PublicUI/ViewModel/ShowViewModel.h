//
//  showViewModel.h
//  HLGA
//
//  Created by 葛亮 on 2018/6/15.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AdsModel.h"
#import "UpgradeVersionModel.h"
#import "NoticeModel.h"

@interface ShowViewModel : NSObject
@property(strong,nonatomic)AdsModel *asdModel;
@property(strong,nonatomic)UpgradeVersionModel *uvModel;
@property(strong,nonatomic)NoticeModel *nModel;
-(void)showAdsViewOwner:(__kindof UIViewController *)owner;
-(void)showUpgradeVersionView:(__kindof UIViewController *)owner;
- (void)showNoticeView:(__kindof UIViewController *)owner;
@end
