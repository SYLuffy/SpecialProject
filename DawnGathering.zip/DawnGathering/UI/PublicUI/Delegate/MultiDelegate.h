//
//  MultiDelegate.h
//  HLGA
//
//  Created by 葛亮 on 2018/6/7.
//  Copyright © 2018年 Linus. All rights reserved.
//

@interface MultiDelegate : NSObject

@property (readonly, nonatomic) NSPointerArray* delegates;
@property (nonatomic, assign) BOOL silentWhenEmpty;

- (id)initWithDelegates:(NSArray*)delegates;
- (void)addDelegate:(id)delegate;
- (void)addDelegate:(id)delegate beforeDelegate:(id)otherDelegate;
- (void)addDelegate:(id)delegate afterDelegate:(id)otherDelegate;
- (void)removeDelegate:(id)delegate;
- (void)removeAllDelegates;

@end
