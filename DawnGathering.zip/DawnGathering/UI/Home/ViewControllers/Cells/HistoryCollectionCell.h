//
//  HistoryCollectionCell.h
//  DawnGathering
//
//  Created by 李冬岐 on 2023/8/18.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HistoryCollectionCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UILabel *cellContentLabel;

+ (instancetype)xibTableViewCell;
@end

NS_ASSUME_NONNULL_END
