//
//  SearchCell.h
//  DawnGathering
//
//  Created by 李冬岐 on 2023/8/17.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN


typedef void (^TapClearRecentHistory)(void);

typedef void(^TapSearchHistoryWithContent)(NSString * content);

@interface SearchCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *cellTitleLabel;
@property (nonatomic,strong)NSArray * dataSource;

+ (CGFloat)getCellHeightWithList:(NSArray*)list;

@property (nonatomic,copy)TapSearchHistoryWithContent tapSearchHistoryWithContent;

@property (nonatomic,copy)TapClearRecentHistory tapClearRecentHistory;

@end

NS_ASSUME_NONNULL_END
