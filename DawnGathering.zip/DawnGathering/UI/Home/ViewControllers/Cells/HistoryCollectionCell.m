//
//  HistoryCollectionCell.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/8/18.
//

#import "HistoryCollectionCell.h"

@implementation HistoryCollectionCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

+ (instancetype)xibTableViewCell{
    return [[[NSBundle mainBundle] loadNibNamed:@"HistoryCollectionCell" owner:nil options:nil] lastObject];
    
}

@end
