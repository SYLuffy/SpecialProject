//
//  SearchCell.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/8/17.
//

#import "SearchCell.h"
#import "HistoryCollectionCell.h"
#import "HorizontalCollectionViewFlowLayout.h"

@interface SearchCell()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;

@end

@implementation SearchCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    self.collectionView.userInteractionEnabled = YES;

    [self.collectionView registerNib:[UINib nibWithNibName:@"HistoryCollectionCell" bundle:[NSBundle mainBundle]] forCellWithReuseIdentifier:@"HistoryCollectionCell"];
    self.collectionView.delegate = self;
    self.collectionView.dataSource = self;
    self.collectionView.scrollEnabled = true;
    self.collectionView.showsHorizontalScrollIndicator = NO;
}


- (void)setDataSource:(NSArray *)dataSource
{
    _dataSource = dataSource;
    
    
    
    [self.collectionView reloadData];
}
- (IBAction)tapClearHistoryHandler:(UIButton *)sender {
    if(self.tapClearRecentHistory)
    {
        self.tapClearRecentHistory();
    }
}


#pragma mark --  UICollectionViewDataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.dataSource.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    HistoryCollectionCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"HistoryCollectionCell" forIndexPath:indexPath];
    if (!cell) {
        cell = [HistoryCollectionCell xibTableViewCell];
    }
    
    NSDictionary *dic = self.dataSource[indexPath.row];
    
    NSString * content = dic[CONTENT];
    
    cell.cellContentLabel.text = content;
    
    
    return cell;
}
-(BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    NSDictionary * dic = self.dataSource[indexPath.row];
    
    NSString * content = dic[CONTENT];
    
    
    if(self.tapSearchHistoryWithContent)
    {
        self.tapSearchHistoryWithContent(content);
    }
    
   
}
#pragma mark -- UICollectionViewDelegateFlowLayout

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    NSDictionary * dic = self.dataSource[indexPath.row];
    
    NSString * content = dic[CONTENT];
    
    CGFloat width = [Utils getLabelWidthByHeight:28 andContent:content andFont:[UIFont fontWithName:DEFAULT_FONT_NAME size:12]] + 30;
    
    
    return CGSizeMake(width,38);
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    
    return 0;
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return 0;
}
- (UIEdgeInsets) collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(0, 0, 0, 0);
}

+ (CGFloat)getCellHeightWithList:(NSArray*)list
{
    
    if(list.count == 0) return 0;
    
    CGFloat totalWith = SCREEN_WIDTH - 10;
    
    CGFloat height = 38;//初始高度;
    
    CGFloat tempWidth = 0;
    for(NSDictionary * dic in list)
    {
        NSString * content = dic[CONTENT];
        
        CGFloat width = [Utils getLabelWidthByHeight:28 andContent:content andFont:[UIFont fontWithName:DEFAULT_FONT_NAME size:12]] + 30;
        tempWidth += width;
        
        if(tempWidth > totalWith)
        {
            height += 38;
            tempWidth = width;
        }
    }
    
    return height + 56;
}

@end
