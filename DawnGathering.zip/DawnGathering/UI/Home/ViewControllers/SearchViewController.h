//
//  SearchViewController.h
//  DawnGathering
//
//  Created by 李冬岐 on 2023/8/17.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SearchViewController : UIViewController


@property (nonatomic,strong)NSString * selectionCodes;

@property (nonatomic,strong)NSString * zoneCodes;

@property (nonatomic,strong)NSString * placeholder;

@end

NS_ASSUME_NONNULL_END
