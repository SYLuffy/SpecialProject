//
//  SearchViewController.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/8/17.
//

#import "SearchViewController.h"
#import "HomeTitleSearchView.h"
#import "SearchCell.h"
#import <IQKeyboardManager.h>

@interface SearchViewController ()<UITextFieldDelegate,UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong)HomeTitleSearchView * titleView;

@property (nonatomic,strong)NSString * searchURL;

@property (nonatomic,strong)NSMutableArray * dataSouce;

@property (weak, nonatomic) IBOutlet UITableView *listTableView;

@end

@implementation SearchViewController


- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [IQKeyboardManager sharedManager].enable = false;

    
    [Utils setDefaultNavigationBar:self];
    
    UIView * container = [[UIView alloc] initWithFrame:CGRectMake(0, 0,  SCREEN_WIDTH, [Utils getNavigationBarAndStatusBarHeight:self])];
    
    
    self.titleView.frame = container.bounds;
    
    self.titleView.leftDistance.constant = 0;
    [container addSubview:self.titleView];
    
    self.titleView.tapButton.hidden = true;//隐藏继续点击
    
    self.titleView.whiteView.backgroundColor = UIColorFromRGB(0xF7F8FA);
    
    self.navigationItem.titleView = container;
    
    
    
    [self getHistoryHandler];
    
    
}

//获取历史记录;
- (void)getHistoryHandler
{
    self.dataSouce = [NSMutableArray array];
    
    NSMutableDictionary * dic = @{TITLE:@"最近搜索",LIST:@[]}.mutableCopy;

    NSMutableArray * historyDatas = [Utils getUserDefaultByKey:HISTORY_USER_SEARCH_DATAS];
    
    if(historyDatas)
    {
        [dic setObject:historyDatas forKey:LIST];
    }
    
    [self.dataSouce addObject:dic];
    
    [self.listTableView reloadData];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    if(self.placeholder)
    {
        self.titleView.inputText.placeholder = self.placeholder;
    }
    
    [self.titleView.inputText becomeFirstResponder];
    self.titleView.inputText.delegate = self;

    self.listTableView.delegate = self;
    self.listTableView.dataSource = self;
    self.listTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.listTableView.tableFooterView = [UIView new];
    

    
}
- (IBAction)backAndPopHandler:(UIBarButtonItem *)sender {
    
    [self.navigationController popViewControllerAnimated:true];
}

- (void)searchWithContentHandler:(NSString*)content
{
    if(content.length == 0) return;
    
    NSString * searchURL;
    
    NSString * goWebURL;
    
    if(self.zoneCodes)
    {
        searchURL = [NSString stringWithFormat:@"%@?%@=%@&%@=%@",[SharedInstance getInstance].saasURLModel.searchURL,KEY_WORD,content,ZONE_CODES,self.zoneCodes];
    }else{
        searchURL = [NSString stringWithFormat:@"%@?%@=%@",[SharedInstance getInstance].saasURLModel.searchURL,KEY_WORD,content];
    }
    
    goWebURL = searchURL;
    
    NSArray * historyDatas = [Utils getUserDefaultByKey:HISTORY_USER_SEARCH_DATAS];
    
    NSMutableArray * tempDatas;
    if(historyDatas)
    {
        tempDatas = historyDatas.mutableCopy;
        for(NSDictionary * dic in tempDatas)
        {
            NSString * checkContent = dic[CONTENT];
            
            if([checkContent isEqualToString:content])
            {
                //如果找到相同的
                
                [tempDatas removeObject:dic];
                
                break;
            }
        }
        
        
        [tempDatas insertObject:@{CONTENT:content} atIndex:0];
        
        if(tempDatas.count > 30)
        {
            //当大于30 删除最后一个
            [tempDatas removeLastObject];
        }
        
    }else{
        tempDatas = [NSMutableArray array];
        [tempDatas addObject:@{CONTENT:content}];
    }
    
    [Utils pushWebViewControllerURL:goWebURL owner:self];
    
    [Utils setUserDefaultByKey:HISTORY_USER_SEARCH_DATAS andValue:tempDatas];
    
}

- (HomeTitleSearchView *)titleView
{
    if(!_titleView)
    {
        _titleView = (HomeTitleSearchView*)[Utils getXibByName:@"HomeTitleSearchView"];
    }
    
    return _titleView;
}



- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self searchWithContentHandler:textField.text];
    
    [self.titleView.inputText resignFirstResponder];
    return YES;
}

#pragma mark -- UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{

    return self.dataSouce.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    SearchCell * cell = [tableView dequeueReusableCellWithIdentifier:@"SearchCell"];
    
    if(!cell)
    {
        cell = (SearchCell*)[Utils getXibByName:@"SearchCell"];
    }
    
    WS(weakSelf);
    cell.tapSearchHistoryWithContent = ^(NSString * _Nonnull content) {
        
        weakSelf.titleView.inputText.text = content;
        [weakSelf searchWithContentHandler:content];
    };
    
    cell.tapClearRecentHistory = ^{
        [weakSelf clearRecentHistoryHandler];
    };
    
    NSDictionary * dic = self.dataSouce[indexPath.row];
    
    NSString * title = dic[TITLE];
    
    cell.cellTitleLabel.text = title;
    
    NSArray * list = dic[LIST];
    
    cell.dataSource = list;
    
    return cell;
}

- (void)clearRecentHistoryHandler
{
    WS(weakSelf);
    
    [Utils alertWithTitle:@"提示" msg:@"是否清除最近搜索记录？" andConfirm:^(BOOL isConfirm) {
        [Utils setUserDefaultByKey:HISTORY_USER_SEARCH_DATAS andValue:@[]];
        
        [weakSelf getHistoryHandler];
    } cancel:^{
        
    }];
}

#pragma mark -- UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSMutableDictionary * dic = self.dataSouce[indexPath.row];
    
    NSArray * list = dic[LIST];
    
    return [SearchCell getCellHeightWithList:list];
}


- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    [IQKeyboardManager sharedManager].enable = true;
}
@end
