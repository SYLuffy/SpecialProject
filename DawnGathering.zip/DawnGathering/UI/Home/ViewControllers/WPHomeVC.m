//
//  WPHomeVC.m
//  HLGA
//  首页
//  Created by 葛亮 on 2018/5/21.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "WPHomeVC.h"
#import "MessageViewController.h"
#import <UIBarButtonItem+WZLBadge.h>
#import "UIImage+tools.h"
#import "UIColor+Extension.h"
#import "WPHomeVM.h"
#import "QuickRefresh.h"
#import "ShowViewModel.h"
#import "WPPaymentPasswordVC.h"
#import "UITableView+EZErrorView.h"
#import "PrivacyPopView.h"
#import "WPNavigationController.h"
#import "ScanCodeViewController.h"
#import "NormalNavigationCollectionViewCell.h"
#import "SmallBannerImageCell.h"
#import "HomeThreeImageCell.h"
#import "BannerImageCell.h"
#import <IQKeyboardManager/IQKeyboardManager.h>
#import "SectionCell.h"
#import "HomeTitleSearchView.h"
#import "TabNavigationCollectionViewCell.h"
#import "WaterFallViewPage.h"
#import "JXPageListView.h"
#import "GoodsZoneCell.h"
#import "SaaSURLModel.h"
#import "SearchViewController.h"
#import "MerchantListViewController.h"
#import "HomeMerchantListCell.h"
#import "MerchantDetailViewController.h"
#import "MerchantMapViewController.h"
#import "NumberEquitiesCell.h"

@interface WPHomeVC ()<UITableViewDelegate,UITableViewDataSource,UITableViewErrorViewDataSource,WPPaymentPasswordVCDelegate,JXPageListViewDelegate>

@property (strong, nonatomic)JXPageListView *pageListView;
@property (nonatomic,strong)UITableView * listTableView;
@property(nonatomic,assign)EZErrorViewType errorType;
@property(nonatomic,strong)QuickRefresh * refresh;
@property(nonatomic,strong)ShowViewModel *showViewModel;
@property (nonatomic,strong)WPHomeVM *homeVM;
@property(nonatomic,assign)BOOL currentIsInBottom;
@property(nonatomic,assign)BOOL isNoMoreDataBOOL;
@property (nonatomic,assign)BOOL isAlreadyShowMessage;
@property (nonatomic,strong)UIBarButtonItem *rightItem;
@property (nonatomic,strong)NSMutableArray * totalItems;
@property (weak, nonatomic) IBOutlet UIButton *topTableViewButton;
@property (nonatomic,strong)UIImageView * backgroundImageView;
@property (nonatomic,strong)HomeTitleSearchView * titleView;
@property (nonatomic,strong)NSMutableArray <NSString*>* titles;
@property (nonatomic,strong)NSMutableArray <NSString*>* subTitles;
@property (nonatomic,strong)NSMutableArray <WaterFallViewPage*>* listViewArray;
@property (nonatomic,strong)NSString * searchBgColor;
@property (nonatomic,assign)BOOL isNormalList;
@property (nonatomic,strong)UIActivityIndicatorView * activityIndicator;
@property (nonatomic,strong)NSNumber * blackWhiteId;
@property (nonatomic,strong)NSArray * blackWhiteIdList;
@property (nonatomic,strong)NSMutableDictionary * numberEquitiesRow;//抢购行数;

@property (nonatomic,strong)UIView * bottomShowTopView;//底部悬浮view;

@end

@implementation WPHomeVC

//改变状态栏颜色（nav隐藏可用）
- (UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:EVENT_UPDATE_HOME_PAGE object:nil];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:EVENT_HOME_JUMP_WITH_TYPE object:nil];
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateMainTableViewData) name:EVENT_UPDATE_HOME_PAGE object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(jumpWithTypeHandler:) name:EVENT_HOME_JUMP_WITH_TYPE object:nil];
    
    
    [Utils setDefaultNavigationBar:self];
    
    if(self.searchBgColor)
    {
        [Utils setNavigationBarBackgroundWithColor:[UIColor colorWithHexString:self.searchBgColor] titleColor:[UIColor blackColor] vc:self];
    }
    
    if(self.homePageID)
    {
        self.navigationItem.rightBarButtonItem = nil;
        
        self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"ic_title_back"] style:UIBarButtonItemStylePlain target:self action:@selector(backAndPopHandler:)];
        
        self.navigationItem.leftBarButtonItem.tintColor = [UIColor blackColor];
       
        
        [Utils setDefaultNavigationBar:self];
        
    }else{
        
        if(self.homeVM.homeModel.isSearch.integerValue == 1)
        {
            UIView * container = [[UIView alloc] initWithFrame:CGRectMake(0, 0,  SCREEN_WIDTH, [Utils getNavigationBarAndStatusBarHeight:self])];
            
            self.titleView.frame = container.bounds;
            
            self.titleView.bottomDistance.constant = 5;
            
            [container addSubview:self.titleView];
            
            self.navigationItem.titleView = container;
        }else{
            self.navigationItem.titleView = nil;
        }

        if([SharedInstance getInstance].isFromPushGotoMessage == true){
            //判断是否是从推送点击进入
            [SharedInstance getInstance].isFromPushGotoMessage = false;
            [self messageHandler:nil];
        }
    }
    
    if([SharedInstance getInstance].needUpdateHomePageOnce)
    {
        [SharedInstance getInstance].needUpdateHomePageOnce = false;
        
        [self updateMainTableViewData];
    }
        
    self.isAlreadyShowMessage = false;
    
    [self alertPriateUrlWebView];
    
    if([SharedInstance getInstance].isNeedUpdateHomePage)
    {
        [SharedInstance getInstance].isNeedUpdateHomePage = false;
        [self updateMainTableViewData];
    }
    
}

- (void)backAndPopHandler:(UIBarButtonItem*)sender
{
    [self.navigationController popViewControllerAnimated:true];
}

- (void)jumpWithTypeHandler:(NSNotification*)notification
{
    NSDictionary *notificationInfo = [notification userInfo];
    NSString *target = [notificationInfo objectForKey:TARGET];
    NSNumber *jumpType = [notificationInfo objectForKey:JUMP_TYPE];
    
    NSNumber * blackWhiteId = notificationInfo[BLACK_WHITE_ID];
    
    NSArray * blackWhiteList = notificationInfo[WHITE_IDS];
    
    [SharedInstance getInstance].sendBlackWhiteList = blackWhiteList;
    
    [self gotoWithTargetURL:target jumpType:jumpType blackWhiteId:blackWhiteId];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getNormalSetting) name:EVENT_SGH_LOGIN_SUCCESS object:nil];
    
    self.titles = [NSMutableArray array];
    
    self.bottomShowTopView = [[UIView alloc] initWithFrame:CGRectZero];
    //self.bottomShowTopView.backgroundColor = [UIColor whiteColor];
    
    
    [self.view addSubview:_bottomShowTopView];
    
    
    [self getUserInfo];
    
    WS(weakSelf);
    self.titleView.tapSearchGotoSearchViewController = ^{
        [weakSelf gotoSearchViewController];
    };
    
    self.titleView.tapMessageHandler = ^{
        [weakSelf gotoTapSearchIconHandler];
    };
    
    self.backgroundImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, -[Utils getNavigationBarAndStatusBarHeight:self], 1, 1)];
    
    [self.view addSubview:self.backgroundImageView];
    
    self.refresh = [[QuickRefresh alloc] init];
    
    if(self.listTableView == nil && self.pageListView == nil)
    {
        if (@available(iOS 13.0, *)) {
            self.activityIndicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleLarge];
        } else {
            // Fallback on earlier versions
            self.activityIndicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
        }
        
        self.activityIndicator.frame = CGRectMake((SCREEN_WIDTH - 60) * 0.5, (self.view.frame.size.height - 60) * 0.5 - [Utils getNavigationBarAndStatusBarHeight:self], 60, 60);
        
        [self.view addSubview:self.activityIndicator];
        
        [self.activityIndicator startAnimating];
    }
    
}

- (void)initNormalList
{
    if(self.pageListView)
    {
        self.pageListView.mainTableView.dataSource = nil;
        self.pageListView.mainTableView.delegate = nil;
        
        [self.pageListView removeFromSuperview];
        
        self.pageListView = nil;
    }
    
    self.isNormalList = true;
    
    CGFloat locationY = 0;
    
    if(self.homeVM.homeModel.isSearch.integerValue == 1 && self.homePageID)
    {
        UIView * container = [[UIView alloc] initWithFrame:CGRectMake(0, 0,  SCREEN_WIDTH, 64)];
        
        self.titleView.frame = container.bounds;
        
        self.titleView.bottomDistance.constant = 16;
        
        [container addSubview:self.titleView];
        
        [self.view addSubview:container];
        locationY = container.frame.size.height;
    }
    
    if(!self.listTableView)
    {
        self.listTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, locationY, self.view.frame.size.width, self.view.frame.size.height - locationY)];
        
        self.listTableView.dataSource = self;
        
        self.listTableView.delegate = self;
        
        self.listTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        
        self.listTableView.tableFooterView = [UIView new];
        
        self.listTableView.backgroundColor = [UIColor clearColor];
        
        [self.view addSubview:self.listTableView];
        
        [self.refresh gifModelRefresh:self.listTableView refreshType:RefreshTypeDropDown firstRefresh:false timeLabHidden:false stateLabHidden:false dropDownBlock:^{
            [self updateMainTableViewData];
        } upDropBlock:^{
            
        }];
    }
    
}

- (void)initPageList
{
    
    if(self.listTableView)
    {
        self.listTableView.dataSource = nil;
        self.listTableView.delegate = nil;
        
        [self.listTableView removeFromSuperview];
        
        self.listTableView = nil;
    }
    
    self.isNormalList = false;
    
    CGFloat locationY = 0;
    
    if(self.homeVM.homeModel.isSearch.integerValue == 1 && self.homePageID)
    {
        UIView * container = [[UIView alloc] initWithFrame:CGRectMake(0, 0,  SCREEN_WIDTH, 64)];
        
        self.titleView.frame = container.bounds;
        
        self.titleView.bottomDistance.constant = 16;
        
        [container addSubview:self.titleView];
        
        [self.view addSubview:container];
        locationY = container.frame.size.height;
    }
    
    if(!self.pageListView)
    {
        self.pageListView = [[JXPageListView alloc] initWithDelegate:self];
        self.pageListView.pinCategoryView.titles =self.titles;
        self.pageListView.pinCategoryView.titleFont = [UIFont fontWithName:DEFAULT_FONT_NAME size:16];
        self.pageListView.pinCategoryView.titleSelectedFont = [UIFont fontWithName:MEDIUM_FONT_NAME size:16];
        self.pageListView.pinCategoryView.titleSelectedColor = [Utils getMainColor];
        self.pageListView.pinCategoryView.titleColor = UIColorFromRGB(0x222222);
        self.pageListView.mainTableView.delegate = self;
        self.pageListView.mainTableView.dataSource = self;
        self.pageListView.listViewScrollStateSaveEnabled = true;
        self.pageListView.pinCategoryView.subTitleColor = UIColorFromRGB(0x222222);
        self.pageListView.pinCategoryView.subTitleSelectedColor = [UIColor whiteColor];
        self.pageListView.pinCategoryView.subTitleSelectedBackgroundColor = [Utils getMainColor];
        self.pageListView.pinCategoryViewVerticalOffset = 0;
        self.pageListView.pinCategoryViewHeight = 60;
        self.pageListView.mainTableView.scrollsToTop = NO;
        self.pageListView.mainTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        self.pageListView.backgroundColor = [UIColor clearColor];
        
        self.pageListView.mainTableView.backgroundColor = [UIColor clearColor];
        
        [self.refresh gifModelRefresh:self.pageListView.mainTableView refreshType:RefreshTypeDropDown firstRefresh:false timeLabHidden:false stateLabHidden:false dropDownBlock:^{
            [self updateMainTableViewData];
        } upDropBlock:^{
                
        }];
        
    }
    
    
    
    [self.view addSubview:self.pageListView];
}
- (void)updateMainTableViewData
{
    //获取全局单位
    [ServiceManager getAppUnit];
    
    //获取全局SaasURL、需要拼接地址
    [ServiceManager getewayAllHTMLURL:^(NSDictionary *data) {
        
        SaaSURLModel * model = [[SaaSURLModel alloc] initByDictionary:data];
        
        [SharedInstance getInstance].saasURLModel = model;
        
    }];
    
    //添加底部栏通知
    [[NSNotificationCenter defaultCenter] postNotificationName:EVET_UPDATE_BOTTOM_TABBAR_LIST object:nil];
    
    //刷新主页数据
    [self.homeVM loadHomeTopListSuccess:^{
        
        self.numberEquitiesRow = [NSMutableDictionary dictionary];
        if(self.homeVM.titleName.length > 0)
        {
            self.title = self.homeVM.titleName;
        }
        
        //由于服务端数据混乱处理了很多不必要的数据格式
        if([self.homeVM.homeModel.isbgImg isKindOfClass:[NSString class]])
        {
            if([self.homeVM.homeModel.isbgImg isEqualToString:@"true"])
            {
                CGFloat radio = 1;
                if(self.homeVM.homeModel.width && self.homeVM.homeModel.height)
                {
                    radio = self.homeVM.homeModel.height.floatValue / self.homeVM.homeModel.width.floatValue;
                }
                
                CGFloat bgHeight = self.view.frame.size.width * radio;
                self.backgroundImageView.frame = CGRectMake(0, -[Utils getNavigationBarAndStatusBarHeight:self], self.view.frame.size.width, bgHeight);
                
                if(self.homeVM.homeModel.bgImg.length > 0)
                {
                    [Utils loadImage:self.backgroundImageView andURL:self.homeVM.homeModel.bgImg isLoadRepeat:false];
                }
            }else{
                self.backgroundImageView.hidden = true;
            }
        }else{
            if(self.homeVM.homeModel.isbgImg.integerValue == 1)
            {
                CGFloat radio = 1;
                if(self.homeVM.homeModel.width && self.homeVM.homeModel.height)
                {
                    radio = self.homeVM.homeModel.height.floatValue / self.homeVM.homeModel.width.floatValue;
                }
                
                CGFloat bgHeight = self.view.frame.size.width * radio;
                self.backgroundImageView.frame = CGRectMake(0, -[Utils getNavigationBarAndStatusBarHeight:self], self.view.frame.size.width, bgHeight);
                
                if(self.homeVM.homeModel.bgImg.length > 0)
                {
                    [Utils loadImage:self.backgroundImageView andURL:self.homeVM.homeModel.bgImg isLoadRepeat:false];
                }
            }else{
                self.backgroundImageView.hidden = true;
            }
        }
        
        //是否有背景色
        if(self.homeVM.homeModel.bodyBgColor && self.homeVM.homeModel.bodyBgColor.length > 0){
            
            self.view.backgroundColor = [UIColor colorWithHexString:self.homeVM.homeModel.bodyBgColor];
            
        }
        
        self.titles = [NSMutableArray array];
        self.listViewArray = [NSMutableArray array];
        self.subTitles = [NSMutableArray array];
        NSDictionary * dic = self.homeVM.homeListData.lastObject.firstObject;
        NSArray * datas = dic[CLASSIFY_LIST];
        NSString * isSubTitle = dic[IS_SUBTITLE];
        NSString * selColor = dic[SEL_COLOR];
        NSString * notSelColor = dic[NOT_SEL_COLOR];
        self.searchBgColor = self.homeVM.homeModel.searchConfig[SEARCH_BG_COLOR];
        
        //是否有搜索栏背景色
        if([Utils checkObjectIsNull:self.searchBgColor] && self.searchBgColor.length > 0)
        {
            [Utils setNavigationBarBackgroundWithColor:[UIColor colorWithHexString:self.searchBgColor] titleColor:[UIColor blackColor] vc:self];
        }
        
        //停止背景loding并删除
        [self.activityIndicator stopAnimating];
        [self.activityIndicator removeFromSuperview];
        
        //如果有数据初始化 带商品的tableView
        if(datas.count != 0)
        {
            [self initPageList];
            WS(weakSelf);
            NSInteger index = 0;
            
            NSString * tempName;
            for(NSDictionary * dic in datas)
            {
                NSString * name = dic[NAME];
                tempName = name;
                NSString * subTitle = dic[SUB_TITLE];
                
                [self.titles addObject:name];
                
                if(isSubTitle.integerValue == 1)
                {
                    if(subTitle)
                    {
                        [self.subTitles addObject:subTitle];
                    }else{
                        [self.subTitles addObject:@""];
                    }
                    
                }else{
                    [self.subTitles addObject:@""];
                }
                
                
                WaterFallViewPage * pageView = (WaterFallViewPage*)[Utils getXibByName:@"WaterFallViewPage"];
                [pageView updateWithDataDic:dic];
                
                pageView.index = index;
                
                pageView.tapWaterFallHandlerWithIndex = ^(NSInteger index, NSString * _Nullable goURL, NSNumber * _Nonnull jumpType) {
                    [weakSelf gotoWithTargetURL:goURL jumpType:jumpType blackWhiteId:@0];
                };
                
                [self.listViewArray addObject:pageView];
                
                index ++;
                
            }
            
            if(datas.count == 1 && tempName.length == 0)
            {
                self.pageListView.pinCategoryViewHeight = 0;
            }
            
            self.pageListView.pinCategoryView.titles = self.titles;
            self.pageListView.pinCategoryView.subTitles = self.subTitles;
            
            self.pageListView.pinCategoryView.titleSelectedColor = [UIColor colorWithHexString:selColor];
            
            self.pageListView.pinCategoryView.titleColor = [UIColor colorWithHexString:notSelColor];
            self.pageListView.pinCategoryView.subTitleColor = [UIColor colorWithHexString:notSelColor];
            
            self.pageListView.pinCategoryView.subTitleSelectedColor = [UIColor whiteColor];
            self.pageListView.pinCategoryView.subTitleSelectedBackgroundColor = [UIColor colorWithHexString:selColor];
            
            [self.pageListView reloadData];
        }else{
            //普通tableView
            [self initNormalList];
            [self.listTableView reloadData];
            
        }
        
        //如果有索索栏
        if(self.homeVM.homeModel.isSearch.integerValue == 1)
        {
            //如果是主页主页没有pageID
            if(self.homePageID == nil){
                UIView * container = [[UIView alloc] initWithFrame:CGRectMake(0, 0,  SCREEN_WIDTH, [Utils getNavigationBarAndStatusBarHeight:self])];
                
                self.titleView.frame = container.bounds;
                
                self.titleView.bottomDistance.constant = 5;
                
                [container addSubview:self.titleView];
                
                self.navigationItem.titleView = container;
            }
            if(self.homeVM.homeModel.placeholder.length > 0)
            {
                self.titleView.inputText.placeholder = self.homeVM.homeModel.placeholder;
            }
            
            NSString * searchIconURL = self.homeVM.homeModel.searchConfig[ICON_URL];
            
            if(searchIconURL.length > 0)
            {
                self.titleView.searchImageViewIconWidth.constant = 32;
                
                [Utils loadImage:self.titleView.searchImageViewIcon andURL:searchIconURL isLoadRepeat:false];
            }else{
                self.titleView.searchImageViewIconWidth.constant = 0;
            }
            
        }else{
            //如果没有搜索栏并并且是主页
            if(self.homePageID == nil)
            {
                self.navigationItem.titleView = nil;
            }
        }
        
        if(self.homeVM.bottomListData.count > 0)
        {
            
            //判断是否显示底部view；
            [self showBottomViewJudge];
        }else{
            
            //删除子视图;
            [self.bottomShowTopView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
            //隐藏
            self.bottomShowTopView.frame = CGRectZero;
        }
        
        [self.refresh endRefreshing];
        
    } FailedBlock:^{
        
        [self.refresh endRefreshing];
        
        [self initNormalList];
        
        
        [self.listTableView reloadData];
        
    } noMoreDataBlock:^{
        [self.refresh endRefreshing];
        
    }];
}

- (void)showBottomViewJudge
{
    //删除子视图;
    [self.bottomShowTopView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    NSDictionary * dic = self.homeVM.bottomListData.firstObject;
    NSString * type = dic[TYPE];
    CGFloat height = [self.homeVM getTableViewCellHeightWithDic:dic type:type numberEquitiesRow:nil indexPath:nil];
    
    [self.view addSubview:self.bottomShowTopView];
    
    CGFloat fixY = self.tabBarController.tabBar.frame.size.height;
    if(self.homePageID)
    {
        fixY = 0;
    }
    self.bottomShowTopView.frame = CGRectMake(0, self.view.frame.size.height - height - fixY, self.view.frame.size.width, height);
    
    if([type isEqualToString:ADVERTISE])
    {
        NSArray * items = @[dic];
        SmallBannerImageCell * cell = (SmallBannerImageCell*)[Utils getXibByName:@"SmallBannerImageCell"];
        
        NSNumber * imgWidth = dic[WIDTH];
        NSNumber * imgHeight = dic[HEIGHT];
        
        if(!imgWidth) imgWidth = @1;
        if(!imgHeight) imgHeight = @1;
        CGFloat portion;
        CGFloat cellHeight = [SmallBannerImageCell getBannerCellRowHeight:items.count];
        if(imgWidth.floatValue > 0)
        {
            portion = imgHeight.floatValue / imgWidth.floatValue;
            
            cellHeight = (SCREEN_WIDTH - 30) * portion + 15;
            
            cell.scrollView.frame = CGRectMake(0, 0, SCREEN_WIDTH - 30, cellHeight - 15);
        }
        
        cell.items = items;
        cell.selectItemBlock = ^(NSInteger index , NSArray * _Nullable items) {
            
            if (items.count == 0) {
                return;
            }
            
            NSDictionary * dic = items[index];
            
            NSString * goURL;
            
            NSNumber * jumpType = dic[JUMP_TYPE];
            
            if(jumpType.integerValue == 3)
            {
                NSDictionary * shopSet = dic[SHOP_SET];
                
                goURL = [Utils dictionaryToJson:shopSet];
            }else{
                goURL = dic[HREF_URL];
            }
            
            if([goURL isKindOfClass:[NSString class]] && [goURL isEqualToString:CLASSIFY])
            {
                [SharedInstance getInstance].currentClassifyID = dic[CLASSIFY_ID];
            }
            
            NSNumber * blackWhiteId = dic[BLACK_WHITE_ID];
            
            NSArray * blackWhiteList = dic[WHITE_IDS];
            
            [SharedInstance getInstance].sendBlackWhiteList = blackWhiteList;
            
            
            [self gotoWithTargetURL:goURL jumpType:jumpType blackWhiteId:blackWhiteId];
            
        };
        
        [cell updateTableViewCellWithData:items];
        
        cell.frame = CGRectMake(0, 5, self.bottomShowTopView.bounds.size.width, self.bottomShowTopView.bounds.size.height);
        
        NSString * bgColor = dic[BG_COLOR];
        
        if(bgColor)
        {
            self.bottomShowTopView.backgroundColor = [UIColor colorWithHexString:bgColor];
        }else
        {
            self.bottomShowTopView.backgroundColor = [UIColor whiteColor];
        }
        
        [self.bottomShowTopView addSubview:cell];
        
    }else if([type isEqualToString:MAGIC_CUBE])
    {
        SectionCell * cell = (SectionCell*)[Utils getXibByName:@"SectionCell"];
        
        NSArray * items = dic[LIST_DATA];
        NSString * col = dic[LAYOUT];
        NSString * titleImgURL = dic[TITLE_IMG_URL];
        cell.col = col.integerValue + 1;
        
        NSNumber * elementWidth = items.firstObject[WIDTH];
        NSNumber * elementHeight = items.firstObject[HEIGHT];
        CGFloat radio = elementHeight.floatValue / elementWidth.floatValue;
        NSNumber * width = dic[WIDTH];
        NSNumber * height = dic[HEIGHT];
        
        if(!width) width = @1;
        if(!height) height = @1;
        
        CGFloat titleRadio = height.floatValue / width.floatValue;
        
        CGFloat titleHeight = (SCREEN_WIDTH - 30) * titleRadio;
        
        if(titleImgURL.length > 0)
        {
            cell.titleBgImageView.hidden = false;
            [Utils loadImage:cell.titleBgImageView andURL:titleImgURL isLoadRepeat:false];
        }else{
            cell.titleBgImageView.hidden = true;
            titleHeight = 0;
        }
        
        [cell setCellData:items radio:radio titleHeight:titleHeight];
        WS(weakSelf);
        cell.tapSectionHandlerWithIndex = ^(NSInteger index, NSString * _Nullable goURL, NSNumber * _Nonnull jumpType , NSNumber * _Nullable blackWhiteId) {
            
            
            [weakSelf gotoWithTargetURL:goURL jumpType:jumpType blackWhiteId:blackWhiteId];
        };
        NSString * bgColor = dic[BG_COLOR];
        if(bgColor)
        {
            self.bottomShowTopView.backgroundColor = [UIColor colorWithHexString:bgColor];
        }else
        {
            self.bottomShowTopView.backgroundColor = [UIColor whiteColor];
        }
        
        cell.frame = CGRectMake(0, 5, self.bottomShowTopView.bounds.size.width, self.bottomShowTopView.bounds.size.height);
        
        [self.bottomShowTopView addSubview:cell];
    }
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];

    CGFloat locationY = 0;
    
    CGFloat bottomViewHeight = 0;
    
    if(self.homePageID && self.homeVM.homeModel.isSearch.integerValue == 1)
    {
        locationY = 64;
    }
    
    if(self.homeVM.bottomListData.count > 0)
    {
        NSDictionary * dic = self.homeVM.bottomListData.firstObject;
        NSString * type = dic[TYPE];
        CGFloat height = [self.homeVM getTableViewCellHeightWithDic:dic type:type numberEquitiesRow:nil indexPath:nil];
        
        bottomViewHeight = height;
        
        if(self.homePageID == nil)
        {
            bottomViewHeight += self.tabBarController.tabBar.frame.size.height;
        }
    }
    CGFloat listHeight = self.view.frame.size.height - locationY - bottomViewHeight;
    NSLog(@"--->>>%.2lf",listHeight);
    if(self.isNormalList)
    {
        self.listTableView.frame = CGRectMake(0, locationY, self.view.frame.size.width, listHeight);
    }else{
        self.pageListView.frame = CGRectMake(0, locationY, self.view.frame.size.width, listHeight);
    }
    
}

#pragma mark - request

-(void)getUserInfo{
    
    NSString *sid = [Utils getUserDefaultByKey:SID];
    if(sid != nil && sid.length > 0 && [SharedInstance getInstance].userInfo == nil){
        
        //判断自动登录
        [ServiceManager getUserInformationBySid:sid successBack:^(NSDictionary *data) {
            NSDictionary * result = data[DATA];
            
            UserInfo * userInfo = [[UserInfo alloc] initByDictionary:result];
            [BuglyManager setPhoneNum:userInfo.telephone];
            [SharedInstance getInstance].userInfo = userInfo;
            
            [SharedInstance getInstance].sid = userInfo.sid;
            [Utils setUserDefaultByKey:SID andValue:userInfo.sid];
            
            [self getShowUnreadMessage];
            [self getNormalSetting];
            
            [self updateMainTableViewData];
            
        } failure:^(NSError *error) {
            
            [self updateMainTableViewData];
        }];
        
    }else{
        [self updateMainTableViewData]; 
    }
}

- (void)gotoSearchViewController
{
    SearchViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_HOME andIdentifier:@"SearchViewController"];
    
    if(self.homePageID && self.homeVM.homeModel.isSearch.integerValue == 1)
    {
        NSString * sectionCodes = self.homeVM.homeModel.searchConfig[SELECTION_CODES];
        
        NSString * zoneID = self.homeVM.homeModel.searchConfig[ZONE_ID]; 
        
        if(sectionCodes && sectionCodes.length > 0)
        {
            vc.selectionCodes = sectionCodes;
        }
        
        if(zoneID && zoneID.length > 0)
        {
            vc.zoneCodes = zoneID;
        }
    }
    
    if(self.homeVM.homeModel.isSearch.integerValue == 1 &&  self.homeVM.homeModel.placeholder.length > 0)
    {
        vc.placeholder = self.homeVM.homeModel.placeholder;
    }
    
    [self.navigationController pushViewController:vc animated:true];
}
/**
 获取是否有未读消息显示
 */
- (void)getShowUnreadMessage{
    NSLog(@"WPHomeVC------------------------");
    if ([[SharedInstance getInstance].userInfo.userId integerValue] == 0) {
        return;
    }
    
    [ServiceManager getMessageCount:^(NSDictionary *data) {
        
        NSArray * results = data[DATA];
        NSInteger sumCount = 0;
        if([Utils checkObjectIsNull:results] == true){
            
            for(NSDictionary * dataSource in results){
                NSNumber * unreadNum = dataSource[UNREAD_NUM];
                sumCount += unreadNum.integerValue;
            }
            if(sumCount > 0){
                [self.rightItem setBadgeMaximumBadgeNumber:9];
                [self.rightItem showBadgeWithStyle:WBadgeStyleNumber value:sumCount animationType:WBadgeAnimTypeNone];

                if (@available(iOS 11.0, *))
                {
                    self.rightItem.badgeCenterOffset = CGPointMake(-2, 4);
                }else{
                    self.rightItem.badgeCenterOffset = CGPointMake(-2, 2);
                }
            }else{
                [self.rightItem clearBadge];
            }
        }else{
            [self.rightItem clearBadge];
        }
    } isShowLoading:false];
}

- (void)gotoTapSearchIconHandler
{
    NSDictionary * iconJump = self.homeVM.homeModel.searchConfig[ICON_JUMP];
    
    NSNumber * jumpType = iconJump[JUMP_TYPE];
    
    NSNumber * blackWhiteId = iconJump[BLACK_WHITE_ID];
    
    NSArray * blackWhiteList = iconJump[WHITE_IDS];
    
    [SharedInstance getInstance].sendBlackWhiteList = blackWhiteList;
    
    NSString * target;
    if(jumpType.integerValue == 3)
    {
        target = [Utils dictionaryToJson:iconJump];
    }else{
        target = iconJump[HREF_URL];
    }
    
    [self gotoWithTargetURL:target jumpType:jumpType blackWhiteId:blackWhiteId];
}

- (void)getNormalSetting{
    //获取支付密码和是否打开免密支付状态
    
    if ([[SharedInstance getInstance].userInfo.userId integerValue] == 0) {
        return;
    }
    [Utils refreshPayPasswordStatus:^(BOOL isCompleted) {
        //刷新支付密码状态;
        
        if([SharedInstance getInstance].isEnterOpenQrCode)
        {
            [SharedInstance getInstance].isEnterOpenQrCode = false;

            [self gotoScanCodeHandler];
        }
        
    }];
}

#pragma -UITableViewDataSource,UITableViewDelegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView;
{
    return self.homeVM.homeListData.count;
}

- (NSInteger)tableView:(nonnull UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    NSInteger count = self.homeVM.homeListData[section].count;
    
    return count;
}

- (nonnull UITableViewCell *)tableView:(nonnull UITableView *)tableView cellForRowAtIndexPath:(nonnull NSIndexPath *)indexPath {
    
    if(self.isNormalList == false)
    {
        if (indexPath.section == self.homeVM.homeListData.count - 1) {
            //Tips:最后一个section（即listContainerCell所在的section）返回listContainerCell的高度
            return [self.pageListView listContainerCellForRowAtIndexPath:indexPath];
        }
    }
    NSMutableDictionary *dic  = self.homeVM.homeListData[indexPath.section][indexPath.row];
    NSString * type = dic[TYPE];
    
    if([type isEqualToString:NAVIGATION])
    {
        NSString * isNavTabs = dic[IS_NAVTABS];
    
        NSArray * items;
        
        if(isNavTabs.integerValue == 1)
        {
            items = dic[NAVTABS_LIST];
            TabNavigationCollectionViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"TabNavigationCollectionViewCell"];
            
            if(!cell)
            {
                cell = (TabNavigationCollectionViewCell*)[Utils getXibByName:@"TabNavigationCollectionViewCell"];
            }
            
            cell.index = indexPath.row;
        
            WS(weakSelf);
            cell.tapTabsAndReloadTableView = ^(NSInteger currentPage, NSInteger index,CGPoint tabOffset) {
                self.homeVM.homeListData[indexPath.section][index][CURRENT_PAGE] = @(currentPage);
                self.homeVM.homeListData[indexPath.section][index][CURRENT_OFFSET_X] = @(tabOffset.x);
                [weakSelf.pageListView.mainTableView reloadData];
                
            };
            
            NSString * bgColor = dic[BACKGROUND_COLOR];
            NSNumber * bgAlpha = dic[BG_COLOR_OPACITY];
            NSString * selTabsColor = dic[SEL_TABS_COLOR];
            NSString * textColor = dic[TEXT_COLOR];
            
            cell.contentView.backgroundColor = [UIColor colorWithHexString:bgColor alpha:bgAlpha.floatValue];
            
            NSNumber * page = dic[CURRENT_PAGE];
            NSNumber * offsetX = dic[CURRENT_OFFSET_X];
            if(page == nil) page = @(0);
            if(offsetX == nil) offsetX = @(0);
            [cell setCellData:items setPage:page.integerValue tabOffset:CGPointMake(offsetX.floatValue, 0) tabsColor:selTabsColor textColor:textColor];
            
            
            return cell;
            
        }else{
            
            items = dic[NAVIGATION_LIST];
            NormalNavigationCollectionViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"NormalNavigationCollectionViewCell"];
            if(!cell){
                cell = [NormalNavigationCollectionViewCell xibTableViewCell];
            }
            
            NSString * bgColor = dic[BACKGROUND_COLOR];
            NSNumber * bgAlpha = dic[BG_COLOR_OPACITY];
            NSString * selTabsColor = dic[SEL_TABS_COLOR];
            NSString * textColor = dic[TEXT_COLOR];
            NSNumber * line = dic[LINE];
            NSNumber * col = dic[COLUMN];
            
            [cell setCellData:items line:line.integerValue col:col.integerValue tabsColor:selTabsColor  textColor:textColor];
            
            cell.contentView.backgroundColor = [UIColor colorWithHexString:bgColor alpha:bgAlpha.floatValue];
           
            cell.homeNewClassifyCellBlock = ^(NSInteger index ,NSString * _Nullable url, NSNumber * _Nullable jumpType ,NSNumber * _Nullable blackWhiteId) {
                
                [self gotoWithTargetURL:url jumpType:jumpType blackWhiteId:blackWhiteId];
            };
            return cell;
        }
        
    }else if([type isEqualToString:ADVERTISE])
    {
        NSArray * items = @[dic];
        
        [self.totalItems addObject:dic];
        
        SmallBannerImageCell * cell = [tableView dequeueReusableCellWithIdentifier:@"SmallBannerImageCell"];
        
        if(!cell)
        {
            cell = (SmallBannerImageCell*)[Utils getXibByName:@"SmallBannerImageCell"];
        }
        
        NSNumber * imgWidth = dic[WIDTH];
        NSNumber * imgHeight = dic[HEIGHT];
        
        if(!imgWidth) imgWidth = @1;
        if(!imgHeight) imgHeight = @1;
        CGFloat portion;
        CGFloat cellHeight = [SmallBannerImageCell getBannerCellRowHeight:items.count];
        if(imgWidth.floatValue > 0)
        {
            portion = imgHeight.floatValue / imgWidth.floatValue;
            
            cellHeight = (SCREEN_WIDTH - 30) * portion + 15;
            
            cell.scrollView.frame = CGRectMake(0, 0, SCREEN_WIDTH - 30, cellHeight - 15);
        }
        
        cell.items = items;
        
        cell.selectItemBlock = ^(NSInteger index , NSArray * _Nullable items) {
            
            
            if (items.count == 0) {
                return;
            }
            
            NSDictionary * dic = items[index];
            
            NSString * goURL;
            
            NSNumber * jumpType = dic[JUMP_TYPE];
            
            if(jumpType.integerValue == 3)
            {
                NSDictionary * shopSet = dic[SHOP_SET];
                
                goURL = [Utils dictionaryToJson:shopSet];
            }else{
                goURL = dic[HREF_URL];
            }
            
            if([goURL isKindOfClass:[NSString class]] && [goURL isEqualToString:CLASSIFY])
            {
                [SharedInstance getInstance].currentClassifyID = dic[CLASSIFY_ID];
            }
            
            NSNumber * blackWhiteId = dic[BLACK_WHITE_ID];
            
            NSArray * blackWhiteList = dic[WHITE_IDS];
            
            [SharedInstance getInstance].sendBlackWhiteList = blackWhiteList;
            
            
            [self gotoWithTargetURL:goURL jumpType:jumpType blackWhiteId:blackWhiteId];
            
        };
        
        [cell updateTableViewCellWithData:items];
        
        return cell;
    }else if([type isEqualToString:TOPIC])
    {
        
        NSString * topicLayout = dic[TOPIC_LAYOUT];
        
        HomeThreeImageCell * cell = [tableView dequeueReusableCellWithIdentifier:@"HomeThreeImageCell"];
        
        if(!cell)
        {
            cell = (HomeThreeImageCell*)[Utils getXibByName:@"HomeThreeImageCell"];
        }
        
        NSArray * topicList = dic[TOPIC_LIST];
        
        NSArray * imageViews = @[cell.oneImageView,cell.towImageView,cell.threeImageView];
        
        for(NSInteger i = 0;i < topicList.count;i++ )
        {
            UIImageView * imageView = imageViews[i];
            NSDictionary * dic = topicList[i];
            NSString * imageURL = dic[IMG_URL];
            
            [Utils loadImage:imageView andURL:imageURL isLoadRepeat:false];
            
        }
        
        cell.dataList = topicList;
        WS(weakSelf);
        cell.tapThreeImageHandler = ^(NSInteger index, NSString *url, NSNumber *jumpType ,  NSNumber * blackWhiteId) {
            [weakSelf gotoWithTargetURL:url jumpType:jumpType blackWhiteId:blackWhiteId];
        };
        
        NSNumber* width = dic[WIDTH];
        NSNumber* height = dic[HEIGHT];
        NSString * bgColor = dic[BG_IMAGE];
        
        NSString* titleImgURL = dic[TITLE_IMG_URL];
        
        if(bgColor)
        {
            cell.contentView.backgroundColor = [UIColor colorWithHexString:bgColor];
        }
        
        if(titleImgURL.length > 0)
        {
            [Utils loadImage:cell.titleImage andURL:titleImgURL isLoadRepeat:false];
            
            CGFloat titleHeight;
            
            if(!width && !height)
            {
                titleHeight = 0;
            }else{
                titleHeight = height.floatValue / width.floatValue * (SCREEN_WIDTH - 30);
            }
            [cell setThreeImageLayoutWithTopicLayout:topicLayout titleHeight:titleHeight];
            
        }else{
            [cell setThreeImageLayoutWithTopicLayout:topicLayout titleHeight:0];
        }
        
        return cell;

    }else if([type isEqualToString:BANNER])
    {
        NSArray * items = dic[BANNER_LIST];

        BannerImageCell * cell = [tableView dequeueReusableCellWithIdentifier:@"BannerImageCell"];
        
        if(!cell)
        {
            cell = (BannerImageCell*)[Utils getXibByName:@"BannerImageCell"];
        }
    
        NSNumber * width = items.firstObject[WIDTH];
        NSNumber * height = items.firstObject[HEIGHT];
        
        if(!width) width = @2;
        if(!height) height = @1;
        cell.selectItemBlock = ^(NSInteger index , NSArray * _Nullable items) {
            
            if (items.count == 0) {
                return;
            }
            NSDictionary * dic = items[index];
            
            NSString * goURL;
            
            NSNumber * jumpType = dic[JUMP_TYPE];
            
            if(jumpType.integerValue == 3)
            {
                NSDictionary * shopSet = dic[SHOP_SET];
                
                goURL = [Utils dictionaryToJson:shopSet];
            }else{
                goURL = dic[HREF_URL];
            }
            
            NSNumber * blackWhiteId = dic[BLACK_WHITE_ID];
            
            NSArray * blackWhiteList = dic[WHITE_IDS];
            
            [SharedInstance getInstance].sendBlackWhiteList = blackWhiteList;
            
            if([goURL isKindOfClass:[NSString class]] && [goURL isEqualToString:CLASSIFY])
            {
                [SharedInstance getInstance].currentClassifyID = dic[CLASSIFY_ID];
            }
        
            [self gotoWithTargetURL:goURL jumpType:jumpType blackWhiteId:blackWhiteId];
            
        };
        
        [cell updateTableViewCellWithData:items radio:height.floatValue / width.floatValue];
        
        return cell;
    }else if([type isEqualToString:MAGIC_CUBE])
    {
        SectionCell * cell = [tableView dequeueReusableCellWithIdentifier:@"SectionCell"];
        
        if(!cell)
        {
            cell = (SectionCell*)[Utils getXibByName:@"SectionCell"];
        }
        
        NSArray * items = dic[LIST_DATA];
        NSString * col = dic[LAYOUT];
        NSString * titleImgURL = dic[TITLE_IMG_URL];
        cell.col = col.integerValue + 1;
        
        NSNumber * elementWidth = items.firstObject[WIDTH];
        NSNumber * elementHeight = items.firstObject[HEIGHT];
        CGFloat radio = elementHeight.floatValue / elementWidth.floatValue;
        NSNumber * width = dic[WIDTH];
        NSNumber * height = dic[HEIGHT];
        
        if(!width) width = @1;
        if(!height) height = @1;
        
        CGFloat titleRadio = height.floatValue / width.floatValue;
        
        CGFloat titleHeight = (SCREEN_WIDTH - 30) * titleRadio;
        
        if(titleImgURL.length > 0)
        {
            cell.titleBgImageView.hidden = false;
            [Utils loadImage:cell.titleBgImageView andURL:titleImgURL isLoadRepeat:false];
        }else{
            cell.titleBgImageView.hidden = true;
            titleHeight = 0;
        }
        
        [cell setCellData:items radio:radio titleHeight:titleHeight];
        WS(weakSelf);
        cell.tapSectionHandlerWithIndex = ^(NSInteger index, NSString * _Nullable goURL, NSNumber * _Nonnull jumpType , NSNumber * _Nullable blackWhiteId) {
            
            
            [weakSelf gotoWithTargetURL:goURL jumpType:jumpType blackWhiteId:blackWhiteId];
        };
        
        return cell;
    }else if([type isEqualToString:GOODS_ZONE])
    {
        GoodsZoneCell * cell = [tableView dequeueReusableCellWithIdentifier:@"GoodsZoneCell"];
        
        if(!cell)
        {
            cell = (GoodsZoneCell*)[Utils getXibByName:@"GoodsZoneCell"];
        }
        NSNumber * width = dic[WIDTH];
        NSNumber * height = dic[HEIGHT];
        if(!width) width = @1;
        if(!height) height = @1;
        NSString * bgImage = dic[BG_IMAGE];
        NSString * zoneId = dic[ZONE_ID];
        NSString * selectionCodes = dic[SELECTION_CODES];
        NSNumber * pageSize = dic[PAGE_SIZ];
        NSNumber * isShowMore = dic[IS_SHOW_MORE];
        NSString * isCountDown = dic[IS_COUNT_DOWN];
        
        CGFloat radio = height.floatValue / width.floatValue;
        
        CGFloat cellHeight = (SCREEN_WIDTH - 30) * radio + 15;
        
        cell.cellHeight = cellHeight;
        cell.zoneId = zoneId;
        cell.selectionCodes = selectionCodes;
        cell.bgImgURL = bgImage;
        cell.pageSize = pageSize;
        cell.isShowCountDown = [NSNumber numberWithInteger:isCountDown.integerValue];
        cell.isShowMore = isShowMore;
        [cell refreshHandler];
        
        WS(weakSelf);
        cell.tapGoodsZoneWithIndexHandler = ^(NSInteger index, NSString * _Nullable goURL, NSNumber * _Nonnull jumpType) {
            [weakSelf gotoWithTargetURL:goURL jumpType:jumpType blackWhiteId:@0];
        };
        
        return cell;
    }else if([type isEqualToString:COUPON])
    {
        SectionCell * cell = [tableView dequeueReusableCellWithIdentifier:@"SectionCell"];
        
        if(!cell)
        {
            cell = (SectionCell*)[Utils getXibByName:@"SectionCell"];
        }
        
        NSArray * items = dic[COUPON_LIST];
        NSString * col = dic[LAYOUT];
        if(!col) col = @"1";
        NSString * titleImgURL = dic[TITLE_IMG];
        NSNumber * activityID = dic[COUPON_ACTIVITY_ID];
        cell.activityID = activityID;
        cell.col = col.integerValue;
        
        if([Utils checkObjectIsNull:items] == false) items = @[];
        
        NSNumber * elementWidth = items.firstObject[NO_RECEIVE_WIDTH];
        NSNumber * elementHeight = items.firstObject[NO_RECEIVE_HEIGHT];
        
        if(!elementWidth) elementWidth = @1;
        if(!elementHeight) elementHeight = @1;
        CGFloat radio = elementHeight.floatValue / elementWidth.floatValue;
        NSNumber * width = dic[WIDTH];
        NSNumber * height = dic[HEIGHT];
        
        if(!width) width = @1;
        if(!height) height = @1;
        
        CGFloat titleRadio = height.floatValue / width.floatValue;
        
        CGFloat titleHeight = (SCREEN_WIDTH - 30) * titleRadio;
        
        if(titleImgURL.length > 0)
        {
            cell.titleBgImageView.hidden = false;
        }else{
            cell.titleBgImageView.hidden = true;
            titleHeight = 0;
        }
        
        cell.isCoupon = true;
        
        [Utils loadImage:cell.titleBgImageView andURL:titleImgURL isLoadRepeat:false];
        
        [cell setCellData:items radio:radio titleHeight:titleHeight];
    
        return cell;
    }else if([type isEqualToString:ADVERTISE_RAMDOM]){
        
        BannerImageCell * cell = [tableView dequeueReusableCellWithIdentifier:@"BannerImageCell"];
        if(!cell)
        {
            cell = (BannerImageCell*)[Utils getXibByName:@"BannerImageCell"];
        }
        cell.isRand = dic[IS_RANDOM];
        cell.showNum = dic[RANDOM_NUM];
        cell.selectItemBlock = ^(NSInteger index , NSArray * _Nullable items) {
            
            if (items.count == 0) {
                return;
            }
            
            NSDictionary * dic = items[index];
            NSString * goURL = dic[URL];
            NSNumber * jumpType = dic[URL_TYPE];
            NSNumber * blackWhiteId = dic[BLACK_WHITE_ID];
            NSArray * blackWhiteList = dic[WHITE_IDS];
            
            [SharedInstance getInstance].sendBlackWhiteList = blackWhiteList;
            
            if([goURL isKindOfClass:[NSString class]] && [goURL isEqualToString:CLASSIFY])
            {
                [SharedInstance getInstance].currentClassifyID = dic[CLASSIFY_ID];
            }
            
            [self gotoWithTargetURL:goURL jumpType:jumpType blackWhiteId:blackWhiteId];
            
        };
        
        cell.reloadMainTableView = ^{
            
            if(self.pageListView)
            {
                [self.pageListView.mainTableView reloadData];
            }else if(self.listTableView)
            {
                [self.listTableView reloadData];
            }
            
        };
        
        NSArray * items = dic[ADVERTISING_ID_LIST];
        
        id firstObject = items.firstObject;
        
        if([firstObject isKindOfClass:[NSNumber class]])
        {
            [cell updateTableViewCellWithData:dic];
        }else{
            NSNumber * width = firstObject[WIDTH];
            NSNumber * height = firstObject[HEIGHT];
            
            if(!width || width.integerValue == 0) width = @2;
            if(!height || height.integerValue == 0) height = @1;
            
            [cell updateTableViewCellWithData:items radio:height.floatValue / width.floatValue];
        }
        return cell;
    }else if([type isEqualToString:MERCHANT])
    {
        HomeMerchantListCell * cell = [tableView dequeueReusableCellWithIdentifier:@"HomeMerchantListCell"];
        
        if(!cell)
        {
            cell = (HomeMerchantListCell*)[Utils getXibByName:@"HomeMerchantListCell"];
        }
        
        NSNumber * maxNum = dic[MAX_NUMBER];
        NSNumber * blackWhiteId = dic[MERCHANT_WHITE_LIST];
        NSArray * blackWhiteIdList = dic[BLACK_WHITE_ID_LIST];
        NSArray * blackWhiteList = dic[WHITE_IDS];
        
        [SharedInstance getInstance].sendBlackWhiteList = blackWhiteList;
        
        [cell setMerchantListWithListCount:maxNum.integerValue blackWhiteId:blackWhiteId blackWhiteIdList:blackWhiteIdList];
        WS(weakSelf);
        cell.tapHomeMerchantListMerchantId = ^(NSNumber * _Nullable merchantId , NSNumber * _Nullable distance , NSNumber * lat , NSNumber * lng , NSString * cityName) {
            [weakSelf gotoMerchantDetailHandlerWithMerchantId:merchantId distance:distance lat:lat lng:lng cityName:cityName];
        };
        cell.tapHomeAllMerchantListHandler = ^(NSNumber * _Nullable blackWhiteId) {
            [weakSelf gotoAllMerchantListHandler:blackWhiteId];
        };
        
        return cell;
    }else if([type isEqualToString:NUMBER_EQUITIES])
    {
        NumberEquitiesCell * cell = [tableView dequeueReusableCellWithIdentifier:@"NumberEquitiesCell"];
        
        if(!cell)
        {
            cell = (NumberEquitiesCell*)[Utils getXibByName:@"NumberEquitiesCell"];
        }
        NSNumber * col = dic[LAYOUT];
        
        NSString * titleImgURL = dic[IMAGE];
        NSString * selectionCodes = dic[SELECTION_CODES];
        NSNumber * pageSize = dic[PAGE_SIZ];
        cell.pageSize = pageSize;
        CGFloat radio;
        if(col.integerValue == 1)
        {
            radio = 95.0f / 375.0f;
        }else{
            radio = 235.0f / 182.0f;
        }
        
        NSNumber * width = @(345.0f);
        NSNumber * height = @(40.0f);
        
        CGFloat titleRadio = height.floatValue / width.floatValue;
        CGFloat titleHeight = (SCREEN_WIDTH - 30) * titleRadio;
        
        if(titleImgURL.length > 0)
        {
            [Utils loadImage:cell.titleBgImageView andURL:titleImgURL isLoadRepeat:false];
        }
        cell.col = col.integerValue;
        
        cell.selectionCodes = selectionCodes;
        
        [cell radio:radio titleHeight:titleHeight];
        WS(weakSelf);
        
        cell.tapNumberEquitiesWithIndex = ^(NSInteger index, NSString * _Nullable goURL, NSNumber * _Nonnull jumpType, NSNumber * _Nullable blackWhiteId) {
            [weakSelf gotoWithTargetURL:goURL jumpType:jumpType blackWhiteId:blackWhiteId];
        };
        
        cell.index = indexPath.row;
        
        cell.refreshNumberEquitiesCellWithRow = ^(NSInteger row , NSInteger index) {
            
            NSNumber * currentRow = weakSelf.numberEquitiesRow[[NSString stringWithFormat:@"%ld",index]];
            
            //当没取出当前保存的条数执行，一但取出条数将不会执行
            if(currentRow == nil)
            {
                [weakSelf.numberEquitiesRow setObject:@(row) forKey:[NSString stringWithFormat:@"%ld",index]];
                
                if(weakSelf.isNormalList)
                {
                    [weakSelf.listTableView reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:index inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
                }else{
                    [weakSelf.pageListView.mainTableView reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:index inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
                }
            }
        };
        
        return cell;
    }
        
    return [UITableViewCell new];
}

- (void)gotoMerchantMapHandler:(NSNumber*)blackWhiteId{
    MerchantMapViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_MERCHAT andIdentifier:@"MerchantMapViewController"];
   
    vc.blackWhiteId = blackWhiteId;
    [self.navigationController pushViewController:vc animated:true];
}

- (void)gotoAllMerchantListHandler:(NSNumber*)blackWhiteId{
    self.blackWhiteId = blackWhiteId;
    MerchantListViewController * listVC = [[MerchantListViewController alloc] init];
    listVC.blackWhiteId = blackWhiteId;
    
    [self.navigationController pushViewController:listVC animated:true];
}


- (void)gotoAllMerchantListWithBlackWhiteIdList:(NSArray*)blackWhiteIdList title:(NSString*)title
{
    self.blackWhiteIdList = blackWhiteIdList;
    MerchantListViewController * listVC = [[MerchantListViewController alloc] init];
    listVC.blackWhiteIdList = blackWhiteIdList;
    listVC.showTitle = title;
    [self.navigationController pushViewController:listVC animated:true];
}
- (void)gotoMerchantDetailHandlerWithMerchantId:(NSNumber*)merchantId distance:(NSNumber*)distance lat:(NSNumber*)lat lng:(NSNumber*)lng cityName:(NSString*)cityName
{
    MerchantDetailViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_MERCHAT andIdentifier:@"MerchantDetailViewController"];
    
    vc.merchantId = merchantId;
    vc.items = @[];
    vc.distance = distance;
    vc.cityName = cityName;
    vc.lat = lat;
    vc.lng = lng;
    vc.blackWhiteId = self.blackWhiteId;
    
    [self.navigationController pushViewController:vc animated:true];
}

//我的权益

- (void)gotoEquityVCHandler
{
    //权益界面;
    UIViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_ME andIdentifier:@"EquityViewController"];
    
    [self.navigationController pushViewController:vc animated:true];
}

//绑定福利券;
- (void)gotoBindCardHandler
{
    UIViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_ME andIdentifier:@"BindingWelfareCouponViewController"];
    
    [self.navigationController pushViewController:vc animated:true];
}
//点击逻辑主要处理方法
- (void)gotoWithTargetURL:(NSString*)target jumpType:(NSNumber*)jumpType blackWhiteId:(NSNumber*)blackWhiteId
{
    if(jumpType.integerValue == 0 && [Utils checkLoginAndGotoLogin:self] == false && [target isEqualToString:CLASSIFY] == false)
    {
        return;
    }
    
    if(jumpType.integerValue == 3)
    {
        NSDictionary * shopSet = [Utils dictionaryWithJsonString:target];
        
        NSString * selectionType = shopSet[SELECTION_TYPE];
        
        if([selectionType isEqualToString:@"SERVER"] && [Utils checkLoginAndGotoLogin:self] == false)
        {
            return;
        }
    }
    
    if(jumpType.integerValue == 0)
    {
        if([target isEqualToString:@"homePage"])
        {
            
            [[NSNotificationCenter defaultCenter] postNotificationName:EVENT_SELECT_TABBAR_WITH_INDEX object:nil userInfo:@{PAGE_INDEX:@0}];
        }else if([target isEqualToString:@"personCenter"])
        {
            [[NSNotificationCenter defaultCenter] postNotificationName:EVENT_SELECT_TABBAR_WITH_INDEX object:nil userInfo:@{PAGE_INDEX:@1}];
            
        }else if([target isEqualToString:@"codePay"])
        {
    //        //主扫
            [self gotoScanCodeHandler];
        }else if([target isEqualToString:@"account"]){
            
            UIViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_ME andIdentifier:@"AccountDetailViewController"];
            [self.navigationController pushViewController:vc animated:true];
            
        }else if([target isEqualToString:@"accountRecord"]){
            
            UIViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_ME andIdentifier:@"BillListViewController"];
            [self.navigationController pushViewController:vc animated:true];
            
        }else if([target isEqualToString:@"CustomerCare"]){
            [self showConnectCustomerHandler];
        }else if([target isEqualToString:@"subHome"]){
            
           
        }else if([target isEqualToString:@"myOrder"]){
            UIViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_ME andIdentifier:@"BillListViewController"];
            [self.navigationController pushViewController:vc animated:true];
        }else if([target isEqualToString:@"changeCompany"]){
            UIViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_SETTING andIdentifier:@"SwitchCompanyViewController"];
            
            [self.navigationController pushViewController:vc animated:true];
        }else if([target isEqualToString:CLASSIFY])
        {
            UIViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_SORT andIdentifier:@"SortViewController"];
            
            [self.navigationController pushViewController:vc animated:true];
        }else if([target isEqualToString:MERCHANT_LIST])
        {
            [self gotoAllMerchantListHandler:blackWhiteId];
        }else if([target isEqualToString:MERCHANT_MAP])
        {
            [self gotoMerchantMapHandler:blackWhiteId];
        }else if([target isEqualToString:MY_EQUITY])
        {
            [self gotoEquityVCHandler];
        }else if([target isEqualToString:BIND_CARD])
        {
            [self gotoBindCardHandler];
        }
            
    }else if(jumpType.integerValue == 1)
    {
        
        WS(weakSelf);
        [self.homeVM getHomePageIsMerchantPageId:target back:^(BOOL isMerchantPage, NSString *merchantTitle, NSArray *whiteIds) {
            if(!isMerchantPage)
            {
                WPHomeVC * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_HOME andIdentifier:@"WPHomeVC"];
                vc.homePageID = target;
                [weakSelf.navigationController pushViewController:vc animated:true];
            }else{
                [weakSelf gotoAllMerchantListWithBlackWhiteIdList:whiteIds title:merchantTitle];
            }
        }];
        
        
    }else if(jumpType.integerValue == 2){
        //网页;
        if([target hasPrefix:@"tel://"])
        {
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:target] options:@{} completionHandler:nil];
        }else if([target hasPrefix:@"mp://"]){
            
            
            NSString * miniValue = [target substringFromIndex:5];
            NSArray * miniSeparate = [miniValue componentsSeparatedByString:@"/"];
            
            NSString * appId = miniSeparate.firstObject;
            
            NSString * path = [miniValue substringFromIndex:appId.length + 1];
            
            WXMiniProgramType type;
            
            if([Utils getProduction])
            {
                type = WXMiniProgramTypeRelease;
            }else{
                type = WXMiniProgramTypePreview;
            }
            
            [[SharedInstance getInstance] wechantMiniProgramPath:path userName:appId miniProgramType:type];
        }else{
            [Utils pushWebViewControllerURL:target owner:self];
        }
        
    }else if(jumpType.integerValue == 3)
    {
        
        NSDictionary * shopSet = [Utils dictionaryWithJsonString:target];
        
        NSString * h5URL = shopSet[H5_URL];
        
        NSString * title = shopSet[TITLE];
        
        if(title && [Utils validateContainsChinese:title])
        {
            title = [title stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
        }
        
        NSString * selectionType = shopSet[SELECTION_TYPE];
        
        NSString * selectionCods = shopSet[SELECTION_CODES];
        
        if([Utils checkObjectIsNull:h5URL] && h5URL.length > 0)
        {
            NSString * goURL;
            if(title)
            {
                if([h5URL containsString:@"?"])
                {
                    goURL = [NSString stringWithFormat:@"%@&title=%@",h5URL,title];
                }else{
                    goURL = [NSString stringWithFormat:@"%@?title=%@",h5URL,title];
                }
            }else{
                goURL = h5URL;
            }
            
            [Utils pushWebViewControllerURL:goURL owner:self];
            
        }else {
            [ServiceManager getHomeH5URLWithRedirectType:@"home" homePageDTO:@{SELECTION_CODE:selectionCods,TAG:selectionType} success:^(NSDictionary *data) {
                
                NSString * h5URL = data[DATA];
                
                NSString * goURL;
                
                if(title)
                {
                    if([h5URL containsString:@"?"])
                    {
                        goURL = [NSString stringWithFormat:@"%@&title=%@",h5URL,title];
                    }else{
                        goURL = [NSString stringWithFormat:@"%@?title=%@",h5URL,title];
                    }
                }else{
                    goURL = h5URL;
                }
                
                [Utils pushWebViewControllerURL:goURL owner:self];
                
            }];
        }
        
    }
}

- (void)showConnectCustomerHandler
{
    //联系客服
    [Utils setDefaultNavigationBar:self];
    [IQKeyboardManager sharedManager].enable = false;
    [Utils setQiYuInfo];
    
    QYSource *source = [[QYSource alloc] init];
    
    
    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
    NSString *app_Version = [infoDictionary objectForKey:@"CFBundleShortVersionString"];
    NSString * sendTitle = [NSString stringWithFormat:@"设备:iOS;应用名称:蜀光惠;版本号:%@;%@",app_Version,@"蜀光惠-首页"];
    source.title = sendTitle;
    source.urlString = @"";
    QYSessionViewController *sessionViewController = [[QYSDK sharedSDK] sessionViewController];
    sessionViewController.robotWelcomeTemplateId = 6655338;
    sessionViewController.robotId = 5401983;
//    sessionViewController.groupId = 1070381;
    sessionViewController.openRobotInShuntMode = NO;
    sessionViewController.commonQuestionTemplateId = 4494027;
    sessionViewController.sessionTitle = @"蜀光惠客服";
    sessionViewController.source = source;
    dispatch_async(dispatch_get_main_queue(), ^{
        
        [self.navigationController pushViewController:sessionViewController animated:true];
    });
    
    UIBarButtonItem * leftBackButton = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"ic_title_back"] style:UIBarButtonItemStylePlain target:self action:@selector(onBack:)];
    leftBackButton.tintColor = [UIColor blackColor];
    sessionViewController.navigationItem.leftBarButtonItem = leftBackButton;
}

- (void)onBack:(id)sender{

    [IQKeyboardManager sharedManager].enable = true;
    [self.navigationController popViewControllerAnimated:true];
}

/**
 动态计算高度
 @param tableView 当前tableview
 @param indexPath 当前行数
 @return 行高
 */
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    if(self.isNormalList == false)
    {
        if (indexPath.section == self.homeVM.homeListData.count - 1) {
            //Tips:最后一个section（即listContainerCell所在的section）返回listContainerCell的高度
            CGFloat defaultHeight = [self.pageListView listContainerCellHeight];
            
            return defaultHeight;
        }
    }

    NSDictionary *dic  = self.homeVM.homeListData[indexPath.section][indexPath.row];
    NSString * type = dic[TYPE];
    
    CGFloat height = [self.homeVM getTableViewCellHeightWithDic:dic type:type numberEquitiesRow:self.numberEquitiesRow indexPath:indexPath];
    
    return height;
}

#pragma mark - JXPageViewDelegate
//Tips:实现代理方法
- (NSArray<UIView<JXPageListViewListDelegate> *> *)listViewsInPageListView:(JXPageListView *)pageListView {
    return self.listViewArray;
}

- (void)pinCategoryView:(JXCategoryBaseView *)pinCategoryView didSelectedItemAtIndex:(NSInteger)index {
    self.navigationController.interactivePopGestureRecognizer.enabled = (index == 0);
}

- (void)gotoScanCodeHandler
{
    if([SharedInstance getInstance].payPasswordEmpty ==  0)
    {
        WPPaymentPasswordVC *vc = (WPPaymentPasswordVC *)[Utils getViewControllerByStoryBoardName:SB_NAME_ME andIdentifier:SB_ID_PAY_MENT_PASS_WORD];
        vc.ppType = WPPaymentPasswordTypeInitPassword;
        vc.enterType = @1;
        vc.delegate = self;
        [self.navigationController pushViewController:vc animated:YES];
        
        return;
    }
    
    [self scanCodeVCPush];
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    //Tips:需要传入mainTableView的scrollViewDidScroll事件
    if(self.isNormalList == false)
    {
        [self.pageListView mainTableViewDidScroll:scrollView];
    }
    
}

#pragma -StyleModeClick

-(void)pushWebUrl:(NSString *)url{
    [Utils pushWebViewControllerURL:url owner:self];
}

#pragma mark - WPPaymentPasswordVCDelegate

-(void)paymentPasswordVerifypwd:(NSString *)pwd{
    
    [self scanCodeVCPush];
}

#pragma mark - other methods

- (BOOL)isLogin{
    if ([[SharedInstance getInstance].userInfo.sid length] == 0) {
        
        [[SharedInstance getInstance] checkLoginAndGotoLogin:self];
        
        return NO;
    }
    return YES;
}
/**
 初始化界面UI
 */
- (void)setAppearance{
    //添加消息
    UIButton *rightItemButton = [UIButton buttonWithType:UIButtonTypeCustom];
    rightItemButton.frame = CGRectMake(0, 0, 34, 20);
    rightItemButton.titleLabel.font = [UIFont fontWithName:[Utils getGlobalFontName] size:14];
    [rightItemButton setImage:[UIImage imageNamed:@"home_icon_message"] forState:UIControlStateNormal];
    [rightItemButton addTarget:self action:@selector(messageHandler:) forControlEvents:UIControlEventTouchUpInside];
    self.rightItem = [[UIBarButtonItem alloc]initWithCustomView:rightItemButton];
    [self.navigationItem setRightBarButtonItem:self.rightItem];
}

//隐私协议
- (void)alertPriateUrlWebView{
    NSNumber * argeePrivacy = [Utils getUserDefaultByKey:@"agreePrivate"];
    if(argeePrivacy == nil || argeePrivacy.integerValue == 0){
        NSArray *objs = [[NSBundle mainBundle]loadNibNamed:@"PrivacyPopView" owner:nil options:nil];
        UIView *xibView = objs.firstObject;
        PrivacyPopView * popView = (PrivacyPopView*)xibView;
        popView.agreeAction = ^{
        };
        [[Utils currentWindow] addSubview:popView];
        [popView fadeIn];
    }
}


- (void)messageHandler:(UIButton*)sender{
    
    if (![self isLogin]) {
        return;
    }
    
    [ServiceManager getMessageCount:^(NSDictionary *data) {
        
        NSArray * results = data[DATA];
        MessageViewController * messageVC = (MessageViewController*)[Utils getViewControllerByStoryBoardName:SB_NAME_MESSAGE andIdentifier:SB_ID_MESSAGE];
        if([Utils checkObjectIsNull:results] == true)
        {
            messageVC.messageDataSource = [results mutableCopy];
        }else{
            messageVC.messageDataSource = [NSMutableArray array];
        }
        [self.navigationController pushViewController:messageVC animated:true];
        
    } isShowLoading:true];
}



-(void)paymentPasswordTypeVerifyPasswordNotification:(NSNotification *)noti{
    __weak WPHomeVC *weakSelf = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [weakSelf scanCodeVCPush];
    });
}

-(void)scanCodeVCPush{
    
    [SharedInstance getInstance].userSetScreenBrightness = [[UIScreen mainScreen] brightness];
    
    ScanCodeViewController * vc = [Utils getViewControllerByStoryBoardName:SCAN_CODE andIdentifier:SB_ID_SCAN_CODE_VC];
   
    vc.isPresent = true;
    WPNavigationController *navVC = [[WPNavigationController alloc]initWithRootViewController:vc];

    [self presentViewController:navVC animated:true completion:nil];
}

#pragma mark - setter
-(WPHomeVM *)homeVM{
    if (!_homeVM) {
        _homeVM = [[WPHomeVM alloc]init];
        
        
        if(self.homePageID)
        {
            _homeVM.homePageID = self.homePageID;
            
        }
        
    }
    return _homeVM;
}

-(QuickRefresh *)refresh{
    if (!_refresh) {
        _refresh = [[QuickRefresh alloc]init];
    }
    return _refresh;
}

-(ShowViewModel *)showViewModel{
    if (!_showViewModel) {
        _showViewModel = [[ShowViewModel alloc]init];
    }
    return _showViewModel;
}

- (HomeTitleSearchView *)titleView
{
    if(!_titleView)
    {
        _titleView = (HomeTitleSearchView*)[Utils getXibByName:@"HomeTitleSearchView"];
    }
    
    return _titleView;
}
@end
