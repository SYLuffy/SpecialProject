//
//  WaterFallCell.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/7/31.
//

#import "WaterFallViewPage.h"

#import "MerchandiseCollectionViewCell.h"
#import <XRWaterfallLayout.h>
#import <MJRefresh.h>
#import <TABAnimated.h>

#define CELL_LABEL_GAP_HEIGHT 50

NSString *ColloctionViewCell = @"MerchandiseCollectionViewCell";

@interface WaterFallViewPage()<UICollectionViewDelegate,UICollectionViewDataSource>

@property (nonatomic,strong)NSMutableArray <UICollectionView*>* collectionViews;
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (nonatomic, copy) void(^scrollCallback)(UIScrollView *scrollView);

@property (nonatomic,strong)NSArray * dataSource;
@property (nonatomic,assign)NSInteger selectCount;
@property (nonatomic,assign)NSInteger col;
@property (nonatomic,assign)NSInteger page;
@property (nonatomic,strong)NSString * zoneId;
@property (nonatomic,strong)NSString * selectionCodes;

@end

@implementation WaterFallViewPage

- (void)awakeFromNib {
    [super awakeFromNib];
    self.collectionView.userInteractionEnabled = YES;
    
    [self.collectionView registerNib:[UINib nibWithNibName:ColloctionViewCell bundle:[NSBundle mainBundle]] forCellWithReuseIdentifier:ColloctionViewCell];
    self.collectionView.delegate = self;
    self.collectionView.dataSource = self;
    self.collectionView.scrollEnabled = true;
    
    self.collectionView.tabAnimated = [TABCollectionAnimated animatedWithCellClass:[MerchandiseCollectionViewCell class] cellSize:CGSizeMake(1, 1)];
    
    WS(weakSelf);
    
    self.collectionView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        weakSelf.page += 1;
        [weakSelf refreshHandler];
    }];
    
}

- (void)drawRect:(CGRect)rect
{
    [super drawRect:rect];
    
    
    
    [self refreshHandler];
}

- (void)updateWithDataDic:(NSDictionary*)dataDic
{
    self.dataDic = dataDic;
    
    self.zoneId = self.dataDic[ZONE_ID];
    self.selectionCodes = self.dataDic[SELECTION_CODES];
    
    NSString * plateType = self.dataDic[PLATE_TYPE];
    if(plateType.integerValue == 0)
    {
        self.col = 2;
    }
    
    XRWaterfallLayout *layout = [XRWaterfallLayout waterFallLayoutWithColumnCount:self.col];

    layout.itemHeightBlock = ^CGFloat(CGFloat itemHeight, NSIndexPath *indexPath) {
        
        CGFloat cellWidth = (SCREEN_WIDTH - 15) / self.col;
        //CGFloat radio = height.floatValue / width.floatValue;
        
        CGFloat nameHeight = 40;
        
        CGFloat cellHeight = nameHeight + (cellWidth - 10) + CELL_LABEL_GAP_HEIGHT;
        return cellHeight;
    };
    
    self.collectionView.collectionViewLayout = layout;
    
}

- (void)refreshHandler
{
    NSLog(@"刷新了页面%ld",self.index);
    
    
    
    if(self.zoneId == nil && self.selectionCodes == nil)
    {
        self.dataSource = @[];
        
        [self.collectionView.mj_footer setHidden:YES];
        
        self.noDataView.hidden = false;
        
        [self.collectionView reloadData];
        
        
        return;
    }
    [self.collectionView tab_startAnimation];
    [ServiceManager getMerchandiseWithPageNum:@(self.page + 1) pageSize:@(20) keyword:nil zoneId:self.zoneId selectionCodes:self.selectionCodes success:^(NSDictionary *data) {

        NSArray * records = data[RECORDS];
        
        if(self.page == 0)
        {
            
            self.dataSource = records;
        }else{
            self.dataSource = [self.dataSource arrayByAddingObjectsFromArray:records];
        }
        
        
        
        [self.collectionView reloadData];

        [self.collectionView tab_endAnimation];
        
        [self.collectionView.mj_footer endRefreshing];
        
        if(records.count < 20)
        {
            if(self.collectionView.mj_footer)
            {
                [self.collectionView.mj_footer resetNoMoreData];
            }
            
            
            [self.collectionView.mj_footer setHidden:YES];
        }else{
            [self.collectionView.mj_footer setHidden:false];
        }
        
        if(self.dataSource.count == 0)
        {
           
            [self.collectionView tab_stopPullLoadingNoMoreData];
            
            [self.collectionView reloadData];
            
            self.noDataView.hidden = false;
        }else{
            self.noDataView.hidden = true;
        }
    } failure:^(NSError *error) {
        [self.collectionView tab_endAnimation];
        
        [self.collectionView tab_stopPullLoadingNoMoreData];
        
        [self.collectionView reloadData];
        
        [self.collectionView.mj_footer setHidden:YES];
        
        self.noDataView.hidden = false;
    }];
}

#pragma mark -- UICollectionViewDataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section;
{
    return self.dataSource.count;
}


- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    MerchandiseCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:ColloctionViewCell forIndexPath:indexPath];
    if (!cell) {
        cell = [MerchandiseCollectionViewCell xibTableViewCell];
    }
    
    NSDictionary *data = self.dataSource[indexPath.row];
    
    NSString * imageURL = data[MAIN_IMAGE];
    NSString * name = data[NAME];
    NSString * amount = data[MARKET_PRICE];
    
    
    NSString * saleAmount = data[SALE_PRICE];
    
    
    if([Utils checkObjectIsNull:name])
    {
        cell.merchandiseNameLabel.text = name;
    }
    
    
    NSString * amountTempStr;
    
    NSString * uint = [SharedInstance getInstance].uint;
    
    if([Utils checkObjectIsNull:saleAmount])
    {
        NSString * showText = [NSString stringWithFormat:@"%.2lf",saleAmount.integerValue * 0.01f];
        
        
        if(uint && uint.length > 0)
        {
            amountTempStr = [NSString stringWithFormat:@"%@%@",showText,uint];
        }else{
            amountTempStr = showText;
        }
    }else{
        cell.merchandiseAmountLabel.text = @"未知价格，需查询服务器";
        
        amountTempStr =  @"未知价格，需查询服务器";
    }
    
    NSString * historyAmountTempStr;
    
    if([Utils checkObjectIsNull:amount])
    {
        NSString * showText = [NSString stringWithFormat:@"%.2lf",amount.integerValue * 0.01f];
        
        if(uint && uint.length > 0)
        {
            historyAmountTempStr = [NSString stringWithFormat:@"%@%@",showText,uint];
        }else{
            historyAmountTempStr = showText;
        }
    }else{
        cell.merchandiseHistoryAmountLabel.text = @"未知价格，需查询服务器";
        
        historyAmountTempStr = @"未知价格，需查询服务器";
    }
    NSString * showStr = [NSString stringWithFormat:@"%@%@",amountTempStr,historyAmountTempStr];
    
    cell.merchandiseAmountLabel.text = showStr;
    
    [Utils labelColorAttributedStripingString:cell.merchandiseAmountLabel andRange:NSMakeRange(amountTempStr.length, historyAmountTempStr.length) color:UIColorFromRGB(0x999999) size:12];
    
    
    cell.merchandiseHistoryAmountLabel.text = @"";
   
    
//      NSLog(@"%@",imageURL);
    if([Utils checkObjectIsNull:imageURL])
    {
        
        NSString * imageRightURL;
        if([imageURL hasPrefix:@"http"] == false){
        
            imageRightURL = [NSString stringWithFormat:@"https:%@",imageURL];
        }else{
            imageRightURL = imageURL;
        }
        
        [Utils loadImage:cell.merchandiseImageView andURL:imageRightURL isLoadRepeat:true];
    }
    
    
    return cell;
}

#pragma mark -- UICollectionViewDelegate

- (BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    if(self.tapWaterFallHandlerWithIndex){
        
        NSDictionary * dic = self.dataSource[indexPath.row];
        
        NSArray * originalStrings = @[@"${SPU_NO}",@"${SELECTION_CODE}",@"${SKU_NO}"];
        
        NSString * selectionCode = dic[SELECTION_CODE];
        
        NSString * skuNo = dic[SKU_NO];
        NSString * spuNo = dic[SPU_NO];
        
        NSArray * replaceStringgs = @[spuNo,selectionCode,skuNo];
        
        NSMutableString * goURL = [SharedInstance getInstance].saasURLModel.goodsDetailURL.mutableCopy;
        
        for(NSInteger i = 0;i < originalStrings.count; i ++)
        {
            NSString * replace = replaceStringgs[i];
            NSString * original = originalStrings[i];
            goURL = [goURL stringByReplacingOccurrencesOfString:original withString:replace].mutableCopy;
        }
        
        self.tapWaterFallHandlerWithIndex(indexPath.row,goURL.copy,@2);
    }
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    !self.scrollCallback?:self.scrollCallback(scrollView);
}

#pragma mark - JXPagingViewListViewDelegate

- (UIScrollView *)listScrollView {
    return self.collectionView;
}

- (void)listViewDidScrollCallback:(void (^)(UIScrollView *))callback {
    self.scrollCallback = callback;
}

- (void)listViewLoadDataIfNeeded {
    if (!self.isFirstLoaded) {
        self.isFirstLoaded = YES;
        if (self.isNeedHeader) {
            [self.collectionView.mj_header beginRefreshing];
        }else {
            
            [self.collectionView reloadData];
            
        }
    }
}

#pragma mark -- UICollectionViewDelegateFlowLayout

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    CGFloat cellWidth = (SCREEN_WIDTH - 15) / self.col;
    //CGFloat radio = height.floatValue / width.floatValue;
   
    
    CGFloat nameHeight = 40;
    
    CGFloat cellHeight = nameHeight + (cellWidth - 10) + CELL_LABEL_GAP_HEIGHT;
    
    return CGSizeMake(cellWidth,cellHeight);
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    
    return 0;
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return 0;
}
- (UIEdgeInsets) collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(0, 0, 0, 0);
}

- (void)dealloc
{
    self.scrollCallback = nil;
    
}
@end
