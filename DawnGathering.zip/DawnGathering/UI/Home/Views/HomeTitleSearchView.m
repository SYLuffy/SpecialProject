//
//  HomeTitleSearchView.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/7/26.
//

#import "HomeTitleSearchView.h"

@interface HomeTitleSearchView()

@end

@implementation HomeTitleSearchView

- (void)awakeFromNib
{
    [super awakeFromNib];
    
    self.inputText.returnKeyType = UIReturnKeySearch;
    
    self.searchImageViewIcon.contentMode = UIViewContentModeScaleAspectFit;
}

- (IBAction)tapMessageHandler:(UIButton *)sender {
    //点击图标;
    if(self.tapMessageHandler)
    {
        self.tapMessageHandler();
    }
}
- (IBAction)tapSearchGotoSearchHandler:(UIButton *)sender {
    if(self.tapSearchGotoSearchViewController)
    {
        self.tapSearchGotoSearchViewController();
    }
    
}




@end
