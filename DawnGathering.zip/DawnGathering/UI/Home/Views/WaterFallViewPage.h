//
//  WaterFallCell.h
//  DawnGathering
//
//  Created by 李冬岐 on 2023/7/31.
//

#import <UIKit/UIKit.h>
#import "JXPageListView.h"

typedef void(^TapWaterFallHandlerWithIndex)(NSInteger index,NSString * _Nullable  goURL,NSNumber * _Nonnull jumpType);

NS_ASSUME_NONNULL_BEGIN

@interface WaterFallViewPage : UIView <JXPageListViewListDelegate>

@property (nonatomic,copy)TapWaterFallHandlerWithIndex tapWaterFallHandlerWithIndex;

- (void)updateWithDataDic:(NSDictionary*)dataDic;

@property (nonatomic,assign)NSInteger index;

@property (nonatomic,strong)NSDictionary * dataDic;
@property (weak, nonatomic) IBOutlet UIView *noDataView;

@property (nonatomic, assign) BOOL isNeedHeader;
@property (nonatomic, assign) BOOL isFirstLoaded;
@end

NS_ASSUME_NONNULL_END
