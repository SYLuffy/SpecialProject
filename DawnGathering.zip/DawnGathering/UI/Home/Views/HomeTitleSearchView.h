//
//  HomeTitleSearchView.h
//  DawnGathering
//
//  Created by 李冬岐 on 2023/7/26.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^TapSearchHandler)(NSString * __nullable content);
typedef void(^TapMessageHandler)(void);

typedef void(^TapSearchGotoSearchViewController)(void);

@interface HomeTitleSearchView : UIView
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *leftDistance;
@property (weak, nonatomic) IBOutlet UIButton *tapButton;//可以隐藏
@property(nonatomic, assign) CGSize intrinsicContentSize;
@property (nonatomic,copy)TapMessageHandler tapMessageHandler;
@property (nonatomic,copy)TapSearchHandler tapSearchHandler;
@property (nonatomic,copy)TapSearchGotoSearchViewController tapSearchGotoSearchViewController;
@property (weak, nonatomic) IBOutlet UITextField *inputText;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bottomDistance;
@property (weak, nonatomic) IBOutlet UIView *whiteView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *searchImageViewIconWidth;//默认0 - 32；
@property (weak, nonatomic) IBOutlet UIImageView *searchImageViewIcon;

@end

NS_ASSUME_NONNULL_END
