//
//  HomeModel.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/7/27.
//

#import "HomeModel.h"

@implementation HomeModel


- (instancetype)initByDictionary:(NSDictionary*)dic
{
    self = [super init];
    if (self) {
    
        [self setValuesForKeysWithDictionary:dic];
        
        self.placeholder = dic[@"searchConfig"][@"placeholder"];
    }
    return self;
}

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    NSLog(@"%@",value);
}


@end
