//
//  SaaSURLModel.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/8/17.
//

#import "SaaSURLModel.h"

@implementation SaaSURLModel


- (instancetype)initByDictionary:(NSDictionary*)dic
{
    self = [super init];
    if (self) {
        
        self.searchURL = dic[@"h5Search"];
        self.cartURL = dic[@"h5Cart"];
        self.userOrderURL = dic[@"h5UserOrder"];
        self.personalAddressURL = dic[@"h5PersonalAddress"];
        self.afterURL = dic[@"h5AfterSale"];
        self.goodsDetailURL = dic[@"h5GoodsDetail"];
        self.cardOrderList = dic[@"cardOrderList"];
        self.goodsMultiProcuctURL = dic[@"service-unify-url"];
        self.benefitURL = dic[@"h5-benefit-url"];
        self.userDelAccount = dic[@"userDelAccount"];
        self.rightsListURL = dic[@"h5-rights-list"];
        
        
    }
    return self;
}

@end
