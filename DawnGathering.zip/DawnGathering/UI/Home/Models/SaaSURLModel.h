//
//  SaaSURLModel.h
//  DawnGathering
//
//  Created by 李冬岐 on 2023/8/17.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SaaSURLModel : NSObject

- (instancetype)initByDictionary:(NSDictionary*)dic;



@property(nonatomic,strong)NSString * searchURL;//搜索
@property(nonatomic,strong)NSString * cartURL;//购物车;
@property(nonatomic,strong)NSString * userOrderURL;//用户订单地址;
@property(nonatomic,strong)NSString * personalAddressURL;//地址管理页面;
@property(nonatomic,strong)NSString * afterURL;//售后页面;
@property(nonatomic,strong)NSString * goodsDetailURL;//商品详情页;
@property(nonatomic,strong)NSString * cardOrderList;//卡券订单页面;

@property(nonatomic,strong)NSString * goodsMultiProcuctURL;//多商品查询;

@property (nonatomic,strong)NSString * benefitURL;//权益;

@property (nonatomic,strong)NSString * userDelAccount;//用户注销

@property (nonatomic,strong)NSString * rightsListURL;//权益商品地址;
@end

NS_ASSUME_NONNULL_END
