//
//  HomeModel.h
//  DawnGathering
//
//  Created by 李冬岐 on 2023/7/27.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface HomeModel : NSObject


- (instancetype)initByDictionary:(NSDictionary*)dic;

@property (nonatomic,strong)NSNumber * height;
@property (nonatomic,strong)NSNumber * width;
@property (nonatomic,strong)NSArray * listData;
@property (nonatomic,strong)NSString * isbgImg;//false,true
@property (nonatomic,strong)NSDictionary * searchConfig;
@property (nonatomic,strong)NSString * isMerchant;//@"1"
@property (nonatomic,strong)NSNumber * isSearch;//@"0"
@property (nonatomic,strong)NSString * name;
@property (nonatomic,strong)NSString * bgImg;
@property (nonatomic,strong)NSString * bodyBgColor;

@property (nonatomic,strong)NSString * placeholder;

@end

NS_ASSUME_NONNULL_END
