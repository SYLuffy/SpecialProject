//
//  HomeNewStartImageCell.h
//  HLGA
//
//  Created by 葛亮 on 2018/6/1.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^TapThreeImageHandler)(NSInteger index,NSString * url ,NSNumber * jumpType , NSNumber * blackWhiteId);

@interface HomeThreeImageCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *oneImageView;
@property (weak, nonatomic) IBOutlet UIImageView *towImageView;
@property (weak, nonatomic) IBOutlet UIImageView *threeImageView;

@property (nonatomic,strong)NSArray * dataList;
@property (weak, nonatomic) IBOutlet UIImageView *titleImage;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *titleImageViewHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topTitleImageDistance;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *oneImageRight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *oneImageBottom;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *towImageLeft;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *towImageBottom;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *towImageRight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *towImageTop;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *threeImageTop;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *threeImageLeft;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *threeImageRight;

@property (nonatomic,copy)TapThreeImageHandler tapThreeImageHandler;

+ (instancetype)xibTableViewCell;

+ (CGFloat)getCellHegihtWith:(NSDictionary*)dic titleHeight:(CGFloat)titleHeight topicLayout:(NSString*)topicLayout;

- (void)setThreeImageLayoutWithTopicLayout:(NSString*)topicLayout titleHeight:(CGFloat)titleHeight;

@end
