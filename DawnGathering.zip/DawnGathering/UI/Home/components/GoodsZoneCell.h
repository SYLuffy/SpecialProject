//
//  GoodsZoneCell.h
//  DawnGathering
//
//  Created by 李冬岐 on 2023/8/14.
//

#import <UIKit/UIKit.h>

typedef void(^TapGoodsZoneWithIndexHandler)(NSInteger index,NSString * _Nullable  goURL,NSNumber * _Nonnull jumpType);

NS_ASSUME_NONNULL_BEGIN

@interface GoodsZoneCell : UITableViewCell

@property (nonatomic,assign)CGFloat cellHeight;

@property (nonatomic,strong)NSString * zoneId;
@property (nonatomic,strong)NSString * selectionCodes;

@property (nonatomic,strong)NSString * bgImgURL;
@property (nonatomic,strong)NSNumber * pageSize;

@property (nonatomic,strong)NSNumber * isShowMore;

@property (nonatomic,strong)NSNumber * isShowCountDown;

@property (weak, nonatomic) IBOutlet UIButton *moreButton;
@property (weak, nonatomic) IBOutlet UIImageView *moreImageView;
@property (weak, nonatomic) IBOutlet UILabel *moreLabel;

@property (nonatomic,copy)TapGoodsZoneWithIndexHandler tapGoodsZoneWithIndexHandler;

- (void)refreshHandler;

@end

NS_ASSUME_NONNULL_END
