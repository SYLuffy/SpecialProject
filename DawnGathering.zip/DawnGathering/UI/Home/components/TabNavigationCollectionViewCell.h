//
//  TabNavigationCollectionViewCell.h
//  DawnGathering
//
//  Created by 李冬岐 on 2023/7/25.
//

#import <UIKit/UIKit.h>




NS_ASSUME_NONNULL_BEGIN

typedef void(^TapCollectionViewCellWithIndex)(NSInteger index , NSString  * __nullable goURL, NSString  * __nullable jumpType);
typedef void(^TapTabsAndReloadTableView)(NSInteger currentPage , NSInteger index , CGPoint tabOffset);

@interface TabNavigationCollectionViewCell : UITableViewCell

- (void)setCellData:(NSArray *)data setPage:(NSInteger)page tabOffset:(CGPoint)tabOffset tabsColor:(NSString*)tabsColor textColor:(NSString*)textColor;

+ (CGFloat)getCellHeight:(NSArray*)list line:(NSInteger)line;

@property (nonatomic,assign)NSInteger index;

@property (nonatomic,copy)TapCollectionViewCellWithIndex tapCollectionViewCellWithIndex;

@property (nonatomic,copy)TapTabsAndReloadTableView tapTabsAndReloadTableView;


@end

NS_ASSUME_NONNULL_END
