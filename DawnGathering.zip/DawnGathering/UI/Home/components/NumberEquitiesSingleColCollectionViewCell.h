//
//  NumberEquitiesSingleColCollectionViewCell.h
//  DawnGathering
//
//  Created by 李冬岐 on 2024/3/27.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface NumberEquitiesSingleColCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *merchandiseImageView;
@property (weak, nonatomic) IBOutlet UILabel *merchandiseNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *merchandiseAmountLabel;
@property (weak, nonatomic) IBOutlet UILabel *merchandiseDiscountLabel;//商品历史价格划线;
@property (weak, nonatomic) IBOutlet UIView *bottomLine;//底部线;
@end

NS_ASSUME_NONNULL_END
