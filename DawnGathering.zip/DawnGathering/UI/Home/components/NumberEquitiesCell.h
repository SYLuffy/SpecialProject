//
//  NumberEquitiesCell.h
//  DawnGathering
//
//  Created by 李冬岐 on 2024/3/27.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^TapNumberEquitiesWithIndex)(NSInteger index,NSString * _Nullable  goURL,NSNumber * _Nonnull jumpType , NSNumber * _Nullable blackWhiteId);

typedef void(^RefreshNumberEquitiesCellWithRow)(NSInteger row , NSInteger index);

@interface NumberEquitiesCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *titleBgImageView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topDistance;

@property (nonatomic,strong)NSString * selectionCodes;

@property (nonatomic,assign)NSInteger col;

@property (nonatomic,assign)NSInteger index;

@property (nonatomic,strong)NSNumber * pageSize;

@property (nonatomic,copy)TapNumberEquitiesWithIndex tapNumberEquitiesWithIndex;

- (void)radio:(CGFloat)radio titleHeight:(CGFloat)titleHeight;

+ (CGFloat)getCellHeight:(NSInteger)row col:(NSInteger)col radio:(CGFloat)radio titleHeight:(CGFloat)titleHeight;

@property (nonatomic,copy)RefreshNumberEquitiesCellWithRow refreshNumberEquitiesCellWithRow;


@end

NS_ASSUME_NONNULL_END
