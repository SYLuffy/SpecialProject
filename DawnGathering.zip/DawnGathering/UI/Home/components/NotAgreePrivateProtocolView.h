//
//  NotAgreePrivateProtocolView.h
//  StaffCulture
//
//  Created by 谢丹 on 2020/4/8.
//  Copyright © 2020 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface NotAgreePrivateProtocolView : UIView

@end

NS_ASSUME_NONNULL_END
