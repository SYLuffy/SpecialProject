//
//  NormalNavigationCell.h
//  SCST
//
//  Created by 葛亮 on 2019/5/16.
//  Copyright © 2019 葛亮. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface NormalNavigationCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *headImageView;
@property (weak, nonatomic) IBOutlet UILabel *titileLable;
+ (instancetype)xibTableViewCell;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *imageViewHeight;

@end

NS_ASSUME_NONNULL_END
