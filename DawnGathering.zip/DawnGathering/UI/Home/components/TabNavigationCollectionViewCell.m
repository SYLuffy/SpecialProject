//
//  TabNavigationCollectionViewCell.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/7/25.
//

#import "TabNavigationCollectionViewCell.h"
#import "UICollectionViewLeftAlignedLayout.h"
#import "LXKit.h"
#import "NormalNavigationCell.h"
#import "UITestButtonView.h"


@interface TabNavigationCollectionViewCell()<UICollectionViewDelegate,UICollectionViewDataSource>
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (weak, nonatomic) IBOutlet UIView *topTabContainer;
@property (weak, nonatomic) IBOutlet UIView *bottomEmptyView;

@property (nonatomic,strong)NSArray <NSDictionary*>* list;

@property (nonatomic,assign)NSInteger currentPage;

@property (nonatomic,assign)NSInteger col;//列
@property (nonatomic,assign)NSInteger line;//行

@property (nonatomic, strong) LXSlideIndicator *slideIndicator;
@property (nonatomic, strong) UITestButtonView * selectView;
@property (nonatomic, strong)NSString * tabsColor;
@property (nonatomic, strong)NSString * textColor;
@end

@implementation TabNavigationCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.col = 1;
    self.line = 1;
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc]init];
    layout.scrollDirection = UICollectionViewScrollDirectionVertical;

    self.collectionView.collectionViewLayout = layout;
    [self.collectionView registerNib:[UINib nibWithNibName:@"NormalNavigationCell" bundle:[NSBundle mainBundle]] forCellWithReuseIdentifier:@"NormalNavigationCell"];
    self.collectionView.delegate = self;
    self.collectionView.dataSource = self;
    self.collectionView.scrollEnabled = true;
    self.collectionView.showsHorizontalScrollIndicator = NO;
    self.collectionView.backgroundColor = [UIColor whiteColor];
    self.currentPage = 0;
    
    self.selectView = [[UITestButtonView alloc] init];
    WS(weakSelf);
    self.selectView.tapSelectViewButtonWithIndex = ^(NSInteger index,NSInteger cellIndex) {
        weakSelf.currentPage = index;
        
        if(weakSelf.tapTabsAndReloadTableView)
        {
            CGFloat moveX = weakSelf.selectView.contentOffset.x;

            weakSelf.tapTabsAndReloadTableView(weakSelf.currentPage,weakSelf.index,CGPointMake(moveX, 0));
        }

    };
    self.selectView.frame = CGRectMake(0, 0, SCREEN_WIDTH, 30);
    [self.topTabContainer addSubview:self.selectView];
}

- (void)initSlideIndicator {
    if (!self.slideIndicator) {
        
        if(_list.count > 10)
        {
            LXSlideIndicatorConfig *config = [LXSlideIndicatorConfig new];
            config.width = 60;
            config.height = 4;
            config.backgroundColor = UIColorFromRGB(0xF6F6F6);
            config.slideViewColor = [Utils getMainColor];
            self.slideIndicator = [[LXSlideIndicator alloc] initWithConfig:config];
            self.slideIndicator.frame = CGRectMake((SCREEN_WIDTH - config.width) * 0.5, 10, config.width, config.height);
            [self.bottomEmptyView addSubview:self.slideIndicator];
        }
        
    }
}

- (void)setCellData:(NSArray *)data setPage:(NSInteger)page tabOffset:(CGPoint)tabOffset tabsColor:(NSString*)tabsColor textColor:(NSString*)textColor{
    
    self.tabsColor = tabsColor;
    self.textColor = textColor;
    _list = data;
    
    self.currentPage = page;
    
    NSDictionary * firstObject = data.firstObject;
    
    NSNumber * line = firstObject[LINE];
    NSNumber * col = firstObject[COLUMN];
    self.line = line.integerValue;
    self.col = col.integerValue;
    
    //[self initSlideIndicator];
    
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc]init];
    
   
    layout.scrollDirection = UICollectionViewScrollDirectionVertical;

    
    self.collectionView.collectionViewLayout = layout;
    
//    _list = data;
//    _list = [data arrayByAddingObjectsFromArray:[data mutableCopy]];

    [self.selectView updateRefreshViewWithSubTitle:self.list curentPage:page];
    
//    [self.selectView setContentOffset:tabOffset];
    
    [self.collectionView reloadData];
}

+ (CGFloat)getCellHeight:(NSArray*)list line:(NSInteger)line
{
    CGFloat height = SCREEN_WIDTH / 375 * 40.0f + 28.0f;
    
    height = height * line;
    
    return height + 50;
    
}

#pragma mark --  UICollectionViewDataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    
    NSArray * currentListData = self.list[self.currentPage][LIST];
    
    return currentListData.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    NormalNavigationCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"NormalNavigationCell" forIndexPath:indexPath];
    if (!cell) {
        cell = [NormalNavigationCell xibTableViewCell];
    }
    
    
    NSDictionary *data = self.list[self.currentPage][LIST][indexPath.row];
    [cell.headImageView sd_setImageWithURL:[NSURL URLWithString:data[@"imgUrl"]] placeholderImage:[UIImage imageNamed:@"img_zhanweitu"]];
    cell.titileLable.text = data[@"name"];
    
    cell.titileLable.textColor = [UIColor colorWithHexString:self.textColor];
    //cell.contentView.backgroundColor = [UIColor colorWithHexString:self.tabsColor];
    
    return cell;
}
-(BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    if(self.tapCollectionViewCellWithIndex){
        
        NSString * goURL = self.list[self.currentPage][LIST][@"hrefUrl"];
        NSString * jumpType = self.list[self.currentPage][LIST][@"jumpType"];
        
        self.tapCollectionViewCellWithIndex(indexPath.row,goURL,jumpType);
    }
}
#pragma UICollectionViewDelegateFlowLayout

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    CGFloat width = SCREEN_WIDTH / self.col;
    
    return CGSizeMake(width,SCREEN_WIDTH / 375 * 40.0f + 28.0f);
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    
    return 0;
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return 0;
}
- (UIEdgeInsets) collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(0, 0, 0, 0);
}

#pragma mark - UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (scrollView == self.collectionView) {
        [self.slideIndicator scrollViewRelativeDidScroll:scrollView];
    }
}

@end
