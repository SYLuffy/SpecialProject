//
//  HomeMerchantListCell.h
//  DawnGathering
//
//  Created by 李冬岐 on 2024/2/2.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^TapHomeMerchantListMerchantId)(NSNumber * _Nullable merchantId , NSNumber * _Nullable distance , NSNumber * lat , NSNumber * lng , NSString * cityName);
typedef void(^TapHomeAllMerchantListHandler)(NSNumber * _Nullable blackWhiteId);

@interface HomeMerchantListCell : UITableViewCell

@property (nonatomic,copy)TapHomeMerchantListMerchantId tapHomeMerchantListMerchantId;
@property (nonatomic,copy)TapHomeAllMerchantListHandler tapHomeAllMerchantListHandler;

- (void)setMerchantListWithListCount:(NSInteger)count blackWhiteId:(NSNumber*)blackWhiteId blackWhiteIdList:(NSArray*)blackWhiteIdList;

//获取此cell高度
+ (CGFloat)getMerchantListCellHeightWithCount:(NSInteger)count;

@end

NS_ASSUME_NONNULL_END
