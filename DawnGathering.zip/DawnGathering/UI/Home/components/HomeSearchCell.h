//
//  HomeSearchCell.h
//  DawnGathering
//
//  Created by 李冬岐 on 2023/10/8.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HomeSearchCell : UITableViewCell

@end

NS_ASSUME_NONNULL_END
