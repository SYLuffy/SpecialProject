//
//  BannerImageCell.h
//  Banks
//
//  Created by 李冬岐 on 2022/9/14.
//  Copyright © 2022 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SDCycleScrollView.h"
#import "HomePageView.h"

typedef void(^BannerCellBlock)(NSInteger index , NSArray * _Nullable items);

typedef void(^ReloadMainTableView)(void);

NS_ASSUME_NONNULL_BEGIN

@interface BannerImageCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIView *bgView;
@property (weak, nonatomic) IBOutlet UIView *pageView;
@property(nonatomic,strong)SDCycleScrollView *scrollView;
@property(nonatomic,strong)HomePageView *pageCtrl;
@property(nonatomic,copy)BannerCellBlock selectItemBlock;
@property(nonatomic,copy)ReloadMainTableView reloadMainTableView;

@property (nonatomic,strong)NSArray * items;
@property (nonatomic,strong)NSNumber * isRand;
@property (nonatomic,strong)NSNumber * showNum;

+(instancetype)xibTableViewCell;
+(CGFloat)getBannerCellRowHeightWithRadio:(CGFloat)radio;
-(void)updateTableViewCellWithData:(NSArray *)data radio:(CGFloat)radio;
- (void)updateTableViewCellWithData:(NSMutableDictionary*)dic;

@end

NS_ASSUME_NONNULL_END
