//
//  BannerImageCell.m
//  Banks
//
//  Created by 李冬岐 on 2022/9/14.
//  Copyright © 2022 Linus. All rights reserved.
//

#import "BannerImageCell.h"
#import "UIImage+tools.h"

@interface BannerImageCell()<SDCycleScrollViewDelegate>
{
    NSArray *_list;
}
@end

@implementation BannerImageCell

-(SDCycleScrollView *)scrollView{
    
    if (!_scrollView) {
        _scrollView = [SDCycleScrollView cycleScrollViewWithFrame:CGRectMake(0, 0,[UIScreen mainScreen].bounds.size.width - 30, SCREEN_WIDTH * 0.43) delegate:self placeholderImage:nil];
        _scrollView.pageControlAliment = SDCycleScrollViewPageContolAlimentCenter;
        _scrollView.titleLabelHeight = 20;
        //_scrollView.placeholderImage= [UIImage imageNamed:@"default_home_newspic"];
        _scrollView.pageControlBottomOffset = -53;
        _scrollView.titleLabelTextFont = [UIFont fontWithName:@"PingFangSC-Regular" size:14];
        _scrollView.titleLabelBackgroundColor =  [UIColor colorWithRed:0/255.0 green:0/255.0 blue:0/255.0 alpha:0.8];
        _scrollView.titleLabelTextColor = [UIColor whiteColor];
        _scrollView.currentPageDotColor = [UIColor colorWithHexString:@"666666"];
        _scrollView.pageDotColor = [UIColor colorWithHexString:@"DEDEDE"];
        _scrollView.backgroundColor = [UIColor clearColor];
        _scrollView.showPageControl = NO;
        _scrollView.layer.masksToBounds = YES;
        _scrollView.bannerImageViewContentMode =  UIViewContentModeScaleToFill;
        _scrollView.autoScrollTimeInterval = 3;
        
    }
    return _scrollView;
}

-(HomePageView *)pageCtrl{
    
    if (!_pageCtrl) {
        _pageCtrl = [[HomePageView alloc]init];
        _pageCtrl.userInteractionEnabled = NO;
        
        if (@available(iOS 16.0, *)) {
            _pageCtrl.preferredCurrentPageIndicatorImage = [UIImage imageNamed:@"page_current"];
        } else {
            // Fallback on earlier versions
        }
        if (@available(iOS 14.0, *)) {
            _pageCtrl.preferredIndicatorImage = [UIImage imageNamed:@"page_indicator"];
        } else {
            // Fallback on earlier versions
        }
//        _pageCtrl.currentImageSize = CGSizeMake(3, 3);
        
        _pageCtrl.currentPageIndicatorTintColor = [UIColor grayColor];
        _pageCtrl.pageIndicatorTintColor = [UIColor lightGrayColor];
    }
    return _pageCtrl;
}

- (void)drawRect:(CGRect)rect{
    [super drawRect:rect];
    
    self.pageCtrl.frame = CGRectMake(80, 0, _pageView.bounds.size.width-160, 10);
}

- (void)awakeFromNib {
    
    [super awakeFromNib];
    [self layoutIfNeeded];

    [self.bgView addSubview:self.scrollView];
    [self.pageView addSubview:self.pageCtrl];
}

+ (instancetype)xibTableViewCell{
    return [[[NSBundle mainBundle] loadNibNamed:@"BannerImageCell" owner:nil options:nil] lastObject];
}

#pragma SDCycleScrollViewDelegate

/** 点击图片回调 */
- (void)cycleScrollView:(SDCycleScrollView *)cycleScrollView didSelectItemAtIndex:(NSInteger)index{
    
    self.pageCtrl.currentPage = index;
    if(_selectItemBlock){
        _selectItemBlock(index, _list);
    }
}

/** 图片滚动回调 */
- (void)cycleScrollView:(SDCycleScrollView *)cycleScrollView didScrollToIndex:(NSInteger)index{
    
    self.pageCtrl.currentPage = index;
    

}

+ (CGFloat)getBannerCellRowHeightWithRadio:(CGFloat)radio{
    
    
    CGFloat width = SCREEN_WIDTH - 30;
    
    return width * radio + 15;
}

- (void)updateTableViewCellWithData:(NSMutableDictionary*)dic
{
    NSArray * data = dic[ADVERTISING_ID_LIST];
    
    [ServiceManager getFlashAdveriseWithAdids:data isRand:self.isRand randNumToShow:self.showNum success:^(NSDictionary *data) {
        
        NSArray * list = data[DATA];
        
        if ([Utils checkObjectIsNull:list]) {
           
            [dic setValue:list forKey:ADVERTISING_ID_LIST];
            
            NSDictionary * dict = list.firstObject;
            
            NSNumber * width = dict[WIDTH];
            NSNumber * height = dict[HEIGHT];
            
            if(!width || width.integerValue == 0) width = @2;
            if(!height || height.integerValue == 0) height = @1;
            
            [dic setValue:width forKey:WIDTH];
            
            [dic setValue:height forKey:HEIGHT];
            
            [self updateTableViewCellWithData:list radio:height.floatValue / width.floatValue];
            
            if(self.reloadMainTableView)
            {
                self.reloadMainTableView();
            }
            
        }
    }];
}

-(void)updateTableViewCellWithData:(NSArray *)data radio:(CGFloat)radio{
    
    _list = data;
    
    NSMutableArray * images = [NSMutableArray array];
    
    for(NSDictionary * dic in data)
    {
        NSString * url = dic[IMG_URL];
        
        if([Utils checkObjectIsNull:url] == false)
        {
            url = dic[IMG];
        }
        
        if([Utils validateContainsChinese:url])
        {
            url = [url stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
        }
        
        [images addObject:url];
    }
    
    self.scrollView.imageURLStringsGroup = [images copy];
    
    
    self.scrollView.frame = CGRectMake(self.scrollView.frame.origin.x, self.scrollView.frame.origin.y, self.scrollView.frame.size.width, self.scrollView.frame.size.width * radio);
    
    self.pageCtrl.numberOfPages = data.count;
    self.pageCtrl.currentPage = 0;
}


@end
