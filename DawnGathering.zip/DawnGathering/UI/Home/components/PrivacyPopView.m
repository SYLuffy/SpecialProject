//
//  PrivacyPopView.m
//  TIFamily
//
//  Created by 李冬岐 on 2019/9/29.
//  Copyright © 2019 葛亮. All rights reserved.
//

#import "PrivacyPopView.h"
#import <Masonry.h>
#import <YYLabel.h>
#import "UIColor+Extension.h"
#import <NSAttributedString+YYText.h>
#import "NotAgreePrivateProtocolView.h"
#import "WPUrlString.h"


#define AGREE_PRIVACY @"agreePrivate"

@implementation PrivacyPopView

- (void)awakeFromNib{
    [super awakeFromNib];
    
    self.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
    self.backgroundColor = [UIColor clearColor];
    
    self.notAgreeButton.layer.borderWidth = 1.0f;
    self.notAgreeButton.layer.borderColor = [UIColor lightGrayColor].CGColor;
    
    
    YYLabel *label = [[YYLabel alloc]init];
    
    label.numberOfLines = 0;
    [self.popView addSubview:label];
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(15);
        make.right.mas_equalTo(-15);
        make.top.mas_equalTo(20 + 30);
        make.height.mas_equalTo(250);
    }];
    
    
    NSString *string = @"欢迎使用“蜀光惠”！我们非常重视您的个人信息和隐私保护。在您使用“蜀光惠”服务之前，请仔细阅读《蜀光惠用户协议》、《蜀光惠隐私政策》，我们将严格按照经您同意的各项条款使用您的个人信息，以便为您提供更好的服务。\n\n如您同意此政策，请点击“同意”并开始使用我们的产品和服务，我们尽全力保护您的个人信息安全。";
    
    NSMutableAttributedString *urlString = [[NSMutableAttributedString alloc] initWithString:string];
    urlString.yy_color = [UIColor blackColor];
    urlString.yy_font = [UIFont systemFontOfSize:14];
    
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineSpacing = 5.0;
    paragraphStyle.alignment = NSTextAlignmentJustified;
    [urlString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, urlString.length)];
    
    NSRange range1 = [string rangeOfString:@"《蜀光惠用户协议》"];
    [urlString yy_setTextHighlightRange:range1 color:[UIColor colorWithHexString:@"007AFF"] backgroundColor:[UIColor whiteColor] tapAction:^(UIView * _Nonnull containerView, NSAttributedString * _Nonnull text, NSRange range, CGRect rect) {
        
        [self fadeOut];
        
        [Utils pushWebViewControllerURL:[NSString stringWithFormat:@"%@%@",BASE_WEB_URL,SERVICE_AGREEMENT] owner:[Utils getCurrentVC]];
    }];
    
    
    NSRange range2 = [string rangeOfString:@"《蜀光惠隐私政策》"];
    [urlString yy_setTextHighlightRange:range2 color:[UIColor colorWithHexString:@"007AFF"] backgroundColor:[UIColor whiteColor] tapAction:^(UIView * _Nonnull containerView, NSAttributedString * _Nonnull text, NSRange range, CGRect rect) {
        
        [self fadeOut];
        
        [Utils pushWebViewControllerURL:[NSString stringWithFormat:@"%@%@",BASE_WEB_URL,PRIVATE_AGREEMENT] owner:[Utils getCurrentVC]];
      
    }];
    
    
    
    label.attributedText = urlString;
}


//不同意
- (IBAction)notAgreeHandler:(id)sender {
    [self fadeOut];
    NSArray *objs = [[NSBundle mainBundle]loadNibNamed:@"NotAgreePrivateProtocolView" owner:nil options:nil];
    UIView *xibView = objs.firstObject;
    NotAgreePrivateProtocolView * popView = (NotAgreePrivateProtocolView*)xibView;
    [[Utils currentWindow] addSubview:popView];
}


- (IBAction)tapAgreeHandler:(UIButton *)sender {
    [Utils setUserDefaultByKey:AGREE_PRIVACY andValue:@1];//保存已同意
    [self fadeOut];
}


- (void)fadeIn{
    
    self.darkView.alpha = 0.0;
    self.popView.alpha = 0.0;
    
    [UIView animateWithDuration:0.3 animations:^{
        self.darkView.alpha = 0.5;
        self.popView.alpha = 1.0f;
    }];
}

- (void)fadeOut{
    
    self.darkView.alpha = 0.5;
    [UIView animateWithDuration:0.3 animations:^{
        
        self.darkView.alpha = 0;
        self.popView.alpha = 0;
        
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
        
        if (self.agreeAction) {
            self.agreeAction();
        }
        
        
        
    }];
    
}


@end
