//
//  SectionCell.h
//  HLGA
//
//  Created by 李冬岐 on 2023/5/5.
//  Copyright © 2023 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^TapSectionHandlerWithIndex)(NSInteger index,NSString * _Nullable  goURL,NSNumber * _Nonnull jumpType , NSNumber * _Nullable blackWhiteId);

NS_ASSUME_NONNULL_BEGIN

@interface SectionCell : UITableViewCell

@property (nonatomic,assign)NSInteger col;
@property (weak, nonatomic) IBOutlet UILabel *descTitleLabel;
@property (weak, nonatomic) IBOutlet UIImageView *titleBgImageView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topDistance;

@property (nonatomic,assign)BOOL isCoupon;

@property (nonatomic,strong)NSNumber * activityID;

@property (nonatomic,copy)TapSectionHandlerWithIndex tapSectionHandlerWithIndex;

- (void)setCellData:(NSArray *)data radio:(CGFloat)radio titleHeight:(CGFloat)titleHeight;

+ (CGFloat)getCellHeight:(NSArray*)list col:(NSInteger)col radio:(CGFloat)radio titleHeight:(CGFloat)titleHeight;



@end

NS_ASSUME_NONNULL_END
