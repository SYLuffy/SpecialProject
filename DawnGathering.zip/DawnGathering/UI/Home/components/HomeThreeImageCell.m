//
//  HomeNewStartImageCell.m
//  HLGA
//
//  Created by 葛亮 on 2018/6/1.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "HomeThreeImageCell.h"
@interface HomeThreeImageCell()

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *midcourtLine;

@end

@implementation HomeThreeImageCell
+ (instancetype)xibTableViewCell{
    
    return [[[NSBundle mainBundle] loadNibNamed:@"HomeNewStartImageCell" owner:nil options:nil] lastObject];
    
}
-(void)awakeFromNib{
    
    [super awakeFromNib];
    self.midcourtLine.constant =  1.0 / [UIScreen mainScreen].scale;

   
}


- (IBAction)pushButtonPressed:(UIButton *)sender {
    NSInteger index = sender.tag - 100;
    
    NSDictionary * dic = self.dataList[index];
    
    
    
    NSString * goURL;
    
    NSNumber * jumpType = dic[JUMP_TYPE];
    
    if(jumpType.integerValue == 3)
    {
        NSDictionary * shopSet = dic[SHOP_SET];
        
        goURL = [Utils dictionaryToJson:shopSet];
    }else{
        goURL = dic[HREF_URL];
    }
    
    if([goURL isKindOfClass:[NSString class]] && [goURL isEqualToString:CLASSIFY])
    {
        [SharedInstance getInstance].currentClassifyID = dic[CLASSIFY_ID];
    }
    
    NSNumber * blackWhiteId = dic[BLACK_WHITE_ID];
    NSArray * blackWhiteList = dic[WHITE_IDS];
    
    [SharedInstance getInstance].sendBlackWhiteList = blackWhiteList;
    
    if(self.tapThreeImageHandler)
    {
        self.tapThreeImageHandler(index,goURL,jumpType,blackWhiteId);
    }
}

- (void)setThreeImageLayoutWithTopicLayout:(NSString*)topicLayout titleHeight:(CGFloat)titleHeight
{
    self.titleImageViewHeight.constant = titleHeight;
    if(titleHeight == 0)
    {
        self.topTitleImageDistance.constant = 2.5;
    }
    NSDictionary * firstObj = self.dataList.firstObject;
    
    NSNumber * firstWidth = firstObj[WIDTH];
    NSNumber * firstHeight = firstObj[HEIGHT];
    
    if(!firstWidth) firstWidth = @1;
    if(!firstHeight) firstHeight = @1;
    
    CGFloat imgHeight = firstHeight.floatValue / firstWidth.floatValue * (SCREEN_WIDTH - 35) / 2;
    
    CGFloat halfPaddingH = (SCREEN_WIDTH - 35) / 2 + 22;
    CGFloat halfPaddingV = imgHeight + 12.5;
    
    switch (topicLayout.integerValue) {
        case 1:
            {
                self.oneImageBottom.constant = halfPaddingV;
                self.oneImageRight.constant = 15;
                self.towImageTop.constant = halfPaddingV;
                self.towImageLeft.constant = 15;
                self.towImageRight.constant = halfPaddingH;
                self.towImageBottom.constant = 7.5;
                self.threeImageTop.constant = halfPaddingV;
                self.threeImageLeft.constant = halfPaddingH;
                break;
            }
            
        case 2:{
            
            halfPaddingV = imgHeight / 2 + 12.5;
            self.oneImageBottom.constant = 7.5;
            self.oneImageRight.constant = halfPaddingH;
            self.towImageTop.constant = 7.5;
            self.towImageLeft.constant = halfPaddingH;
            self.towImageRight.constant = 15;
            self.towImageBottom.constant = halfPaddingV;
            self.threeImageTop.constant = halfPaddingV;
            self.threeImageLeft.constant = halfPaddingH;
            self.threeImageRight.constant = 15;
            break;
            }
            
            
        case 3:{
      
            self.oneImageBottom.constant = halfPaddingV;
            self.oneImageRight.constant = halfPaddingH;
            self.towImageTop.constant = 7.5;
            self.towImageLeft.constant = halfPaddingH;
            self.towImageRight.constant = 15;
            self.towImageBottom.constant = 7.5;
            self.threeImageTop.constant = halfPaddingV;
            self.threeImageLeft.constant = 15;
            self.threeImageRight.constant = halfPaddingH;
            break;
        }
            
        default:
            break;
    }
    
    [self layoutIfNeeded];
}


+ (CGFloat)getCellHegihtWith:(NSDictionary*)dic titleHeight:(CGFloat)titleHeight topicLayout:(NSString*)topicLayout{
    
    CGFloat totalHeight = 0;
    
    NSNumber * width = dic[WIDTH];
    NSNumber * height = dic[HEIGHT];
    
    if(!width) width = @1;
    if(!height) height = @1;
    
    CGFloat imgHeight = height.floatValue / width.floatValue * (SCREEN_WIDTH - 35)/2;
    
    if(topicLayout.integerValue != 2)
    {
        imgHeight = imgHeight * 2;
    }
    
    totalHeight = imgHeight + titleHeight + 25;
    
    if(titleHeight == 0) totalHeight -= 5;
    
    return totalHeight;
    
}


@end
