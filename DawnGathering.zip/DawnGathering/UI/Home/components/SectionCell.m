//
//  SectionCell.m
//  HLGA
//
//  Created by 李冬岐 on 2023/5/5.
//  Copyright © 2023 Linus. All rights reserved.
//

#import "SectionCell.h"
#import "ImageCollectionViewCell.h"

NSString *SectionCellString = @"SectionCell";

NSString *ImageCollectionViewCellString = @"ImageCollectionViewCell";

@interface SectionCell()<UICollectionViewDelegate,UICollectionViewDataSource>

@property (nonatomic,strong)NSArray * list;
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (nonatomic,assign)CGFloat radio;

@property (nonatomic,strong)NSMutableArray * recevieList;

@end

@implementation SectionCell


+ (instancetype)xibTableViewCell{
    return [[[NSBundle mainBundle] loadNibNamed:SectionCellString owner:nil options:nil] lastObject];
    
}

- (void)awakeFromNib {
    [super awakeFromNib];
    self.collectionView.userInteractionEnabled = YES;
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc]init];
    layout.scrollDirection = UICollectionViewScrollDirectionVertical;

    self.collectionView.collectionViewLayout = layout;
    [self.collectionView registerNib:[UINib nibWithNibName:ImageCollectionViewCellString bundle:[NSBundle mainBundle]] forCellWithReuseIdentifier:ImageCollectionViewCellString];
    self.collectionView.delegate = self;
    self.collectionView.dataSource = self;
    self.collectionView.scrollEnabled = true;
    self.collectionView.showsHorizontalScrollIndicator = NO;
    
    
    
}

- (void)setCellData:(NSArray *)data radio:(CGFloat)radio titleHeight:(CGFloat)titleHeight{
   
    self.radio = radio;
    
    _list = data;
    
    self.topDistance.constant = titleHeight;
    
    
    if(self.isCoupon)
    {
        
        NSMutableArray * couponTemplateCodes = [NSMutableArray array];
        for(NSDictionary * dic in data)
        {
            NSNumber * templateCode = dic[TEMPLATE_CODE];
            
            [couponTemplateCodes addObject:templateCode];
            
            [self.recevieList addObject:@{STATE:@1}];
        }
        
        if([SharedInstance getInstance].sid.length > 0)
        {
            [ServiceManager getReceiveCouponStatsWithActivityID:self.activityID couponTemplateCodes:couponTemplateCodes.copy success:^(NSDictionary *data) {
                
                NSArray * coupons = data[COUPONS];
                
                if([Utils checkObjectIsNull:coupons])
                {
                    self.recevieList = coupons.mutableCopy;
                }
                
                
                [self.collectionView reloadData];
                
            }];
        }
        
        
        [self.collectionView reloadData];
    }else{
        [self.collectionView reloadData];
    }
    
    
    
}


+ (CGFloat)getCellHeight:(NSArray*)list col:(NSInteger)col radio:(CGFloat)radio titleHeight:(CGFloat)titleHeight;
{
    NSInteger row = list.count / col;
    
    if(list.count % col) row += 1;
    
    CGFloat cellWidth = (SCREEN_WIDTH - 15) / col;
    CGFloat totalHeight = 0;
    
    CGFloat cellHeight = cellWidth * radio;;
    
    totalHeight = cellHeight * row;
    
    return totalHeight + 10 + titleHeight;
    
}

#pragma mark -- UICollectionViewDataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return [_list count];
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    ImageCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:ImageCollectionViewCellString forIndexPath:indexPath];
    if (!cell) {
        cell = [ImageCollectionViewCell xibTableViewCell];
    }
    
    NSDictionary * couponsDic = self.recevieList[indexPath.row];
    
    NSNumber * isRecevied = couponsDic[STATE];
    
    NSDictionary *data = _list[indexPath.row];
    
    NSString * imgURL;
    
    if(self.isCoupon == true)
    {
        if(isRecevied.integerValue == 1 || isRecevied == nil)
        {
            imgURL = data[@"noReceiveImg"];
        }else{
            imgURL = data[@"receiveImg"];
        }
        
    }else{
        imgURL = data[IMG_URL];
    }
    
    [Utils loadImage:cell.contentImageView andURL:imgURL  isLoadRepeat:true];
    
    return cell;
}


- (BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    NSDictionary * dic = self.list[indexPath.row];
    
    if(self.isCoupon == true)
    {
        
        if ([[SharedInstance getInstance].userInfo.sid length] == 0) {
            
            [[SharedInstance getInstance] checkLoginAndGotoLogin:[Utils getCurrentVC]];
            
            return;
        }
        
        //领券
        NSNumber * activityID = self.activityID;
        NSString * templateCode = dic[TEMPLATE_CODE];
        
        NSMutableDictionary * selectedRecevieDic = self.recevieList[indexPath.row];
        
        NSNumber * selectedState = selectedRecevieDic[STATE];
        
        if(selectedState.integerValue == 2)
        {
            //已经领取无法继续领取;
            //[Utils showToast:@"已领取"];
            return;
        }
        
        [ServiceManager receiveCouponWithActivityID:activityID templateId:@1 templateCode:templateCode success:^(NSDictionary *data) {
            
    
            [Utils showToast:@"领取成功"];
            
            selectedRecevieDic[STATE] = @2;
            
            self.recevieList[indexPath.row] = selectedRecevieDic;
            
            [self.collectionView reloadData];
            
        }];
        
        return;
    }
    
    
    if(self.tapSectionHandlerWithIndex){
        
        NSString * goURL;
        
        NSNumber * jumpType = dic[JUMP_TYPE];
        
        if(jumpType.integerValue == 3)
        {
            NSDictionary * shopSet = dic[SHOP_SET];
            
            goURL = [Utils dictionaryToJson:shopSet];
        }else{
            goURL = dic[HREF_URL];
        }
        NSNumber * blackWhiteId = dic[BLACK_WHITE_ID];
        NSArray * blackWhiteList = dic[WHITE_IDS];
        
        [SharedInstance getInstance].sendBlackWhiteList = blackWhiteList;
        
        if([goURL isKindOfClass:[NSString class]] && [goURL isEqualToString:CLASSIFY])
        {
            [SharedInstance getInstance].currentClassifyID = dic[CLASSIFY_ID];
        }
        
        self.tapSectionHandlerWithIndex(indexPath.row,goURL,jumpType,blackWhiteId);
    }
}
#pragma UICollectionViewDelegateFlowLayout

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    CGFloat cellWidth = (SCREEN_WIDTH - 15) / self.col;
    CGFloat cellHeight = cellWidth * self.radio;
    
    return CGSizeMake(cellWidth,cellHeight);
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    
    return 0;
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return 0;
}
- (UIEdgeInsets) collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(0, 0, 0, 0);
}

@end
