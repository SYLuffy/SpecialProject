//
//  NumberEquitiesCollectionViewCell.m
//  DawnGathering
//
//  Created by 李冬岐 on 2024/3/27.
//

#import "NumberEquitiesCollectionViewCell.h"

@implementation NumberEquitiesCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

+ (instancetype)xibTableViewCell{
    return [[[NSBundle mainBundle] loadNibNamed:@"NumberEquitiesCollectionViewCell" owner:nil options:nil] lastObject];
    
}


- (void)drawRect:(CGRect)rect{
    [super drawRect:rect];
    
    if(self.whiteBg.layer.cornerRadius == 0)
    {
        self.whiteBg.layer.cornerRadius = 10;
        
        self.merchandiseDiscountLabel.layer.masksToBounds = true;
        self.merchandiseDiscountLabel.layer.borderColor = [UIColor colorWithHexString:@"#FF462D"].CGColor;
        self.merchandiseDiscountLabel.layer.borderWidth = 1.0f / [UIScreen mainScreen].scale;
        self.merchandiseDiscountLabel.layer.cornerRadius = 2.0f;

        
        
        //获取UILabel上最后一个字符串的位置。
        CGPoint lastPoint;
        
        CGFloat totalWidth = (SCREEN_WIDTH - 15) / 2 - 15;
        
        NSAttributedString * attributeText = self.merchandiseAmountLabel.attributedText;
        
        CGRect rect = [attributeText boundingRectWithSize:CGSizeMake(MAXFLOAT,40) options: NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading context:nil];
        
        
        CGRect lineRect = [attributeText boundingRectWithSize:CGSizeMake(totalWidth, MAXFLOAT) options: NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading context:nil];
     

        if(rect.size.width <= lineRect.size.width) //判断是否折行
        {
            lastPoint = CGPointMake(rect.size.width, 0);
        }
        else
        {
            lastPoint = CGPointMake(rect.size.width - lineRect.size.width,lineRect.size.height - rect.size.height);
        }
        
        CGFloat left = lastPoint.x + 9;
        CGFloat top = 54 + lastPoint.y;
   
        if(left + 34.0 > totalWidth)
        {
            //没有换行但是超显示长度 //换行
            if(rect.size.width + 34.f <= totalWidth)
            {
                self.discountTopDistance.constant = top;
                self.discountLeftDistance.constant = left;
                
            }else{
                
                //此时为已经换行 需要换行的位置
                self.discountTopDistance.constant = top + 15;
                self.discountLeftDistance.constant = 5;
            }
            
        }else{
            //此时为并未超出显示范围默认就行
            self.discountTopDistance.constant = top;
           
            self.discountLeftDistance.constant = left;
        }
        
        self.whiteBg.layer.borderColor = UIColorFromRGB(0xEEEEEE).CGColor;
        self.whiteBg.layer.borderWidth = 1.0f / [UIScreen mainScreen].scale;

        
    }
}

@end
