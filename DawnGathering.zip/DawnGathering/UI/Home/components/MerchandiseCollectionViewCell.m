//
//  MerchandiseCollectionViewCell.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/8/14.
//

#import "MerchandiseCollectionViewCell.h"


NSString *MerchandiseCollectionViewCellString = @"MerchandiseCollectionViewCell";

@interface MerchandiseCollectionViewCell()
@property (weak, nonatomic) IBOutlet UIView *whiteBg;

@end

@implementation MerchandiseCollectionViewCell


+ (instancetype)xibTableViewCell{
    return [[[NSBundle mainBundle] loadNibNamed:MerchandiseCollectionViewCellString owner:nil options:nil] lastObject];
    
}


- (void)drawRect:(CGRect)rect{
    [super drawRect:rect];
    
    if(self.whiteBg.layer.cornerRadius == 0)
    {
        self.whiteBg.layer.cornerRadius = 10;
    }
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
