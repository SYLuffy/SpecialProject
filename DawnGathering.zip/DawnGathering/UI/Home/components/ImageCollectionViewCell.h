//
//  ImageCollectionViewCell.h
//  HLGA
//
//  Created by 李冬岐 on 2023/5/5.
//  Copyright © 2023 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ImageCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *contentImageView;
+ (instancetype)xibTableViewCell;
@end

NS_ASSUME_NONNULL_END
