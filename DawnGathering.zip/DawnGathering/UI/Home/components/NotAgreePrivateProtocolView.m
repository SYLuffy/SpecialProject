//
//  NotAgreePrivateProtocolView.m
//  StaffCulture
//
//  Created by 谢丹 on 2020/4/8.
//  Copyright © 2020 Linus. All rights reserved.
//

#import "NotAgreePrivateProtocolView.h"
#import "AppDelegate.h"

@implementation NotAgreePrivateProtocolView


- (void)awakeFromNib{
    [super awakeFromNib];
    
    self.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
    self.backgroundColor = [UIColor clearColor];
}


- (IBAction)agreePrivateProtocolCLick:(id)sender {
    
    AppDelegate *app = (AppDelegate *)[UIApplication sharedApplication].delegate;
    UIWindow*window = app.window;
    
    [UIView animateWithDuration:0.3f animations:^{
        window.alpha = 0.5;
    } completion:^(BOOL finished) {
        exit(0);
    }];
    
}

@end
