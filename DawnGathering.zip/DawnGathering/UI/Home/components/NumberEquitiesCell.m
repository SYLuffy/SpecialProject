//
//  NumberEquitiesCell.m
//  DawnGathering
//
//  Created by 李冬岐 on 2024/3/27.
//

#import "NumberEquitiesCell.h"
#import "NumberEquitiesCollectionViewCell.h"
#import "NumberEquitiesSingleColCollectionViewCell.h"



NSString *NumberEquitiesCellString = @"NumberEquitiesCellString";


@interface NumberEquitiesCell()<UICollectionViewDelegate,UICollectionViewDataSource>
@property (nonatomic,strong)NSArray * list;
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (nonatomic,assign)CGFloat radio;

@property (nonatomic,strong)NSMutableArray * recevieList;

@property (nonatomic,assign)NSInteger page;
@property (weak, nonatomic) IBOutlet UIView *moreView;


@end

@implementation NumberEquitiesCell

+ (instancetype)xibTableViewCell{
    return [[[NSBundle mainBundle] loadNibNamed:NumberEquitiesCellString owner:nil options:nil] lastObject];
    
}

- (void)awakeFromNib {
    [super awakeFromNib];
    self.collectionView.userInteractionEnabled = YES;
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc]init];
    layout.scrollDirection = UICollectionViewScrollDirectionVertical;

    self.collectionView.collectionViewLayout = layout;
    
    self.collectionView.delegate = self;
    self.collectionView.dataSource = self;
    self.collectionView.scrollEnabled = true;
    self.collectionView.showsHorizontalScrollIndicator = NO;
    
}
- (IBAction)tapMoreButtonHandler:(UIButton *)sender {
    //点击更多

    NSString * rightListURL = [SharedInstance getInstance].saasURLModel.rightsListURL;
    
    NSString * goWebURL = [rightListURL stringByReplacingOccurrencesOfString:@"${SELECTION_CODE}" withString:self.selectionCodes];
    
    [Utils pushWebViewControllerURL:goWebURL owner:[Utils getCurrentVC]];
    
}

- (void)radio:(CGFloat)radio titleHeight:(CGFloat)titleHeight{
   
    self.radio = radio;
    
    self.topDistance.constant = titleHeight;
    
    if(self.col == 1)
    {
        [self.collectionView registerNib:[UINib nibWithNibName:@"NumberEquitiesSingleColCollectionViewCell" bundle:[NSBundle mainBundle]] forCellWithReuseIdentifier:@"NumberEquitiesSingleColCollectionViewCell"];
    }else{
        [self.collectionView registerNib:[UINib nibWithNibName:@"NumberEquitiesCollectionViewCell" bundle:[NSBundle mainBundle]] forCellWithReuseIdentifier:@"NumberEquitiesCollectionViewCell"];
    }
    
    [self refreshHandler];
}

- (void)refreshHandler
{
    
    if(!self.pageSize) self.pageSize = @(10);
    
    [ServiceManager getMerchandiseWithPageNum:@(self.page + 1) pageSize:self.pageSize keyword:nil zoneId:NUMBER_EQUITIES selectionCodes:self.selectionCodes success:^(NSDictionary *data) {
        
        NSArray * records = data[RECORDS];
        NSNumber * total = data[TOTAL];
        
        if(self.page == 0)
        {
            self.list = records;
        }else{
            self.list = [self.list arrayByAddingObjectsFromArray:records];
        }
        [self.collectionView reloadData];
        
      
        if(self.refreshNumberEquitiesCellWithRow)
        {
            NSInteger row = self.list.count / self.col;
            
            if(self.list.count % self.col > 0)
            {
                row += 1;
            }
            //只有数据大于0 才刷新主页，否则将不刷新；
            if(self.list.count > 0)
            {
                self.refreshNumberEquitiesCellWithRow(row,self.index);
            }
        }
        
        if(total.integerValue > self.pageSize.integerValue)
        {
            self.moreView.hidden = false;
        }else{
            self.moreView.hidden = true;
        }
        
    } failure:^(NSError *error) {
        self.list = @[];
        
        [self.collectionView reloadData];
    }];
}


+ (CGFloat)getCellHeight:(NSInteger)row col:(NSInteger)col radio:(CGFloat)radio titleHeight:(CGFloat)titleHeight;
{
    CGFloat cellWidth = (SCREEN_WIDTH - 15) / col;
    
    CGFloat totalHeight = 0;
    
    CGFloat cellHeight = cellWidth * radio;;
    
    totalHeight = cellHeight * row;
    
    return totalHeight + 10 + titleHeight;
    
}

#pragma mark -- UICollectionViewDataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return [_list count];
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    
    NSDictionary *data = self.list[indexPath.row];
    
    NSString * imageURL = data[MAIN_IMAGE];
    NSString * name = data[NAME];
    NSString * amount = data[MARKET_PRICE];
    NSString * saleAmount = data[SALE_PRICE];
    NSString * discount = data[DISCOUNT];
    if(self.col == 1)
    {
        NumberEquitiesSingleColCollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"NumberEquitiesSingleColCollectionViewCell" forIndexPath:indexPath];
        
        if(!cell)
        {
            cell = (NumberEquitiesSingleColCollectionViewCell*)[Utils getXibByName:@"NumberEquitiesSingleColCollectionViewCell"];
        }
    
        cell.merchandiseNameLabel.text = name;
        
        NSString * amountTempStr;
        
        NSString * uint = [SharedInstance getInstance].uint;
        
        if([Utils checkObjectIsNull:saleAmount])
        {
            NSString * showText = [NSString stringWithFormat:@"%.2lf",saleAmount.integerValue * 0.01f];
            
            
            if(uint && uint.length > 0)
            {
                amountTempStr = [NSString stringWithFormat:@"%@%@",showText,uint];
            }else{
                amountTempStr = showText;
            }
        }else{
            cell.merchandiseAmountLabel.text = @"未知价格，需查询服务器";
            
            amountTempStr =  @"未知价格，需查询服务器";
        }
        
        NSString * historyAmountTempStr;
        
        if([Utils checkObjectIsNull:amount])
        {
            NSString * showText = [NSString stringWithFormat:@"%.2lf",amount.integerValue * 0.01f];
            
            if(uint && uint.length > 0)
            {
                historyAmountTempStr = [NSString stringWithFormat:@"%@%@",showText,uint];
            }else{
                historyAmountTempStr = showText;
            }
        }else{
            historyAmountTempStr = @"未知价格，需查询服务器";
        }
        NSString * showStr = [NSString stringWithFormat:@"%@%@",amountTempStr,historyAmountTempStr];
        
        cell.merchandiseAmountLabel.text = showStr;
        BOOL hasUint = uint.length > 0 ? true : false;
        [Utils labelColorAttributedStripingString:cell.merchandiseAmountLabel andRange:NSMakeRange(amountTempStr.length, historyAmountTempStr.length) color:UIColorFromRGB(0x999999) size:12 hasUint:hasUint];
        
        
    //      NSLog(@"%@",imageURL);
        if([Utils checkObjectIsNull:imageURL])
        {
            
            NSString * imageRightURL;
            if([imageURL hasPrefix:@"http"] == false){
            
                imageRightURL = [NSString stringWithFormat:@"https:%@",imageURL];
            }else{
                imageRightURL = imageURL;
            }
            
            [Utils loadImage:cell.merchandiseImageView andURL:imageRightURL isLoadRepeat:true];
        }
        
        if(indexPath.row == self.list.count -1)
        {
            cell.bottomLine.hidden = true;
        }
        
        cell.merchandiseDiscountLabel.text = [NSString stringWithFormat:@"%@折",discount];
        
        return cell;
    }
    
    
    NumberEquitiesCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"NumberEquitiesCollectionViewCell" forIndexPath:indexPath];
    
    if (!cell) {
        cell = [NumberEquitiesCollectionViewCell xibTableViewCell];
    }
    
    cell.merchandiseNameLabel.text = name;
    
    NSString * amountTempStr;
    
    NSString * uint = [SharedInstance getInstance].uint;
    
    if([Utils checkObjectIsNull:saleAmount])
    {
        NSString * showText = [NSString stringWithFormat:@"%.2lf",saleAmount.integerValue * 0.01f];
        
        
        if(uint && uint.length > 0)
        {
            amountTempStr = [NSString stringWithFormat:@"%@%@",showText,uint];
        }else{
            amountTempStr = showText;
        }
    }else{
        cell.merchandiseAmountLabel.text = @"未知价格，需查询服务器";
        
        amountTempStr =  @"未知价格，需查询服务器";
    }
    
    NSString * historyAmountTempStr;
    
    if([Utils checkObjectIsNull:amount])
    {
        NSString * showText = [NSString stringWithFormat:@"%.2lf",amount.integerValue * 0.01f];
        
        if(uint && uint.length > 0)
        {
            historyAmountTempStr = [NSString stringWithFormat:@"%@%@",showText,uint];
        }else{
            historyAmountTempStr = showText;
        }
    }else{
        historyAmountTempStr = @"未知价格，需查询服务器";
    }
    NSString * showStr = [NSString stringWithFormat:@"%@%@",amountTempStr,historyAmountTempStr];
    
    cell.merchandiseAmountLabel.text = showStr;

    BOOL hasUint = uint.length > 0 ? true : false;
    [Utils labelColorAttributedStripingString:cell.merchandiseAmountLabel andRange:NSMakeRange(amountTempStr.length, historyAmountTempStr.length) color:UIColorFromRGB(0x999999) size:12 hasUint:hasUint];
    
    
//      NSLog(@"%@",imageURL);
    if([Utils checkObjectIsNull:imageURL])
    {
        
        NSString * imageRightURL;
        if([imageURL hasPrefix:@"http"] == false){
        
            imageRightURL = [NSString stringWithFormat:@"https:%@",imageURL];
        }else{
            imageRightURL = imageURL;
        }
        
        [Utils loadImage:cell.merchandiseImageView andURL:imageRightURL isLoadRepeat:true];
    }
    
    cell.merchandiseDiscountLabel.text = [NSString stringWithFormat:@"%@折",discount];
    return cell;
}


- (BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    NSDictionary * dic = self.list[indexPath.row];
    
    if(self.tapNumberEquitiesWithIndex){
        
        NSMutableString * goURL = dic[@"descriptionUrl"];
        
        self.tapNumberEquitiesWithIndex(indexPath.row,goURL.copy,@2,@0);
    }
}
#pragma UICollectionViewDelegateFlowLayout

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    CGFloat cellWidth = (SCREEN_WIDTH - 15) / self.col;
    CGFloat cellHeight = cellWidth * self.radio;
    
    return CGSizeMake(cellWidth,cellHeight);
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    
    return 0;
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return 0;
}
- (UIEdgeInsets) collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(0, 0, 0, 0);
}

@end
