//
//  SmallBannerImageCell.h
//  Banks
//
//  Created by 李冬岐 on 2022/9/19.
//  Copyright © 2022 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SDCycleScrollView.h"
typedef void(^SmallBannerCellBlock)(NSInteger index , NSArray * _Nullable items);
NS_ASSUME_NONNULL_BEGIN

@interface SmallBannerImageCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIView *bgView;
@property(nonatomic,strong)SDCycleScrollView *scrollView;
@property(nonatomic,copy)SmallBannerCellBlock selectItemBlock;
@property(nonatomic,strong)NSArray * items;

+(instancetype)xibTableViewCell;
+ (NSInteger)getBannerCellRowHeight:(NSInteger)count;
-(void)updateTableViewCellWithData:(NSArray *)data;
@end

NS_ASSUME_NONNULL_END
