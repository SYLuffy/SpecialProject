//
//  ImageCollectionViewCell.m
//  HLGA
//
//  Created by 李冬岐 on 2023/5/5.
//  Copyright © 2023 Linus. All rights reserved.
//

#import "ImageCollectionViewCell.h"


NSString *CollectionViewCellString = @"ImageCollectionViewCell";

@implementation ImageCollectionViewCell


+ (instancetype)xibTableViewCell{
    return [[[NSBundle mainBundle] loadNibNamed:CollectionViewCellString owner:nil options:nil] lastObject];
    
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
