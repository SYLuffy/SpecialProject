//
//  PrivacyPopView.h
//  TIFamily
//
//  Created by 李冬岐 on 2019/9/29.
//  Copyright © 2019 葛亮. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>

typedef void(^AgreeAction)(void);


NS_ASSUME_NONNULL_BEGIN

@interface PrivacyPopView : UIView <WKNavigationDelegate,WKUIDelegate>

@property (weak, nonatomic) IBOutlet UIButton *notAgreeButton;

@property (strong, nonatomic) WKWebView *webView;
@property (weak, nonatomic) IBOutlet UIView *darkView;
@property (weak, nonatomic) IBOutlet UIView *popView;


@property (nonatomic,strong)AgreeAction agreeAction;

- (void)fadeIn;
- (void)fadeOut;

@end

NS_ASSUME_NONNULL_END
