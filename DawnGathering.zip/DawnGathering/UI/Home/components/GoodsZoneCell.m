//
//  GoodsZoneCell.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/8/14.
//

#import "GoodsZoneCell.h"
#import "MerchandiseCollectionViewCell.h"
#import "GCDTimer.h"
//#import <TABAnimated.h>

#define CELL_LABEL_GAP_HEIGHT 60

@interface GoodsZoneCell()<UICollectionViewDelegate,UICollectionViewDataSource>
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (weak, nonatomic) IBOutlet UIImageView *backgroundImageView;
@property (weak, nonatomic) IBOutlet UIImageView *titleImageView;
@property (weak, nonatomic) IBOutlet UILabel *hourLabel;
@property (weak, nonatomic) IBOutlet UILabel *minuteLabel;
@property (weak, nonatomic) IBOutlet UILabel *secondLabel;
@property (weak, nonatomic) IBOutlet UIView *timeViewContainer;

@property (nonatomic,strong)NSArray * dataSource;
@property (nonatomic,assign)NSInteger page;

@property (nonatomic,strong)GCDTimer * timer;

@property (nonatomic,assign)NSInteger countDown;
@end

@implementation GoodsZoneCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.collectionView.userInteractionEnabled = YES;
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc]init];
    layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;

    self.collectionView.collectionViewLayout = layout;
    [self.collectionView registerNib:[UINib nibWithNibName:@"MerchandiseCollectionViewCell" bundle:[NSBundle mainBundle]] forCellWithReuseIdentifier:@"MerchandiseCollectionViewCell"];
    self.collectionView.delegate = self;
    self.collectionView.dataSource = self;
    self.collectionView.scrollEnabled = true;
    self.collectionView.showsHorizontalScrollIndicator = NO;
    self.countDown = 0;
    
//    self.collectionView.tabAnimated = [TABCollectionAnimated animatedWithCellClass:[MerchandiseCollectionViewCell class] cellSize:CGSizeMake(1, 1)];
    
//    [Utils gradualChangeBottomToTopColor:self.hourLabel.layer withStartColor:0xF28D3B withEndColor:0xFA7F5F];
//    [Utils gradualChangeBottomToTopColor:self.minuteLabel.layer withStartColor:0xF28D3B withEndColor:0xFA7F5F];
//    [Utils gradualChangeBottomToTopColor:self.secondLabel.layer withStartColor:0xF28D3B withEndColor:0xFA7F5F];
    self.hourLabel.layer.masksToBounds = true;
    self.hourLabel.layer.cornerRadius = 3;
    
    self.minuteLabel.layer.masksToBounds = true;
    self.minuteLabel.layer.cornerRadius = 3;
    
    self.secondLabel.layer.masksToBounds = true;
    self.secondLabel.layer.cornerRadius = 3;
}


- (void)startTimer
{
    if (self.timer) {
        return;
    }
    //开启定时器
    WS(weakSelf);
    self.timer = [GCDTimer scheduleTimer:1 actionBlock:^{
        [weakSelf handleEvent];
    } willRepeat:YES];
}

- (void)handleEvent
{
    //NSInteger nowTime = [Utils getNowTimeTimestamp].integerValue;
    
    self.countDown --;
   
    NSString * showTime = [Utils timeWithSecond:self.countDown];
    
    //self.timeLabel.text = [NSString stringWithFormat:@"剩余时间 %@",showTime];
    self.hourLabel.text = [showTime substringWithRange:NSMakeRange(0, 2)];
    
    self.minuteLabel.text = [showTime substringWithRange:NSMakeRange(3, 2)];
    
    self.secondLabel.text = [showTime substringWithRange:NSMakeRange(6, 2)];
    
    
}

- (void)stopTimer
{
    if (!self.timer) {
        return;
    }
    
    [self.timer stop];
    self.timer = nil;
}


- (void)dealloc{
    [self stopTimer];
}

- (void)refreshHandler
{
    if(self.isShowMore.integerValue == 1)
    {
        self.moreLabel.hidden = false;
        self.moreButton.hidden = false;
        self.moreImageView.hidden = false;
    }else{
        self.moreLabel.hidden = true;
        self.moreButton.hidden = true;
        self.moreImageView.hidden = true;
    }
    
    if(self.isShowCountDown.integerValue == 1)
    {
        self.timeViewContainer.hidden = false;
    }else{
        self.timeViewContainer.hidden = true;
    }
    
    
    [Utils loadImage:self.backgroundImageView andURL:self.bgImgURL isLoadRepeat:false];
    
    
    
    if(!self.pageSize) self.pageSize = @(10);
    [ServiceManager getMerchandiseWithPageNum:@(self.page + 1) pageSize:self.pageSize keyword:nil zoneId:self.zoneId selectionCodes:self.selectionCodes success:^(NSDictionary *data) {
        
        NSArray * records = data[RECORDS];
        NSNumber * coundDown = data[REMAINING_SECONDS];
        
        self.countDown = coundDown.integerValue;
        
        if(self.countDown == 0)
        {
            self.timeViewContainer.hidden = true;
        }else{
            [self startTimer];
        }
        
        if(self.page == 0)
        {
            self.dataSource = records;
        }else{
            self.dataSource = [self.dataSource arrayByAddingObjectsFromArray:records];
        }
        [self.collectionView reloadData];
        
      
        
    } failure:^(NSError *error) {
        self.timeViewContainer.hidden = true;
    }];
}
- (IBAction)tapMoreHandler:(UIButton *)sender {
    //点击更多;
    
    NSString * searchURL = [NSString stringWithFormat:@"%@?%@=%@",[SharedInstance getInstance].saasURLModel.searchURL,SELECTION_CODES,self.selectionCodes];
    [Utils pushWebViewControllerURL:searchURL owner:[Utils getCurrentVC]];
}


#pragma mark -- UICollectionViewDataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.dataSource.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    MerchandiseCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"MerchandiseCollectionViewCell" forIndexPath:indexPath];
    if (!cell) {
        cell = [MerchandiseCollectionViewCell xibTableViewCell];
    }
    
    NSDictionary *data = self.dataSource[indexPath.row];
    
    NSString * imageURL = data[MAIN_IMAGE];
    NSString * name = data[NAME];
    NSString * amount = data[MARKET_PRICE];
    NSString * saleAmount = data[SALE_PRICE];
    
    cell.merchandiseNameLabel.text = name;
    
    NSString * amountTempStr;
    
    NSString * uint = [SharedInstance getInstance].uint;
    
    if([Utils checkObjectIsNull:saleAmount])
    {
        NSString * showText = [NSString stringWithFormat:@"%.2lf",saleAmount.integerValue * 0.01f];
        
        
        if(uint && uint.length > 0)
        {
            amountTempStr = [NSString stringWithFormat:@"%@%@",showText,uint];
        }else{
            amountTempStr = showText;
        }
    }else{
        cell.merchandiseAmountLabel.text = @"未知价格，需查询服务器";
        
        amountTempStr =  @"未知价格，需查询服务器";
    }
    
    NSString * historyAmountTempStr;
    
    if([Utils checkObjectIsNull:amount])
    {
        NSString * showText = [NSString stringWithFormat:@"%.2lf",amount.integerValue * 0.01f];
        
        if(uint && uint.length > 0)
        {
            historyAmountTempStr = [NSString stringWithFormat:@"%@%@",showText,uint];
        }else{
            historyAmountTempStr = showText;
        }
    }else{
        cell.merchandiseHistoryAmountLabel.text = @"未知价格，需查询服务器";
        
        historyAmountTempStr = @"未知价格，需查询服务器";
    }
    NSString * showStr = [NSString stringWithFormat:@"%@%@",amountTempStr,historyAmountTempStr];
    
    cell.merchandiseAmountLabel.text = showStr;
    BOOL hasUint = uint.length > 0 ? true : false;
    [Utils labelColorAttributedStripingString:cell.merchandiseAmountLabel andRange:NSMakeRange(amountTempStr.length, historyAmountTempStr.length) color:UIColorFromRGB(0x999999) size:12 hasUint:hasUint];
    
    
    cell.merchandiseHistoryAmountLabel.text = @"";
    
//      NSLog(@"%@",imageURL);
    if([Utils checkObjectIsNull:imageURL])
    {
        
        NSString * imageRightURL;
        if([imageURL hasPrefix:@"http"] == false){
        
            imageRightURL = [NSString stringWithFormat:@"https:%@",imageURL];
        }else{
            imageRightURL = imageURL;
        }
        
        [Utils loadImage:cell.merchandiseImageView andURL:imageRightURL isLoadRepeat:true];
    }
    
    return cell;
}


- (BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    if(self.tapGoodsZoneWithIndexHandler){
        
        NSDictionary * dic = self.dataSource[indexPath.row];
        
        NSArray * originalStrings = @[@"${SPU_NO}",@"${SELECTION_CODE}",@"${SKU_NO}"];
        
        NSString * selectionCode = dic[SELECTION_CODE];
        
        NSString * skuNo = dic[SKU_NO];
        NSString * spuNo = dic[SPU_NO];
        
        NSArray * replaceStringgs = @[spuNo,selectionCode,skuNo];
        
        NSMutableString * goURL = [SharedInstance getInstance].saasURLModel.goodsDetailURL.mutableCopy;
        
        for(NSInteger i = 0;i < originalStrings.count; i ++)
        {
            NSString * replace = replaceStringgs[i];
            NSString * original = originalStrings[i];
            goURL = [goURL stringByReplacingOccurrencesOfString:original withString:replace].mutableCopy;
        }
        
        self.tapGoodsZoneWithIndexHandler(indexPath.row,goURL.copy,@2);
    }
}
#pragma UICollectionViewDelegateFlowLayout

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    CGFloat cellWidth = (SCREEN_WIDTH - 30) / 3.33;
    
    CGFloat cellHeight = self.cellHeight - 70;
    
    return CGSizeMake(cellWidth,cellHeight);
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    
    return 0;
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return 0;
}
- (UIEdgeInsets) collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(0, 0, 0, 0);
}

@end
