//
//  NormalNavigationCell.m
//  SCST
//
//  Created by 葛亮 on 2019/5/16.
//  Copyright © 2019 葛亮. All rights reserved.
//

#import "NormalNavigationCell.h"

@implementation NormalNavigationCell
+ (instancetype)xibTableViewCell{
    return [[[NSBundle mainBundle] loadNibNamed:@"NormalNavigationCell" owner:nil options:nil] lastObject];
    
}
- (void)awakeFromNib {
    [super awakeFromNib];
    self.titileLable.font = [UIFont fontWithName:[Utils getGlobalFontName] size:12];

    
    [self layoutIfNeeded];
}

@end
