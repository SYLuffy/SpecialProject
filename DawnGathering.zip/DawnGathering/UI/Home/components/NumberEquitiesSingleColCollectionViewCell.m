//
//  NumberEquitiesSingleColCollectionViewCell.m
//  DawnGathering
//
//  Created by 李冬岐 on 2024/3/27.
//

#import "NumberEquitiesSingleColCollectionViewCell.h"

@implementation NumberEquitiesSingleColCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)drawRect:(CGRect)rect
{
    [super drawRect:rect];
    
    if(self.merchandiseDiscountLabel.layer.masksToBounds == false)
    {
        self.merchandiseDiscountLabel.layer.masksToBounds = true;
        self.merchandiseDiscountLabel.layer.borderColor = [UIColor colorWithHexString:@"#FF462D"].CGColor;
        self.merchandiseDiscountLabel.layer.borderWidth = 1.0f / [UIScreen mainScreen].scale;
        self.merchandiseDiscountLabel.layer.cornerRadius = 2.0f;
    }
    
}

@end
