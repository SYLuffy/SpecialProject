//
//  SmallBannerImageCell.m
//  Banks
//
//  Created by 李冬岐 on 2022/9/19.
//  Copyright © 2022 Linus. All rights reserved.
//

#import "SmallBannerImageCell.h"

@interface SmallBannerImageCell()<SDCycleScrollViewDelegate>
{
    NSArray *_list;
}

@end

@implementation SmallBannerImageCell

-(SDCycleScrollView *)scrollView{
    
    if (!_scrollView) {
        _scrollView = [SDCycleScrollView cycleScrollViewWithFrame:CGRectMake(0, 0,[UIScreen mainScreen].bounds.size.width - 30, [SmallBannerImageCell getBannerCellRowHeight:_list.count] - 15) delegate:self placeholderImage:nil];
        _scrollView.pageControlAliment = SDCycleScrollViewPageContolAlimentCenter;
        _scrollView.titleLabelHeight = 20;
        _scrollView.placeholderImage= [UIImage imageNamed:@"default_home_newspic"];
        _scrollView.pageControlBottomOffset = -53;
        _scrollView.titleLabelTextFont = [UIFont fontWithName:@"PingFangSC-Regular" size:14];
        _scrollView.titleLabelBackgroundColor =  [UIColor colorWithRed:0/255.0 green:0/255.0 blue:0/255.0 alpha:0.8];
        _scrollView.titleLabelTextColor = [UIColor whiteColor];
        _scrollView.currentPageDotColor = [UIColor colorWithHexString:@"666666"];
        _scrollView.pageDotColor = [UIColor colorWithHexString:@"DEDEDE"];
        _scrollView.backgroundColor = [UIColor clearColor];
        _scrollView.showPageControl = NO;
//        _scrollView.layer.cornerRadius = _scrollView.frame.size.height * 0.5;
        _scrollView.layer.masksToBounds = YES;
        _scrollView.bannerImageViewContentMode =  UIViewContentModeScaleToFill;
        _scrollView.autoScrollTimeInterval = 3;
        
    }
    return _scrollView;
}




- (void)awakeFromNib {
    
    [super awakeFromNib];
    [self layoutIfNeeded];

    
}

+ (instancetype)xibTableViewCell{
    return [[[NSBundle mainBundle] loadNibNamed:@"BannerImageCell" owner:nil options:nil] lastObject];
}

#pragma SDCycleScrollViewDelegate

/** 点击图片回调 */
- (void)cycleScrollView:(SDCycleScrollView *)cycleScrollView didSelectItemAtIndex:(NSInteger)index{
    
    if(_selectItemBlock){
        _selectItemBlock(index, self.items);
    }
}

/** 图片滚动回调 */
- (void)cycleScrollView:(SDCycleScrollView *)cycleScrollView didScrollToIndex:(NSInteger)index{

    

}

+ (NSInteger)getBannerCellRowHeight:(NSInteger)count{
    
    if(count > 1)
    {
        return [UIScreen mainScreen].bounds.size.width * 0.34;
    }else{
        return [UIScreen mainScreen].bounds.size.width * 0.28;
    }

}

-(void)updateTableViewCellWithData:(NSArray *)data{
    _list = data;
    
    NSMutableArray * images = [NSMutableArray array];
    
    for(NSDictionary * dic in data)
    {
        NSString * url = dic[IMG_URL];
        
        [images addObject:url];
    }
    
    self.scrollView.imageURLStringsGroup = [images copy];
    [self.bgView addSubview:self.scrollView];
}
@end
