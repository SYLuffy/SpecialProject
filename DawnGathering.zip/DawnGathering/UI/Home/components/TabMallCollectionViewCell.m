//
//  TabMallCollectionViewCell.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/8/11.
//

#import "TabMallCollectionViewCell.h"

@interface TabMallCollectionViewCell()

@end

@implementation TabMallCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
