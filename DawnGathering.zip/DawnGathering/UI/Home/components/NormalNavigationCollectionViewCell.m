//
//  HomeNewClassifyCell.m
//  SCST
//
//  Created by 葛亮 on 2019/5/16.
//  Copyright © 2019 葛亮. All rights reserved.
//

#import "NormalNavigationCollectionViewCell.h"
#import "UICollectionViewLeftAlignedLayout.h"
#import "LXKit.h"
#import <UIImageView+WebCache.h>
#import "HorizontalCollectionViewFlowLayout.h"




@interface NormalNavigationCollectionViewCell()<UICollectionViewDelegate,UICollectionViewDataSource>{
    NSArray *_list;
}

@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;

@property (nonatomic,assign)NSString * currentPage;

@property (nonatomic, strong) LXSlideIndicator *slideIndicator;
@property (nonatomic, strong)NSString * tabsColor;
@property (nonatomic, strong)NSString * textColor;
@property (nonatomic, assign)NSInteger line;
@property (nonatomic, assign)NSInteger col;

@property (nonatomic,assign)CGSize size;

@end
@implementation NormalNavigationCollectionViewCell

+ (instancetype)xibTableViewCell{
    return [[[NSBundle mainBundle] loadNibNamed:@"NormalNavigationCollectionViewCell" owner:nil options:nil] lastObject];
    
}
- (void)awakeFromNib {
    [super awakeFromNib];
    self.collectionView.userInteractionEnabled = YES;

    [self.collectionView registerNib:[UINib nibWithNibName:@"NormalNavigationCell" bundle:[NSBundle mainBundle]] forCellWithReuseIdentifier:@"NormalNavigationCell"];
    self.collectionView.delegate = self;
    self.collectionView.dataSource = self;
    self.collectionView.scrollEnabled = true;
    self.collectionView.showsHorizontalScrollIndicator = NO;
    self.currentPage = 0;

}


- (void)initSlideIndicator {
    if (!self.slideIndicator) {
        
        
        if(_list.count > self.line * self.col)
        {
            LXSlideIndicatorConfig *config = [LXSlideIndicatorConfig new];
            config.width = 50;
            config.height = 4;
            config.backgroundColor = UIColorFromRGB(0xEEEEEE);
            config.slideViewColor = [Utils getMainColor];
            self.slideIndicator = [[LXSlideIndicator alloc] initWithConfig:config];
            self.slideIndicator.frame = CGRectMake((SCREEN_WIDTH - config.width) * 0.5, 0, config.width, config.height);
            [self.bottomEmptyView addSubview:self.slideIndicator];
            
            
        }
        
        
    }
}
-(void)setCellData:(NSArray *)data line:(NSInteger)line col:(NSInteger)col tabsColor:(NSString*)tabsColor textColor:(NSString*)textColor{
    
    
    self.col = col;
    self.tabsColor = tabsColor;
    self.textColor = textColor;
    
    self.line = line;
    
    _list = data;
    
    [self initSlideIndicator];
    
    HorizontalCollectionViewFlowLayout *layout = [[HorizontalCollectionViewFlowLayout alloc]init];
    layout.size = self.size;
    layout.row =self.line;
    layout.column = self.col;
    layout.columnSpacing = 0;
    layout.rowSpacing = 0;
    
    self.collectionView.collectionViewLayout = layout;
    [self.collectionView reloadData];
}

+ (CGFloat)getCellHeight:(NSArray*)list line:(NSInteger)line;
{
    CGFloat totalHeight;
    
    CGFloat height = SCREEN_WIDTH / 375 * 40.0f + 34.0f;
     
    totalHeight = height * line;
    
    return totalHeight + 10;
    
}

#pragma mark --  UICollectionViewDataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return [_list count];
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    NormalNavigationCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"NormalNavigationCell" forIndexPath:indexPath];
    if (!cell) {
        cell = [NormalNavigationCell xibTableViewCell];
    }
    
    NSDictionary *data = _list[indexPath.row];
    [cell.headImageView sd_setImageWithURL:[NSURL URLWithString:data[@"imgUrl"]] placeholderImage:[UIImage imageNamed:@"img_zhanweitu"]];
    cell.titileLable.text = data[@"name"];
    
    cell.titileLable.textColor = [UIColor colorWithHexString:self.textColor];
    //cell.contentView.backgroundColor = [UIColor colorWithHexString:self.tabsColor];
    
    
    
    return cell;
}
-(BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    if(self.homeNewClassifyCellBlock){
        
        
        NSDictionary * dic  = _list[indexPath.row];
        
        NSString * goURL;
        
        NSNumber * jumpType = dic[JUMP_TYPE];
        
        if(jumpType.integerValue == 3)
        {
            NSDictionary * shopSet = dic[SHOP_SET];
            
            goURL = [Utils dictionaryToJson:shopSet];
        }else{
            goURL = dic[HREF_URL];
        }
        
        
        if([goURL isKindOfClass:[NSString class]] &&  [goURL isEqualToString:CLASSIFY])
        {
            [SharedInstance getInstance].currentClassifyID = dic[CLASSIFY_ID];
        }
        
        NSNumber * blackWhiteId = dic[BLACK_WHITE_ID];
        
        NSArray * blackWhiteList = dic[WHITE_IDS];
        
        [SharedInstance getInstance].sendBlackWhiteList = blackWhiteList;
        
        self.homeNewClassifyCellBlock(indexPath.row,goURL,jumpType,blackWhiteId);
    }
}
#pragma UICollectionViewDelegateFlowLayout

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    CGFloat width;
    
    NSInteger count = self.col;
    
    NSInteger sub = _list.count % self.line;
    
    if(sub > 0) count += sub;
    
    
    width = [UIScreen mainScreen].bounds.size.width / count;
    
    return CGSizeMake(width,SCREEN_WIDTH / 375 * 40.0f + 34.0f);
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    
    return 0;
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return 0;
}
- (UIEdgeInsets) collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(0, 0, 0, 0);
}

#pragma mark - UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (scrollView == self.collectionView) {
        [self.slideIndicator scrollViewRelativeDidScroll:scrollView];
    }
}

- (CGSize)size
{
    CGFloat width;
    
    NSInteger count = self.col;
    
    width = [UIScreen mainScreen].bounds.size.width / count;
    
    CGFloat height = SCREEN_WIDTH / 375 * 40.0f + 34.0f;
    
    return CGSizeMake(width, height);
}

@end
