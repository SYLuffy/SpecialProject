//
//  HomeMerchantListCell.m
//  DawnGathering
//
//  Created by 李冬岐 on 2024/2/2.
//

#import "HomeMerchantListCell.h"
#import "MerchantMapListCell.h"
#import "QuickRefresh.h"
#import "MenuModel.h"
#import "SystemAuthority.h"

@interface HomeMerchantListCell()<UITableViewDelegate,UITableViewDataSource>

@property (weak, nonatomic) IBOutlet UITableView *listTableView;

@property (nonatomic,strong)NSArray * dataSource;

@property (nonatomic,assign)NSInteger pageSize;

@property (nonatomic,strong)QuickRefresh * refresh;

@property (nonatomic,assign)NSInteger page;

@property (nonatomic,assign)BOOL isGetUserLocation;

@property (nonatomic,strong)UIColor * menuTextColor;

@property (nonatomic,strong)MenuModel * menuModel;

@property (nonatomic,strong)NSMutableArray <NSString*>* items;

@property (nonatomic,strong)NSString * areaIndexId;
@property (nonatomic,strong)NSString * merchantIndexId;
@property (nonatomic,strong)NSString * sortType;

@property (nonatomic,strong)NSNumber * lat;
@property (nonatomic,strong)NSNumber * lng;

@property (nonatomic,strong)AMapLocationManager * locationManager;

@property (nonatomic,strong)NSString * cityName;

@property (nonatomic,strong)NSString * requestId;

@property (nonatomic,strong)NSNumber * blackWhiteId;
@property (nonatomic,strong)NSArray * blackWhiteIdList;

@end
@implementation HomeMerchantListCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.items = [NSMutableArray array];
    self.areaIndexId = @"";
    self.merchantIndexId = @"";
    self.sortType = @"";
    self.requestId = @"";
    self.page = 1;
    self.listTableView.dataSource = self;
    self.listTableView.delegate = self;
    
    self.listTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    self.listTableView.tableFooterView = [UIView new];
    
    self.listTableView.scrollEnabled = false;
    
}
- (IBAction)tapAllStoreHandler:(UIButton *)sender {
    //全部商户;
    if(self.tapHomeAllMerchantListHandler)
    {
        self.tapHomeAllMerchantListHandler(self.blackWhiteId);
    }
}

- (void)setMerchantListWithListCount:(NSInteger)count blackWhiteId:(NSNumber*)blackWhiteId blackWhiteIdList:(NSArray*)blackWhiteIdList{
    
    _pageSize = count;
    
    self.blackWhiteId = blackWhiteId;
    
    self.blackWhiteIdList = blackWhiteIdList;
    
    [self.listTableView reloadData];
    
    NSString * defaultCityName = [Utils getUserDefaultByKey:USER_DEFAULT_CITY];
    
    if(defaultCityName && defaultCityName.length > 0)
    {
        self.cityName = defaultCityName;
        self.lat = [Utils getUserDefaultByKey:USER_DEFAULT_LATITUDE];
        self.lng = [Utils getUserDefaultByKey:USER_DEFAULT_LONGITUDE];
        
        [self refreshHandler];
    }
    
    [self getUserLocation];
}

- (void)getUserLocation
{
    TenAuthorizationStatus status = [SystemAuthority locationStatus];
    
    if(status == TenAuthorizationStatusAuthorized)
    {
        //同意授权;
        self.isGetUserLocation = true;
    }else if(status == TenAuthorizationStatusNotDetermined)
    {
        //未确定;
        self.isGetUserLocation = false;
        [SystemAuthority getLocationAuthority:^(BOOL isOpen) {
            self.isGetUserLocation = isOpen;
        }];
    }else{
        self.isGetUserLocation = false;
        
    }
    // 带逆地理（返回坐标和地址信息）。将下面代码中的 YES 改成 NO ，则不会返回地址信息。
    [self.locationManager requestLocationWithReGeocode:YES completionBlock:^(CLLocation *location, AMapLocationReGeocode *regeocode, NSError *error) {
        
        if (error)
        {
            NSLog(@"locError:{%ld - %@};", (long)error.code, error.localizedDescription);
            
            self.menuTextColor = ENABLE_MENU_TEXT_COLOR;
            
            if (error.code != AMapLocationErrorLocateFailed)
            {
                [self getUserLocation];
            }else{
                
                NSString * defaultCity = [Utils getUserDefaultByKey:USER_DEFAULT_CITY];
                
                if(defaultCity && defaultCity.length > 0)
                {
                    self.cityName = defaultCity;
                    self.lat = [Utils getUserDefaultByKey:USER_DEFAULT_LATITUDE];
                    self.lng = [Utils getUserDefaultByKey:USER_DEFAULT_LONGITUDE];
                }else{
                    self.cityName = @"成都市";
                    self.lat = [NSNumber numberWithInt:0];
                    self.lng = [NSNumber numberWithInt:0];
                }
                
                [self refreshHandler];
            }
            return;
        }
        
        self.menuTextColor = DEFAULT_MENU_TEXT_COLOR;
        
        NSString * latString = [NSString stringWithFormat:@"%.6lf",location.coordinate.latitude];
        NSString * lngString = [NSString stringWithFormat:@"%.6lf",location.coordinate.longitude];
        
        self.lat = [NSNumber numberWithFloat:latString.floatValue];
        self.lng = [NSNumber numberWithFloat:lngString.floatValue];
        
        [Utils setUserDefaultByKey:USER_DEFAULT_CITY andValue:regeocode.city];
        [Utils setUserDefaultByKey:USER_DEFAULT_LATITUDE andValue:self.lat];
        [Utils setUserDefaultByKey:USER_DEFAULT_LONGITUDE andValue:self.lng];
        
        self.cityName = regeocode.city;
        
        [self refreshHandler];
    }];
    
    
}

- (void)gotoMerchantDetailHandlerWithMerchantId:(NSNumber*)merchantId distance:(NSNumber*)distance
{
    if(self.tapHomeMerchantListMerchantId)
    {
        self.tapHomeMerchantListMerchantId(merchantId , distance , self.lat, self.lng, self.cityName);
    }
}


+ (CGFloat)getMerchantListCellHeightWithCount:(NSInteger)count
{
    CGFloat height = count * 125.0f;
    return height + 70.0f;
}

#pragma mark -- UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;
{
    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    MerchantMapListCell * cell = [tableView dequeueReusableCellWithIdentifier:@"MerchantMapListCell"];
    NSDictionary * dic = self.dataSource[indexPath.row];
    if(!cell)
    {
        cell = (MerchantMapListCell*)[Utils getXibByName:@"MerchantMapListCell"];
    }
    WS(weakSelf);
    cell.tapMerchantWithIdHandler = ^(NSNumber * _Nullable merchantId , NSNumber * _Nullable distance) {
        [weakSelf gotoMerchantDetailHandlerWithMerchantId:merchantId distance:distance];
    };
    
    if([dic isKindOfClass:[NSNumber class]] == false){
        NSString * imgURL = dic[IMG];
        if(imgURL.length == 0 || !imgURL)
        {
            imgURL = dic[BRAND_LOGO];
        }
        NSString * typeLogo = dic[TYPE_LOGO];
        NSString * merhcantName = dic[MERCHANT_NAME];
        NSString * typeName = dic[TYPE_NAME];
        NSString * areaName = dic[AREA_NAME];
        NSNumber * distance = dic[DISTANCE];
        NSNumber * merchantId = dic[MERCHANT_ID];
        cell.merchantTitleLabel.text = merhcantName;
        cell.merchantAddressLabel.text = areaName;
        cell.merchantTypeLabel.text = typeName;
        [Utils loadImage:cell.merchantImageView andURL:imgURL isLoadRepeat:false];
        if(typeLogo && typeLogo.length > 0)
        {
            [Utils loadImage:cell.typeLogoImageView andURL:typeLogo isLoadRepeat:false];
            cell.typeLogoImageView.hidden = false;
            cell.typeNameLeft.constant = 29;
        }else{
            cell.typeLogoImageView.hidden = true;
            cell.typeNameLeft.constant = 10;
        }
        cell.distance = distance;
        cell.merchantId = merchantId;
        NSString *uint;
        CGFloat showDis = 0;
        
        if(distance.integerValue > 1000)
        {
            uint = @"km";
            showDis = distance.floatValue / 1000;
            cell.merchantDistanceLabel.text = [NSString stringWithFormat:@"%.2lf%@",showDis,uint];
        }else{
            uint = @"m";
            showDis = distance.floatValue;
            cell.merchantDistanceLabel.text = [NSString stringWithFormat:@"%.0lf%@",showDis,uint];
        }
        
        NSArray * items = dic[ITEMS];
        if([Utils checkObjectIsNull:items] && items.count > 0)
        {
            [cell setItems:items];
        }
    }
    return cell;
}

#pragma mark -- UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 125.0f;
}

- (void)refreshHandler{
    
    if(!_blackWhiteIdList)
    {
        _blackWhiteIdList = [SharedInstance getInstance].sendBlackWhiteList;
    }
    //请求数据
    [ServiceManager getMerchantListWithItems:self.items word:@"" isCutWord:true Lng:self.lng Lat:self.lat resId:self.requestId page:@(self.page) pageSize:@(self.pageSize) areaIndex:self.areaIndexId merchantIndex:self.merchantIndexId sortType:self.sortType blackWhiteId:self.blackWhiteId brandIndex:@"" blackWhiteIdList:self.blackWhiteIdList brandIndexList:nil success:^(NSDictionary *data) {
        
        NSDictionary * dic = data[DATA];
        
        if([Utils checkObjectIsNull:dic])
        {
            NSArray * merchantData = dic[MERCHANT_DATA];
            
            if([Utils checkObjectIsNull:merchantData])
            {
                if(self.page == 1)
                {
                    self.dataSource = merchantData;
                }else{
                    self.dataSource = [self.dataSource arrayByAddingObjectsFromArray:merchantData];
                }
                
                if(merchantData.count < 10)
                {
                    [self.refresh noMoreData];
                }
            }else{
                [self.refresh noMoreData];
            }
        }else{
            [self.refresh noMoreData];
        }
        NSString * resId = dic[RES_ID];
        self.requestId = resId;
        [self.listTableView reloadData];
        [self.refresh endRefreshing];
        
    } failure:^(NSError *error) {
        
        [self.refresh noMoreData];
        [self.refresh endRefreshing];
    }];

}

- (AMapLocationManager *)locationManager
{
    if(!_locationManager)
    {
        // 带逆地理信息的一次定位（返回坐标和地址信息）
        _locationManager = [[AMapLocationManager alloc] init];
        
        [_locationManager setDesiredAccuracy:kCLLocationAccuracyHundredMeters];
        //   定位超时时间，最低2s，此处设置为2s
        _locationManager.locationTimeout = 2;
        //   逆地理请求超时时间，最低2s，此处设置为2s
        _locationManager.reGeocodeTimeout = 2;
    }
    
    return _locationManager;
}


@end
