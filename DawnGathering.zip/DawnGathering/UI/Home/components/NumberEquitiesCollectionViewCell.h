//
//  NumberEquitiesCollectionViewCell.h
//  DawnGathering
//
//  Created by 李冬岐 on 2024/3/27.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface NumberEquitiesCollectionViewCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UIImageView *merchandiseImageView;
@property (weak, nonatomic) IBOutlet UILabel *merchandiseNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *merchandiseAmountLabel;
@property (weak, nonatomic) IBOutlet UILabel *merchandiseDiscountLabel;//商品历史价格划线;
@property (weak, nonatomic) IBOutlet UIView *whiteBg;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *discountTopDistance;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *discountLeftDistance;


+ (instancetype)xibTableViewCell;
@end

NS_ASSUME_NONNULL_END
