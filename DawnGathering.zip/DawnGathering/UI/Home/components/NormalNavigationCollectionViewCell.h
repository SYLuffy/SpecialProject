//
//  HomeNewClassifyCell.h
//  SCST
//
//  Created by 葛亮 on 2019/5/16.
//  Copyright © 2019 葛亮. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NormalNavigationCell.h"

NS_ASSUME_NONNULL_BEGIN
typedef void(^HomeNewClassifyCellBlock)(NSInteger index ,NSString * _Nullable url, NSNumber * _Nullable jumpType , NSNumber * _Nullable blackWhiteId);


@interface NormalNavigationCollectionViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIView *topContainer;
@property(nonatomic,copy)HomeNewClassifyCellBlock homeNewClassifyCellBlock;

+ (instancetype)xibTableViewCell;
-(void)setCellData:(NSArray *)data line:(NSInteger)line col:(NSInteger)col tabsColor:(NSString*)tabsColor textColor:(NSString*)textColor;

+ (CGFloat)getCellHeight:(NSArray*)list line:(NSInteger)line;
@property (weak, nonatomic) IBOutlet UIView *bottomEmptyView;
@end

NS_ASSUME_NONNULL_END
