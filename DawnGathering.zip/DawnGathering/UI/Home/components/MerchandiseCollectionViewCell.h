//
//  MerchandiseCollectionViewCell.h
//  DawnGathering
//
//  Created by 李冬岐 on 2023/8/14.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MerchandiseCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *merchandiseImageView;
@property (weak, nonatomic) IBOutlet UILabel *merchandiseNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *merchandiseAmountLabel;
@property (weak, nonatomic) IBOutlet UILabel *merchandiseHistoryAmountLabel;//商品历史价格划线;


+ (instancetype)xibTableViewCell;
@end

NS_ASSUME_NONNULL_END
