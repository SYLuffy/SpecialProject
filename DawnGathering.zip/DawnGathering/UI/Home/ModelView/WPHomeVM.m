//
//  WPHomePageVM.m
//  HLGA
//
//  Created by 葛亮 on 2018/6/4.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "WPHomeVM.h"
#import "TabNavigationCollectionViewCell.h"
#import "NormalNavigationCollectionViewCell.h"
#import "SmallBannerImageCell.h"
#import "HomeThreeImageCell.h"
#import "BannerImageCell.h"
#import "SectionCell.h"
#import "HomeMerchantListCell.h"
#import "NumberEquitiesCell.h"

#define HOME_TOP_PANEL_HEIGHT 111

@interface WPHomeVM()
@end

@implementation WPHomeVM

-(void)loadHomeTopListSuccess:(WPHomeViewModelSuccessBlock )success FailedBlock:(WPHomeViewModelFailedBlock)failed noMoreDataBlock:(WPHomeViewModelNoMoreDataBlock )noMoreDataBlock{
    
    if(self.homePageID)
    {
        [ServiceManager getHomePageListDataWithID:self.homePageID success:^(NSDictionary *data) {

            NSDictionary * dic = [Utils dictionaryWithJsonString:data[CONTENT]];
            self.homeModel = [[HomeModel alloc] initByDictionary:dic];
            
            NSString * titleName = data[NAME];
            if([Utils checkObjectIsNull:titleName])
            {
                self.titleName = titleName;
            }
            if([Utils checkObjectIsNull:data])
            {
                [self setResultWithData];
                success();
            }else{
                if (failed) {
                    failed();
                }
            }
            
        } failure:^(NSError *error) {
            if (failed) {
                failed();
            }
        }];
    }else{
        
        
        [ServiceManager getHomePageListData:^(NSDictionary *data) {
              
            if([Utils checkObjectIsNull:data]){
            
                self.homeModel = [[HomeModel alloc] initByDictionary:data];
                
                [self setResultWithData];
                
                success();
            }else{
                if (failed) {
                    failed();
                }
            }
            
        } failure:^(NSError *error) {
            if (failed) {
                failed();
            }
        }];
    }
}

- (void)getHomePageIsMerchantPageId:(NSString*)pageId back:(WPHomeViewModelIsMerchantPage)back{
    [ServiceManager getHomePageListDataWithID:pageId success:^(NSDictionary *data) {

        NSDictionary * dic = [Utils dictionaryWithJsonString:data[CONTENT]];
        HomeModel * model = [[HomeModel alloc] initByDictionary:dic];
        NSArray * list = model.listData;
        NSString * titleName = data[NAME];
        if([Utils checkObjectIsNull:list] && list.count > 0)
        {
            NSDictionary * firstObject = list.firstObject;
            
            NSString * type = firstObject[TYPE];
            NSNumber * isWhiteId = firstObject[IS_WHITE_LIST];
            NSArray * whiteIds = firstObject[WHITE_IDS];
            
            if([type isEqualToString:MERCHANT_PAGE])
            {
                if(isWhiteId.boolValue)
                {
                    back(true,titleName,whiteIds);
                }else{
                    back(true,titleName,nil);
                }
            }else{
                back(false,nil,nil);
            }
        }else{
            back(false,nil,nil);
        }
    } failure:^(NSError *error) {
        back(false,nil,nil);
    }];
}

- (void)setResultWithData
{
    NSArray * list = self.homeModel.listData;
    self.bottomListData = [NSMutableArray array];
    
    if([Utils checkObjectIsNull:list])
    {
        NSMutableArray * normalDics = [NSMutableArray array];
        NSMutableArray * classifyDics = [NSMutableArray array];
        self.homeListData = [NSMutableArray array];
        
        BOOL hasClassify = false;
        for(NSDictionary * dic in list)
        {
            NSString * type = dic[TYPE];
            NSNumber * fixedBottom = dic[FIXED_BOTTOM];
            //如果是底部悬浮择加入上面;
            if(fixedBottom && fixedBottom.boolValue == true)
            {
                [self.bottomListData addObject:dic];
            }else{
                if([type isEqualToString:CLASSIFY])
                {
                    hasClassify = true;
                    [classifyDics addObject:dic];
                }else{
                    [normalDics addObject:dic];
                }
            }
        }
        
        if(hasClassify == false)
        {
            [classifyDics addObject:@{CLASSIFY_LIST:@[]}];
        }
        
        [self.homeListData addObject:normalDics];
        [self.homeListData addObject:classifyDics];
    }
}

- (CGFloat)getTableViewCellHeightWithDic:(NSDictionary*)dic type:(NSString*)type numberEquitiesRow:(NSDictionary*)numberEquitiesRow indexPath:(NSIndexPath*)indexPath
{
    if([type isEqualToString:NAVIGATION])
    {
        NSString * isNavTabs = dic[IS_NAVTABS];
        NSArray * items;
        
        
        if(isNavTabs.integerValue == 1)
        {
            items = dic[NAVTABS_LIST];
            NSNumber * page = dic[CURRENT_PAGE];
            if(page == nil) page = @(0);

            NSDictionary * dic = items[page.integerValue];
            NSNumber * line = dic[LINE];
            NSArray * list = dic[LIST];
            
            return [TabNavigationCollectionViewCell getCellHeight:list line:line.integerValue];
            
        }else{
            NSNumber * line = dic[LINE];
            items = dic[NAVIGATION_LIST];
            return [NormalNavigationCollectionViewCell getCellHeight:items line:line.integerValue];
        }
        
    }else if([type isEqualToString:ADVERTISE])
    {
        NSNumber * imgWidth = dic[WIDTH];
        NSNumber * imgHeight = dic[HEIGHT];
        if(!imgWidth) imgWidth = @1;
        if(!imgHeight) imgHeight = @1;
        CGFloat portion;
        if(imgWidth.floatValue > 0)
        {
            portion = imgHeight.floatValue / imgWidth.floatValue;
            
            CGFloat advertiseImageHeight = (SCREEN_WIDTH - 30) * portion + 15;
            
            return advertiseImageHeight;
        }else{
            return [SmallBannerImageCell getBannerCellRowHeight:1];
        }
        
    }else if([type isEqualToString:ADVERTISE_SLIDER])
    {
        NSArray * items = dic[@"advertiseList"];
        return [SmallBannerImageCell getBannerCellRowHeight:items.count];
    }else if([type isEqualToString:TOPIC])
    {
        NSNumber* width = dic[WIDTH];
        NSNumber* height = dic[HEIGHT];
        
        if(width == nil) width =  @(1);
        if(height == nil) height =  @(1);
        
        NSArray * topicList = dic[TOPIC_LIST];
        NSString * topicLayout = dic[TOPIC_LAYOUT];
        NSString* titleImgURL = dic[TITLE_IMG_URL];
        CGFloat titleHeight = 0;
        
        if(titleImgURL.length > 0)
        {
            titleHeight = height.floatValue / width.floatValue * (SCREEN_WIDTH - 30);
        }
        return [HomeThreeImageCell getCellHegihtWith:topicList.firstObject titleHeight:titleHeight topicLayout:topicLayout];
        
    }else if([type isEqualToString:BANNER])
    {
        
        NSArray * list = dic[BANNER_LIST];
        
        NSDictionary * first = list.firstObject;
        
        NSNumber* width = first[WIDTH];
        NSNumber* height = first[HEIGHT];
        
        if(width == nil) width =  @(1);
        if(height == nil) height =  @(1);
        
        return [BannerImageCell getBannerCellRowHeightWithRadio:height.floatValue / width.floatValue];
    }else if([type isEqualToString:MAGIC_CUBE])
    {
        NSArray * items = dic[LIST_DATA];
        NSNumber * col = dic[LAYOUT];
        NSString * titleImgURL = dic[TITLE_IMG_URL];
        NSNumber * elementWidth = items.firstObject[WIDTH];
        NSNumber * elementHeight = items.firstObject[HEIGHT];
        
        CGFloat radio = elementHeight.floatValue / elementWidth.floatValue;
        
        NSNumber * width = dic[WIDTH];
        NSNumber * height = dic[HEIGHT];
        
        if(!width) width = @1;
        if(!height) height = @1;
        
        CGFloat titleRadio = height.floatValue / width.floatValue;
        CGFloat titleHeight = (SCREEN_WIDTH - 30) * titleRadio;
        
        
        if(titleImgURL.length == 0)
        {
            titleHeight = 0;
        }
        
        CGFloat cellHeight = [SectionCell getCellHeight:items col:col.integerValue + 1 radio:radio titleHeight:titleHeight];
        
        return cellHeight;
    }else if([type isEqualToString:GOODS_ZONE])
    {
        NSNumber * width = dic[WIDTH];
        NSNumber * height = dic[HEIGHT];
        
        if(!width) width = @1;
        if(!height) height = @1;
        
        CGFloat radio = height.floatValue / width.floatValue;
        
        CGFloat cellHeight = (SCREEN_WIDTH - 30) * radio + 15;
        
        return cellHeight;
        
    }else if([type isEqualToString:COUPON])
    {
        NSString * layout = dic[LAYOUT];
        NSArray * list = dic[COUPON_LIST];
        NSNumber * isShowTitle = dic[IS_SHOW_TITLE];
        
        if([Utils checkObjectIsNull:list] == false) return 0;
        if(!list) return 0;
            
        NSNumber * elementWidth = list.firstObject[NO_RECEIVE_WIDTH];
        NSNumber * elementHeight = list.firstObject[NO_RECEIVE_HEIGHT];
        
        if(!elementWidth) elementWidth = @1;
        if(!elementHeight) elementHeight = @1;
        
        NSNumber * width = dic[WIDTH];
        NSNumber * height = dic[HEIGHT];
        if(!width) width = @1;
        if(!height) height = @1;
        CGFloat radio = elementHeight.floatValue / elementWidth.floatValue;
        
        CGFloat titleRadio = height.floatValue / width.floatValue;
        CGFloat titleHeight = (SCREEN_WIDTH - 30) * titleRadio;
        NSString * titleImgURL = dic[TITLE_IMG];
         
        if(titleImgURL.length == 0 || isShowTitle.boolValue == false)
        {
            titleHeight = 0;
        }
        if(!layout) layout = @"1";
        
        CGFloat cellHeight = [SectionCell getCellHeight:list col:layout.integerValue radio:radio titleHeight:titleHeight];
        
        return cellHeight;
    }else if([type isEqualToString:ADVERTISE_RAMDOM])
    {
        
        NSNumber * width = dic[WIDTH];
        NSNumber * height = dic[HEIGHT];
        
        if(!width || width.integerValue == 0) width = @2;
        if(!height || height.integerValue == 0) height = @1;
        
        
        return [BannerImageCell getBannerCellRowHeightWithRadio:height.floatValue / width.floatValue];
    }else if([type isEqualToString:MERCHANT])
    {
        NSNumber * maxNum = dic[MAX_NUMBER];
        
        return [HomeMerchantListCell getMerchantListCellHeightWithCount:maxNum.integerValue];
    }else if([type isEqualToString:NUMBER_EQUITIES])
    {
        NSNumber * col = dic[LAYOUT];
        
        CGFloat radio;
        if(col.integerValue == 1)
        {
            radio = 95.0f / 375.0f;
        }else{
            radio = 235.0f / 182.0f;
        }
        
        NSNumber * width = @(345.0f);
        NSNumber * height = @(40.0f);
    
        CGFloat titleRadio = height.floatValue / width.floatValue;
        CGFloat titleHeight = (SCREEN_WIDTH - 30) * titleRadio;
        
        NSNumber * currentRow = numberEquitiesRow[[NSString stringWithFormat:@"%ld",indexPath.row]];
        
        if(!currentRow) currentRow = @0;
        
        CGFloat cellHeight = [NumberEquitiesCell getCellHeight:currentRow.integerValue col:col.integerValue radio:radio titleHeight:titleHeight];
        return cellHeight;
    }
    
    return 0;
}

@end
