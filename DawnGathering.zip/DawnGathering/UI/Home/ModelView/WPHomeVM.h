//
//  WPHomePageVM.h
//  HLGA
//
//  Created by 葛亮 on 2018/6/4.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HomeModel.h"
typedef void (^WPHomeViewModelSuccessBlock)(void);
typedef void (^WPHomeViewModelFailedBlock)(void);
typedef void (^WPHomeViewModelNoMoreDataBlock)(void);
typedef void(^WPHomeViewModelIsMerchantPage)(BOOL isMerchantPage ,NSString * merchantTitle,NSArray * whiteIds);
@interface WPHomeVM : NSObject

@property(nonatomic,assign)NSInteger page;
@property(nonatomic,assign)NSInteger pageSize;
@property(nonatomic,strong)NSString *companyLogo;//logo图片
@property(nonatomic,assign)BOOL isPaySwitch;//支付开关（1.支付,2.关闭）
@property(nonatomic,strong)NSString *paySwitchCloseDesc;//关闭开关描述

@property(nonatomic,strong)NSMutableArray <NSMutableArray*>* homeListData;

@property(nonatomic,strong)NSMutableArray <NSDictionary*>* bottomListData;
@property(nonatomic,strong)NSDictionary * classifyDic;
@property(nonatomic,strong)NSString * titleName;


@property(nonatomic,assign)BOOL isAddBool;
@property(nonatomic,assign)BOOL isRefreshAddData;

@property(nonatomic,strong)NSString *homePageID;

@property(nonatomic,strong)HomeModel * homeModel;



-(void)loadHomeTopListSuccess:(WPHomeViewModelSuccessBlock )success FailedBlock:(WPHomeViewModelFailedBlock)failed noMoreDataBlock:(WPHomeViewModelNoMoreDataBlock )noMoreDataBlock;

//获取是否是门店列表页面
- (void)getHomePageIsMerchantPageId:(NSString*)pageId back:(WPHomeViewModelIsMerchantPage)back;
//获取MainTableViewCell高度
- (CGFloat)getTableViewCellHeightWithDic:(NSDictionary*)dic type:(NSString*)type numberEquitiesRow:(NSDictionary*)numberEquitiesRow indexPath:(NSIndexPath*)indexPath;




@end
