//
//  WPStartBgVC.m
//  HLGA
//
//  Created by 葛亮 on 2018/9/19.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "WPStartBgVC.h"

@interface WPStartBgVC ()

@end

@implementation WPStartBgVC

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"sdfasdf");
}
-(void)dealloc{
    
    NSLog(@"WPStartBgVC  dealloc");
}


@end
