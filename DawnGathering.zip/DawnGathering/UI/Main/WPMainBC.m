//
//  WPMainBC.m
//  WelfarePlatform
//  基类 UITabBarController
//  Created by 葛亮 on 2018/5/21.
//  Copyright © 2018年 Linus. All rights reserved.
//

typedef NS_ENUM(NSUInteger,ToolbarType) {
    ToolbarTypeDefault = 0,
    ToolbarTypeTravelFunction,
    ToolbarTypeIndexNews,
    ToolbarTypeAll
};

#import "WPMainBC.h"
#import "WPNavigationController.h"
#import <SDWebImageDownloader.h>
#import "SDWebImageManager.h"
#import "UIImage+tools.h"
#import "MessageViewController.h"
#import "ShowViewModel.h"
#import "WPBusinessTravelVC.h"
#import "ScanCodeViewController.h"
#import "UITestButtonView.h"
#import "WPHomeVC.h"
#import "WPPaymentPasswordVC.h"
#import "MerchantMapViewController.h"
#import "MerchantListViewController.h"

#define BUTTON_LABEL_TAG 111
#define BUTTON_IMAGE_TAG 222


@interface WPMainBC ()<WPPaymentPasswordVCDelegate>

@property (nonatomic,strong)NSMutableArray *buttons;

@property (nonatomic,strong)NSArray *titles;//标题
@property (nonatomic,strong)NSArray *normalImages;//未选中图片
@property (nonatomic,strong)NSArray *selectedImages;//选中的图片


@property(nonatomic,strong)ShowViewModel *viewModel;
@property(nonatomic,assign)ToolbarType boolbar;

@property(nonatomic,strong)UITestButtonView * selectView;

@property (nonatomic,strong)NSArray * bottomList;

@property (nonatomic,assign)NSInteger selectedPage;

@property (nonatomic,strong)NSArray * dataSource;

@end

@implementation WPMainBC


- (void)dealloc{
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:EVENT_LAUNCH_IN_APP object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:EVENT_BUSINESS_TRAVEL object:nil];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:EVENT_OPEN_QR_CODE object:nil];
}


- (void)viewWillLayoutSubviews {
    [super viewWillLayoutSubviews];
    [self removeTabbarButton];
}

//老是移除不了。。。。。。
-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    [self removeTabbarButton];
}

- (void)removeTabbarButton{
    for (UIView *child in self.tabBar.subviews) {
        if ([child isKindOfClass:NSClassFromString(@"UITabBarButton")]) {
            [child removeFromSuperview];
        }
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setToolbar];
    [self initData];
    
    
    self.selectedIndex = 0;
    [self highlightButtonWithIndex:0];
    [self updateTabBarStyle];

//    [self getUserInfo];
    [self updateAdsViewData];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateTabbarSelect:) name:@"UpdateTabbarSelectIndex" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(judgeFromMessageHandler) name:EVENT_LAUNCH_IN_APP object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateBottomTabBarList) name:EVET_UPDATE_BOTTOM_TABBAR_LIST object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(selectTabarWithIndex:) name:EVENT_SELECT_TABBAR_WITH_INDEX object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(openQrpayHandler) name:EVENT_OPEN_QR_CODE object:nil];
    
    [self.viewModel showAdsViewOwner:self];
    
}

- (void)selectTabarWithIndex:(NSNotification*)notification
{
    NSNumber * index = notification.userInfo[PAGE_INDEX];
    
    [self setSelectedIndex:index.integerValue];
    
    [self.selectView updateRefreshViewWith:self.dataSource curentPage:index.integerValue];
}

#pragma mark - init UI

-(void)setToolbar{
    self.boolbar = ToolbarTypeDefault;
    if([SharedInstance getInstance].userInfo.travelFunction.integerValue == 1 && [SharedInstance getInstance].userInfo.indexNews.integerValue == 1 ){
        self.boolbar = ToolbarTypeAll;
    }else if ([SharedInstance getInstance].userInfo.travelFunction.integerValue == 1){
        self.boolbar = ToolbarTypeTravelFunction;
    }else if ([SharedInstance getInstance].userInfo.indexNews.integerValue == 1){
        self.boolbar = ToolbarTypeIndexNews;
    }
}


-(void)updateBottomTabBarList{
    
    [ServiceManager getHomePageBottomListData:^(NSDictionary *data) {
        
        NSArray * list = data[LIST];
        self.bottomList = list;
        
        if(self.bottomList.count == 0)
        {
            [self addDefaultButton];
            
            [Utils showToast:@"首页BottomList 为空请检查数据!"];
        }else{
            
            
            if(self.buttons)
            {
                for(UIButton * button in self.buttons)
                {
                    [button removeFromSuperview];
                }
            }
            
            NSString * inactiveColor = data[INATIVE_COLOR];
            NSString * activeColor = data[ACTIVE_COLOR];
            
            UIColor * selectColor = [UIColor colorWithHexString:activeColor];
            UIColor * normalColor = [UIColor colorWithHexString:inactiveColor];
            
            
            NSMutableArray * dataSource = [NSMutableArray array];
            
            for(NSDictionary * dic in list)
            {
                NSNumber * status = dic[STATUS];
                
                if(status.boolValue == YES)
                {
                    [dataSource addObject:dic];
                }
            }
            
            self.dataSource = dataSource;
            
            if(!self.selectView)
            {
                self.selectView = [[UITestButtonView alloc] initWithFrame:CGRectMake(0, 0, self.tabBar.frame.size.width, self.tabBar.frame.size.height)];
            }
            self.selectView.selectedColor = selectColor;
            self.selectView.normalColor = normalColor;
            
            self.selectView.backgroundColor = [UIColor whiteColor];

            [self.selectView updateRefreshWithImagesTitles:self.dataSource currentPage:self.selectedPage];
            
            WS(weakSelf);
            self.selectView.tapSelectViewButtonWithIndex = ^(NSInteger index,NSInteger cellIndex) {
                
                [weakSelf tapWithIndex:index];
            };
            
            
        
            [self.tabBar addSubview:self.selectView];
            
            [self.viewModel showUpgradeVersionView:[Utils currentWindow].rootViewController];
        }
    } failure:^(NSError *error) {
        [Utils showToast:error.userInfo[MSG]];
        [self addDefaultButton];
    }];
}

- (void)addDefaultButton
{
    NSInteger totalCount = self.titles.count;

    for (NSInteger i = 0; i < totalCount; i++) {
        UIButton *btn = [self createBtnForImage:[UIImage imageNamed:self.normalImages[i]] title:self.titles[i] tag:i];
        [self.buttons addObject:btn];
        [self.tabBar insertSubview:btn atIndex:0];
//        [self.tabBar addSubview:btn];

        CGFloat width = (self.tabBar.bounds.size.width / totalCount);
        //判断中间添加跳转付款BUTTON
        if(self.boolbar == ToolbarTypeDefault)
        {
            width = (self.tabBar.bounds.size.width / (totalCount + 1));
        }
        CGFloat locationX = i * width;
        if(self.boolbar == ToolbarTypeDefault && i == 1)
        {
            locationX = (i + 1) * width;
//
//            UIButton * qrButton  = [UIButton buttonWithType:UIButtonTypeCustom];
//            [qrButton setImage:[UIImage imageNamed:@"tabbar_pay_pre"] forState:UIControlStateNormal];
//            qrButton.frame = CGRectMake(width * i, 0, width, self.tabBar.bounds.size.height);
//
//            [qrButton addTarget:self action:@selector(gotoQrPayHandler:) forControlEvents:UIControlEventTouchUpInside];
//
//            [self.tabBar addSubview:qrButton];
        }

        btn.frame = CGRectMake(locationX, 0, width, self.tabBar.bounds.size.height);
    }
}


- (void)tapWithIndex:(NSInteger)index
{
    
    
    NSDictionary * dic = self.bottomList[index];
    
    NSNumber * blackWhiteId = dic[BLACK_WHITE_ID];
    
    NSArray * blackWhiteList = dic[WHITE_IDS];
    
    [SharedInstance getInstance].sendBlackWhiteList = blackWhiteList;
    
    NSNumber * jumpType = dic[JUMP_TYPE];
    NSString * hrefURL;
    if(jumpType.integerValue == 3)
    {
        NSDictionary * shopSet = dic[SHOP_SET];
        
        hrefURL = [Utils dictionaryToJson:shopSet];
        
        blackWhiteId = shopSet[BLACK_WHITE_ID];
        
        NSArray * blackWhiteList = shopSet[WHITE_IDS];
        
        [SharedInstance getInstance].sendBlackWhiteList = blackWhiteList;
    }else{
        hrefURL = dic[HREF_URL];
    }
    
    
    if(jumpType.integerValue == 0)
    {
        //app内跳转
        if([hrefURL isEqualToString:@"homePage"])
        {
            self.selectedPage = index;
            [self setSelectedIndex:0];
        }else if([hrefURL isEqualToString:@"personCenter"])
        {
            [self setSelectedIndex:1];
            self.selectedPage = index;
        }else if([hrefURL isEqualToString:@"codePay"])
        {
            [self gotoQrPayHandler:nil];
        }else if([hrefURL isEqualToString:@"changeCompany"])
        {
            [self changeCompanyHandler];
        }else if([hrefURL isEqualToString:@"account"])
        {
            [self gotoAccountDetailHandler];
        }else if([hrefURL isEqualToString:@"accountRecord"])
        {
            [self gotoBillListHandler];
        }else if([hrefURL isEqualToString:MERCHANT_LIST])
        {
            [self gotoAllMerchantListHandler:blackWhiteId];
        }else if([hrefURL isEqualToString:MERCHANT_MAP])
        {
            [self gotoMerchantMapHandler:blackWhiteId];
        }else if([hrefURL isEqualToString:CLASSIFY])
        {
            [SharedInstance getInstance].currentClassifyID = dic[CLASSIFY_ID];
            
            [self gotoSortHandler];
        }else if([hrefURL isEqualToString:@"CustomerCare"]){
            [self showConnectCustomerHandler];
        }else if([hrefURL isEqualToString:@"myOrder"]){
            UIViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_ME andIdentifier:@"BillListViewController"];
            [self.navigationController pushViewController:vc animated:true];
        }else if([hrefURL isEqualToString:@"changeCompany"]){
            UIViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_SETTING andIdentifier:@"SwitchCompanyViewController"];
            
            [self.navigationController pushViewController:vc animated:true];
        }else if([hrefURL isEqualToString:CLASSIFY])
        {
            UIViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_SORT andIdentifier:@"SortViewController"];
            
            [self.navigationController pushViewController:vc animated:true];
        }else if([hrefURL isEqualToString:MY_EQUITY])
        {
            [self gotoEquityVCHandler];
        }else if([hrefURL isEqualToString:BIND_CARD])
        {
            [self gotoBindCardHandler];
        }
        
        
    }else if(jumpType.integerValue == 2)
    {
        //web跳转
        if([hrefURL hasPrefix:@"tel://"])
        {
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:hrefURL] options:@{} completionHandler:nil];
        }else if([hrefURL hasPrefix:@"mp://"]){
            
            
            NSString * miniValue = [hrefURL substringFromIndex:5];
            NSArray * miniSeparate = [miniValue componentsSeparatedByString:@"/"];
            
            NSString * appId = miniSeparate.firstObject;
            
            NSString * path = [miniValue substringFromIndex:appId.length + 1];
            
            WXMiniProgramType type;
            
            if([Utils getProduction])
            {
                type = WXMiniProgramTypeRelease;
            }else{
                type = WXMiniProgramTypePreview;
            }
            
            [[SharedInstance getInstance] wechantMiniProgramPath:path userName:appId miniProgramType:type];
        }else{
            [Utils pushWebViewControllerURL:hrefURL owner:[Utils getCurrentVC]];
        }
        
    }else if(jumpType.integerValue == 1)
    {
        //二级页面
        
        NSString * pageID;
        
        if([hrefURL isKindOfClass:[NSNumber class]])
        {
            pageID = [NSString stringWithFormat:@"%ld",hrefURL.integerValue];
        }else {
            pageID = hrefURL;
            
            if(!hrefURL || hrefURL.length == 0)
            {
                [Utils showToast:@"未识别到正确的配置id"];
                return;
            }
        }
        
        WPHomeVC * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_HOME andIdentifier:@"WPHomeVC"];
        vc.homePageID = hrefURL;
        [[Utils getCurrentVC].navigationController pushViewController:vc animated:true];
    }else if(jumpType.integerValue == 3)
    {
        NSDictionary * shopSet = [Utils dictionaryWithJsonString:hrefURL];
        
        NSString * h5URL = shopSet[H5_URL];
        
        NSString * selectionType = shopSet[SELECTION_TYPE];
        
        NSString * selectionCods = shopSet[SELECTION_CODES];
        
        NSString * title = shopSet[TITLE];
        
        if(title && [Utils validateContainsChinese:title])
        {
            title = [title stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
        }
        
        if([Utils checkObjectIsNull:h5URL] && h5URL.length > 0)
        {
            NSString * goURL;
            
            if([h5URL containsString:@"?"])
            {
                goURL = [NSString stringWithFormat:@"%@&title=%@",h5URL,title];
            }else{
                goURL = [NSString stringWithFormat:@"%@?title=%@",h5URL,title];
            }
            
            [Utils pushWebViewControllerURL:goURL owner:self];
            
        }else {
            [ServiceManager getHomeH5URLWithRedirectType:@"home" homePageDTO:@{SELECTION_CODE:selectionCods,TAG:selectionType} success:^(NSDictionary *data) {
                
                NSString * h5URL = data[DATA];
                
                NSString * goURL;
                
                if(title)
                {
                    if([h5URL containsString:@"?"])
                    {
                        goURL = [NSString stringWithFormat:@"%@&title=%@",h5URL,title];
                    }else{
                        goURL = [NSString stringWithFormat:@"%@?title=%@",h5URL,title];
                    }
                }else{
                    goURL = h5URL;
                }
                
                
                [Utils pushWebViewControllerURL:goURL owner:self];
                
            }];
        }
        
        
    }
    
    
}
- (void)gotoSortHandler
{
    
    dispatch_async(dispatch_get_main_queue(), ^{
        UIViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_SORT andIdentifier:@"SortViewController"];
        
        [[Utils getCurrentVC].navigationController pushViewController:vc animated:true];
    });
    
    
}


- (void)gotoBillListHandler
{
    if(![self isLogin])
    {
        return;
    }
    
    UIViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_ME andIdentifier:@"BillListViewController"];
    [[Utils getCurrentVC].navigationController pushViewController:vc animated:true];
}

- (void)gotoAccountDetailHandler
{
    if(![self isLogin])
    {
        return;
    }
    
    UIViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_ME andIdentifier:@"AccountDetailViewController"];
    [[Utils getCurrentVC].navigationController pushViewController:vc animated:true];
}

- (void)changeCompanyHandler
{
    if(![self isLogin])
    {
        return;
    }
    
    UIViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_SETTING andIdentifier:@"SwitchCompanyViewController"];
    
    [[Utils getCurrentVC].navigationController pushViewController:vc animated:true];
}

- (void)openQrpayHandler
{
    NSString * sid = [Utils getUserDefaultByKey:SID];
    
    if(sid.length > 0 && [SharedInstance getInstance].userInfo == nil)
    {
        [SharedInstance getInstance].isEnterOpenQrCode = true;
        
        return;
    }
    
    
    UIViewController * vc =  [Utils getCurrentVC];
    
    if([vc isKindOfClass:ScanCodeViewController.class] == true)
    {
        return;
    }
        
    
    [self gotoQrPayHandler:nil];
}

- (void)gotoQrPayHandler:(UIButton*)sender
{
    if(![self isLogin])
    {
        return;
    }
    
    [self enterScanCodeViewHandler];
}

- (BOOL)isLogin{
    if ([[SharedInstance getInstance].userInfo.sid length] == 0) {
        
        [[SharedInstance getInstance] checkLoginAndGotoLogin:self];
        
        return NO;
    }
    return YES;
}

- (void)enterScanCodeViewHandler
{
    
    if([SharedInstance getInstance].payPasswordEmpty ==  0)
    {
        WPPaymentPasswordVC *vc = (WPPaymentPasswordVC *)[Utils getViewControllerByStoryBoardName:SB_NAME_ME andIdentifier:SB_ID_PAY_MENT_PASS_WORD];
        vc.ppType = WPPaymentPasswordTypeInitPassword;
        vc.enterType = @1;
        vc.delegate = self;
        [[Utils getCurrentVC].navigationController pushViewController:vc animated:YES];
        
        return;
    }
    
    [self scanCodeVCPush];
}

- (void)scanCodeVCPush{
    
    
    
    [SharedInstance getInstance].userSetScreenBrightness = [[UIScreen mainScreen] brightness];
    
    ScanCodeViewController * vc = [Utils getViewControllerByStoryBoardName:SCAN_CODE andIdentifier:SB_ID_SCAN_CODE_VC];
   
    vc.isPresent = true;
    WPNavigationController *navVC = [[WPNavigationController alloc]initWithRootViewController:vc];

    [self presentViewController:navVC animated:true completion:nil];
}


#pragma mark - request methods

-(void)getUserInfo{
    
    NSLog(@"WPMainBC------------------------");
    NSString *sid = [Utils getUserDefaultByKey:SID];
    if(sid != nil && sid.length > 0 && [SharedInstance getInstance].userInfo == nil){
        
        //判断自动登录
        [ServiceManager getUserInformationBySid:sid successBack:^(NSDictionary *data) {
            NSDictionary * result = data[DATA];
            
            UserInfo * userInfo = [[UserInfo alloc] initByDictionary:result];
            [BuglyManager setPhoneNum:userInfo.telephone];
            [SharedInstance getInstance].userInfo = userInfo;
            
            [SharedInstance getInstance].sid = userInfo.sid;
            [Utils setUserDefaultByKey:SID andValue:userInfo.sid];
            
        } failure:^(NSError *error) {
        }];
        
    }
}

/**
 请求开屏广告网络连接
 */
-(void)updateAdsViewData{

    
    [ServiceManager getFlashAdveriseWithAdids:nil isRand:@1 randNumToShow:@1 success:^(NSDictionary *data) {
        
        NSArray * list = data[DATA];
        
        if ([Utils checkObjectIsNull:list]) {
           
            NSDictionary * dict = list.firstObject;
            
            NSUserDefaults *dataUser = [NSUserDefaults standardUserDefaults];
            [dataUser setObject:dict forKey:@"AdsView"];
            [dataUser synchronize];
            
            NSString *urlSir = dict[IMG];
            NSURL *url = [NSURL URLWithString:urlSir];
            
            [[SDWebImageDownloader sharedDownloader] downloadImageWithURL:url options:SDWebImageDownloaderLowPriority progress:^(NSInteger receivedSize, NSInteger expectedSize, NSURL * _Nullable targetURL) {
                
            } completed:^(UIImage * _Nullable image, NSData * _Nullable data, NSError * _Nullable error, BOOL finished) {
                if (finished == YES) {
                
                    [[SDWebImageManager sharedManager] cacheKeyForURL:url];
                }
            }];
        }
        
        
    }];
    
}


#pragma mark - other methods

- (void)judgeFromMessageHandler{
    if ([SharedInstance getInstance].isOpenedUnifiedPay == true || [SharedInstance getInstance].sid == nil || [SharedInstance getInstance].isOpenMessageVC == true)
    {
        return;
    }
    
    
    UIViewController * vc = [Utils getCurrentVC];
    
    [ServiceManager getMessageCount:^(NSDictionary *data) {
        
        NSArray * results = data[DATA];
        MessageViewController * messageVC = (MessageViewController*)[Utils getViewControllerByStoryBoardName:SB_NAME_MESSAGE andIdentifier:SB_ID_MESSAGE];
        if([Utils checkObjectIsNull:results] == true){
            messageVC.messageDataSource = [results mutableCopy];
        }else{
            messageVC.messageDataSource = [NSMutableArray array];
        }
        [vc.navigationController pushViewController:messageVC animated:true];
    } isShowLoading:false];
}


-(void)businessTravelPressed{
    [self setToolbar];
    for (UIView *view in[self.tabBar subviews]) {
        [view removeFromSuperview];
    }
    [self.buttons removeAllObjects];
    [self updateTabBarStyle];
    [self initData];
    self.selectedIndex = 0;
    [self highlightButtonWithIndex:0];
}

-(void)updateTabBarStyle{
    self.tabBar.backgroundImage = [[UIImage alloc]init];
    self.tabBar.shadowImage = [UIImage new];
    self.tabBar.backgroundColor =  [UIColor colorWithRed:255/255.0 green:255/255.0 blue:255/255.0 alpha:1/1.0];
    UIView *topView =  [[UIView alloc]initWithFrame:CGRectMake( 0, 0, [UIScreen mainScreen].bounds.size.width,1.0 / [UIScreen mainScreen].scale)];
    topView.backgroundColor = [UIColor colorWithHexString:@"dedede"];
    [self.tabBar addSubview:topView];
}

- (void)deleteDefaultTabbarButton{
    for (UIView *child in self.tabBar.subviews) {
        if ([child isKindOfClass:NSClassFromString(@"UITabBarButton")]) {
            [child removeFromSuperview];
        }
    }
}

- (void)updateTabbarSelect:(NSNotification*)notification{
    NSDictionary *statusDictionary = [notification userInfo];
    NSInteger index = [statusDictionary[@"selectIndex"] integerValue];
    [self buttonPressed:[self.view viewWithTag:index]];
}

- (void)buttonPressed:(UIButton *)button{
    
    NSInteger tag = button.tag == 0 ? 0 : button.tag;
    
    if (button.tag != self.selectedIndex) {
        //埋点
        
    }else{
        if (button.tag == 0) {
            [[NSNotificationCenter defaultCenter] postNotificationName:@"HomeTableViewReturnTopNotification" object:nil];
        }
    }
    
    [self normalizeButtonWithIndex:self.selectedIndex];
    self.selectedIndex = tag;
    [self highlightButtonWithIndex:tag];
    [self deleteDefaultTabbarButton];
}


#pragma mark -Buttons


- (void)initData{
    
    self.viewControllers = nil;
    self.viewControllers = @[];
    
    UIStoryboard *homeStoryboard = [UIStoryboard storyboardWithName:@"Home_Storyboard" bundle:nil];
    UIStoryboard *meStoryboard = [UIStoryboard storyboardWithName:@"Me_Storyboard" bundle:nil];
    UIStoryboard *newsStoryboard = [UIStoryboard storyboardWithName:@"News_Storyboard" bundle:nil];
    
    
    WPNavigationController *homeNavi = homeStoryboard.instantiateInitialViewController;
    WPNavigationController *meNavi = meStoryboard.instantiateInitialViewController;
    WPNavigationController *newsNavi = newsStoryboard.instantiateInitialViewController;
    
    switch (self.boolbar) {
        case ToolbarTypeAll:{
            WPBusinessTravelVC *vc = [[WPBusinessTravelVC alloc]init];
            self.viewControllers = @[homeNavi,vc,newsNavi,meNavi];
            self.titles = @[@"首页",@"商旅",@"企业圈",@"我的"];
            self.normalImages = @[@"home_icon_home_normal.png", @"ic_shanglv_normal.png",@"home_icon_qiye_normal.png",@"home_icon_mine_normal.png"];
            self.selectedImages = @[@"home_icon_home_selected.png", @"ic_shanglv_press.png",@"home_icon_qiye_selected.png",@"home_icon_mine_selected.png"];
            break;
        }
        case ToolbarTypeTravelFunction:{
            WPBusinessTravelVC *vc = [[WPBusinessTravelVC alloc]init];
            self.viewControllers = @[homeNavi,vc,meNavi];
            self.titles = @[@"首页",@"商旅",@"我的"];
            self.normalImages = @[@"home_icon_home_normal.png", @"ic_shanglv_normal.png",@"home_icon_mine_normal.png"];
            self.selectedImages = @[@"home_icon_home_selected.png", @"ic_shanglv_press.png",@"home_icon_mine_selected.png"];
            break;
        }
        case ToolbarTypeIndexNews:{
            self.viewControllers = @[homeNavi,newsNavi,meNavi];
            self.titles = @[@"首页",@"企业圈",@"我的"];
            self.normalImages = @[@"home_icon_home_normal.png", @"home_icon_qiye_normal.png",@"home_icon_mine_normal.png"];
            self.selectedImages = @[@"home_icon_home_selected.png", @"home_icon_qiye_selected.png",@"home_icon_mine_selected.png"];
            break;
        }
        default:{
            self.viewControllers = @[homeNavi,meNavi];
            self.titles = @[@"首页",@"我的"];
            self.normalImages = @[@"home_icon_home_normal.png", @"home_icon_mine_normal.png"];
            self.selectedImages = @[@"home_icon_home_selected.png", @"home_icon_mine_selected.png"];
            
            [self updateBottomTabBarList];
            break;
        }
    }
}


- (void)highlightButtonWithIndex:(NSInteger)index{
    UIButton *button = self.buttons[index];
    UILabel *label = (UILabel *)[button viewWithTag:BUTTON_LABEL_TAG];
    label.textColor = [Utils getMainColor];
    UIImageView *imageView = (UIImageView *)[button viewWithTag:BUTTON_IMAGE_TAG];
    imageView.image = [UIImage imageNamed:self.selectedImages[button.tag]];
}

- (void)normalizeButtonWithIndex:(NSInteger)index{
    UIButton *button = self.buttons[index];
    UILabel *label = (UILabel *)[button viewWithTag:BUTTON_LABEL_TAG];
    label.textColor = [UIColor colorWithHexString:@"222222"];
    UIImageView *imageView = (UIImageView *)[button viewWithTag:BUTTON_IMAGE_TAG];
    imageView.image = [UIImage imageNamed:self.normalImages[button.tag]];
}


- (UIButton *)createBtnForImage:(UIImage *)image title:(NSString *)title tag:(NSInteger)tag{
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.tag = tag;
    btn.backgroundColor = [UIColor clearColor];
    [btn addTarget:self action:@selector(buttonPressed:) forControlEvents:UIControlEventTouchUpInside];
    
    UILabel *label = [[UILabel alloc] init];
    label.textColor = [UIColor colorWithRed:0.310 green:0.310 blue:0.310 alpha:1];
    label.tag = BUTTON_LABEL_TAG;
    label.text = title;
    label.textAlignment = NSTextAlignmentCenter;
    label.translatesAutoresizingMaskIntoConstraints = NO;
    label.font = [UIFont fontWithName:@"PingFangSC-Regular" size:11];
    [btn addSubview:label];
    [self SetConstraintsForLabel:label onButton:btn];

    UIImageView *imageView = [[UIImageView alloc] init];
    imageView.tag = BUTTON_IMAGE_TAG;
    imageView.contentMode = UIViewContentModeScaleAspectFit;
    imageView.translatesAutoresizingMaskIntoConstraints = NO;
    imageView.image = image;
    [btn addSubview:imageView];
    [self SetConstraintsForImageView:imageView onButton:btn];
    return btn;
}

- (void)SetConstraintsForLabel:(UILabel *)label onButton:(UIButton *)button{
        NSLayoutConstraint *heightConstraint = [NSLayoutConstraint constraintWithItem:label attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.0 constant:11];
        [label addConstraint:heightConstraint];
        NSLayoutConstraint *TopConstraint = [NSLayoutConstraint constraintWithItem:label attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:button attribute:NSLayoutAttributeTop multiplier:1.0 constant:34.0];
        NSLayoutConstraint *LeftConstraint = [NSLayoutConstraint constraintWithItem:label attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:button attribute:NSLayoutAttributeLeft multiplier:1.0 constant:0.0];
        NSLayoutConstraint *RightConstraint = [NSLayoutConstraint constraintWithItem:label attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:button attribute:NSLayoutAttributeRight multiplier:1.0 constant:0.0];
        [button addConstraints:@[TopConstraint, LeftConstraint, RightConstraint]];
}

- (void)SetConstraintsForImageView:(UIImageView *)imageView onButton:(UIButton *)button{
        NSLayoutConstraint *heightConstraint = [NSLayoutConstraint constraintWithItem:imageView attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.0 constant:20];
        NSLayoutConstraint *widthConstraint = [NSLayoutConstraint constraintWithItem:imageView attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.0 constant:20];
        [imageView addConstraints:@[heightConstraint, widthConstraint]];
        NSLayoutConstraint *TopConstraint = [NSLayoutConstraint constraintWithItem:imageView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:button attribute:NSLayoutAttributeTop multiplier:1.0 constant:5.0];
        NSLayoutConstraint *centerConstraint = [NSLayoutConstraint constraintWithItem:imageView attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:button attribute:NSLayoutAttributeCenterX multiplier:1.0 constant:0.0];
        [button addConstraints:@[TopConstraint, centerConstraint]];
}


- (ShowViewModel *)viewModel{
    
    if (!_viewModel) {
        _viewModel = [[ShowViewModel alloc]init];
    }
    return _viewModel;
}


- (instancetype)initWithCoder:(NSCoder *)coder
{
    self = [super initWithCoder:coder];
    if (self) {
        self.buttons = [[NSMutableArray alloc] initWithCapacity:10];
    }
    return self;
}

- (void)paymentPasswordVerifypwd:(NSString *)pwd;
{
    NSLog(@"%@",pwd);
}

- (void)showConnectCustomerHandler
{
    //联系客服
    [Utils setDefaultNavigationBar:self];
    
    [Utils setQiYuInfo];
    
    QYSource *source = [[QYSource alloc] init];
    
    
    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
    NSString *app_Version = [infoDictionary objectForKey:@"CFBundleShortVersionString"];
    NSString * sendTitle = [NSString stringWithFormat:@"设备:iOS;应用名称:蜀光惠;版本号:%@;%@",app_Version,@"蜀光惠-首页"];
    source.title = sendTitle;
    source.urlString = @"";
    QYSessionViewController *sessionViewController = [[QYSDK sharedSDK] sessionViewController];
    sessionViewController.robotWelcomeTemplateId = 6655338;
    sessionViewController.robotId = 5401983;
//    sessionViewController.groupId = 1070381;
    sessionViewController.openRobotInShuntMode = NO;
    sessionViewController.commonQuestionTemplateId = 4494027;
    sessionViewController.sessionTitle = @"蜀光惠客服";
    sessionViewController.source = source;
    dispatch_async(dispatch_get_main_queue(), ^{
        
        [[Utils getCurrentVC].navigationController pushViewController:sessionViewController animated:true];
    });
    
    UIBarButtonItem * leftBackButton = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"ic_title_back"] style:UIBarButtonItemStylePlain target:self action:@selector(onBack:)];
    leftBackButton.tintColor = [UIColor blackColor];
    sessionViewController.navigationItem.leftBarButtonItem = leftBackButton;
}


- (void)onBack:(id)sender{

    [[Utils getCurrentVC].navigationController popViewControllerAnimated:true];
}


//我的权益

- (void)gotoEquityVCHandler
{
    //权益界面;
    UIViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_ME andIdentifier:@"EquityViewController"];
    
    [[Utils getCurrentVC].navigationController pushViewController:vc animated:true];
}

//绑定福利券;
- (void)gotoBindCardHandler
{
    UIViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_ME andIdentifier:@"BindingWelfareCouponViewController"];
    
    [[Utils getCurrentVC].navigationController pushViewController:vc animated:true];
}

- (void)gotoMerchantMapHandler:(NSNumber*)blackWhiteId{
    MerchantMapViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_MERCHAT andIdentifier:@"MerchantMapViewController"];
   
    vc.blackWhiteId = blackWhiteId;
    [[Utils getCurrentVC].navigationController pushViewController:vc animated:true];
}

- (void)gotoAllMerchantListHandler:(NSNumber*)blackWhiteId{
    
    MerchantListViewController * listVC = [[MerchantListViewController alloc] init];
    listVC.blackWhiteId = blackWhiteId;
    [[Utils getCurrentVC].navigationController pushViewController:listVC animated:true];
}



@end
