//
//  WPBusinessTravelVC.m
//  HLGA
//
//  Created by 葛亮 on 2018/9/20.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "WPBusinessTravelVC.h"
#import "UIImage+tools.h"
#import "OpenJSWebKitController.h"

@interface WPBusinessTravelVC ()

@property(nonatomic,strong)TableViewProgressView *tProgressView;
@property(nonatomic,strong)NoDataView *noDataView;
@property(nonatomic,strong)NoNetworkView *noNetworkView;

@end

@implementation WPBusinessTravelVC


- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
//    [self setStatusBarBackgroundColor:[UIColor colorWithHexString:@"6064CA"]];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
//    [self setStatusBarBackgroundColor:[UIColor clearColor]];

}


- (void)setStatusBarBackgroundColor:(UIColor *)color {
    
    if (@available(iOS 13.0, *)) {
         UIView *statusBar = [[UIView alloc]initWithFrame:[UIApplication sharedApplication].keyWindow.windowScene.statusBarManager.statusBarFrame] ;
        statusBar.backgroundColor = color;
        [[Utils currentWindow] addSubview:statusBar];
    } else{
       UIView *statusBar = [[[UIApplication sharedApplication] valueForKey:@"statusBarWindow"] valueForKey:@"statusBar"];
       if ([statusBar respondsToSelector:@selector(setBackgroundColor:)]) {
           statusBar.backgroundColor = color;
       }
    }
    
}


-(TableViewProgressView *)tProgressView{
    
    if (!_tProgressView) {
        _tProgressView = [TableViewProgressView xibView];
        _tProgressView.backgroundColor = [UIColor whiteColor];
        _tProgressView.frame = self.view.frame;
    }
    return _tProgressView;
}

-(NoDataView *)noDataView{
    if (!_noDataView) {
        _noDataView = [NoDataView xibView];
        _noDataView.backgroundColor = [UIColor whiteColor];
        _noDataView.frame = self.view.frame;
    }
    return _noDataView;
}

-(NoNetworkView *)noNetworkView{
    if (!_noNetworkView) {
        _noNetworkView = [NoNetworkView xibView];
        _noNetworkView.backgroundColor = [UIColor whiteColor];
        _noNetworkView.frame = self.view.frame;
    }
    return _noNetworkView;
}


- (void)viewDidLoad {
    [super viewDidLoad];

    
    __weak WPBusinessTravelVC *weakSelf = self;

    self.noNetworkView.reloadBlk = ^{
        [weakSelf.tProgressView removeFromSuperview];
        [weakSelf.noDataView removeFromSuperview];
        [weakSelf.noNetworkView removeFromSuperview];
        [weakSelf initDataAndUI];
    };
    
    [self initDataAndUI];
}

-(void)initDataAndUI{

    __weak WPBusinessTravelVC *weakSelf = self;

    [self.view addSubview:self.tProgressView];
    [ServiceManager getBusinessTravelUrlSuccessBack:^(NSDictionary *data) {
        [weakSelf.tProgressView removeFromSuperview];
        
         OpenJSWebKitController *webVC = [[OpenJSWebKitController alloc]init];
        NSString *url  = data[@"data"][@"url"];

        if (url.length > 0) {

            webVC.goUrl = url;
            [weakSelf addChildViewController:webVC];
            [weakSelf.view addSubview:webVC.view];
        }else{
            [weakSelf.view addSubview:weakSelf.noDataView];
        }
    } failure:^(NSError *error) {
        [weakSelf.tProgressView removeFromSuperview];
        [weakSelf.view addSubview:weakSelf.noNetworkView];
    }];
}



@end
