//
//  WPMainBC.h
//  HLGA
//
//  Created by 葛亮 on 2018/5/21.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WPMainBC : UITabBarController

@end
