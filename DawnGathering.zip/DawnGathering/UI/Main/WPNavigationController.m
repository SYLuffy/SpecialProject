//
//  WPNavigationController.m
//  HLGA
//  基类导航栏
//  Created by 葛亮 on 2018/5/21.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "WPNavigationController.h"
#import "WPMainBC.h"
#import "WPMineViewController.h"
#import "WPHomeVC.h"
#import "UIColor+Extension.h"
#import "UIImage+tools.h"
#import "WPNewsMainVC.h"
@interface WPNavigationController ()<UIGestureRecognizerDelegate,UINavigationControllerDelegate>

@end

@implementation WPNavigationController


- (void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    [self setNav];
    
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    //左滑返回方法
    __weak typeof (self) weakSelf = self;
    if ([self respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        self.interactivePopGestureRecognizer.delegate = weakSelf;
        self.delegate = weakSelf;
    }
    
}



- (void)setNav{
    
    UINavigationBar *bar = [UINavigationBar appearance];
    [bar setTitleTextAttributes:@{NSForegroundColorAttributeName : UIColorFromRGB(0x000000)}];
    [bar setTranslucent:false];
    bar.barTintColor = [UIColor whiteColor];
    UIColor *color = UIColorFromRGB(0xEEEEEE);
     
    UIImage *image =  [UIImage imageWithColor:color size:CGSizeMake( 1, 1.0 / [UIScreen mainScreen].scale)];
    [bar setShadowImage:image];
}

#pragma 左滑返回

- (void)navigationController:(UINavigationController *)navigationController
       didShowViewController:(UIViewController *)viewController
                    animated:(BOOL)animated
{
    
    if(navigationController.viewControllers.count <= 1)
    {
        navigationController.interactivePopGestureRecognizer.enabled = NO;
    }else{
        navigationController.interactivePopGestureRecognizer.enabled = YES;
    }
}

- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    if (self.viewControllers.count > 0) {
        viewController.hidesBottomBarWhenPushed = YES;
    }
    dispatch_async(dispatch_get_main_queue(), ^{
        
        if ([self respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
            self.interactivePopGestureRecognizer.enabled = NO;
        }
        [super pushViewController:viewController animated:animated];
        
    });
}



@end
