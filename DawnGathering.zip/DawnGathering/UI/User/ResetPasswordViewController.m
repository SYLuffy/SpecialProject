//
//  ResetPasswordViewController.m
//  HLGA
//
//  Created by Linus on 2018/5/15.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "ResetPasswordViewController.h"
#import "WPNavigationController.h"

@interface ResetPasswordViewController ()
@property (weak, nonatomic) IBOutlet UITextField *passwordText;
@property (weak, nonatomic) IBOutlet UITextField *confirmPasswordText;
@property (weak, nonatomic) IBOutlet UIButton *confirmButton;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *panelHeight;

@end

@implementation ResetPasswordViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setAppearance];
    [self.passwordText addTarget:self action:@selector(textChangeEdit:) forControlEvents:UIControlEventEditingChanged];
    [self.confirmPasswordText addTarget:self action:@selector(textChangeEdit:) forControlEvents:UIControlEventEditingChanged];
    
}

- (void)setAppearance{
    self.panelHeight.constant = self.panelHeight.constant - 20 + [Utils getStatusBarHeight:self];
    [self.confirmButton gradualDefaultButton];
    [self judgeButtonEnable];
}

- (void)textChangeEdit:(UITextField*)sender
{
    [self judgeButtonEnable];
}


- (void)judgeButtonEnable{
    BOOL passwordEnable = false;
    
    if([Utils passwordTextRule:self.passwordText] == true)
    {
        passwordEnable = true;
    }
    
    BOOL confirmPasswordEnable = false;
    
    if([Utils passwordTextRule:self.confirmPasswordText] == true)
    {
        confirmPasswordEnable = true;
    }
    
    if(passwordEnable && confirmPasswordEnable)
    {
        [self.confirmButton setGrayEnable:false];
    }else{
        [self.confirmButton setGrayEnable:true];
    }
}
- (IBAction)confirmHandler:(UIButton *)sender {
    
    //确认提交
    if(self.passwordText.text.length != self.confirmPasswordText.text.length || [self.passwordText.text isEqualToString:self.confirmPasswordText.text] == false)
    {
        [Utils showToast:@"两次输入的密码不一致，请重新输入"];
        return;
    }
    
    [ServiceManager resetPasswordByAccount:self.account andSetPassword:self.passwordText.text andSecurityCode:self.securityCode success:^(NSDictionary *data) {
        
        [Utils dissmissToViewController:[WPNavigationController class] andCurrentVC:self];
        
    }];
    
    
}


- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.passwordText resignFirstResponder];
    [self.confirmPasswordText resignFirstResponder];
}


- (IBAction)backAndClonseHandler:(UIButton *)sender {
    
    [self dismissViewControllerAnimated:true completion:nil];
}


-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}

@end
