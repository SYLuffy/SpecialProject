//
//  LogOutSuccessViewController.h
//  Banks
//
//  Created by 李冬岐 on 2022/3/21.
//  Copyright © 2022 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LogOutSuccessViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
