//
//  LoginViewController.m
//  HLGA
//
//  Created by 谢丹 on 2021/10/21.
//  Copyright © 2021 Linus. All rights reserved.
//

#import "LoginViewController.h"
#import "MBProgressHUD+Add.h"
#import "Networking.h"
#import "RegisterView.h"
#import "WPUrlString.h"
#import <TYRZUISDK/TYRZUISDK.h>
#import "UIImage+tools.h"

@interface LoginViewController ()<UITextViewDelegate>

@property (weak, nonatomic) IBOutlet UIView *loginView;
@property (weak, nonatomic) IBOutlet UIButton *loginButton;
@property (weak, nonatomic) IBOutlet UITextField *phoneTextField;
@property (weak, nonatomic) IBOutlet UITextField *verifyCodeTextField;
@property (weak, nonatomic) IBOutlet UIButton *verifyCodeButton;

@property (nonatomic,strong)  NSString *timeString;//时间戳
@property (strong, nonatomic)  NSTimer *timer;
@property (nonatomic,assign)  NSInteger count;

@property (weak, nonatomic) IBOutlet UIButton *protocolButton;

@property (weak, nonatomic) IBOutlet UITextView *textView;


@end

@implementation LoginViewController



- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.loginButton gradualDefaultButton];
    [self.verifyCodeButton setTitleColor:[Utils getMainColor] forState:UIControlStateNormal];
    
    NSMutableAttributedString * attributed = [Utils attributeStringUnderLine:self.verifyCodeButton.titleLabel.text color:[Utils getMainColor]];
    self.verifyCodeButton.titleLabel.attributedText = attributed;

    [self.view layoutIfNeeded];
    
    self.textView.font = [UIFont fontWithName:DEFAULT_FONT_NAME size:11];
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineSpacing= 1;
    NSDictionary* attributes = @{NSFontAttributeName:[UIFont fontWithName:DEFAULT_FONT_NAME size:11],NSParagraphStyleAttributeName:paragraphStyle};
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:self.textView.text attributes:attributes];

    
    NSString * service = [NSString stringWithFormat:@"%@%@",BASE_WEB_URL,SERVICE_AGREEMENT];
    NSString * privacy = [NSString stringWithFormat:@"%@%@",BASE_WEB_URL,PRIVATE_AGREEMENT];
    
    
    NSRange serviceRange = [[attributedString string] rangeOfString:@"《平台服务协议》"];
    serviceRange.length = 8;
    
    [attributedString addAttribute:NSLinkAttributeName value:service range:serviceRange];

    
    NSRange privacyRange = [[attributedString string] rangeOfString:@"《隐私政策协议》"];
    privacyRange.length = 8;
    [attributedString addAttribute:NSLinkAttributeName value:privacy range:privacyRange];
    
    [attributedString addAttribute:NSForegroundColorAttributeName value:UIColorFromRGB(0x999999) range:NSMakeRange(0,self.textView.text.length)];
    
    self.textView.attributedText = attributedString;
    
    self.textView.linkTextAttributes = @{NSForegroundColorAttributeName:UIColorFromRGB(0x0086d0)};

    self.textView.delegate = self;

    //必须禁止输入，否则点击将弹出输入键盘

    self.textView.editable = NO;
}
    


- (BOOL)textView:(UITextView *)textView shouldInteractWithURL:(NSURL *)URL inRange:(NSRange)characterRange interaction:(UITextItemInteraction)interaction
{
    NSString * service = [NSString stringWithFormat:@"%@%@",BASE_WEB_URL,SERVICE_AGREEMENT];
    NSString * privacy = [NSString stringWithFormat:@"%@%@",BASE_WEB_URL,PRIVATE_AGREEMENT];
    
    NSString * URLString = URL.absoluteString;
    
    if ([URLString containsString:SERVICE_AGREEMENT]) {

        [Utils pushWebViewControllerURL:service owner:self];

    }else if ([URLString containsString:PRIVATE_AGREEMENT]) {

        [Utils pushWebViewControllerURL:privacy owner:self];
    }

    return NO;
}


- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:YES animated:animated];
    
//    [self showTelephoneQuickLogin];
    
}


- (void)enterHomePageHandler:(NSDictionary*)result{
    UserInfo * userInfo = [[UserInfo alloc] initByDictionary:result];
    [BuglyManager setPhoneNum:userInfo.telephone];
    [SharedInstance getInstance].userInfo = userInfo;
    [SharedInstance getInstance].sid = userInfo.sid;
    [Utils setUserDefaultByKey:SID andValue:userInfo.sid];

    if ([SharedInstance getInstance].userInfo.travelFunction.integerValue == 1 || [SharedInstance getInstance].userInfo.indexNews.integerValue == 1) {
        [[NSNotificationCenter defaultCenter] postNotificationName:EVENT_BUSINESS_TRAVEL object:nil];

    }
    
    [[NSNotificationCenter defaultCenter] postNotificationName:EVET_HTML_LOGIN_CALL_BACK object:nil];
   
    [self dismissViewControllerAnimated:YES completion:nil];

    [[NSNotificationCenter defaultCenter] postNotificationName:EVENT_SGH_LOGIN_SUCCESS object:nil];
}



- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:animated];
}




- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.phoneTextField resignFirstResponder];
    [self.verifyCodeTextField resignFirstResponder];
}


-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}

- (IBAction)protocolClick:(id)sender {
    self.protocolButton.selected = !self.protocolButton.selected;
}


- (IBAction)getVerifyCodeClick:(id)sender {
    
    if (self.phoneTextField.text.length != 11) {
        [Utils showToast:@"请输入正确的手机号码"];
        return;
    }
    
    NSDictionary *param = @{@"phone":self.phoneTextField.text,
                             @"module":@"appLogin",
                             @"moduleId":@(5),
                             @"systemType":@(2),
                            @"timeS":self.timeString
    };
    
    NSMutableDictionary *parameters = [param mutableCopy];
    [[SharedInstance getInstance].hideLoadingDataSource addObject:@119];
    
    MBProgressHUD *hud = [MBProgressHUD showMessag:@"发送中" toView:self.view];
    [Networking postWithParameters:parameters andCmd:@119 success:^(NSDictionary *data) {
        
        [hud hideAnimated:YES];
        
        [Utils securityButtonCountDown:self.verifyCodeButton];
    } failure:^(NSError *error) {
        [hud hideAnimated:YES];
        [Utils showToast:error.userInfo[@"msg"]];
    }];
    
}

- (IBAction)dismissClick:(id)sender {
    
    if(self.isPush)
    {
        [self.navigationController popViewControllerAnimated:true];
        return;
    }
    
    [self dismissViewControllerAnimated:YES completion:nil];
}


- (IBAction)loginClick:(id)sender {
    
    if (!self.protocolButton.selected) {
        [Utils showToast:@"请阅读并同意协议"];
        return;
    }
    if (self.phoneTextField.text.length != 11) {
        [Utils showToast:@"请输入正确手机号"];
        return;
    }
    if (self.verifyCodeTextField.text.length == 0) {
        [Utils showToast:@"请输入验证码"];
        return;
    }
    
    NSString *pushToken = [SharedInstance getInstance].pushToken;
    if(pushToken == nil){
        pushToken = @"rjfsdakljfkdlsajfkldsajkl";
    }
    
    NSDictionary *param = @{@"phone":self.phoneTextField.text,
                             @"code":self.verifyCodeTextField.text,
                             @"systemType":@(2),
                            @"usercid":pushToken,
    };
    
    NSMutableDictionary *parameters = [param mutableCopy];
    [[SharedInstance getInstance].hideLoadingDataSource addObject:@180];
    MBProgressHUD *hud = [MBProgressHUD showMessag:@"登录中" toView:self.view];
    [Networking postWithParameters:parameters andCmd:@180 success:^(NSDictionary *data) {
        [hud hideAnimated:YES];
        
        NSDictionary * result = data[DATA];
        
        UserInfo * userInfo = [[UserInfo alloc] initByDictionary:result];
        [BuglyManager setPhoneNum:userInfo.telephone];
        [SharedInstance getInstance].userInfo = userInfo;
        [SharedInstance getInstance].sid = userInfo.sid;
        [Utils setUserDefaultByKey:SID andValue:userInfo.sid];
        
        [Utils setUserDefaultByKey:COMPANY_ID andValue:[SharedInstance getInstance].userInfo.companyId];
        [Utils setUserDefaultByKey:COMPANY_NAME andValue:[SharedInstance getInstance].userInfo.companyName];

        if ([SharedInstance getInstance].userInfo.travelFunction.integerValue == 1 || [SharedInstance getInstance].userInfo.indexNews.integerValue == 1) {
            [[NSNotificationCenter defaultCenter] postNotificationName:EVENT_BUSINESS_TRAVEL object:nil];

        }
        
        
        
       
        [self dismissViewControllerAnimated:YES completion:nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:EVET_HTML_LOGIN_CALL_BACK object:nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:EVENT_SGH_LOGIN_SUCCESS object:nil];
        
        [SharedInstance getInstance].isNeedUpdateHomePage = true;
        
        
        
    } failure:^(NSError *error) {
        [hud hideAnimated:YES];
        
        [Utils showToast:error.userInfo[@"msg"]];
    }];
    
}


- (IBAction)serviceProtocolClick:(id)sender {
    [Utils pushWebViewControllerURL:[NSString stringWithFormat:@"%@%@",BASE_WEB_URL,SERVICE_AGREEMENT] owner:self];
    
}


- (IBAction)privateProtocolClick:(id)sender {
    [Utils pushWebViewControllerURL:[NSString stringWithFormat:@"%@%@",BASE_WEB_URL,PRIVATE_AGREEMENT] owner:self];
}




- (UIImage*)imageWithCornerRadius:(CGFloat)radius size:(CGSize)size {

// 开始图形上下文

    UIGraphicsBeginImageContextWithOptions(size, NO, 0.0);

// 获得图形上下文

    CGContextRef ctx = UIGraphicsGetCurrentContext();

// 设置一个范围

    CGRect rect = CGRectMake(0, 0, size.width, size.height);

// 根据radius的值画出路线

    CGContextAddPath(ctx, [UIBezierPath bezierPathWithRoundedRect:rect cornerRadius:radius].CGPath);

// 裁剪

    CGContextClip(ctx);

    // 从上下文上获取剪裁后的照片

    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();

    // 关闭上下文

    UIGraphicsEndImageContext();

    return newImage;

}

@end
