//
//  RegisterView.m
//  HLGA
//
//  Created by 谢丹 on 2021/11/1.
//  Copyright © 2021 Linus. All rights reserved.
//

#import "RegisterView.h"


@interface RegisterView ()

@property (weak, nonatomic) IBOutlet UITextField *phoneTextField;
@property (weak, nonatomic) IBOutlet UITextField *userNameTextField;
@property (weak, nonatomic) IBOutlet UITextField *verifyCodeTextField;
@property (weak, nonatomic) IBOutlet UIButton *verifyCodeButton;
@property (weak, nonatomic) IBOutlet UIButton *agreeButton;
@property (weak, nonatomic) IBOutlet UIView *contentView;

@property (strong, nonatomic)  NSTimer *timer;
@property (nonatomic,assign)  NSInteger count;

@end

@implementation RegisterView




#pragma mark - click methods

- (IBAction)sureClick:(id)sender {
    
    if (!self.agreeButton.selected) {
        [Utils showToast:@"请阅读并同意协议"];
        return;
    }
    if ([self.phoneTextField.text length] != 11) {
        [Utils showToast:@"请输入合法的手机号"];
        return;
    }
    if ([self.userNameTextField.text length] == 0) {
        [Utils showToast:@"请输入用户名"];
        return;
    }
    if ([self.verifyCodeTextField.text length] == 0) {
        [Utils showToast:@"请输入验证码"];
        return;
    }
}


- (IBAction)getVerifyCodeClick:(id)sender {
    if ([self.phoneTextField.text length] != 11) {
        [Utils showToast:@"请输入合法的手机号"];
        return;
    }
    
}



- (IBAction)cannelClick:(id)sender {
    [self fadeOut];
}


- (IBAction)agreeButtonClick:(id)sender {
    self.agreeButton.selected = !self.agreeButton.selected;
}

//用户协议
- (IBAction)userProtocolClick:(id)sender {
    
}


//隐私协议
- (IBAction)privateProtocolClick:(id)sender {
    
    
}

- (void)show{
    
}

#pragma mark - other methods

//计时器
-(void)loadtimeview{
    
    if (self.timer) {
        [self.timer invalidate];
    }
    self.count = 60;
    [self.verifyCodeButton setTitle:@"60秒"forState:UIControlStateNormal];
    self.timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(updateBtn) userInfo:nil repeats:YES];
}

-(void)updateBtn{
    if (--self.count >0) {
        self.verifyCodeButton.userInteractionEnabled = NO;
        [self.verifyCodeButton setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [self.verifyCodeButton setTitle:[NSString stringWithFormat:@"%ld秒",self.count] forState:UIControlStateNormal];
    }else{
        self.verifyCodeButton.userInteractionEnabled = YES;
        [self.verifyCodeButton setTitleColor:[UIColor colorWithHexString:@"FFC156"] forState:UIControlStateNormal];
        [self.verifyCodeButton setTitle:@"获取验证码" forState:UIControlStateNormal];
        [self.timer invalidate];
    }
}

- (void)fadeIn{
    RegisterView *view = (RegisterView *)[Utils getXibByName:@"RegisterView"];

    [[Utils currentWindow] addSubview:view];
    
    self.contentView.alpha = 0.0;
    self.backgroundColor = [UIColor colorWithHexString:@"222222" alpha:0];
    
    [UIView animateWithDuration:0.3 animations:^{
        
        self.backgroundColor = [UIColor colorWithHexString:@"222222" alpha:0.3];
        self.contentView.alpha = 1.0f;
    }];
}

- (void)fadeOut{
    
    self.backgroundColor = [UIColor colorWithHexString:@"222222" alpha:0.3];
    [UIView animateWithDuration:0.3 animations:^{
        
        self.backgroundColor = [UIColor colorWithHexString:@"222222" alpha:0];
        self.contentView.alpha = 0;
        
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
    
}


@end
