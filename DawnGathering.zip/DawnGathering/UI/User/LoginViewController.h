//
//  LoginViewController.h
//  HLGA
//
//  Created by 谢丹 on 2021/10/21.
//  Copyright © 2021 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LoginViewController : UIViewController
@property (nonatomic,assign)BOOL isPush;
@end

NS_ASSUME_NONNULL_END
