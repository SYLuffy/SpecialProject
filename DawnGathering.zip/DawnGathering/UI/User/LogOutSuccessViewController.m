//
//  LogOutSuccessViewController.m
//  Banks
//
//  Created by 李冬岐 on 2022/3/21.
//  Copyright © 2022 Linus. All rights reserved.
//

#import "LogOutSuccessViewController.h"

@interface LogOutSuccessViewController ()
@property (weak, nonatomic) IBOutlet UIButton *backButton;

@end

@implementation LogOutSuccessViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self.backButton gradualDefaultButton];
}
- (IBAction)backAndPopSetHandler:(UIBarButtonItem *)sender {
    

    [self.navigationController popToRootViewControllerAnimated:YES];
    
}
- (IBAction)tapBackButtonHandler:(UIButton *)sender {
    [self.navigationController popToRootViewControllerAnimated:YES];
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
