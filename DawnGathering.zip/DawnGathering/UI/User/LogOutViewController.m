//
//  LogOutViewController.m
//  Banks
//
//  Created by 李冬岐 on 2022/3/21.
//  Copyright © 2022 Linus. All rights reserved.
//

#import "LogOutViewController.h"

@interface LogOutViewController ()
@property (weak, nonatomic) IBOutlet UILabel *phoneTipsLabel;
@property (weak, nonatomic) IBOutlet UIButton *confirmButton;

@end

@implementation LogOutViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self.confirmButton gradualDefaultButton];
    UserInfo * userInfo = [SharedInstance getInstance].userInfo;
    self.phoneTipsLabel.text = [NSString stringWithFormat:@"将%@账号注销",userInfo.hiddenPhoneString];
}
- (IBAction)confirmLogoutHandler:(UIButton *)sender {
    
    //确认注销;
    [ServiceManager userLogoutAccount:^(NSDictionary *data) {
        
        UIViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_USER andIdentifier:@"LogOutSuccessViewController"];
        
        [self.navigationController pushViewController:vc animated:true];
        
    }];
    
}
- (IBAction)backAndPopHandler:(UIBarButtonItem *)sender {
    [self.navigationController popViewControllerAnimated:true];
}


@end
