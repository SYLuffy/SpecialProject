//
//  ForgetPasswordController.m
//  HLGA
//
//  Created by Linus on 2018/5/15.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "ForgetPasswordController.h"
#import "ResetPasswordViewController.h"
#import "WPNavigationController.h"
#import "BaseTextField.h"
@interface ForgetPasswordController ()
@property (weak, nonatomic) IBOutlet UITextField *accountText;
@property (weak, nonatomic) IBOutlet BaseTextField *securityCodeText;
@property (weak, nonatomic) IBOutlet UIButton *nextButton;//下一步按钮
@property (weak, nonatomic) IBOutlet UIButton *securityButton;//获取验证码按钮
@property (weak, nonatomic) IBOutlet UILabel *bottemDescLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *panelHeight;
@property (strong, nonatomic)NSString * telephone;

@end

@implementation ForgetPasswordController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
        
    [self setAppearance];
    
    
    [self.accountText addTarget:self action:@selector(textChangeEdit:) forControlEvents:UIControlEventEditingChanged];
    [self.securityCodeText addTarget:self action:@selector(textChangeEdit:) forControlEvents:UIControlEventEditingChanged];
    
}

- (void)textChangeEdit:(UITextField*)sender
{
    [self judgeButtonEnable];
}

- (void)setAppearance{
    
    self.panelHeight.constant = self.panelHeight.constant - 20 + [Utils getStatusBarHeight:self];
    
    [self.nextButton gradualDefaultButton];//渐变
    [self.securityButton securityStyleButton];//验证码风格
    
    [self judgeButtonEnable];
    
}
- (IBAction)sendSecurityCodeHandler:(UIButton *)sender {
    
    if(self.accountText.text.length < 1)
    {
        [Utils showToast:TOAST_PLEASE_INPUT_ACCOUNT];
        return;
    }
    
    NSString *removeEmptyString = [self.accountText.text stringByReplacingOccurrencesOfString:@" " withString:@""];//提交时候去掉空格
    self.accountText.text = removeEmptyString;
    
    [ServiceManager sendSecurityCodeByAccount:self.accountText.text moduleName:CODE_MODEL_FORGET_PASSWORD success:^(NSDictionary *data) {
        
        //NSLog(@"%@",data);
        
        NSString * tel = data[DATA][TELEPHONE];
        
        NSString * lastFourTel = [tel stringByReplacingCharactersInRange:NSMakeRange(3, 4) withString:@"****"];
        
        NSString * bottomShowDesc = [NSString stringWithFormat:@"验证码将发送到%@",lastFourTel];
        
        self.bottemDescLabel.text = bottomShowDesc;
        
        [Utils labelColorAttributedString:self.bottemDescLabel andRange:NSMakeRange(8, 4) color:[UIColor blackColor] size:self.bottemDescLabel.font.pointSize];
        
        [Utils securityButtonCountDown:self.securityButton];

        
    }];
}

- (IBAction)nextHandler:(UIButton *)sender {
    //下一步
    NSString *removeEmptyString = [self.accountText.text stringByReplacingOccurrencesOfString:@" " withString:@""];//提交时候去掉空格
    self.accountText.text = removeEmptyString;
    [ServiceManager verificationSecutityCodeByAccount:self.accountText.text andSecurityCode:self.securityCodeText.text success:^(NSDictionary *data) {
        
        //验证成功
        [self performSegueWithIdentifier:PRESENT_FORGET_TO_RESET sender:self];
    }];

}


- (void)judgeButtonEnable
{
    BOOL accountEnable = false;
    
    if([Utils accountTextRule:self.accountText] == true)
    {
        accountEnable = true;
    }
    
    BOOL securityCodeEnable = false;
    
    if([Utils securityCodeTextRule:self.securityCodeText] == true)
    {
        securityCodeEnable = true;
    }
    
    if(accountEnable && securityCodeEnable)
    {
        [self.nextButton setGrayEnable:false];
    }else{
        [self.nextButton setGrayEnable:true];
    }
}

//传值到下个界面
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if([segue.identifier isEqualToString:PRESENT_FORGET_TO_RESET])
    {
        ResetPasswordViewController * presentVC = (ResetPasswordViewController*)segue.destinationViewController;
        presentVC.securityCode = self.securityCodeText.text;
        presentVC.account = self.accountText.text;
    }
}


- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.accountText resignFirstResponder];
    [self.securityCodeText resignFirstResponder];
}


- (IBAction)backAndCloseHandler:(UIButton *)sender {
    
    //关闭返回
    [self dismissViewControllerAnimated:true completion:nil];

    
}


-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}


@end
