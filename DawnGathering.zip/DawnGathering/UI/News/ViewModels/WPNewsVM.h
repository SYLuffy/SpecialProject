//
//  WPNewsVM.h
//  HLGA
//
//  Created by Stickey on 2019/3/11.
//  Copyright © 2019 Linus. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@class WPBannerModel;
@class WPNewsTypeModel;
@class WPDetailedModel;

typedef void (^WPNewsVMSuccessBlock)(void);
typedef void (^WPNewsVMFailedBlock)(NSError *error);
typedef void (^WPNewsVMNoMoreDataBlock)(void);

@interface WPNewsVM : NSObject

@property(nonatomic,assign)NSInteger moudelId;
@property(nonatomic,assign)NSInteger pageSize;
@property(nonatomic,assign)NSInteger page;
@property(nonatomic,strong)NSMutableArray *list;


@property (nonatomic,strong)NSMutableArray<WPBannerModel *> *bannerList;
@property (nonatomic,strong)NSMutableArray *imageBannerList;
@property (nonatomic,strong)NSMutableArray<WPNewsTypeModel *> *newsTypeList;
@property (nonatomic,strong)NSMutableArray *titleNewsTypeList;



-(void)loadNewsListSuccess:(WPNewsVMSuccessBlock)successBack failure:(WPNewsVMFailedBlock)failureBack;

-(void)loadNewsDetailsListSuccess:(WPNewsVMSuccessBlock)successBack failure:(WPNewsVMFailedBlock)failureBack noMoreDataBlock:(WPNewsVMNoMoreDataBlock )noMoreDataBlock;;

@end

@interface WPDetailedModel : NSObject
@property(nonatomic,strong)NSString *url;
@property(nonatomic,strong)NSString *img;
@property(nonatomic,strong)NSString *title;
@property(nonatomic,strong)NSString *content;



- (instancetype)initByDictionary:(NSDictionary*)dict;


@end
@interface WPBannerModel : NSObject

@property(nonatomic,strong)NSString *bannerImg;
@property(nonatomic,strong)NSString *url;

- (instancetype)initByDictionary:(NSDictionary*)dict;


@end

@interface WPNewsTypeModel : NSObject
@property(nonatomic,assign)NSInteger companyId;
@property(nonatomic,assign)NSInteger moudelId;
@property(nonatomic,strong)NSString *typName;

- (instancetype)initByDictionary:(NSDictionary*)dict;


@end

NS_ASSUME_NONNULL_END
