//
//  WPNewsVM.m
//  HLGA
//
//  Created by Stickey on 2019/3/11.
//  Copyright © 2019 Linus. All rights reserved.
//

#import "WPNewsVM.h"


@implementation WPNewsVM

-(NSMutableArray<WPBannerModel *> *)bannerList{
    if (!_bannerList) {
        _bannerList = [NSMutableArray array];
    }
    return _bannerList;
}

-(NSMutableArray<WPNewsTypeModel *> *)newsTypeList{
    if (!_newsTypeList) {
        _newsTypeList = [NSMutableArray array];
    }
    return _newsTypeList;
}

-(NSMutableArray *)imageBannerList{
    if (!_imageBannerList) {
        _imageBannerList  = [NSMutableArray array];
    }
    return _imageBannerList;
}


-(NSMutableArray *)titleNewsTypeList{
    if (!_titleNewsTypeList) {
        _titleNewsTypeList = [NSMutableArray array];
    }
    return _titleNewsTypeList;
}

-(NSMutableArray *)list{
    
    if (!_list) {
        _list = [NSMutableArray array];
    }
    return _list;
}

-(void)loadNewsListSuccess:(WPNewsVMSuccessBlock)successBack failure:(WPNewsVMFailedBlock)failureBack{

    [ServiceManager getNewsListSuccessBack:^(NSDictionary *data) {
        
        
        NSArray *bannerList = data[@"data"][@"bannerList"];
        if ([Utils checkObjectIsNull:bannerList]) {
            for (int i  = 0; i < [bannerList count]; i++) {
                WPBannerModel *model = [[WPBannerModel alloc]initByDictionary:bannerList[i]];
                [self.imageBannerList addObject:model.bannerImg];
                [self.bannerList addObject:model];
            }
        }
        
        NSArray *newsTypeList = data[@"data"][@"newType"];
        if ([Utils checkObjectIsNull:newsTypeList]) {
            for (int i  = 0; i < [newsTypeList count]; i++) {
                WPNewsTypeModel *model = [[WPNewsTypeModel alloc]initByDictionary:newsTypeList[i]];
                [self.titleNewsTypeList addObject:model.typName];
                [self.newsTypeList addObject:model];
            }
        }
        
        if (successBack != nil) {
            successBack();
        }
    } failure:^(NSError *error) {
        
    }];
}

- (void)loadNewsDetailsListSuccess:(WPNewsVMSuccessBlock)successBack failure:(WPNewsVMFailedBlock)failureBack noMoreDataBlock:(WPNewsVMNoMoreDataBlock)noMoreDataBlock{
    
    [ServiceManager getNewsDetailsListMoudelId:self.moudelId andPageIndex:@(self.page) andPageSize:@(self.pageSize) SuccessBack:^(NSDictionary *data) {
        NSArray *list = data[@"data"];
        if (_page == 0 || _page == 1) {
            [self.list removeAllObjects];
        }
        if([list isEqual:[NSNull null]]  ){
            if(noMoreDataBlock != nil){
                noMoreDataBlock();
                return;
            }
        }
        if ( list.count == 0) {
            if(noMoreDataBlock != nil){
                noMoreDataBlock();
                return;
            }
        }
        if (![list isEqual:[NSNull null]]) {
            for (int i = 0 ; i < list.count ; i++) {
                WPDetailedModel *model = [[WPDetailedModel alloc]initByDictionary:list[i]];
                [self.list addObject:model];
            }
        }
        if(successBack != nil){
            successBack();
            return;
        }
    } failure:^(NSError *error) {
        if (failureBack != nil) {
            failureBack(error);
            return ;
        }
    } ];
    
}

@end

@implementation WPDetailedModel
- (instancetype)initByDictionary:(NSDictionary*)dict
{
    self = [super init];
    if (self) {
        _url = dict[@"jumpUrl"];
        _img = dict[@"img"];
        _title = dict[@"title"];
        _content = dict[@"abstract"];
    }
    return self;
}

@end



@implementation WPBannerModel
- (instancetype)initByDictionary:(NSDictionary*)dict
{
    self = [super init];
    if (self) {
        _url = dict[@"jumpUrl"];
        _bannerImg = dict[@"bannerImg"];
    }
    return self;
}

@end


@implementation WPNewsTypeModel
- (instancetype)initByDictionary:(NSDictionary*)dict
{
    self = [super init];
    if (self) {
        
        _companyId = [dict[@"companyId"]integerValue];
        _moudelId = [dict[@"moudelId"]integerValue];
        _typName = dict[@"typName"];
    }
    return self;
}

@end
