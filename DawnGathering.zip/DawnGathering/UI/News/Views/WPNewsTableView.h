//
//  HomeTableView.h
//  GJTakeout
//
//  Created by 葛亮 on 2018/9/5.
//  Copyright © 2018年 葛亮. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WPNewsTableView : UITableView <UIGestureRecognizerDelegate>

@end
