//
//  WPNewsDetailsVC.m
//  HLGA
//
//  Created by Stickey on 2019/3/11.
//  Copyright © 2019 Linus. All rights reserved.
//

#import "WPNewsDetailsVC.h"
#import "WPNewsCell.h"
#import "QuickRefresh.h"
#import "UITableView+EZErrorView.h"
#import <UIImageView+WebCache.h>
#import "MBProgressHUD.h"
#import "OpenJSWebKitController.h"
//#import "OpenWebViewController.h"
@interface WPNewsDetailsVC ()

@property(nonatomic,strong)WPNewsVM *vm;
@property(nonatomic,strong)QuickRefresh * refresh;
@property(nonatomic,assign)EZErrorViewType errorType;
@property(nonatomic,assign)BOOL isRefresh;
@end

@implementation WPNewsDetailsVC


-(QuickRefresh *)refresh{
    if (!_refresh) {
        _refresh = [QuickRefresh new];
    }
    return _refresh;
}

-(WPNewsVM *)vm{
    if (!_vm) {
        _vm = [[WPNewsVM alloc] init];
        _vm.page = 1;
        _vm.pageSize = 10;
        _vm.moudelId = self.model.moudelId;

    }
    return _vm;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(manualRequest) name:@"NotificationWPNewsDetailsVCRequestNetwork" object:nil];
    
    __weak WPNewsDetailsVC *weakSelf = self;
    [self.refresh gifModelRefresh:self.tableView refreshType:RefreshTypeUpDrop firstRefresh:NO timeLabHidden:YES stateLabHidden:YES dropDownBlock:nil upDropBlock:^{
        if ( weakSelf.isRefresh == YES) {
            return;
        }
        weakSelf.vm.page +=1;
        [weakSelf request];
    }];
    [self.refresh noMoreData];
    [self oneRuest];
}

-(void)oneRuest{
    
    __weak WPNewsDetailsVC *weakSelf = self;
    
    
    CGFloat zoom = 0.7;
    CGFloat topIndex = -120;
    NSInteger titleFont = 12;
    
    NoDataView *noDataView = [NoDataView xibView];
    noDataView.backgroundColor = [UIColor whiteColor];
    [noDataView setImageOrTitileNoDataViewType:NoDataViewTypeDefault];
    [noDataView setZoomView:zoom topIndex:topIndex titileFont:titleFont];
    
    NoNetworkView *noNetworkView = [NoNetworkView xibView];
    noNetworkView.backgroundColor = [UIColor whiteColor];
    [noNetworkView setZoomView:zoom topIndex:topIndex titileFont:titleFont buttonFont:titleFont + 2];
    noNetworkView.reloadBlk = ^{
        weakSelf.errorType = EZErrorViewTypeProgress;
        [weakSelf.tableView reloadData];
        [weakSelf request];
    };
    
    [_tableView setErrorView:noDataView ForType:EZErrorViewTypeEmpty];
    [_tableView setErrorView:noNetworkView ForType:EZErrorViewTypeNetwork];
    
    self.errorType = EZErrorViewTypeDefault;
    
    MBProgressHUD * hud = [[MBProgressHUD alloc]initWithView:[Utils currentWindow]];

    [[Utils currentWindow] addSubview:hud];
    
    hud.mode = MBProgressHUDModeIndeterminate;
    
    [hud showAnimated:true];

    
    [self.vm loadNewsDetailsListSuccess:^{
        [hud hideAnimated:true];
        [weakSelf.tableView reloadData];
        [self.refresh yesData];
    } failure:^(NSError * _Nonnull error) {
        [hud hideAnimated:true];
        weakSelf.errorType = EZErrorViewTypeNetwork;
        [weakSelf.tableView reloadData];
    } noMoreDataBlock:^{
        [hud hideAnimated:true];
        weakSelf.errorType = EZErrorViewTypeEmpty;
        [weakSelf.tableView reloadData];
    }];
    
}
-(void)request{
    __weak WPNewsDetailsVC *weakSelf = self;
    [self.vm loadNewsDetailsListSuccess:^{
        if(weakSelf.isRefresh == YES){
            [weakSelf.refresh yesData];
            [weakSelf endRefresh];
        }
        weakSelf.isRefresh = NO;
        [weakSelf.refresh endRefreshing];
//        weakSelf.errorType = EZErrorViewTypeDefault;
        [weakSelf.tableView reloadData];
    } failure:^(NSError * _Nonnull error) {
        if(weakSelf.isRefresh == YES){
            [weakSelf endRefresh];
        }
        weakSelf.isRefresh = NO;
        [weakSelf.refresh endRefreshing];
        if (weakSelf.vm.list.count == 0) {
            weakSelf.errorType = EZErrorViewTypeNetwork;
            [weakSelf.tableView reloadData];
        }else{
            [Utils showToast:TOAST_NET_FAILURE];
        }
      
    } noMoreDataBlock:^{
        if(weakSelf.isRefresh == YES){
            [weakSelf endRefresh];
        }
        weakSelf.isRefresh = NO;
        [weakSelf.refresh endRefreshing];
        [weakSelf.refresh noMoreData];
        if (weakSelf.vm.list.count != 0 && weakSelf.vm.page == 1) {
        }else{
            weakSelf.errorType = EZErrorViewTypeEmpty;
            [weakSelf.tableView reloadData];
            [weakSelf.refresh noMoreData];
        }
    }];
}

-(void)endRefresh{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"NotificationWPNewsDetailsVCEndRefresh" object:nil];
}

-(void)manualRequest{
    
    if(self.isRefresh == YES){
        return;
    }
    [self.refresh noMoreData];
    self.vm.page = 1;
    self.isRefresh = YES;
    self.errorType = EZErrorViewTypeDefault;
    [self request];
}



#pragma UITableViewDataSource

- (NSInteger)tableView:(nonnull UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return self.vm.list.count;
}

- (nonnull UITableViewCell *)tableView:(nonnull UITableView *)tableView cellForRowAtIndexPath:(nonnull NSIndexPath *)indexPath {
    
    WPNewsCell *cell = [tableView dequeueReusableCellWithIdentifier:WPNewsCellString forIndexPath:indexPath];
    WPDetailedModel *model = self.vm.list[indexPath.row];
    
    cell.myTitileLable.text = model.title;
    cell.connectLable.text = model.content;
    [cell.headImageView sd_setImageWithURL:[NSURL URLWithString:model.img] placeholderImage:[UIImage imageNamed:@"placeholder_image"]];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 120;
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (!self.vcCanScroll) {
        scrollView.contentOffset = CGPointZero;
    }
    if (scrollView.contentOffset.y <= 0) {

        self.vcCanScroll = NO;
        scrollView.contentOffset = CGPointZero;
        [[NSNotificationCenter defaultCenter] postNotificationName:@"leaveTop" object:nil];
    }
    self.tableView.showsVerticalScrollIndicator = _vcCanScroll?YES:NO;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    WPDetailedModel *model = self.vm.list[indexPath.row];
    
    OpenJSWebKitController * webVC = [[OpenJSWebKitController alloc]init];
    webVC.goUrl = model.url ;
//    webVC.fromClass = [self class];
    webVC.webTitle = @"企业圈";
    [self.navigationController pushViewController:webVC animated:true];
}

#pragma UITableViewErrorViewDataSource

- (EZErrorViewType)tableViewTypeOfErrorViewToShow:(UITableView *)tableView
{
    return _errorType;
}
-(void)dealloc{
    [_tableView  dismissErrorView];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
@end
