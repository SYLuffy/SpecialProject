//
//  WPNewsMainVC.m
//  HLGA
//
//  Created by Stickey on 2019/3/5.
//  Copyright © 2019 Linus. All rights reserved.
//

#import "WPNewsMainVC.h"
#import "SGPageTitleView.h"
#import <SGPageContentScrollView.h>
#import "SGPageTitleViewConfigure.h"
#import "WPNewsDetailsVC.h"
#import "WPNewsBaseCell.h"
#import "WPNewsTableView.h"
#import "SDCycleScrollView.h"
#import "WPNewsPageView.h"
#import "WPNewsVM.h"
#import "QuickRefresh.h"
//#import "OpenWebViewController.h"
#import "OpenJSWebKitController.h"

@interface WPNewsMainVC ()<SGPageTitleViewDelegate,SGPageContentScrollViewDelegate,SDCycleScrollViewDelegate>

@property(nonatomic,strong)WPNewsVM *vm;

@property (weak, nonatomic) IBOutlet UIView *headView;
@property (weak, nonatomic) IBOutlet WPNewsTableView *tableView;

@property (nonatomic, strong) SGPageTitleView *pageTitleView;
@property (nonatomic, strong) SGPageContentScrollView *pageContentScrollView;

@property(nonatomic,assign) CGFloat headViewHeight;
@property(nonatomic,strong)WPNewsBaseCell * contentCell;

@property (nonatomic,strong)NSArray *childArr;
@property (nonatomic, assign) BOOL canScroll;

@property (weak, nonatomic) IBOutlet SDCycleScrollView *scrollView;
@property (weak, nonatomic) IBOutlet WPNewsPageView *pageView;

@property(nonatomic,strong)UIView *sectionView;
@property(nonatomic,assign)NSInteger nameLableHeight;

@property(nonatomic,strong)QuickRefresh * refresh;

@end

@implementation WPNewsMainVC

#pragma 懒加载

-(QuickRefresh *)refresh{
    if(!_refresh){
         _refresh = [QuickRefresh new];
    }
    return _refresh;
}

-(NSInteger )nameLableHeight{
    if ([self.vm.titleNewsTypeList count] > 1) {
        return 45;
    }
    return 0.01;
}

-(UIView *)sectionView{
    if (!_sectionView) {
        _sectionView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 44)];
        [_sectionView addSubview:self.pageTitleView];
        UIView *viewx = [[UIView alloc]initWithFrame:CGRectMake(0, 44, [UIScreen mainScreen].bounds.size.height, 0.5)];
        viewx.backgroundColor = [UIColor colorWithHexString:@"dedede"];
        [_sectionView addSubview:viewx];
    }
    return _sectionView;
}

-(WPNewsVM *)vm{
    if (!_vm) {
        _vm = [[WPNewsVM alloc]init];
    }
    return  _vm;
}

-(CGFloat )headViewHeight{
    CGFloat tempIndex = [UIScreen mainScreen].bounds.size.width - 30;
    _headViewHeight = (0.521739 * tempIndex ) + 45;
    return _headViewHeight;
}

-(SGPageTitleView *)pageTitleView{
    if (!_pageTitleView) {
        //设置指示器样式
        SGPageTitleViewConfigure *configure = [SGPageTitleViewConfigure pageTitleViewConfigure];
        configure.titleColor =  [UIColor colorWithHexString:@"323232"];
        configure.titleSelectedColor = [UIColor colorWithHexString:@"FDA23F"];
        configure.indicatorHeight = 2;
        configure.indicatorCornerRadius = 5;
        configure.indicatorColor = [UIColor colorWithHexString:@"FDA23F"];
        configure.titleFont = [UIFont fontWithName:@"PingFangSC-Regular" size:14];
        configure.indicatorStyle = SGIndicatorStyleDefault;
        configure.bottomSeparatorColor = [UIColor colorWithHexString:@"DEDEDE"];
        configure.indicatorAdditionalWidth = 60;
        _pageTitleView = [SGPageTitleView pageTitleViewWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 44) delegate:self titleNames:self.vm.titleNewsTypeList configure:configure];
        _pageTitleView.selectedIndex = 0;
        _pageTitleView.backgroundColor = [UIColor whiteColor];
    }
    return _pageTitleView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    __weak WPNewsMainVC *weakSelf = self;

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeScrollStatus) name:@"leaveTop" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(endRequest) name:@"NotificationWPNewsDetailsVCEndRefresh" object:nil];

    self.canScroll = YES;

    [self.refresh gifModelRefresh:weakSelf.tableView refreshType:RefreshTypeDropDown firstRefresh:NO timeLabHidden:YES stateLabHidden:YES dropDownBlock:^{
        [weakSelf.refresh endRefreshing];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"NotificationWPNewsDetailsVCRequestNetwork" object:nil];
    } upDropBlock:^{}];
    

    [self request];

}


-(void)endRequest{
    [self.refresh endRefreshing];
}

-(void)request{
    __weak WPNewsMainVC *weakSelf = self;
    
    [self.vm loadNewsListSuccess:^{
            [weakSelf initSDCycleScrollView];
            [weakSelf.tableView reloadData];
     
    } failure:^(NSError * _Nonnull error) {
   
    }];
}



-(void)initSDCycleScrollView{
    
    
    if ([self.vm.imageBannerList count]> 0) {
    
        self.headView.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, self.headViewHeight);
        self.tableView.tableHeaderView = self.headView;
        _scrollView.delegate = self;
        _scrollView.pageControlAliment = SDCycleScrollViewPageContolAlimentCenter;
        _scrollView.placeholderImage= [UIImage imageNamed:@"placeholder_image"];
        _scrollView.backgroundColor = [UIColor clearColor];
        _scrollView.showPageControl = NO;
        _scrollView.layer.cornerRadius = 5;
        _scrollView.layer.masksToBounds = YES;
        _scrollView.bannerImageViewContentMode =  UIViewContentModeScaleAspectFill;
        _scrollView.autoScrollTimeInterval = 3;
        _scrollView.imageURLStringsGroup = self.vm.imageBannerList;
        _pageView.userInteractionEnabled = NO;
        _pageView.inactiveImage = [UIImage imageNamed:@"carousel_off"];
        _pageView.inactiveImageSize = CGSizeMake(6, 3);
        _pageView.currentImage = [UIImage imageNamed:@"carousel_in"];
        _pageView.currentImageSize = CGSizeMake(10, 3);
        _pageView.currentPageIndicatorTintColor = [UIColor clearColor];
        _pageView.pageIndicatorTintColor = [UIColor clearColor];
        _pageView.numberOfPages = [self.vm.imageBannerList count];
        _pageView.currentPage = 0;
    
    }
    
   

}

#pragma UITableViewDataSource

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(nonnull UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return 1;
}

- (nonnull UITableViewCell *)tableView:(nonnull UITableView *)tableView cellForRowAtIndexPath:(nonnull NSIndexPath *)indexPath {

    _contentCell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];

    if ([self.vm.titleNewsTypeList count] > 0) {
        if (_contentCell && self.childArr.count <= 0) {
          
            NSMutableArray *arr = [NSMutableArray array];
            for (int i = 0;  i < [self.vm.titleNewsTypeList count]; i++) {
                WPNewsDetailsVC *vc  = [Utils getViewControllerByStoryBoardName:@"News_Storyboard" andIdentifier:@"WPNewsDetailsVC"];
                WPNewsTypeModel *model = self.vm.newsTypeList[i];
                vc.model = model;
                [arr addObject:vc];
            }
            _childArr = arr;
            _pageContentScrollView = [[SGPageContentScrollView alloc] initWithFrame:CGRectMake(0,0, _tableView.frame.size.width, _tableView.frame.size.height-self.nameLableHeight) parentVC:self childVCs:_childArr];
            _pageContentScrollView.isScrollEnabled = YES;
            _pageContentScrollView.delegatePageContentScrollView = self;
            
            _contentCell.viewControllers = [_childArr mutableCopy];
            [_contentCell.contentView addSubview: _pageContentScrollView];
        }
    }

    return _contentCell;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
        return self.sectionView;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return self.nameLableHeight;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    return _tableView.frame.size.height -  self.nameLableHeight;
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer
{
    return YES;
}

#pragma SGPageTitleViewDelegate
- (void)pageTitleView:(SGPageTitleView *)pageTitleView selectedIndex:(NSInteger)selectedIndex{
    [self.pageContentScrollView setPageContentScrollViewCurrentIndex:selectedIndex];
}
#pragma SGPageContentScrollViewDelegate

- (void)pageContentScrollView:(SGPageContentScrollView *)pageContentScrollView progress:(CGFloat)progress originalIndex:(NSInteger)originalIndex targetIndex:(NSInteger)targetIndex{
    [self.pageTitleView setPageTitleViewWithProgress:progress originalIndex:originalIndex targetIndex:targetIndex];
    
}
#pragma SDCycleScrollViewDelegate

/** 点击图片回调 */
- (void)cycleScrollView:(SDCycleScrollView *)cycleScrollView didSelectItemAtIndex:(NSInteger)index{
    self.pageView.currentPage = index;
    WPBannerModel *model =  self.vm.bannerList[index];
    OpenJSWebKitController * webVC = [[OpenJSWebKitController alloc]init];
    webVC.goUrl = model.url ;
    webVC.webTitle = @"企业圈";
    [self.navigationController pushViewController:webVC animated:true];}

/** 图片滚动回调 */
- (void)cycleScrollView:(SDCycleScrollView *)cycleScrollView didScrollToIndex:(NSInteger)index{
    self.pageView.currentPage = index;
    
}

#pragma mark UIScrollView
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat bottomCellOffset = 10;
    
    if ([self.vm.imageBannerList count]> 0) {
        bottomCellOffset = self.headViewHeight;
    }

    if (scrollView.contentOffset.y >= bottomCellOffset) {
        scrollView.contentOffset = CGPointMake(0, bottomCellOffset);
        if (self.canScroll) {
            self.canScroll = NO;
            self.contentCell.cellCanScroll = YES;
        }
    }else{
        if (!self.canScroll) {//子视图没到顶部
            scrollView.contentOffset = CGPointMake(0, bottomCellOffset);
        }
    }
    self.tableView.showsVerticalScrollIndicator = _canScroll?YES:NO;
}

#pragma mark notify
- (void)changeScrollStatus//改变主视图的状态
{
    self.canScroll = YES;
    self.contentCell.cellCanScroll = NO;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

@end
