//
//  WPNewsDetailsVC.h
//  HLGA
//
//  Created by Stickey on 2019/3/11.
//  Copyright © 2019 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WPNewsVM.h"
NS_ASSUME_NONNULL_BEGIN

@interface WPNewsDetailsVC : UIViewController

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic, assign) BOOL vcCanScroll;
@property(nonatomic,strong)WPNewsTypeModel *model;
@end

NS_ASSUME_NONNULL_END
