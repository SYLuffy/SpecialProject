//
//  WPNewsMainVC.h
//  HLGA
//
//  Created by Stickey on 2019/3/5.
//  Copyright © 2019 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface WPNewsMainVC : UIViewController

@end

NS_ASSUME_NONNULL_END
