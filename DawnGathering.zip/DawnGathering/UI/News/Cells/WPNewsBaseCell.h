//
//  WPNewsBaseCell.h
//  HLGA
//
//  Created by Stickey on 2019/3/11.
//  Copyright © 2019 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface WPNewsBaseCell : UITableViewCell

@property (nonatomic, strong) NSMutableArray *viewControllers;
@property (nonatomic, assign) BOOL cellCanScroll;

@end

NS_ASSUME_NONNULL_END
