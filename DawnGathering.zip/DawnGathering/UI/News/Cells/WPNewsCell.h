//
//  WPNewsCell.h
//  HLGA
//
//  Created by Stickey on 2019/3/7.
//  Copyright © 2019 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>

extern NSString  *WPNewsCellString;

NS_ASSUME_NONNULL_BEGIN

@interface WPNewsCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *headImageView;
@property (weak, nonatomic) IBOutlet UILabel *myTitileLable;
@property (weak, nonatomic) IBOutlet UILabel *connectLable;

+ (instancetype)xibTableViewCell;

@end

NS_ASSUME_NONNULL_END
