//
//  WPNewsCell.m
//  HLGA
//
//  Created by Stickey on 2019/3/7.
//  Copyright © 2019 Linus. All rights reserved.
//

#import "WPNewsCell.h"
NSString  *WPNewsCellString = @"WPNewsCell";

@interface WPNewsCell()

@end


@implementation WPNewsCell

+ (instancetype)xibTableViewCell{
    return [[[NSBundle mainBundle] loadNibNamed:WPNewsCellString owner:nil options:nil] lastObject];
    
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
