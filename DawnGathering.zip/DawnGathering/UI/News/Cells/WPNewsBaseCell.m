//
//  WPNewsBaseCell.m
//  HLGA
//
//  Created by Stickey on 2019/3/11.
//  Copyright © 2019 Linus. All rights reserved.
//

#import "WPNewsBaseCell.h"
#import "WPNewsDetailsVC.h"
@implementation WPNewsBaseCell

#pragma mark Setter
- (void)setViewControllers:(NSMutableArray *)viewControllers
{
    _viewControllers = viewControllers;
}

- (void)setCellCanScroll:(BOOL)cellCanScroll
{
    _cellCanScroll = cellCanScroll;
    
    for (WPNewsDetailsVC *VC in _viewControllers) {
        VC.vcCanScroll = cellCanScroll;
        if (!cellCanScroll) {//如果cell不能滑动，代表到了顶部，修改所有子vc的状态回到顶部
            VC.tableView.contentOffset = CGPointZero;
        }
    }
}

@end
