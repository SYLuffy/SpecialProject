//
//  SaasOrderListCountModel.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/8/17.
//

#import "SaasOrderListCountModel.h"

@implementation SaasOrderListCountModel


- (instancetype)initByDictionary:(NSDictionary*)dic
{
    self = [super init];
    
    if(self){
    
        [self setValuesForKeysWithDictionary:dic];
        
    }
    return self;
}


- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    NSLog(@"%@",value);
}

@end
