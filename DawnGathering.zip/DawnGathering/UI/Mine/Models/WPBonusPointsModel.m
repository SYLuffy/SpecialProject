//
//  WPBonusPointsConsumptionModel.m
//  HLGA
//
//  Created by 葛亮 on 2018/5/31.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "WPBonusPointsModel.h"

@implementation WPBonusPointsModel
- (instancetype)initByDictionary:(NSDictionary*)dic
{
    self = [super init];
    if (self) {
        _orderNumber = dic[@"orderNumber"];
        _transType = [dic[@"transType"]integerValue];
        _amount = [dic[@"amount"]integerValue];
        _createTime = [dic[@"createTime"]integerValue];
        _transDesc = dic[@"transDesc"];
        _merchantNumber = [dic[@"merchantNumber"]integerValue];
        _merchantName = dic[@"merchantName"];
        _terminalNumber = [dic[@"terminalNumber"]integerValue];
        _url = dic[@"url"];
//        _integralAmount = [dic[@"integralAmount"]integerValue];
        _tradeType = [dic[@"tradeType"]integerValue];//1 充值 2 消费
    }
    return self;
}
@end
