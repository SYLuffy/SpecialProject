//
//  SaasOrderListCountModel.h
//  DawnGathering
//
//  Created by 李冬岐 on 2023/8/17.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SaasOrderListCountModel : NSObject
- (instancetype)initByDictionary:(NSDictionary*)dic;

@property (nonatomic,strong)NSString * afterSaleOrderCount;
@property (nonatomic,strong)NSString * afterSaleOrderUrl;
@property (nonatomic,strong)NSString * toDeliveryOrderCount;
@property (nonatomic,strong)NSString * toDeliveryOrderUrl;

@property (nonatomic,strong)NSString * toPayOrderUrl;
@property (nonatomic,strong)NSString * toPayOrderCount;
@property (nonatomic,strong)NSString * toSendOrderCount;
@property (nonatomic,strong)NSString * toSendOrderUrl;
@end

NS_ASSUME_NONNULL_END
