//
//  WPBonusPointsConsumptionModel.h
//  HLGA
//
//  Created by 葛亮 on 2018/5/31.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WPBonusPointsModel : NSObject

@property(nonatomic,assign)NSInteger amount;
@property(nonatomic,assign)NSInteger createTime;
@property(nonatomic,assign)NSInteger merchantNumber;
@property(nonatomic,assign)NSString *orderNumber;
@property(nonatomic,assign)NSInteger terminalNumber;
@property(nonatomic,assign)NSInteger transType;
@property(nonatomic,strong)NSString *merchantName;
@property(nonatomic,strong)NSString *transDesc;
@property(nonatomic,strong)NSString *url;
//@property(nonatomic,assign)NSInteger integralAmount;
@property(nonatomic,assign)NSInteger tradeType;

- (instancetype)initByDictionary:(NSDictionary*)dic;
@end
