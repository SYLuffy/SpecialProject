//
//  MineMallCell.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/7/26.
//

#import "MineMallCell.h"
#import <UIView+WZLBadge.h>

#define IMAGE_TAG 300

@interface MineMallCell()

@end

@implementation MineMallCell

- (void)awakeFromNib {
    [super awakeFromNib];
    
    
    
    
}

- (void)setDataSource:(NSArray *)dataSource
{
    
    NSMutableArray  * tempSource = dataSource.mutableCopy;
    if([Utils checkObjectIsNull:[SharedInstance getInstance].userInfo.ygflhAuthUrl] && [SharedInstance getInstance].userInfo.ygflhAuthUrl.length > 1 && [self.cellTitleLabel.text isEqualToString:@"更多服务"])
    {
        [tempSource addObject:@{TITLE:@"历史订单",IMG:@"ic_history"}];
    }
    _dataSource = tempSource.copy;
    CGFloat WH = SCREEN_WIDTH / 375 * 30;
    
    NSInteger col = self.dataSource.count;
    
    if(col > 4) col = 4;
    
    CGFloat singleWidth = (SCREEN_WIDTH - 30) / col;
    
    for(NSInteger i = 0; i < self.dataSource.count; i++)
    {
        NSDictionary * dic = self.dataSource[i];
        
        NSNumber * number = dic[NUMBER];
        
        NSString * title = dic[TITLE];
        
        UIImageView * imageView = [self createImageWithImageURL:dic[IMG]];
        
        NSInteger index = i % col;
        
        CGFloat imageX = index  * singleWidth + (singleWidth - WH) * 0.5;
        
        CGFloat imageY = i / col * (WH + 32);
        
        imageView.frame = CGRectMake(imageX , imageY, WH, WH);
        
        
        UILabel * titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(index* singleWidth, imageView.frame.origin.y + imageView.frame.size.height + 5, singleWidth, 17)];
        
        titleLabel.font = [UIFont fontWithName:DEFAULT_FONT_NAME size:12];
        
        titleLabel.textAlignment = NSTextAlignmentCenter;
         
        titleLabel.textColor = UIColorFromRGB(0x222222);
        
        titleLabel.text = title;
        
        [self.listContainerView addSubview:imageView];
        [self.listContainerView addSubview:titleLabel];
        
        imageView.userInteractionEnabled = true;
        
        imageView.tag = IMAGE_TAG + i;
        
        UITapGestureRecognizer * tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapImageGestureHandler:)];
        [imageView addGestureRecognizer:tapGesture];
        
        if(number && number.integerValue > 0)
        {
            [imageView setBadgeBgColor:UIColorFromRGB(0xFF462D )];
            [imageView showBadgeWithStyle:WBadgeStyleNumber value:number.integerValue animationType:WBadgeAnimTypeNone];
            [imageView setBadgeCenterOffset:CGPointMake(0, 0)];
        }else{
            [imageView clearBadge];
        }
        
    }
}

- (void)tapImageGestureHandler:(UITapGestureRecognizer*)gesture
{
    NSInteger index = gesture.view.tag - IMAGE_TAG;
    
    NSDictionary * dic = self.dataSource[index];
    
    NSString * title = dic[TITLE];
    
    if(self.tapButtonWithTitle)
    {
        self.tapButtonWithTitle(title);
    }
}

- (void)drawRect:(CGRect)rect
{
    [super drawRect:rect];
    
    if(self.listContainerView.layer.shadowRadius == 0)
    {
        self.listContainerView.layer.shadowColor = [UIColor blackColor].CGColor;
       
        self.listContainerView.layer.shadowRadius = 6;
        
        self.listContainerView.layer.shadowOpacity = 0.05;
    }
    
}

- (IBAction)tapMoreHandler:(UIButton *)sender {
    //点击更多全部按钮;
    if(self.tapButtonWithTitle)
    {
        self.tapButtonWithTitle(@"全部");
    }
}


- (UIImageView*)createImageWithImageURL:(NSString*)imageURL
{
    CGFloat WH = SCREEN_WIDTH / 375 * 30;
    
    UIImageView * imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, WH, WH)];
    
//    [Utils loadImage:imageView andURL:imageURL isLoadRepeat:false];
    imageView.image = [UIImage imageNamed:imageURL];
    
    
    return imageView;
    
}

@end
