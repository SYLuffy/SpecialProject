//
//  WPBonusPointsCell.m
//  HLGA
//
//  Created by 葛亮 on 2018/8/30.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "WPBonusPointsCell.h"

@implementation WPBonusPointsCell

-(void)updataBonusPointsModel:(WPBonusPointsModel *)model{
    
    [Utils loadImage:_headImageView andURL:model.url isLoadRepeat:false];
    _timeLable.text =  [Utils getBonusPointsDateByTime:[NSString stringWithFormat:@"%ld",model.createTime]];
    _titileLable.text = model.merchantName;
    CGFloat amount = model.amount * 0.01;
    
    //1 充值 2 消费
    if (model.tradeType == 1) {
        _IntegralLable.text = [NSString stringWithFormat:@"+%.2f积分",amount];
        _IntegralLable.textColor = [UIColor colorWithRed:30/255.0 green:205/255.0 blue:151/255.0 alpha:1/1.0];
    }else if (model.tradeType == 2){
        _IntegralLable.text = [NSString stringWithFormat:@"-%.2f积分",amount];
        _IntegralLable.textColor = [UIColor colorWithRed:102/255.0 green:102/255.0 blue:102/255.0 alpha:1/1.0];
    }else{
        _IntegralLable.text = [NSString stringWithFormat:@"-%.2f积分",amount];
        _IntegralLable.textColor = [UIColor colorWithRed:102/255.0 green:102/255.0 blue:102/255.0 alpha:1/1.0];
    }
    
}

@end
