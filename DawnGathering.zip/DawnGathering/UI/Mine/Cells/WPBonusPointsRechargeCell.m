//
//  WPBonusPointsRechargeCell.m
//  HLGA
//
//  Created by 葛亮 on 2018/5/22.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "WPBonusPointsRechargeCell.h"
@implementation WPBonusPointsRechargeCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(void)updataBonusPointsModel:(WPBonusPointsModel *)model{
    
    [Utils loadImage:_headImageView andURL:model.url isLoadRepeat:false];
    _timeLable.text =  [Utils getBonusPointsDateByTime:[NSString stringWithFormat:@"%ld",model.createTime]];
    _titileLable.text = model.merchantName;
    CGFloat amount = model.amount * 0.01;
    _IntegralLable.text = [NSString stringWithFormat:@"+%.2f积分",amount];
}

@end
