//
//  MineMallCell.h
//  DawnGathering
//
//  Created by 李冬岐 on 2023/7/26.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^TapButtonWithTitle)(NSString * title);

@interface MineMallCell : UITableViewCell

@property (nonatomic,strong)NSArray * dataSource;
@property (weak, nonatomic) IBOutlet UIView *listContainerView;
@property (weak, nonatomic) IBOutlet UILabel *cellTitleLabel;
@property (weak, nonatomic) IBOutlet UIButton *moreButton;

@property (nonatomic,copy)TapButtonWithTitle tapButtonWithTitle;

@end

NS_ASSUME_NONNULL_END
