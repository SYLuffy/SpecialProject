//
//  WPBonusPointsConsumptionCell.h
//  HLGA
//
//  Created by 葛亮 on 2018/5/22.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WPBonusPointsModel.h"
@interface WPBonusPointsConsumptionCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *headImageView;
@property (weak, nonatomic) IBOutlet UILabel *titileLable;
@property (weak, nonatomic) IBOutlet UILabel *timeLable;
@property (weak, nonatomic) IBOutlet UILabel *IntegralLable;

-(void)updataBonusPointsModel:(WPBonusPointsModel *)model;
@end
