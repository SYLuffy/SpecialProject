//
//  MyRedEnvelopeViewController.h
//  DawnGathering
//
//  Created by 李冬岐 on 2024/5/10.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MyRedEnvelopeViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
