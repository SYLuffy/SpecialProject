//
//  RedEnvelopeListViewController.m
//  DawnGathering
//
//  Created by 李冬岐 on 2024/5/7.
//

#import "RedEnvelopeListViewController.h"
#import "QuickRefresh.h"
#import "UITableView+EZErrorView.h"
#import "RedEnvelopeCell.h"

@interface RedEnvelopeListViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UITableView *listTableView;
@property (nonatomic,assign)NSInteger page;

@property (nonatomic,strong)NSArray * dataSource;

@property (nonatomic,strong)QuickRefresh * refresh;

@property(nonatomic,assign)EZErrorViewType errorType;

@end

@implementation RedEnvelopeListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    self.listTableView.dataSource = self;
    self.listTableView.delegate = self;
    
    self.listTableView.tableFooterView = [UIView new];
    
    self.listTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    self.refresh = [[QuickRefresh alloc] init];
    
    self.page = 1;
    
    [self.refresh gifModelRefresh:self.listTableView refreshType:RefreshTypeDouble firstRefresh:false timeLabHidden:false stateLabHidden:false dropDownBlock:^{
        self.page = 1;
        [self refreshHandler];
    } upDropBlock:^{
        self.page += 1;
        
        [self refreshHandler];
    }];
    
    NoDataView *noDataView = [NoDataView xibView];
    [noDataView setImageOrTitileNoDataViewType:NoDataViewTypeDefault];
    WS(weakSelf);
    NoNetworkView *noNetworkView = [NoNetworkView xibView];
    noNetworkView.reloadBlk = ^{
        weakSelf.errorType = EZErrorViewTypeProgress;
        [weakSelf.listTableView reloadData];
        [weakSelf refreshHandler];
    };
    
    TableViewProgressView *tProgressView = [TableViewProgressView xibView];

    [self.listTableView setErrorView:noDataView ForType:EZErrorViewTypeEmpty];
    [self.listTableView  setErrorView:noNetworkView ForType:EZErrorViewTypeNetwork];
    [self.listTableView  setErrorView:tProgressView ForType:EZErrorViewTypeProgress];

    self.errorType = EZErrorViewTypeProgress;

    [self refreshHandler];
    
}



- (void)refreshHandler{
    
    [ServiceManager getUserRedEnvelopRecordListWithPage:@(self.page) pageSize:@20 success:^(NSDictionary *data) {
        
        NSArray * list = data[@"transactions"];
    
        
        if([Utils checkObjectIsNull:list])
        {
            if(list.count < 20){
                //没有更多数据
                [self.refresh noMoreData];
            }
            
            if(self.page == 1)
            {
                self.dataSource = list;
            }else{
                self.dataSource = [self.dataSource arrayByAddingObjectsFromArray:list];
            }
            
        }else{
            
            list = @[];
            self.errorType = EZErrorViewTypeEmpty;
        }
        
        if(self.dataSource.count == 0)
        {
            [self.refresh noMoreData];
        }
        
        [self.listTableView reloadData];
        
        [self.refresh endRefreshing];
    } failure:^(NSError *error) {
        self.dataSource = @[];
        
        self.errorType = EZErrorViewTypeNetwork;
        
        [self.refresh noMoreData];
        
        [self.listTableView reloadData];
        
        [self.refresh endRefreshing];
    }];
}

- (IBAction)backAndPopHandler:(UIBarButtonItem *)sender {
    [self.navigationController popViewControllerAnimated:true];
}



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    RedEnvelopeCell * cell = [tableView dequeueReusableCellWithIdentifier:@"RedEnvelopeCell"];
    
    if(!cell)
    {
        cell = (RedEnvelopeCell*)[Utils getXibByName:@"RedEnvelopeCell"];
    }
    
    NSDictionary * dic = self.dataSource[indexPath.row];
    
    NSNumber * amount = dic[AMOUNT];
    
    //交易类型 1 充值 2充值撤销 3转账 4发放红包 5发放红包回退 6 过期回收 7 消费使用红包 8 消费红包退货
    NSNumber * transType = dic[TRANS_TYPE];
    NSString * merchantName = dic[MERCHANT_NAME];
    
    NSString * title;
    NSString * img;
    NSString * flag;
    switch (transType.integerValue) {
        case 4:
        {
            img = @"ic_rp_transtype_fafang";
            title = @"获得红包";
            flag = @"+";
            break;
        }
        case 5:
        {
            img = @"ic_rp_transtype_chexiao";
            title = @"红包撤回";
            flag = @"-";
            break;
        }
        case 6:
        {
            img = @"ic_rp_transtype_guoqi";
            title = @"红包过期";
            flag = @"-";
            break;
        }
        case 7:
        {
            img = @"ic_rp_transtype_dikou";
            if(merchantName)
            {
                title = [NSString stringWithFormat:@"红包抵扣-%@",merchantName];
            }else{
                title = @"红包抵扣";
            }
            flag = @"-";
            break;
        }
        case 1:
        {
            img = @"ic_CAD";
            title = @"用户端无此交易类型";
            flag = @"+";
            break;
        }
        case 2:
        {
            img = @"ic_CAF";
            title = @"用户端无此交易类型";
            flag = @"-";
            break;
        }
        case 3:
        {
            img = @"ic_TAF";
            title = @"用户端无此交易类型";
            flag = @"+";
            break;
        }
        case 8:
        {
            img = @"ic_rp_transtype_fafang";
            title = @"红包返还";
            flag = @"+";
            break;
        }
        
        default:
            img = @"ic_rp_transtype_chexiao";
            title = @"未知类型";
            flag = @"-";
            break;
    }
    
    cell.typeLabel.text = title;
    cell.iconImageView.image = [UIImage imageNamed:img];
    
    cell.amountLabel.text = [NSString stringWithFormat:@"%@%.2lf",flag,amount.floatValue * 0.01];
    
    NSNumber * txTime = dic[TX_TIME];
    NSString * txContent = [Utils getDateByTime:[NSString stringWithFormat:@"%ld",txTime.integerValue] fomatter:@"yyyy-MM-dd HH:mm:ss"];
    cell.timeLabel.text = txContent;
    if([flag isEqualToString:@"+"])
    {
        cell.amountLabel.textColor = UIColorFromRGB(0xFF462D);
    }
    
    
    return cell;
}

#pragma mark -- UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80.0f;
}


- (EZErrorViewType)tableViewTypeOfErrorViewToShow:(UITableView *)tableView
{
    return _errorType;
}

-(void)dealloc{
    [_listTableView dismissErrorView];
    
}

@end
