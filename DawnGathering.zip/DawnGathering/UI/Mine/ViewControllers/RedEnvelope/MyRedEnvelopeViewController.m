//
//  MyRedEnvelopeViewController.m
//  DawnGathering
//
//  Created by 李冬岐 on 2024/5/10.
//

#import "MyRedEnvelopeViewController.h"
#import "MyRedEnvelopeCell.h"
#import "QuickRefresh.h"
#import "UITableView+EZErrorView.h"
@interface MyRedEnvelopeViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UILabel *totalRpAmountLabel;
@property (weak, nonatomic) IBOutlet UITableView *listTableView;

@property (nonatomic,strong)NSArray * dataSource;

@property (nonatomic,strong)QuickRefresh * refresh;

@property(nonatomic,assign)EZErrorViewType errorType;

@end

@implementation MyRedEnvelopeViewController

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [Utils setDefaultNavigationBar:self];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.listTableView.dataSource = self;
    self.listTableView.delegate = self;
    self.listTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.listTableView.tableFooterView = [UIView new];
    
    NoDataView *noDataView = [NoDataView xibView];
    [noDataView setImageOrTitileNoDataViewType:NoDataViewTypeRedEnvelope];
    WS(weakSelf);
    NoNetworkView *noNetworkView = [NoNetworkView xibView];
    noNetworkView.reloadBlk = ^{
        weakSelf.errorType = EZErrorViewTypeProgress;
        [weakSelf.listTableView reloadData];
        [weakSelf refreshHandler];
    };
    
    TableViewProgressView *tProgressView = [TableViewProgressView xibView];

    [self.listTableView setErrorView:noDataView ForType:EZErrorViewTypeEmpty];
    [self.listTableView  setErrorView:noNetworkView ForType:EZErrorViewTypeNetwork];
    [self.listTableView  setErrorView:tProgressView ForType:EZErrorViewTypeProgress];

    self.errorType = EZErrorViewTypeProgress;
    
    [self refreshHandler];
    
}

- (void)refreshHandler
{
    [ServiceManager getUserRedEnvelop:^(NSDictionary *data) {
       
        NSNumber * amount = data[AMOUNT];
        
        NSString * amountText = [NSString stringWithFormat:@"%.2lf",amount.floatValue * 0.01];
        
        self.totalRpAmountLabel.text = amountText;
        [Utils labelColorAttributedString:self.totalRpAmountLabel andRange:NSMakeRange(amountText.length - 2, 2) color:self.totalRpAmountLabel.textColor size:34];
        
        NSArray * items = data[ITEMS];
        
        if([Utils checkObjectIsNull:items])
        {
            self.dataSource = items;
        }else{
            self.dataSource = @[];
            
            self.errorType = EZErrorViewTypeEmpty;
        }
        
        [self.listTableView reloadData];

    }];
}

- (IBAction)rpHistoryHandler:(UIButton *)sender {
    //红包记录
    UIViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_ME andIdentifier:@"RedEnvelopeListViewController"];
    
    [self.navigationController pushViewController:vc animated:true];
}

- (IBAction)backAndPopHandler:(UIBarButtonItem *)sender {
    [self.navigationController popViewControllerAnimated:true];
}

#pragma mark -- UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    MyRedEnvelopeCell * cell = [tableView dequeueReusableCellWithIdentifier:@"MyRedEnvelopeCell"];
    
    if(!cell)
    {
        cell = (MyRedEnvelopeCell*)[Utils getXibByName:@"MyRedEnvelopeCell"];
    }
    NSDictionary * dic = self.dataSource[indexPath.row];
    
    NSNumber * amount = dic[AMOUNT];
    
    NSString * amountText = [NSString stringWithFormat:@"%.2lf",amount.floatValue * 0.01];
    
    cell.amountLabel.text = amountText;
    [Utils labelColorAttributedString:cell.amountLabel andRange:NSMakeRange(amountText.length - 2, 2) color:cell.amountLabel.textColor size:20];
    
    NSNumber * startTime = dic[OPEN_TIME];
    NSNumber * endTitme = dic[EXPIRY_TIME];
    
    NSString * start = [Utils getDateByTime:[NSString stringWithFormat:@"%ld",startTime.integerValue] fomatter:@"yyyy MM:dd HH:mm"];
    
    NSString * end  = [Utils getDateByTime:[NSString stringWithFormat:@"%ld",endTitme.integerValue] fomatter:@"yyyy MM:dd HH:mm"];
    
    cell.expiredLabel.text = [NSString stringWithFormat:@"有效期：%@ - %@",start,end];
    
    
    return cell;
}
#pragma mark -- UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 97.0f;
}

- (EZErrorViewType)tableViewTypeOfErrorViewToShow:(UITableView *)tableView
{
    return _errorType;
}

-(void)dealloc{
    [_listTableView dismissErrorView];
    
}

@end
