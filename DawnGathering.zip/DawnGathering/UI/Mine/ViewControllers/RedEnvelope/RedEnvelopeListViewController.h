//
//  RedEnvelopeListViewController.h
//  DawnGathering
//
//  Created by 李冬岐 on 2024/5/7.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface RedEnvelopeListViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
