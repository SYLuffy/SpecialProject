//
//  AccountDetailViewController.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/8/2.
//

#import "AccountDetailViewController.h"
#import "AccountDetailCell.h"
#import "AccountDetailHeader.h"
#import "AccountDetailSection.h"
#import "SpecialDetailViewController.h"
#import "MyPickupCardViewController.h"

@interface AccountDetailViewController ()<UITableViewDataSource,UITableViewDelegate,AccountDetailHeaderDelegate>
@property ( nonatomic,strong) UITableView *listTableView;
@property (nonatomic,strong)NSMutableArray <NSDictionary*>* dataSource;
@property (nonatomic,strong)AccountDetailHeader * detailHeader;
@property (weak, nonatomic) IBOutlet UIView *noDataView;


@property (nonatomic,assign)BOOL needUpdateUserInfo;

@end

@implementation AccountDetailViewController

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [Utils setClearNavigationBar:self titleColor:[UIColor whiteColor]];
    
    if(self.needUpdateUserInfo)
    {
        [self getUserInfo];
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    
    self.noDataView.hidden = true;
    self.listTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, - [Utils getNavigationBarAndStatusBarHeight:self], self.view.frame.size.width, self.view.frame.size.height + [Utils getNavigationBarAndStatusBarHeight:self]) style:UITableViewStyleGrouped];
    
    self.listTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.listTableView.dataSource = self;
    self.listTableView.delegate = self;
    
    CGFloat headerHeight = 215 + [Utils getStatusBarHeight:self];
    
    UIView * header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, headerHeight)];
    self.detailHeader = (AccountDetailHeader*)[Utils getXibByName:@"AccountDetailHeader"];
    
    self.detailHeader.topDistance.constant = [Utils getStatusBarHeight:self] + 54;
    self.detailHeader.frame = header.bounds;
    self.detailHeader.delegate = self;
    [header addSubview:self.detailHeader];
    self.listTableView.tableHeaderView = header;
    self.listTableView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:self.listTableView];
    
//    UIBarButtonItem * rightItem = [[UIBarButtonItem alloc] initWithTitle:@"收支明细" style:UIBarButtonItemStylePlain target:self action:@selector(tapBillListHandler)]; 
//    
//    rightItem.tintColor = [UIColor whiteColor];
//    
//    self.navigationItem.rightBarButtonItem = rightItem;
    
    [self updateUserDataSource];
}

- (void)tapBillListHandler{
    
    UIViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_ME andIdentifier:@"BillListViewController"];
    [self.navigationController pushViewController:vc animated:true];
}

- (void)updateUserDataSource
{
    self.dataSource = [NSMutableArray array];
    
    UserInfo * userInfo = [SharedInstance getInstance].userInfo;
    NSInteger totalAmount = userInfo.totalAmount.integerValue;
    NSInteger normalAmount = userInfo.normalAmount.integerValue;
    NSInteger specialAmount = userInfo.specialAmount.integerValue;
    NSInteger pickupCardAmount = userInfo.cardAmount.integerValue;
    NSInteger pickupCardCount = userInfo.cardCount.integerValue;
    
    
    for(NSDictionary * dic in userInfo.accountFundingTypes)
    {
        [self.dataSource addObject:dic];
    }
    

    NSString * amountText = [NSString stringWithFormat:@"%.2lf",totalAmount * 0.01];
    
    [Utils setUintWithLabel:self.detailHeader.totalAmountLabel andText:amountText fontSize:16];
    
    self.detailHeader.normalAmountLabel.text = [NSString stringWithFormat:@"%.2lf",normalAmount * 0.01];
    self.detailHeader.specialAmountLabel.text = [NSString stringWithFormat:@"%.2lf",specialAmount * 0.01];
    
    if(pickupCardCount == 0)
    {
        self.detailHeader.firstNormalWidth = [self changeMultiplierOfConstraint:self.detailHeader.firstNormalWidth multiplier:0.50f];
        
        self.detailHeader.pickupCardContainer.hidden = true;
    }else{
        self.detailHeader.firstNormalWidth = [self changeMultiplierOfConstraint:self.detailHeader.firstNormalWidth multiplier:0.33f];
        
        self.detailHeader.pickupAmountLabel.text = [NSString stringWithFormat:@"%.2lf",pickupCardAmount * 0.01];
        
        self.detailHeader.pickupCountLabel.text = [NSString stringWithFormat:@"提货券(%ld张)",pickupCardCount];
        
        self.detailHeader.pickupCardContainer.hidden = false;
    }
    
    [self.listTableView reloadData];
    
}

- (IBAction)backAndPopHandler:(UIBarButtonItem *)sender {
    [self.navigationController popViewControllerAnimated:true];
}


#pragma mark -- UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.dataSource.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;
{
    NSArray * userAccounts = self.dataSource[section][USER_ACCOUNTS];
    
    if(userAccounts.count == 0)
    {
        self.noDataView.hidden = false;
    }else{
        self.noDataView.hidden = true;
    }
    
    return userAccounts.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    AccountDetailCell * cell = [tableView dequeueReusableCellWithIdentifier:@"AccountDetailCell"];
    NSDictionary * accountFundingDic = self.dataSource[indexPath.section];
    
    NSArray * userAccounts = accountFundingDic[USER_ACCOUNTS];
    
    NSDictionary * dic = userAccounts[indexPath.row];
    
    if(!cell)
    {
        cell = (AccountDetailCell*)[Utils getXibByName:@"AccountDetailCell"];
    }
    
    cell.leftLabel.font = [UIFont fontWithName:DEFAULT_FONT_NAME size:14];
    cell.bottomLine.hidden = true;
    
    
    if(indexPath.row == userAccounts.count -1)
    {
        cell.isCornerRidausBottom = true;
    }
    
    NSString * itemName = dic[ITEM_NAME];
    
    NSNumber * amount = dic[AMOUNT];
    
    cell.rightLabel.text = [NSString stringWithFormat:@"%.2lf",amount.floatValue * 0.01];
    NSNumber * itemType = dic[ACCOUNT_ITEM_TYPE];
    NSNumber * itemMediumType = dic[ITEM_MEDIUM_TYPE];
    
    
    NSArray * physicalCardNO = dic[PHYSICAL_CARD_NO];
    
    NSInteger cardCout = 0;
    
    if([Utils checkObjectIsNull:physicalCardNO])
    {
        cardCout = physicalCardNO.count;
    }
    
    NSString * imageName;
    if(itemMediumType.integerValue == 1)
    {
        if(itemType.integerValue == 1)
        {
            imageName = @"ic_normal_flag";
            cell.leftLabel.text = itemName;
            cell.rightArrowImage.hidden = true;
        }else{
            imageName = @"ic_special_flag";
            cell.rightArrowImage.hidden = false;
            cell.leftLabel.text = itemName;
        }
    }else{
        imageName = @"ic_pickup_flag";
        cell.rightArrowImage.hidden = false;
        cell.leftLabel.text = [NSString stringWithFormat:@"%@（%ld张）",itemName,cardCout];
    }
    
    cell.leftFlag.image = [UIImage imageNamed:imageName];
        
    
    return cell;
}

#pragma mark -- UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary * accountFundingDic = self.dataSource[indexPath.section];
    
    NSArray * userAccounts = accountFundingDic[USER_ACCOUNTS];
    
    NSDictionary * dic = userAccounts[indexPath.row];
    
    NSNumber * itemType = dic[ACCOUNT_ITEM_TYPE];
    NSNumber * itemMediumType = dic[ITEM_MEDIUM_TYPE];
    NSNumber * itemId = dic[ITEM_ID];
    if(itemType.integerValue == 1 && itemMediumType.integerValue == 1)
    {
        return;
    }
    
    if(itemMediumType.integerValue == 2)
    {
        //提货券;
        MyPickupCardViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_ME andIdentifier:@"MyPickupCardViewController"];
        vc.selectItemID = itemId;
        
        [self.navigationController pushViewController:vc animated:true];
        
        return;
    }
    
    SpecialDetailViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_ME andIdentifier:@"SpecialDetailViewController"];
    vc.dataDic = dic;
    [self.navigationController pushViewController:vc animated:true];
    
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    AccountDetailSection * sectionView = (AccountDetailSection*)[Utils getXibByName:@"AccountDetailSection"];
    
    sectionView.frame = CGRectMake(0, 0, self.view.frame.size.width, 55);
    
    NSDictionary * dic = self.dataSource[section];
    
    NSString * name = dic[ACCOUNT_FUNDING_NAME];

    NSNumber * amount = dic[SUM_AMOUNT];
    
    sectionView.rightLabel.text = [NSString stringWithFormat:@"%.2lf",amount.floatValue * 0.01];
    
    sectionView.leftLabel.text = name;
    
    sectionView.isCornerRidausTop = true;
    
    
    return sectionView;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 45;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    NSDictionary * accountFundingDic = self.dataSource[section];
    NSArray * userAccounts = accountFundingDic[USER_ACCOUNTS];
    
    if(!userAccounts || userAccounts.count == 0) return 0;
    
    return 55;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0;
}
#pragma mark -- AccountDetailHeaderDelegate
- (void)gotoBillListHandler
{
    UIViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_ME andIdentifier:@"BillListViewController"];
    
    [self.navigationController pushViewController:vc animated:true];
}

- (void)gotoMyPickupCardHandler
{
    UIViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_ME andIdentifier:@"MyPickupCardViewController"];
    
    [self.navigationController pushViewController:vc animated:true];
    
    self.needUpdateUserInfo = true;
}

- (NSLayoutConstraint*)changeMultiplierOfConstraint:(NSLayoutConstraint *)constraint multiplier:(CGFloat)multiplier {
    [NSLayoutConstraint deactivateConstraints:@[constraint]];
    
    NSLayoutConstraint *newConstraint = [NSLayoutConstraint constraintWithItem:constraint.firstItem attribute:constraint.firstAttribute relatedBy:constraint.relation toItem:constraint.secondItem attribute:constraint.secondAttribute multiplier:multiplier constant:constraint.constant];
    newConstraint.priority = constraint.priority;
    newConstraint.shouldBeArchived = constraint.shouldBeArchived;
    newConstraint.identifier = constraint.identifier;
    
    [NSLayoutConstraint activateConstraints:@[newConstraint]];
    
    return newConstraint;
}

- (void)getUserInfo{
    //判断自动登录
    NSString *sid = [Utils getUserDefaultByKey:SID];
    if (sid.length != 0) {
        [ServiceManager getUserInformationBySid:sid successBack:^(NSDictionary *data) {
            NSDictionary * result = data[DATA];
            
            UserInfo * userInfo = [[UserInfo alloc] initByDictionary:result];
            [BuglyManager setPhoneNum:userInfo.telephone];
            [SharedInstance getInstance].userInfo = userInfo;
            [SharedInstance getInstance].sid = userInfo.sid;
            [Utils setUserDefaultByKey:SID andValue:userInfo.sid];
            
            [self updateUserDataSource];
        } failure:^(NSError *error) {
            
        }];
    }else{
        
    }
}

@end
