//
//  BindingPickupCardViewController.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/10/17.
//

#import "BindingPickupCardViewController.h"
#import "BindingPickupCardCell.h"
#import "ImageCell.h"
@interface BindingPickupCardViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *listTableView;

@property (nonatomic,strong)NSArray * dataSrouce;
@end

@implementation BindingPickupCardViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.listTableView.delegate = self;
    self.listTableView.dataSource = self;
    self.listTableView.tableFooterView = [UIView new];
    
    self.listTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    
    
}


- (IBAction)backAndPopHandler:(UIBarButtonItem *)sender {
    
    [self.navigationController popViewControllerAnimated:true];
}

#pragma mark -- UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;
{
    return self.dataSrouce.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSDictionary * dic = self.dataSrouce[indexPath.row];
    
    NSString * img = dic[IMG];
    
    if(img)
    {
        ImageCell * cell = [tableView dequeueReusableCellWithIdentifier:@"ImageCell"];
        
        if(!cell)
        {
            cell = (ImageCell*)[Utils getXibByName:@"ImageCell"];
        }
        
        cell.centerImageView.image = [UIImage imageNamed:img];
        
        
        if(indexPath.row == 2)
        {
            cell.tapBottomRightButtonHandler = ^{
                NSMutableString *str = [[NSMutableString alloc] initWithFormat:@"telprompt://%@",@"4008-331133"];
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:str] options:@{} completionHandler:nil];
            };
        }
        
        
        return cell;
    }
    
    
    BindingPickupCardCell * cell = [tableView dequeueReusableCellWithIdentifier:@"BindingPickupCardCell"];
    
    if(!cell)
    {
        cell  = (BindingPickupCardCell*)[Utils getXibByName:@"BindingPickupCardCell"];
    }
    
    WS(weakSelf);
    cell.tapBindingPickupCardHandler = ^(NSString * _Nullable cardNum, NSString * _Nullable pwd) {
        [weakSelf bindCardWithCardNum:cardNum cardPWD:pwd];
    };
    
    return cell;
    
}

#pragma mark -- UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.row == 1)
    {
        return 271.0f * RADIO;
    }else if(indexPath.row == 2)
    {
        return 312.0f * RADIO;
    }
    
    return 180.0f * RADIO;
}



- (void)bindCardWithCardNum:(NSString*)cardNum cardPWD:(NSString*)cardPWD
{
//    [ServiceManager bindPickupCardWithCardNO:cardNum cardPWD:cardPWD success:^(NSDictionary *data) {
//        
//        [Utils showToast:@"绑定成功!"];
//        
//        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.4 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//            
//            [self.navigationController popViewControllerAnimated:true];
//            
//        });
//        
//    }];
}


- (NSArray *)dataSrouce
{
    if(!_dataSrouce)
    {
        _dataSrouce = @[@{IMG:@"binding_card_top_img"},@{},@{IMG:@"binding_card_bottom_img"}];
    }
    
    return _dataSrouce;
}



@end
