//
//  SpecialDetailViewController.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/8/2.
//

#import "SpecialDetailViewController.h"
#import "SpecialDetailCell.h"
#import "UITestButtonView.h"
#import "WPHomeVC.h"
#import "MerchantListViewController.h"

#define CELL_HEIGHT 58

@interface SpecialDetailViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UITableView *listTableView;
@property (weak, nonatomic) IBOutlet UILabel *amountLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *contentViewHeight;///cell每行高度58;
@property (weak, nonatomic) IBOutlet UIView *bottomView;
@property (weak, nonatomic) IBOutlet UIView *topView;
@property (weak, nonatomic) IBOutlet UILabel *itemNameLabel;
@property (weak, nonatomic) IBOutlet UIView *line;
@property (weak, nonatomic) IBOutlet UIImageView *specialbackgroundImageView;//专项背景图;

@property (nonatomic,strong)NSArray * dataSource;

@property (nonatomic,strong)NSMutableArray * selectData;
@property (weak, nonatomic) IBOutlet UIButton *moreButton;//下拉button

@property (nonatomic,assign)BOOL isShowMoreStete;//是否显示更多状态;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bottomViewHeight;

@end

@implementation SpecialDetailViewController
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [Utils setDefaultNavigationBar:self];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.listTableView.dataSource = self;
    self.listTableView.delegate = self;
    self.isShowMoreStete = false;
    
    if(!self.dataSource)
    {
        self.dataSource = @[@{},@{},@{},@{},@{},@{},@{}];
    }
    
    NSString * amount = self.dataDic[AMOUNT];
    NSString * itemName = self.dataDic[ITEM_NAME];
    
    NSString * amountText = [NSString stringWithFormat:@"%.2lf",amount.integerValue * 0.01];
    
    [Utils setUintWithLabel:self.amountLabel andText:amountText fontSize:16];

    self.itemNameLabel.text = itemName;
    
    self.dataSource = self.dataDic[DETAILS];
    
    if([Utils checkObjectIsNull:self.dataSource] == false)
    {
        self.dataSource = @[];
    }

    
    if(self.dataSource.count <= 2)
    {
        self.moreButton.hidden = true;
        
        self.contentViewHeight.constant = 69 + self.dataSource.count * CELL_HEIGHT;
    }
    
    self.listTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.listTableView.tableFooterView = [UIView new];
    
    self.listTableView.rowHeight = CELL_HEIGHT;
    
    
    NSString * backgroundImageURL = self.dataDic[IMG];
    
    if(backgroundImageURL.length > 0)
    {
        [Utils loadImage:self.specialbackgroundImageView andURL:backgroundImageURL isLoadRepeat:false];
    }
    
   
    
    NSString * guideURL = self.dataDic[GUIDE_TEXT_URL];
    NSString * cardURL = self.dataDic[CARD_EXCHANGE_URL];
    NSString * shopURL = self.dataDic[SHOP_URL];
    NSString * offlineURL = self.dataDic[OFFLINE_MERCHANT_URL];
    self.selectData = [NSMutableArray array];
    BOOL lineHidden = true;
    if(guideURL.length > 0)
    {
        [self.selectData addObject:@{NAME:@"使用说明"}];
        lineHidden = false;
    }
    
    if(offlineURL.length > 0)
    {
        [self.selectData addObject:@{NAME:@"线下商户"}];
        lineHidden = false;
    }

    if(shopURL.length > 0)
    {
        [self.selectData addObject:@{NAME:@"线上商城"}];
        lineHidden = false;
    }
    
    if(cardURL.length > 0)
    {
        [self.selectData addObject:@{NAME:@"卡券兑换"}];
        lineHidden = false;
    }
    
    self.line.hidden = lineHidden;
    
    if(lineHidden == true)
    {
        self.bottomViewHeight.constant = 0;
        
        self.topView.layer.cornerRadius = 10;
    }
    
    
    UITestButtonView * selectView = [[UITestButtonView alloc] initWithFrame: CGRectMake(0, 0, SCREEN_WIDTH - 30, 44)];

    
    selectView.selectedColor = UIColorFromRGB(0X666666);
    selectView.normalColor = UIColorFromRGB(0X666666);
    WS(weakSelf);
    selectView.tapSelectViewButtonWithIndex = ^(NSInteger index, NSInteger cellIndex) {

        [weakSelf showViewWithIndex:index];

    };
    
    [selectView updateRefreshViewWith:self.selectData curentPage:0];
    
//    UITestButtonView * selectView = [[UITestButtonView alloc] init];
//
//    selectView.frame = CGRectMake(0, 0, SCREEN_WIDTH, 60);
//
    [self.view addSubview:selectView];
    
    
    [self.bottomView addSubview:selectView];

    
    [self.view layoutIfNeeded];
}
- (void)viewWillLayoutSubviews
{
    [Utils cornerRadiusBottomLRWithView:self.bottomView withRadius:10];
    [Utils cornerRadiusTopLRWithView:self.specialbackgroundImageView withRadius:10];
}

- (IBAction)showMoreHandler:(UIButton *)sender {
    sender.selected = !sender.selected;
    
    if(sender.selected)
    {
        self.isShowMoreStete = true;
        CGFloat totalHeight = self.view.frame.size.height - 243;
        CGFloat contentViewHeight = 69 + self.dataSource.count * CELL_HEIGHT;
        
        if(contentViewHeight > totalHeight) contentViewHeight = totalHeight;
        
        self.contentViewHeight.constant = contentViewHeight;
        
    }else{
        self.isShowMoreStete = false;
        
        self.contentViewHeight.constant = 69 + 2 * CELL_HEIGHT;
    }
    
    [self.listTableView reloadData];
}

- (void)showViewWithIndex:(NSInteger)index
{
    NSDictionary * dic = self.selectData[index];
    
    NSString * name = dic[NAME];
    
    
    if([name isEqualToString:@"线下商户"])
    {
        //线下
        MerchantListViewController * listVC = [[MerchantListViewController alloc] init];
        
        NSNumber * itemId = self.dataDic[ITEM_ID];
        
        NSArray * blackWhiteList = dic[WHITE_IDS];
        
        [SharedInstance getInstance].sendBlackWhiteList = blackWhiteList;
        
        listVC.items = @[[NSString stringWithFormat:@"%ld",itemId.integerValue]];
        [self.navigationController pushViewController:listVC animated:true];
    }else if([name isEqualToString:@"卡券兑换"])
    {
        NSString * cardURL = self.dataDic[CARD_EXCHANGE_URL];
        
        if([cardURL hasPrefix:@"http"])
        {
            [Utils pushWebViewControllerURL:cardURL owner:self];
        }else{
            
            if(!cardURL || cardURL.length == 0)
            {
                [Utils showToast:@"未识别到正确的配置id"];
                return;
            }
            
            WPHomeVC * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_HOME andIdentifier:@"WPHomeVC"];
            vc.homePageID = cardURL;
            [[Utils getCurrentVC].navigationController pushViewController:vc animated:true];
        }
        
        
    }else if([name isEqualToString:@"使用说明"])
    {
        NSString * guideURL = self.dataDic[GUIDE_TEXT_URL];
        [Utils pushWebViewControllerURL:guideURL owner:self];
    }else if([name isEqualToString:@"线上商城"])
    {
        NSString * shopURL = self.dataDic[SHOP_URL];
        [Utils pushWebViewControllerURL:shopURL owner:self];
    }
}

- (IBAction)backAndPopHandler:(UIBarButtonItem *)sender {
    
    [self.navigationController popViewControllerAnimated:true];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;

{
    if(self.isShowMoreStete == false && self.dataSource.count > 2)
    {
        return 2;
    }
    
    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    SpecialDetailCell * cell = [tableView dequeueReusableCellWithIdentifier:@"SpecialDetailCell"];
    
    if(!cell)
    {
        cell = (SpecialDetailCell*)[Utils getXibByName:@"SpecialDetailCell"];
    }
    
    NSDictionary * dic = self.dataSource[indexPath.row];
    
    NSNumber * amount = dic[AMOUNT];
    NSNumber * expireTime = dic[EXPIRE_TIME];
    NSNumber * createTime = dic[CREATE_TIME];
    
  
    NSString * amountText = [NSString stringWithFormat:@"%.2lf",amount.floatValue * 0.01];
    
    [Utils setUintWithLabel:cell.amountLabel andText:amountText fontSize:16];
    
    cell.createLabel.text = [NSString stringWithFormat:@"发放时间：%@",[Utils getDateByTime:[NSString stringWithFormat:@"%ld",createTime.integerValue] fomatter:@"yyyy-MM-dd"]];
    
    cell.expireLabel.text = [NSString stringWithFormat:@"到期时间：%@",[Utils getDateByTime:[NSString stringWithFormat:@"%ld",expireTime.integerValue] fomatter:@"yyyy-MM-dd"]];
    
    return cell;
}

@end
