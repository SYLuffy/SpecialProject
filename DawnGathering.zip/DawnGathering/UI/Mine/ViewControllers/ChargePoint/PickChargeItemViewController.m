//
//  PickChargeItemViewController.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/11/7.
//

#import "PickChargeItemViewController.h"
#import "PickChargeTitleHeader.h"
#import "PickChargeItemCell.h"

@interface PickChargeItemViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *listTableView;

@property (nonatomic,strong)NSMutableArray * dataSource;
@property (nonatomic,strong)NSIndexPath * indexPath;

@end

@implementation PickChargeItemViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.listTableView.dataSource = self;
    self.listTableView.delegate = self;
    
    self.listTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.listTableView.tableFooterView = [UIView new];
    
    [self updateUserDataSource];
    
    if(self.selectIndexPath)
    {
        self.indexPath = self.selectIndexPath;
        
        [self.listTableView selectRowAtIndexPath:self.selectIndexPath animated:NO scrollPosition:UITableViewScrollPositionNone];
        
    }else{
        if(self.dataSource.count > 0)
        {
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:0];
            
            self.indexPath = indexPath;
            
            [self.listTableView selectRowAtIndexPath:indexPath animated:NO scrollPosition:UITableViewScrollPositionNone];
        }
    }
    
    
}
- (IBAction)confirmHandler:(UIButton *)sender {
    
    //确定;
    if(self.tapPickChargeConfirmWithIndex)
    {
        self.tapPickChargeConfirmWithIndex(self.indexPath);
    }
    
    [self.navigationController popViewControllerAnimated:true];

}

- (void)updateUserDataSource
{
    self.dataSource = [NSMutableArray array];
    
    UserInfo * userInfo = [SharedInstance getInstance].userInfo;
    
    
    for(NSDictionary * dic in userInfo.accountFundingTypes)
    {
        NSArray * userAccounts = dic[USER_ACCOUNTS];
        NSString * accountFundingName = dic[ACCOUNT_FUNDING_NAME];
        NSMutableArray * canUseAccounts = [NSMutableArray array];
        for(NSDictionary * accountDic in userAccounts)
        {
            NSNumber * itemType = accountDic[ACCOUNT_ITEM_TYPE];
            NSNumber * itemMediumType = accountDic[ITEM_MEDIUM_TYPE];
            
            if(itemType.integerValue == 1 && itemMediumType.integerValue == 1)
            {
                [canUseAccounts addObject:accountDic];
            }
        }
        
        if(canUseAccounts.count > 0)
        {
            [self.dataSource addObject:@{ACCOUNT_FUNDING_NAME:accountFundingName,USER_ACCOUNTS:canUseAccounts}];
        }
        
    }
    
//    for(NSDictionary * dic in userInfo.accountFundingTypes)
//    {
////        NSArray * userAccounts = dic[USER_ACCOUNTS];
//        [self.dataSource addObject:dic];
//    }
//    
//    for(NSDictionary * dic in userInfo.accountFundingTypes)
//    {
////        NSArray * userAccounts = dic[USER_ACCOUNTS];
//        [self.dataSource addObject:dic];
//    }
//    
//    [self.listTableView reloadData];
    
}


- (IBAction)backAndPopHandler:(UIBarButtonItem *)sender {
    [self.navigationController popViewControllerAnimated:true];
}


#pragma mark -- UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.dataSource.count;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    NSDictionary * dic = self.dataSource[section];
    
    NSArray * userAccounts = dic[USER_ACCOUNTS];
    
    return userAccounts.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    PickChargeItemCell * cell = [tableView dequeueReusableCellWithIdentifier:@"PickChargeItemCell"];
    
    if(!cell)
    {
        cell = (PickChargeItemCell*)[Utils getXibByName:@"PickChargeItemCell"];
    }
    NSDictionary * userAccountsDic = self.dataSource[indexPath.section];
    
    NSArray * userAccounts = userAccountsDic[USER_ACCOUNTS];
    
    NSDictionary * dic  = userAccounts[indexPath.row];
    
    NSString * itemName = dic[ITEM_NAME];
    NSNumber * amount = dic[AMOUNT];
    
    cell.itemNameLabel.text = itemName;
    
    NSString * attriteText = [NSString stringWithFormat:@"余额%.2lf",amount.floatValue * 0.01];
    
    [Utils setUintWithLabel:cell.balanceLabel andText:attriteText fontSize:12];
    
    if(indexPath.row == userAccounts.count - 1)
    {
        cell.isCornerRidausBottom = true;
    }
    

    
    NSNumber * itemType = dic[ACCOUNT_ITEM_TYPE];
    NSNumber * itemMediumType = dic[ITEM_MEDIUM_TYPE];
    
    NSString * imageName;
    if(itemMediumType.integerValue == 1)
    {
        if(itemType.integerValue == 1)
        {
            imageName = @"ic_normal_flag";
          
        }else{
            imageName = @"ic_special_flag";
            
        }
    }else{
        imageName = @"ic_pickup_flag";
       
    }
    
    cell.leftFlag.image = [UIImage imageNamed:imageName];
    
    
    return cell;
}
#pragma mark -- UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 69.0f;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 70.0f;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0.01f;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    NSDictionary * dic = self.dataSource[section];
    
    NSString * accountFundingName = dic[ACCOUNT_FUNDING_NAME];
    
    
    PickChargeTitleHeader * headerView = (PickChargeTitleHeader*)[Utils getXibByName:@"PickChargeTitleHeader"];
    
    headerView.accountFundingNameLabel.text = accountFundingName;
    
    headerView.isCornerRidausTop = true;
    
    return headerView;
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    self.indexPath = indexPath;
}

@end
