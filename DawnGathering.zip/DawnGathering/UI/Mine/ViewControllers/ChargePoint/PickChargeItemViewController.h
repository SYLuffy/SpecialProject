//
//  PickChargeItemViewController.h
//  DawnGathering
//
//  Created by 李冬岐 on 2023/11/7.
//

#import <UIKit/UIKit.h>


NS_ASSUME_NONNULL_BEGIN

typedef void(^TapPickChargeConfirmWithIndex)(NSIndexPath * indexPath);

@interface PickChargeItemViewController : UIViewController


@property (nonatomic,copy)TapPickChargeConfirmWithIndex tapPickChargeConfirmWithIndex;


@property (nonatomic,strong)NSIndexPath * selectIndexPath;

@end

NS_ASSUME_NONNULL_END
