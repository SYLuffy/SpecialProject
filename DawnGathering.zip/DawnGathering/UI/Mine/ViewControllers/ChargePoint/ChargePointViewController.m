//
//  ChargePointViewController.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/11/7.
//

#import "ChargePointViewController.h"
#import "ChargePointInputCell.h"

#import "ChargePointFooterView.h"
#import "PickChargeItemViewController.h"
#import "BillListViewController.h"

@interface ChargePointViewController ()<UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UILabel *balanceLabel;//余额

@property (weak, nonatomic) IBOutlet UIButton *itemButton;
//默认通用福利;
@property (weak, nonatomic) IBOutlet UITableView *listTableView;
@property (weak, nonatomic) IBOutlet UIButton *chargeButton;


@property (nonatomic,strong)ChargePointFooterView *footerView;

@property (nonatomic,strong)ChargePointInputCell *inputCell;

@property (nonatomic,strong)NSNumber * currentItemID;


@property (nonatomic,strong)NSIndexPath * currentIndexPath;

@property (nonatomic,strong)NSMutableArray * dataSource;

@property (nonatomic,strong)NSNumber * currentPayType;
@property (weak, nonatomic) IBOutlet UIView *topView;

@end

@implementation ChargePointViewController


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [Utils setDefaultNavigationBar:self];
}


- (void)refreshAllAccountHandler
{
    self.dataSource = [NSMutableArray array];
    
    UserInfo * userInfo = [SharedInstance getInstance].userInfo;
    
    for(NSDictionary * dic in userInfo.accountFundingTypes)
    {
        NSArray * userAccounts = dic[USER_ACCOUNTS];
        NSString * accountFundingName = dic[ACCOUNT_FUNDING_NAME];
        NSMutableArray * canUseAccounts = [NSMutableArray array];
        for(NSDictionary * accountDic in userAccounts)
        {
            NSNumber * itemType = accountDic[ACCOUNT_ITEM_TYPE];
            NSNumber * itemMediumType = accountDic[ITEM_MEDIUM_TYPE];
            
            if(itemType.integerValue == 1 && itemMediumType.integerValue == 1)
            {
                [canUseAccounts addObject:accountDic];
            }
        }
        
        if(canUseAccounts.count > 0)
        {
            [self.dataSource addObject:@{ACCOUNT_FUNDING_NAME:accountFundingName,USER_ACCOUNTS:canUseAccounts}];
        }
    }
//    for(NSDictionary * dic in userInfo.accountFundingTypes)
//    {
////        NSArray * userAccounts = dic[USER_ACCOUNTS];
//        [self.dataSource addObject:dic];
//    }
//    
//    for(NSDictionary * dic in userInfo.accountFundingTypes)
//    {
////        NSArray * userAccounts = dic[USER_ACCOUNTS];
//        [self.dataSource addObject:dic];
//    }
    
    NSDictionary * userAccountDic = self.dataSource[self.currentIndexPath.section];
    
    NSArray * userAccounts = userAccountDic[USER_ACCOUNTS];
    
    NSDictionary * dic = userAccounts[self.currentIndexPath.row];
    
    NSNumber * amount = dic[AMOUNT];
    [Utils setUintWithLabel:self.balanceLabel andText:[NSString stringWithFormat:@"%.2lf",amount.floatValue * 0.01] fontSize:self.balanceLabel.font.pointSize];
    
    NSNumber * itemID = dic[ITEM_ID];
    
    NSString * accountFundingName = dic[ACCOUNT_FUNDING_NAME];
    NSString * accountFundingType = dic[ACCOUNT_FUNDING_TYPE];
    NSString * itemName = dic[ITEM_NAME];
    
    if(accountFundingName == nil && itemName == nil)
    {
        self.topView.hidden = true;
        self.listTableView.hidden = true;
        self.chargeButton.hidden = true;
    }else{
        self.topView.hidden = false;
        self.listTableView.hidden = false;
        self.chargeButton.hidden = false;
    }
    
    self.currentItemID = itemID;
    
    
    
    [self.itemButton setTitle:[NSString stringWithFormat:@"%@（%@）",itemName,accountFundingName] forState:UIControlStateNormal];
    
    
    [ServiceManager getPayStyleWithAccountFundingType:accountFundingType success:^(NSDictionary *data) {
        
        
        NSArray * list = data[DATA];
        
        if([Utils checkObjectIsNull:list])
        {
            [self.footerView updateWithDataSource:list];
        }else{
            [self.footerView updateWithDataSource:@[]];
        }
        
        
        
    }];
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.currentIndexPath = [NSIndexPath indexPathForRow:0 inSection:0];
    
    self.listTableView.dataSource = self;
    self.listTableView.rowHeight = 162.0f;
    
    self.listTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    UIView * footer = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 194)];
    
    self.footerView = (ChargePointFooterView*)[Utils getXibByName:@"ChargePointFooterView"];
    WS(weakSelf);
    self.footerView.tapChargeWithPayType = ^(NSNumber * _Nullable payType) {
        weakSelf.currentPayType = payType;
    };
    
    
    self.footerView.frame = footer.bounds;
    
    [footer addSubview:self.footerView];
    
    self.listTableView.tableFooterView = footer;
    
    self.currentPayType = @1;
    
    [Utils refreshUserInfo:^(BOOL isCompleted) {
        
        [self refreshAllAccountHandler];
    }];
    
    self.currentIndexPath = [NSIndexPath indexPathForRow:0 inSection:0];
    
}
- (IBAction)watchBillListHandler:(UIBarButtonItem *)sender {
    
    BillListViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_ME andIdentifier:@"BillListViewController"];
    
    vc.defaultIndex = 1;
    
    [self.navigationController pushViewController:vc animated:true];
}
- (IBAction)backAndPopHandler:(UIBarButtonItem *)sender {
    [self.navigationController popViewControllerAnimated:true];
}

- (IBAction)tapItemButtonHandler:(UIButton *)sender {
    //点击选择;
    PickChargeItemViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_ME andIdentifier:@"PickChargeItemViewController"];
    
    WS(weakSelf);
    vc.tapPickChargeConfirmWithIndex = ^(NSIndexPath * _Nonnull indexPath) {
        
        weakSelf.currentIndexPath = indexPath;
        
        [weakSelf refreshAllAccountHandler];
        
    };
    
    vc.selectIndexPath = self.currentIndexPath;
    
    [self.navigationController pushViewController:vc animated:true];
}
- (IBAction)sendChargeHandler:(UIButton *)sender {
    
    //提交充值;
    
    if(self.inputCell.inputText.text.floatValue == 0 && self.inputCell.inputText.text.length > 0)
    {
        [Utils showToast:@"输入金额错误"];
        return;
    }
    
    if(self.inputCell.inputText.text.length == 0)
    {
        [Utils showToast:self.inputCell.inputText.placeholder];
        
        return;
    }
    
    if(!self.currentPayType)
    {
        [Utils showToast:@"请选择支付方式"];
        return;
    }
    

    NSInteger amount = self.inputCell.inputText.text.floatValue * 100;
    
    [ServiceManager userAccountChargeWithItemID:self.currentItemID amount:@(amount) payType:self.currentPayType success:^(NSDictionary *data) {
        
        
        NSString * jsonStr = data[PAY_ORDER_INFO];
        NSDictionary * payOrderInfo = [Utils dictionaryWithJsonString:jsonStr];
        [self wechantPayWithDic:payOrderInfo ];
        
    }];
    
    
}


- (void)wechantPayWithDic:(NSDictionary*)payOrderInfo
{
    [[SharedInstance getInstance] wechatByPayInfo:payOrderInfo];
    
    
    [SharedInstance getInstance].wechatPayResult = ^(NSInteger result) {
       
        
        
        if(result == 1)
        {
            //支付成功
            self.inputCell.inputText.text = @"";
            [Utils alertWithTitle:@"提示" msg:@"充值成功!" confirm:^(BOOL isConfirm) {
                
                
            }];
            
            [Utils refreshUserInfo:^(BOOL isCompleted) {
                
                
                [self refreshAllAccountHandler];
                
                
            }];
            
        }else{
            //支付失败
            [Utils showToast:@"支付取消"];
        }
        
    };
}

#pragma mark -- UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    ChargePointInputCell * cell = [tableView dequeueReusableCellWithIdentifier:@"ChargePointInputCell"];
    
    if(!cell)
    {
        cell = (ChargePointInputCell*)[Utils getXibByName:@"ChargePointInputCell"];
    }
    
    self.inputCell = cell;
    
    
    return cell;
}



@end
