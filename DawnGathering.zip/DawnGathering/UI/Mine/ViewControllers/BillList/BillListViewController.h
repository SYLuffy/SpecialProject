//
//  MyOrderViewController.h
//  DawnGathering
//
//  Created by 李冬岐 on 2023/8/1.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BillListViewController : UIViewController

@property (nonatomic,assign)NSInteger defaultIndex;

@end

NS_ASSUME_NONNULL_END
