//
//  MyOrderViewController.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/8/1.
//

#import "BillListViewController.h"
#import "BillListHeader.H"
#import "BillListCell.h"
#import "UITableView+EZErrorView.h"
#import "NoDataView.h"
#import "QuickRefresh.h"
#import "LBDatePickerView.h"
#import "BillingInfoViewController.h"
#import "UITableView+EZErrorView.h"

#define BUTTON_TAG 400

@interface BillListViewController ()<UITableViewDelegate,UITableViewDataSource,UIScrollViewDelegate>

@property (nonatomic,strong)NSArray <UIButton*>* tabButtons;

@property (nonatomic,strong)NSMutableArray <NSArray*>* dataSource;
@property (weak, nonatomic) IBOutlet UIView *topTabBarContentView;

@property (nonatomic,strong)UIView * selectLine;

@property (weak, nonatomic) IBOutlet UIButton *allButton;

@property (weak, nonatomic) IBOutlet UIButton *getButton;
@property (weak, nonatomic) IBOutlet UIButton *costButton;

@property (nonatomic,strong)UIScrollView * pageView;

@property (nonatomic,strong)NSMutableArray <UITableView*>* listTableViews;
@property (nonatomic,assign)NSInteger yearIndex;
@property (nonatomic,strong)QuickRefresh *refresh;
@property(nonatomic,strong)NSMutableArray <NSNumber*>* errorTypes;

@property (nonatomic,strong)NSMutableArray <NSNumber*>* pages;
@property (nonatomic,assign)NSInteger currentType;
@property (nonatomic,strong)LBDatePickerView * datePicker;

@property (nonatomic,strong)NSMutableArray <NSString*>* currentYears;

@property (nonatomic,strong)NSMutableArray <BillListHeader*>* headers;

@property (nonatomic,assign)BOOL isRefresh;

@property (nonatomic,assign)NSInteger refreshType;

@property (nonatomic,assign)BOOL firstRefresh;


@end

@implementation BillListViewController

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [Utils setDefaultNavigationBar:self];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.firstRefresh = false;
    self.isRefresh = false;
    self.currentType = self.defaultIndex;
    self.dataSource = @[@[],@[],@[]].mutableCopy;
    
    self.errorTypes = @[@(EZErrorViewTypeEmpty),@(EZErrorViewTypeEmpty),@(EZErrorViewTypeEmpty) ].mutableCopy;
    self.currentYears = [NSMutableArray array];
    self.tabButtons = @[self.allButton,self.getButton,self.costButton];

    self.selectLine = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 15, 3)];
    self.selectLine.backgroundColor = UIColorFromRGB(0xFDA23F);
    
    self.selectLine.center = CGPointMake(self.view.frame.size.width / 3/2, self.topTabBarContentView.frame.size.height - 1.5);
    
    self.allButton.titleLabel.font = [UIFont fontWithName:MEDIUM_FONT_NAME size:16];
    [self.allButton setTitleColor:UIColorFromRGB(0xFDA23F) forState:UIControlStateNormal];
    
    [self.topTabBarContentView addSubview:self.selectLine];
    
    self.pageView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 40, self.view.frame.size.width,self.view.frame.size.height - [Utils getNavigationBarAndStatusBarHeight:self] - 40)];
    self.pageView.delegate = self;
    self.pageView.pagingEnabled = true;
    self.pageView.bounces = NO;
    self.pageView.showsVerticalScrollIndicator = NO;
    self.pageView.showsHorizontalScrollIndicator = NO;
    
    [self.pageView setContentSize:CGSizeMake(self.view.frame.size.width * 3, 0)];

    self.pages = [NSMutableArray array];
    
    [self.view addSubview:self.pageView];
    
    self.listTableViews = [NSMutableArray array];
    self.headers = [NSMutableArray array];
    
    for(NSInteger i = 0;i < 3;i ++)
    {
        UITableView * tableView = [[UITableView alloc] initWithFrame:CGRectMake(i * self.view.frame.size.width, 0, self.view.frame.size.width,self.pageView.frame.size.height) style:UITableViewStylePlain];
        tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        tableView.rowHeight = 80;
        
        tableView.dataSource = self;
        tableView.delegate = self;
        UIView * header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 48)];
        
        BillListHeader * myOrderHeader = (BillListHeader*)[Utils getXibByName:@"BillListHeader"];
        myOrderHeader.frame = header.bounds;
        WS(weakSelf);

        if(i > 0)
        {
            myOrderHeader.costLabel.hidden = true;
            myOrderHeader.getLabel.hidden = false;
            myOrderHeader.lineView.hidden = true;
        }
    

        myOrderHeader.tapSelectYearHandler = ^{

            [weakSelf getYearList];

        };
        [header addSubview:myOrderHeader];

        [self.headers addObject:myOrderHeader];
        
        tableView.tableHeaderView = header;
        tableView.tableFooterView = [UIView new];
        
        [self.pageView addSubview:tableView];
        
        [self.pages addObject:@(1)];
        
        [self.listTableViews addObject:tableView];
        
        NoDataView *noDataView = [NoDataView xibView];
        [noDataView setImageOrTitileNoDataViewType:NoDataViewTypeNoContent];
        NoNetworkView *noNetworkView = [NoNetworkView xibView];
        noNetworkView.reloadBlk = ^{
            weakSelf.errorTypes[self.currentType] = @(EZErrorViewTypeProgress);
            [weakSelf updateTableView];
        };


        [tableView setErrorView:noDataView ForType:EZErrorViewTypeEmpty];
        
        
        [self.currentYears addObject:[Utils getDateByTime:[Utils getNowTimeTimestamp] fomatter:@"YYYY"]];
        
        [myOrderHeader.yearButton setTitle:[NSString stringWithFormat:@"%@年",self.currentYears[i]] forState:UIControlStateNormal];
        
    }
    
    [self addQuickRefresh];
    
    [self updateTableView];
    
    [self.pageView.panGestureRecognizer requireGestureRecognizerToFail:self.navigationController.interactivePopGestureRecognizer];
}
- (void)viewWillLayoutSubviews
{
    [super viewWillLayoutSubviews];
    
    self.selectLine.center = CGPointMake(self.tabButtons[self.currentType].center.x, self.selectLine.center.y);
    
    for(UIButton * button in self.tabButtons)
    {
        button.titleLabel.font = [UIFont fontWithName:DEFAULT_FONT_NAME size:16];
        [button setTitleColor:UIColorFromRGB(0x222222) forState:UIControlStateNormal];
    }
    
    self.tabButtons[self.currentType].titleLabel.font = [UIFont fontWithName:MEDIUM_FONT_NAME size:16];
    [self.tabButtons[self.currentType] setTitleColor:UIColorFromRGB(0xFDA23F) forState:UIControlStateNormal];
    
    [self.pageView setContentOffset:CGPointMake(self.currentType * self.view.frame.size.width, 0)];
}

- (void)addQuickRefresh
{
    if(self.refreshType == self.currentType && self.firstRefresh == true)
    {
        return;
    }
    self.firstRefresh = true;
    self.refreshType = self.currentType;
    [self.refresh gifModelRefresh:self.listTableViews[self.currentType] refreshType:RefreshTypeDouble firstRefresh:false timeLabHidden:true stateLabHidden:true dropDownBlock:^{
        
        self.pages[self.currentType] = @1;
        [self updateTableView];
    } upDropBlock:^{
        
        NSInteger currentPage = self.pages[self.currentType].integerValue;
        self.pages[self.currentType] = @(currentPage + 1);
        [self updateTableView];
        
    }];
    
    
}


- (void)updateTableView
{
    if(self.isRefresh) return;

    self.isRefresh = true;
    
    [ServiceManager getAccountOrderListWithPage:self.pages[self.currentType] pageSize:@(20) type:@(self.currentType) year:self.currentYears[self.currentType] success:^(NSDictionary *data) {
        
        NSArray * list = data[LIST];
        
        NSNumber * getAmount = data[C_SUM_AMOUNT];
        NSNumber * costAmount = data[D_SUM_AMOUNT];
        
        if(self.currentType == 0)
        {
            NSString * getStr = [NSString stringWithFormat:@"收入%.2lf",getAmount.integerValue * 0.01];
            [Utils setUintWithLabel:self.headers[self.currentType].getLabel andText:getStr fontSize:self.headers[self.currentType].getLabel.font.pointSize];
            
            NSString * costStr = [NSString stringWithFormat:@"支出%.2lf",costAmount.integerValue * 0.01];
            
            [Utils setUintWithLabel:self.headers[self.currentType].costLabel andText:costStr fontSize:self.headers[self.currentType].costLabel.font.pointSize];
            
            
        }else if(self.currentType == 1)
        {
            
            NSString * getStr = [NSString stringWithFormat:@"收入%.2lf",getAmount.integerValue * 0.01];
            [Utils setUintWithLabel:self.headers[self.currentType].getLabel andText:getStr fontSize:self.headers[self.currentType].getLabel.font.pointSize];
    
        }else if(self.currentType == 2)
        {
            NSString * costStr = [NSString stringWithFormat:@"支出%.2lf",costAmount.integerValue * 0.01];
            [Utils setUintWithLabel:self.headers[self.currentType].getLabel andText:costStr fontSize:self.headers[self.currentType].getLabel.font.pointSize];
        }
        
        
        if(self.pages[self.currentType].integerValue == 1)
        {
            
            self.dataSource[self.currentType] = list;
            
        }else{
            self.dataSource[self.currentType] = [self.dataSource[self.currentType] arrayByAddingObjectsFromArray:list];
        }
        
        [self.listTableViews[self.currentType] reloadData];
        
        [self.refresh endRefreshing];
        
        
        if(list.count < 20)
        {
            [self.refresh noMoreData];
        }
        
        if(self.pages[self.currentType].integerValue == 0 && list.count == 0)
        {
            
//            [self.listTableViews[self.currentType] setErrorView:self.noDataView ForType:EZErrorViewTypeEmpty];
            self.errorTypes[self.currentType] = @(EZErrorViewTypeEmpty);
            //[self.refresh noMoreData];
        }
        
        self.isRefresh = false;
        
        
    } failure:^(NSError *error) {
        self.errorTypes[self.currentType] = @(EZErrorViewTypeEmpty);
        [self.refresh endRefreshing];
        [self.refresh noMoreData];
        self.isRefresh = false;
    }];
}

#pragma mark -- UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;
{
    NSInteger index = [self.listTableViews indexOfObject:tableView];
    NSArray * dataSource = self.dataSource[index];

    return dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    BillListCell * cell = [tableView dequeueReusableCellWithIdentifier:@"BillListCell"];
    
    if(!cell)
    {
        cell = (BillListCell*)[Utils getXibByName:@"BillListCell"];
    }
    
    NSInteger index = [self.listTableViews indexOfObject:tableView];
    NSArray * dataSource = self.dataSource[index];
    
    NSDictionary * dic = dataSource[indexPath.row];

    NSString * transType = dic[TRANS_TYPE];

    
    NSNumber * amount = dic[AMOUNT];
   
    NSNumber * txTime = dic[TX_TIME];
    
    NSString * merchantName = dic[MERCHANT_NAME];
    
    NSString * subOrAddFlag = [SharedInstance getInstance].transTypeMap[transType];
    
    NSString * transName = [SharedInstance getInstance].transTypeName[transType];
    
    NSArray * items = dic[ITEMS];
    
    NSDictionary * firstItemDic = items.firstObject;
    
    NSString * itemName = firstItemDic[ITEM_NAME];

    if([transType isEqualToString:@"DAD"])
    {
        cell.orderIdLabel.text = [NSString stringWithFormat:@"%@-%@",transName,merchantName];
    }else if([transType isEqualToString:@"PRF"]){
        cell.orderIdLabel.text = [NSString stringWithFormat:@"%@-%@",transName,merchantName];
    }else if([transType isEqualToString:@"CAD"]){
        cell.orderIdLabel.text = [NSString stringWithFormat:@"%@-%@",transName,itemName];
    } else {
        cell.orderIdLabel.text = transName;
    }
    
    if([subOrAddFlag isEqualToString:@"+"])
    {
        cell.amountLabel.textColor = UIColorFromRGB(0xB80000);
    }else{
        cell.amountLabel.textColor = UIColorFromRGB(0x222222);
    }

    cell.amountLabel.text = [NSString stringWithFormat:@"%@%.2lf",subOrAddFlag,amount.floatValue * 0.01];
    
    cell.logoImageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"ic_%@",transType]];
    
    cell.descLabel.text = [NSString stringWithFormat:@"%@",[Utils getDateByTime:[NSString stringWithFormat:@"%ld",txTime.integerValue] fomatter:@"yyyy-MM-dd HH:mm"]];
    
    return cell;
    
}
#pragma mark -- UIScrollViewDelegate

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    
    if([scrollView isKindOfClass:[UITableView class]])
    {
        return;
    }

    NSInteger index = scrollView.contentOffset.x / self.view.frame.size.width;
    
    if(self.currentType == index)
    {
        return;
    }
    
    self.currentType = index;
    for(UIButton * button in self.tabButtons)
    {
        button.titleLabel.font = [UIFont fontWithName:DEFAULT_FONT_NAME size:16];
        [button setTitleColor:UIColorFromRGB(0x222222) forState:UIControlStateNormal];
    }
    
    self.tabButtons[index].titleLabel.font = [UIFont fontWithName:MEDIUM_FONT_NAME size:16];
    [self.tabButtons[index] setTitleColor:UIColorFromRGB(0xFDA23F) forState:UIControlStateNormal];
    
    
    [UIView animateWithDuration:0.3 animations:^{
        
        self.selectLine.center = CGPointMake(self.tabButtons[self.currentType].center.x, self.selectLine.center.y);
        
    }];
    
    
    [self addQuickRefresh];
    
    [self updateTableView];
    
    
    
}

- (void)getYearList{
    [self.datePicker show];
}

- (IBAction)tapTabHandler:(UIButton *)sender {
    NSInteger index = sender.tag - 400;
    
    
    [UIView animateWithDuration:0.3 animations:^{
        
        self.selectLine.center = CGPointMake(sender.center.x, self.selectLine.center.y);
        
    }];
    
    for(UIButton * button in self.tabButtons)
    {
        button.titleLabel.font = [UIFont fontWithName:DEFAULT_FONT_NAME size:16];
        [button setTitleColor:UIColorFromRGB(0x222222) forState:UIControlStateNormal];
    }
    
    sender.titleLabel.font = [UIFont fontWithName:MEDIUM_FONT_NAME size:16];
    [sender setTitleColor:UIColorFromRGB(0xFDA23F) forState:UIControlStateNormal];
    
    
    self.currentType = index;
    
    [self.pageView setContentOffset:CGPointMake(self.currentType * self.view.frame.size.width, 0)];
    
    [self addQuickRefresh];
    
    [self updateTableView];
 
}

#pragma mark -- UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSString * orderNo = self.dataSource[self.currentType][indexPath.row][SERIAL_NUMBER];
    [ServiceManager getBillDetailWithOrderNo:orderNo success:^(NSDictionary *data) {
    
        BillingInfoViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_ME andIdentifier:@"BillingInfoViewController"];
        
        vc.dataDic = data;
        [self.navigationController pushViewController:vc animated:true];
        
    }];
}



- (IBAction)backAndPopHandler:(UIBarButtonItem *)sender {
    
    [self.navigationController popViewControllerAnimated:true];
}

- (QuickRefresh *)refresh{
    if (!_refresh) {
        _refresh = [[QuickRefresh alloc]init];
    }
    return _refresh;
}
- (LBDatePickerView *)datePicker
{
    if(!_datePicker)
    {
        _datePicker = [[LBDatePickerView alloc] initYearPickerViewWithResponse:^(NSString * year) {
            self.currentYears[self.currentType] = year;
            
            [self.headers[self.currentType].yearButton setTitle:[NSString stringWithFormat:@"%@年",self.currentYears[self.currentType]] forState:UIControlStateNormal];
            
            [self updateTableView];
        }];
    }
    
    return _datePicker;
}


- (EZErrorViewType)tableViewTypeOfErrorViewToShow:(UITableView *)tableView
{
    return self.errorTypes[self.currentType].integerValue;
}

- (void)dealloc{
    for (UITableView * tableview in self.listTableViews)
    {
        [tableview dismissErrorView];
    }
}
@end
