//
//  MyPickupCardViewController.h
//  DawnGathering
//
//  Created by 李冬岐 on 2023/10/17.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MyPickupCardViewController : UIViewController

@property (nonatomic,strong)NSNumber * selectItemID;

@end

NS_ASSUME_NONNULL_END
