//
//  MyPickupCardViewController.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/10/17.
//

#import "MyPickupCardViewController.h"
#import "MyPickupCardCell.h"
#import "QuickRefresh.h"
#import "UITableView+EZErrorView.h"
#import "UITestButtonView.h"
#import "WPHomeVC.h"
#import "SelectItemActionView.h"
#import "ModifyCardPasswordViewController.h"
#import "MerchantListViewController.h"
@interface MyPickupCardViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *listTableView;
@property (weak, nonatomic) IBOutlet UITextField *searchText;

@property (nonatomic,assign)NSInteger page;

@property (nonatomic,strong)NSNumber * itemID;

@property (nonatomic,strong)NSString * keyword;

@property (nonatomic,strong)NSArray * dataSource;

@property (nonatomic,strong)QuickRefresh * refresh;

@property(nonatomic,assign)EZErrorViewType errorType;

@property (nonatomic,strong)NSMutableArray <NSMutableArray*>*selectDatas;

@property (nonatomic,assign)NSInteger selectedIndex;

@property (nonatomic,strong)NSArray * cardItems;

@property (nonatomic,strong)NSArray * itemIDs;

@end

@implementation MyPickupCardViewController

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [Utils setDefaultNavigationBar:self];
    
    [self refreshHandler];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    if(self.selectItemID)
    {
        self.itemID = self.selectItemID;
    }else{
        self.itemID = @(0);
    }
    
    self.page = 1;
    self.selectedIndex = 0;
    self.listTableView.dataSource = self;
    self.listTableView.delegate = self;
    self.listTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.listTableView.rowHeight = 209.0f;
    self.listTableView.tableFooterView = [UIView new];
    self.refresh = [[QuickRefresh alloc] init];
    
    [self.refresh gifModelRefresh:self.listTableView refreshType:RefreshTypeDouble firstRefresh:false timeLabHidden:false stateLabHidden:false dropDownBlock:^{
        self.page = 1;
        [self refreshHandler];
    } upDropBlock:^{
        self.page += 1;
        
        [self refreshHandler];
    }];
    
    NoDataView *noDataView = [NoDataView xibView];
    [noDataView setImageOrTitileNoDataViewType:NoDataViewTypeDefault];
    WS(weakSelf);
    NoNetworkView *noNetworkView = [NoNetworkView xibView];
    noNetworkView.reloadBlk = ^{
        weakSelf.errorType = EZErrorViewTypeProgress;
        [weakSelf.listTableView reloadData];
        [weakSelf refreshHandler];
    };
    
    TableViewProgressView *tProgressView = [TableViewProgressView xibView];

    [self.listTableView setErrorView:noDataView ForType:EZErrorViewTypeEmpty];
    [self.listTableView  setErrorView:noNetworkView ForType:EZErrorViewTypeNetwork];
    [self.listTableView  setErrorView:tProgressView ForType:EZErrorViewTypeProgress];

    self.errorType = EZErrorViewTypeProgress;
    
    //[self refreshHandler];
}


- (void)refreshHandler
{
    self.selectDatas = [NSMutableArray array];
    if(self.cardItems)
    {
        NSDictionary * selectItem = self.cardItems[self.selectedIndex];
        NSNumber * itemID = selectItem[ITEM_ID];
        self.itemID = itemID;
    }
    
    
    [ServiceManager getPickupCardWithPage:@(self.page) pageSize:@20 itemID:self.itemID key:self.keyword success:^(NSDictionary *data) {
        
        NSArray * list = data[CARDS];
        NSMutableArray * cardItems = data[CARD_ITEMS];
        
        if([Utils checkObjectIsNull:cardItems])
        {
            [cardItems insertObject:@{ITEM_NAME:@"全部提货券",ITEM_ID:@0} atIndex:0];
            
            self.cardItems = cardItems.copy;
        }else{
            self.cardItems = @[@{ITEM_NAME:@"全部提货券",ITEM_ID:@0}];
        }
        
        
        for(NSInteger i = 0;i < self.cardItems.count;i++)
        {
            NSDictionary * item = self.cardItems[i];
            
            NSNumber * itemID = item[ITEM_ID];
            
            if(itemID.integerValue == self.itemID.integerValue)
            {
                NSString * itemName = item[ITEM_NAME];
                
                self.selectedIndex = i;
                
                self.title = [NSString stringWithFormat:@"%@",itemName];
            }
        }
        
        if([Utils checkObjectIsNull:list])
        {
            if(self.page > 1)
            {
                if(list != nil && list.count > 0)
                {
                    self.dataSource = [self.dataSource arrayByAddingObjectsFromArray:list];
                }
                
            }else{
                self.dataSource = list;
            }
            
            if(list.count < 20){
                //没有更多数据
                [self.refresh noMoreData];
            }
            
        }else{
            self.dataSource = @[];
            [self.refresh noMoreData];
        }
        
        self.errorType = EZErrorViewTypeEmpty;
        
        self.selectDatas = [NSMutableArray array];
        
        [self.listTableView reloadData];
        
        [self.refresh endRefreshing];
        
        
    } failure:^(NSError *error) {
        
        [self.refresh endRefreshing];
        
        self.errorType = EZErrorViewTypeNetwork;
        
        [self.refresh noMoreData];
        
        self.selectDatas = [NSMutableArray array];
        [self.listTableView reloadData];
    }];
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;
{
    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    MyPickupCardCell * cell = [tableView dequeueReusableCellWithIdentifier:@"MyPickupCardCell"];
    
    if(!cell)
    {
        cell = (MyPickupCardCell*)[Utils getXibByName:@"MyPickupCardCell"];
    }
    
    NSDictionary * dic = self.dataSource[indexPath.row];
    
    NSString * cardNo = dic[CARD_NO];
    
    NSString * itemName = dic[ITEM_NAME];
    
    NSNumber * amount = dic[AMOUNT];
    
    NSString * amountText = [NSString stringWithFormat:@"%.2lf",amount.floatValue * 0.01];
    
    NSString * guideText = dic[GUIDE_TEXT];
    
    NSString * offlineMerchantURL = dic[OFFLINE_MERCHANT_URL];
    
    NSString * shopURL = dic[SHOP_URL];
    
    NSString * cardExchangeURL = dic[CARD_EXCHANGE];
    
    NSString * imgURL = dic[IMG];
    
    NSMutableArray * selectData = [NSMutableArray array];
   
    
    
    if(guideText.length > 0)
    {
        [selectData addObject:@{NAME:@"使用说明"}];
        
    }
    
    if(offlineMerchantURL.length > 0)
    {
        [selectData addObject:@{NAME:@"线下商户"}];
        
    }

    if(shopURL.length > 0)
    {
        [selectData addObject:@{NAME:@"线上商城"}];
       
    }
    
    if(cardExchangeURL.length > 0)
    {
        [selectData addObject:@{NAME:@"卡券兑换"}];
    }
    
    [selectData addObject:@{NAME:@"修改密码"}];
    
    
    [self.selectDatas addObject:selectData];
    
    UITestButtonView * selectView = [[UITestButtonView alloc] initWithFrame: CGRectMake(0, 0, SCREEN_WIDTH - 30, 44)];

    
    selectView.selectedColor = UIColorFromRGB(0x222222);
    selectView.normalColor = UIColorFromRGB(0x222222);
    
    selectView.cellIndex = indexPath.row;
    WS(weakSelf);
    selectView.tapSelectViewButtonWithIndex = ^(NSInteger index ,NSInteger cellIndex) {

        [weakSelf showViewWithIndex:index cellIndex:cellIndex];

    };
    
    [selectView updateRefreshViewWith:selectData curentPage:0];
    selectView.cellIndex = indexPath.row;

    [cell.bottomContainer addSubview:selectView];
    
    
    [Utils setUintWithLabel:cell.cardAmountLabel andText:amountText fontSize:cell.cardAmountLabel.font.pointSize - 4];
    
    cell.cardNameLabel.text = itemName;
    cell.cardNumberLabel.text = [Utils getNewBankNumWitOldBankNum:cardNo];
    
    if(imgURL.length > 0)
    {
        [Utils loadImage:cell.cardImageView andURL:imgURL isLoadRepeat:NO];
    }else{
        cell.cardImageView.image = [UIImage imageNamed:@"img_card_default_bg"];
    }
    

    return cell;
}

- (void)showViewWithIndex:(NSInteger)index cellIndex:(NSInteger)cellIndex
{
    NSMutableArray * selectData = self.selectDatas[cellIndex];
    
    NSDictionary * dic = self.dataSource[cellIndex];
    
    NSString * cardNo = dic[CARD_NO];
    
    NSString * name = selectData[index][NAME];
    
    if([name isEqualToString:@"线下商户"])
    {
        //线下
        
        MerchantListViewController * listVC = [[MerchantListViewController alloc] init];
        
        NSNumber * itemId = dic[ITEM_ID];
        
        NSArray * blackWhiteList = dic[WHITE_IDS];
        
        [SharedInstance getInstance].sendBlackWhiteList = blackWhiteList;
        listVC.items = @[[NSString stringWithFormat:@"%ld",itemId.integerValue]];
        [self.navigationController pushViewController:listVC animated:true];
        
        
    }else if([name isEqualToString:@"卡券兑换"])
    {
        NSString * cardURL = dic[CARD_EXCHANGE];
        
        if([cardURL hasPrefix:@"http"])
        {
            [Utils pushWebViewControllerURL:cardURL owner:self];
        }else{
            
            if(!cardURL || cardURL.length == 0)
            {
                [Utils showToast:@"未识别到正确的配置id"];
                return;
            }
            
            WPHomeVC * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_HOME andIdentifier:@"WPHomeVC"];
            vc.homePageID = cardURL;
            [[Utils getCurrentVC].navigationController pushViewController:vc animated:true];
        }
        
        
    }else if([name isEqualToString:@"使用说明"])
    {
        NSNumber * guideType = dic[GUIDE_TEXT_TYPE];
        NSString * guideURL = dic[GUIDE_TEXT];
        if(guideType.integerValue == 1)
        {
            WPHomeVC * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_HOME andIdentifier:@"WPHomeVC"];
            vc.homePageID = guideURL;
            [[Utils getCurrentVC].navigationController pushViewController:vc animated:true];
        }else{
            [Utils pushWebViewControllerURL:guideURL owner:self];
        }
        
        
    }else if([name isEqualToString:@"线上商城"])
    {
        NSNumber * shopType = dic[SHOP_URL_TYPE];
        NSString * shopURL = dic[SHOP_URL];
        
        if(shopType.integerValue == 1)
        {
            WPHomeVC * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_HOME andIdentifier:@"WPHomeVC"];
            vc.homePageID = shopURL;
            [[Utils getCurrentVC].navigationController pushViewController:vc animated:true];
        }else{
            [Utils pushWebViewControllerURL:shopURL owner:self];
        }
        
    }else if ([name isEqualToString:@"修改密码"]){
        
        ModifyCardPasswordViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_ME andIdentifier:@"ModifyCardPasswordViewController"];
        vc.cardNo = cardNo;
        [self.navigationController pushViewController:vc animated:true];
        
    }
    
}

- (IBAction)searchHandler:(UIButton *)sender {

    self.keyword = self.searchText.text;
    
    if(self.searchText.text.length == 0)
    {
        self.keyword = nil;
    }
    [self refreshHandler];
    
}
- (IBAction)backAndPopHandler:(UIBarButtonItem *)sender {
    
    [self.navigationController popViewControllerAnimated:true];
}

- (IBAction)showItemListPickerHandler:(UIBarButtonItem *)sender {
    //显示选择专项筛选列表;
    
    SelectItemActionView * popView = (SelectItemActionView*)[Utils getXibByName:@"SelectItemActionView"];
    

    popView.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
    
    popView.dataSource = self.cardItems;
    
    popView.selectedIndex = self.selectedIndex;
    WS(weakSelf);
    popView.tapConfirmRefreshWithIndex = ^(NSInteger index) {
        weakSelf.selectedIndex = index;
        
        [weakSelf refreshHandler];
    };
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [popView fadeIn];
    });
    
    [[Utils currentWindow] addSubview:popView];
}
- (IBAction)bindingPickupCardHandler:(UIButton *)sender {
    
    UIViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_ME andIdentifier:@"BindingWelfareCouponViewController"];
    
    [self.navigationController pushViewController:vc animated:true];
}

- (EZErrorViewType)tableViewTypeOfErrorViewToShow:(UITableView *)tableView
{
    return _errorType;
}

-(void)dealloc{
    [_listTableView dismissErrorView];
    
}

@end
