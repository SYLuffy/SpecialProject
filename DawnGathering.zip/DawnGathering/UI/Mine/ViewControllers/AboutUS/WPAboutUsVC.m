//
//  WPAboutUsVC.m
//  HLGA
//
//  Created by 葛亮 on 2018/7/24.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "WPAboutUsVC.h"
#import "WPUrlString.h"
#import <IQKeyboardManager.h>
#import "UIImage+tools.h"
#import "UIColor+Extension.h"
#import <UIBarButtonItem+WZLBadge.h>

@interface WPAboutUsVC ()

@property (weak, nonatomic) IBOutlet UILabel *versionLabel;
@property (weak, nonatomic) IBOutlet UILabel *currentVersionLabel;

@end

@implementation WPAboutUsVC


-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [Utils setDefaultNavigationBar:self];
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
//    self.navigationController.navigationBar.barStyle = UIBarStyleDefault;
//    [self setNeedsStatusBarAppearanceUpdate];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    //获取当前版本号
    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
    NSString *app_Version = [infoDictionary objectForKey:@"CFBundleShortVersionString"];
    
    self.currentVersionLabel.text = [NSString stringWithFormat:@"当前版本：v%@",app_Version];
    
    NSString * remoteVersion = [SharedInstance getInstance].updateVersion;
    
    if(!remoteVersion)
    {
        remoteVersion = app_Version;
    }
        
    
    self.versionLabel.text = [NSString stringWithFormat:@"v%@",remoteVersion];
    
    if ([SharedInstance getInstance].updateVersion.length != 0) {
        if (![app_Version isEqualToString:[SharedInstance getInstance].updateVersion]) {
            [self.versionLabel showBadgeWithStyle:WBadgeStyleRedDot value:1 animationType:WBadgeAnimTypeNone];
            
            if (@available(iOS 11.0, *))
            {
                self.versionLabel.badgeCenterOffset = CGPointMake(-5, 0);
            }else{
                self.versionLabel.badgeCenterOffset = CGPointMake(-6, 0);
            }
            
            self.versionLabel.textColor = [UIColor colorWithHexString:@"2196F3"];
        }
    }
    
}


- (IBAction)openICPHandler:(UIButton *)sender {
    
    [Utils pushWebViewControllerURL:@"https://beian.miit.gov.cn" owner:self];
    
}

//最新版本
- (IBAction)versionClick:(id)sender {
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[SharedInstance getInstance].updateVersionUrl] options:@{} completionHandler:nil];
}


- (IBAction)telPhoneClick:(id)sender {
    NSMutableString *str = [[NSMutableString alloc] initWithFormat:@"telprompt://%@",@"4008-331133"];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:str] options:@{} completionHandler:nil];
}


- (IBAction)privateAgreeButtonPressed:(id)sender {
    
    [Utils pushWebViewControllerURL:[NSString stringWithFormat:@"%@%@",BASE_WEB_URL,PRIVATE_AGREEMENT] owner:self];
}


- (IBAction)serviceAgreementButtonPressed:(id)sender {
    
    [Utils pushWebViewControllerURL:[NSString stringWithFormat:@"%@%@",BASE_WEB_URL,SERVICE_AGREEMENT] owner:self];
    
}


- (void)onBack:(id)sender
{
    [self.navigationController popViewControllerAnimated:true];
    [[IQKeyboardManager sharedManager]setEnable:YES];
    
}
@end
