//
//  MyCouponsViewController.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/9/26.
//

#import "MyCouponsViewController.h"
#import "MyCouponsCell.h"
#import "WPHomeVC.h"
#import "QuickRefresh.h"
#import "UITableView+EZErrorView.h"
#define BUTTON_TAG 400

@interface MyCouponsViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *listTableView;
@property (nonatomic,strong)NSArray * dataSource;

@property (nonatomic,assign)NSInteger currentState;

@property (nonatomic,assign)NSInteger page;

@property (nonatomic,strong)QuickRefresh * refresh;

@property(nonatomic,assign)EZErrorViewType errorType;

@property (weak, nonatomic) IBOutlet UIButton *allButton;
@property (weak, nonatomic) IBOutlet UIButton *expireButton;
@property (weak, nonatomic) IBOutlet UIButton *enableButton;
@property (weak, nonatomic) IBOutlet UIView *topViewContainer;

@property (nonatomic,strong)NSArray <UIButton*>* buttons;

@property (nonatomic,strong)UIView * selectLine;

@property (nonatomic,strong)NSDictionary * stateNum;

@end

@implementation MyCouponsViewController


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [Utils setDefaultNavigationBar:self];
}

- (void)refreshHandler
{
    [ServiceManager getMyCouponsWithState:@(self.currentState) page:@(self.page) pageSize:@20 success:^(NSDictionary *data) {
        
        NSArray * list = data[DATA];
        self.stateNum = data[@"stateNum"];
        NSNumber * allNum = self.stateNum[@"all"];
        
        NSNumber * willExpireNum = self.stateNum[@"willExpire"];
        
        NSNumber * expiredNum = self.stateNum[@"expired"];
        
        if(allNum.integerValue > 0)
        {
            [self.allButton setTitle:[NSString stringWithFormat:@"全部(%ld)",allNum.integerValue] forState:UIControlStateNormal];
        }else{
            [self.allButton setTitle:[NSString stringWithFormat:@"全部"] forState:UIControlStateNormal];
        }
        
        if(willExpireNum.integerValue > 0)
        {
            
            [self.expireButton setTitle:[NSString stringWithFormat:@"快过期(%ld)",willExpireNum.integerValue] forState:UIControlStateNormal];
        }else{
            [self.expireButton setTitle:[NSString stringWithFormat:@"快过期"] forState:UIControlStateNormal];
        }
        
        if(expiredNum.integerValue > 0)
        {
            [self.enableButton setTitle:[NSString stringWithFormat:@"已失效(%ld)",expiredNum.integerValue] forState:UIControlStateNormal];
        }else{
            [self.enableButton setTitle:[NSString stringWithFormat:@"已失效"] forState:UIControlStateNormal];
        }
        
        
        if([Utils checkObjectIsNull:list])
        {
            if(self.page > 1)
            {
                if(list != nil && list.count > 0)
                {
                    self.dataSource = [self.dataSource arrayByAddingObjectsFromArray:list];
                    
                }
                
            }else{
                self.dataSource = list;
            }
            
            if(list.count < 20){
                //没有更多数据
                [self.refresh noMoreData];
            }
            
        }else{
            self.dataSource = @[];
            [self.refresh noMoreData];
        }
        
        
        self.errorType = EZErrorViewTypeEmpty;
        
        [self.listTableView reloadData];
        
        [self.refresh endRefreshing];
        
    } failure:^(NSError *error) {
        [self.refresh endRefreshing];
        
        self.errorType = EZErrorViewTypeNetwork;
        
        [self.refresh noMoreData];
        
        [self.listTableView reloadData];
    }];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.currentState = 0;
    self.page = 1;
    
    self.buttons = @[self.allButton,self.expireButton,self.enableButton];
    [self refreshHandler];
    self.listTableView.dataSource = self;
    self.listTableView.delegate = self;
    
    self.listTableView.tableFooterView = [UIView new];
    
    self.listTableView.separatorStyle = UITableViewCellSeparatorStyleNone;

    self.listTableView.rowHeight = 125.0f;
    
    self.refresh = [[QuickRefresh alloc] init];
    
    [self.refresh gifModelRefresh:self.listTableView refreshType:RefreshTypeDouble firstRefresh:false timeLabHidden:false stateLabHidden:false dropDownBlock:^{
        self.page = 1;
        [self refreshHandler];
    } upDropBlock:^{
        self.page += 1;
        
        [self refreshHandler];
    }];
    
    NoDataView *noDataView = [NoDataView xibView];
    [noDataView setImageOrTitileNoDataViewType:NoDataViewTypeDefault];
    WS(weakSelf);
    NoNetworkView *noNetworkView = [NoNetworkView xibView];
    noNetworkView.reloadBlk = ^{
        weakSelf.errorType = EZErrorViewTypeProgress;
        [weakSelf.listTableView reloadData];
        [weakSelf refreshHandler];
    };
    
    TableViewProgressView *tProgressView = [TableViewProgressView xibView];

    [self.listTableView setErrorView:noDataView ForType:EZErrorViewTypeEmpty];
    [self.listTableView  setErrorView:noNetworkView ForType:EZErrorViewTypeNetwork];
    [self.listTableView  setErrorView:tProgressView ForType:EZErrorViewTypeProgress];

    self.errorType = EZErrorViewTypeProgress;
    
    
    self.selectLine = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 15, 3)];
    self.selectLine.backgroundColor = UIColorFromRGB(0xFDA23F);
    
    self.selectLine.center = CGPointMake(self.view.frame.size.width / 3/2, self.topViewContainer.frame.size.height - 1.5);
    
    [self.topViewContainer addSubview:self.selectLine];
    
}
- (IBAction)backAndPopHandler:(UIBarButtonItem *)sender {
    [self.navigationController popViewControllerAnimated:true];
}

#pragma mark -- UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;
{
    return _dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    MyCouponsCell * cell = [tableView dequeueReusableCellWithIdentifier:@"MyCouponsCell"];
    
    if(!cell)
    {
        cell = (MyCouponsCell*)[Utils getXibByName:@"MyCouponsCell"];
    }
    
    NSDictionary * dic = self.dataSource[indexPath.row];
    cell.index = indexPath.row;
    NSString * name = dic[NAME];
    NSNumber * amount = dic[AMOUNT];
    NSString * logo = dic[LOGO];
    NSString * tips = dic[TIPS];
    NSNumber * descType = dic[DESC_TYPE];
    NSString * descContent = dic[DESC_CONTENT];
    NSNumber * endTime = dic[END_TIME];
    
    NSNumber * state = dic[STATE];
    
    cell.descType = descType;
    cell.descContent = descContent;
    
    cell.couponsNameLabel.text = name;
    
    
    NSString * amountText = [Utils stringFromNumber:[NSNumber numberWithFloat:amount.floatValue * 0.01]];
    
    [Utils setUintWithLabel:cell.couponsAmountLabel andText:amountText fontSize:14];
    
    NSString * time = [Utils getDateByTime:[NSString stringWithFormat:@"%ld",endTime.integerValue] fomatter:@"yyyy-MM-dd"];
    cell.couponsExpireLabel.text = [NSString stringWithFormat:@"有效期至%@",time];
    
    if(logo.length == 0 || logo == nil)
    {
        [cell hiddenImageView:true];
    }else{
        [cell hiddenImageView:false];
        
        [Utils loadImage:cell.couponsImageView andURL:logo isLoadRepeat:false];
    }
    
    [cell hiddenRepeatLabel:true];
    WS(weakSelf);
    cell.tapMyCouponsGoUseHandler = ^(NSInteger index) {
        [weakSelf gotoUseWithIndex:index];
    };
    
    [cell setStyleWithState:state];
    
    cell.couponsRuleLabel.text = tips;
    
    return cell;
}
- (IBAction)tapStateHandler:(UIButton *)sender {
    
    for(UIButton * button in self.buttons)
    {
        button.titleLabel.font = [UIFont fontWithName:DEFAULT_FONT_NAME size:16];
        [button setTitleColor:UIColorFromRGB(0x222222) forState:UIControlStateNormal];
    }
    
    sender.titleLabel.font = [UIFont fontWithName:MEDIUM_FONT_NAME size:16];
    [sender setTitleColor:[Utils getMainColor] forState:UIControlStateNormal];
    
    NSInteger index = sender.tag - BUTTON_TAG;
    
    self.currentState = index;
    
    [UIView animateWithDuration:0.3 animations:^{
         
        self.selectLine.center = CGPointMake(self.buttons[self.currentState].center.x, self.selectLine.center.y);
        
    }];
    
    self.page = 1;
    
    [self refreshHandler];
}

- (void)gotoUseWithIndex:(NSInteger)index
{
    NSDictionary * dic = self.dataSource[index];
    
    NSString * commodityAddress = dic[@"commodityAddress"];
    
    NSNumber * commodityAddressType = dic[@"commodityAddressType"];
    
    if(commodityAddressType.integerValue == 1)
    {
        WPHomeVC * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_HOME andIdentifier:@"WPHomeVC"];
        
        vc.homePageID = commodityAddress;
        [[Utils getCurrentVC].navigationController pushViewController:vc animated:true];
    }else if(commodityAddressType.integerValue == 2){
        [Utils pushWebViewControllerURL:commodityAddress owner:[Utils getCurrentVC]];
    }
}

#pragma mark -- UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //点击
    
   
}

- (EZErrorViewType)tableViewTypeOfErrorViewToShow:(UITableView *)tableView
{
    return _errorType;
}

-(void)dealloc{
    [_listTableView dismissErrorView];
    
}

@end
