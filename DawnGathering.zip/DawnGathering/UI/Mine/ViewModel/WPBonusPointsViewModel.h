//
//  WPBonusPointsViewModel.h
//  HLGA
//
//  Created by 葛亮 on 2018/5/31.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "WPBonusPointsModel.h"
typedef void (^WPBonusPointsViewModelSuccessBlock)(void);
typedef void (^WPBonusPointsViewModelFailedBlock)(NSError *error);
typedef void (^WPBonusPointsViewModelNoMoreDataBlock)(void);

@interface WPBonusPointsViewModel : NSObject


@property(nonatomic,assign)NSInteger type;//（1充值列表，4消费列表,0新接口）
@property(nonatomic,assign)NSInteger page;
@property(nonatomic,assign)NSInteger pageSize;

@property(nonatomic,strong)NSMutableArray<WPBonusPointsModel *> *list;

-(void)loadBonusPointsSuccess:(WPBonusPointsViewModelSuccessBlock )success FailedBlock:(WPBonusPointsViewModelFailedBlock)failed noMoreDataBlock:(WPBonusPointsViewModelNoMoreDataBlock )noMoreDataBlock;

@end
