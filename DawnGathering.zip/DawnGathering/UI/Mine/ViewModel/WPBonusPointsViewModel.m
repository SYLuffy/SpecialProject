//
//  WPBonusPointsViewModel.m
//  HLGA
//
//  Created by 葛亮 on 2018/5/31.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "WPBonusPointsViewModel.h"

@implementation WPBonusPointsViewModel


-(NSMutableArray<WPBonusPointsModel *> *)list{
    
    if(!_list){
        
        _list = [NSMutableArray array];
    
    }
    return _list;
}

-(void)loadBonusPointsSuccess:(WPBonusPointsViewModelSuccessBlock )success FailedBlock:(WPBonusPointsViewModelFailedBlock)failed noMoreDataBlock:(WPBonusPointsViewModelNoMoreDataBlock )noMoreDataBlock{

    [ServiceManager bonusPointsBytype:_type andPage:_page andPageSize: [Utils getGlobalPageSize].integerValue success:^(NSDictionary *data) {
        NSArray *list = data[@"data"][@"list"];
        if (self.page == 0 || self.page == 1) {
            [self.list removeAllObjects];
        }else{
            if([list isEqual:[NSNull null]] || list.count == 0 ){
                if(noMoreDataBlock != nil){
                    noMoreDataBlock();
                }
            }
        }
        if (![list isEqual:[NSNull null]]) {
            for (int i = 0 ; i < list.count ; i++) {
                WPBonusPointsModel *model = [[WPBonusPointsModel alloc]initByDictionary:list[i]];
                [self.list addObject:model];
            }
        }
        if(success != nil){
            success();
        }
    } failure:^(NSError *error) {
        
        if(failed != nil){
            failed(error);
        }
    }];
}

@end
