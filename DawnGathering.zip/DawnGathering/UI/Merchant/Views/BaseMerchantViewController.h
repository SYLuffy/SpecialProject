//
//  BaseMerchantViewController.h
//  DawnGathering
//
//  Created by 李冬岐 on 2024/1/10.
//

#import <UIKit/UIKit.h>
#import "WMZDropDwonMenuConfig.h"
#import "WMZDropDownMenu.h"

NS_ASSUME_NONNULL_BEGIN

@interface BaseMerchantViewController : UIViewController<WMZDropMenuDelegate>

@end

NS_ASSUME_NONNULL_END
