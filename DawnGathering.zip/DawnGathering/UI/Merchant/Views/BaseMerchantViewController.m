//
//  BaseMerchantViewController.m
//  DawnGathering
//
//  Created by 李冬岐 on 2024/1/10.
//

#import "BaseMerchantViewController.h"

@interface BaseMerchantViewController ()

@end

@implementation BaseMerchantViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = MenuColor(0x00A6FF);
    if (@available(iOS 11.0, *)) {

    }else{
        self.automaticallyAdjustsScrollViewInsets = NO;
    }
}
- (NSArray*)titleArrInMenu:(WMZDropDownMenu *)menu{
    return @[];
}
/*
*返回WMZDropIndexPath每行 每列的数据
*/
- (NSArray*)menu:(WMZDropDownMenu *)menu dataForRowAtDropIndexPath:(WMZDropIndexPath*)dropIndexPath{
    return @[];
}
- (void)dealloc{
    
}

@end
