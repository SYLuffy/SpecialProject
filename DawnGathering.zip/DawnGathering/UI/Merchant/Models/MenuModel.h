//
//  MenuModels.h
//  DawnGathering
//
//  Created by 李冬岐 on 2024/1/19.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MenuModel : NSObject
@property (nonatomic,strong)NSMutableArray * merchantSortList;//排序;

@property (nonatomic,strong)NSMutableArray * shoppingList;//全城；
@property (nonatomic,strong)NSMutableArray * merchantTypes;//全部分类
@property (nonatomic,strong)NSMutableArray * items;//更多;

@property (nonatomic,strong)NSMutableArray * areaList;//区域城市数据;

@property (nonatomic,strong)NSMutableArray * brandList;//品牌列表

- (NSMutableArray *)getAreaListWithDefaultCityName:(NSString*)cityName;
- (NSMutableArray*)getMerchantSortWithSortName:(NSString*)sortName;
- (NSString*)getDefaultMainSortWithSortName:(NSString*)sortName;
- (NSMutableArray*)getShoppingListWithAreaName:(NSString*)areaName;
- (NSString*)getDefaultMainShoppingNameWithAreaName:(NSString*)areaName;

- (instancetype)initByDictionary:(NSDictionary*)dic;

- (NSString*)getItemNameWithItemId:(NSNumber*)itemId;
@end

NS_ASSUME_NONNULL_END
