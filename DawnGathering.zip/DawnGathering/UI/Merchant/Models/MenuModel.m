//
//  MenuModels.m
//  DawnGathering
//
//  Created by 李冬岐 on 2024/1/19.
//

#import "MenuModel.h"

@implementation MenuModel

- (instancetype)initByDictionary:(NSDictionary*)dic
{
    self = [super init];
    if (self) {

        [self setValuesForKeysWithDictionary:dic];
        
    }
    return self;
}

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    NSLog(@"%@",value);
}

- (void)setAreaList:(NSArray *)areaList
{
    NSMutableArray * array = [NSMutableArray array];
    
    for(NSMutableDictionary * dic in areaList)
    {
        NSMutableDictionary * newDic = @{NAME:dic[AREA_NAME],OTHER_DATA:dic}.mutableCopy;
    
        [array addObject:newDic];
     
    }
    
    _areaList = array.copy;
}

- (NSMutableArray *)getAreaListWithDefaultCityName:(NSString*)cityName
{
    for(NSInteger i = 0;i < self.areaList.count;i++)
    {
        NSMutableDictionary * dic = self.areaList[i];
        NSArray * list = dic[OTHER_DATA][CHILD_LIST];
        
        if([Utils checkObjectIsNull:list] == false)
        {
            list = @[];
        }

        for(NSMutableDictionary * diction in list)
        {
            NSString * name = diction[AREA_NAME];

            if([name isEqualToString:cityName])
            {
                [self.areaList[i] setObject:@(YES) forKey:IS_SELECTED];
                break;
            }
        }
    }
    
    return _areaList;
}


- (void)setMerchantSortList:(NSMutableArray *)merchantSortList
{
    NSMutableArray * array = [NSMutableArray array];
    
    for(NSMutableDictionary * dic in merchantSortList)
    {
        NSMutableDictionary * newDic = @{NAME:dic[DESCRIPTION],OTHER_DATA:dic}.mutableCopy;
        
        [array addObject:newDic];
    }
    
    _merchantSortList = array.copy;
}

- (NSMutableArray*)getMerchantSortWithSortName:(NSString*)sortName
{
    for(NSInteger i = 0;i < self.merchantSortList.count;i++)
    {
        NSMutableDictionary * dic = self.merchantSortList[i];
        
        NSString * name = dic[NAME];
        
        if([name isEqualToString:sortName])
        {
            [self.merchantSortList[i] setObject:@(YES) forKey:IS_SELECTED];
        }
    }
    
    return self.merchantSortList;
}

- (void)setShoppingList:(NSMutableArray *)shoppingList
{
    NSMutableArray * array = [NSMutableArray array];
    
    for(NSMutableDictionary * dic in shoppingList)
    {
        NSMutableDictionary * newDic = @{NAME:dic[AREA_NAME],OTHER_DATA:dic}.mutableCopy;
        
        [array addObject:newDic];
    }
    
    _shoppingList = array.copy;
}

- (NSMutableArray*)getShoppingListWithAreaName:(NSString*)areaName
{
    for(NSInteger i = 0;i < self.shoppingList.count;i++)
    {
        NSMutableDictionary * dic = self.shoppingList[i];
        NSArray * list = dic[OTHER_DATA][SHOPPING_LIST];
        
        if([Utils checkObjectIsNull:list] == false)
        {
            list = @[];
        }

        for(NSMutableDictionary * diction in list)
        {
            NSString * name = diction[SHOPPING_AREA_NAME];

            if([name isEqualToString:areaName])
            {
                [self.shoppingList[i] setObject:@(YES) forKey:IS_SELECTED];
                break;
            }
        }
    }
    
    return _shoppingList;
}

- (void)setMerchantTypes:(NSMutableArray *)merchantTypes
{
    NSMutableArray * array = [NSMutableArray array];
    
    for(NSDictionary * dic in merchantTypes)
    {
        NSDictionary * newDic = @{NAME:dic[TYPE_NAME],OTHER_DATA:dic,IS_SELECTED:@(NO)};
        
        [array addObject:newDic];
    }
    
    
    NSDictionary * allDefault = @{NAME:@"全部分类",IS_SELECTED:@(YES),OTHER_DATA:@{TYPE_NAME:@"全部分类",CHILD_LIST:@[@{TYPE_NAME:@"全部分类", MERCHANT_TYPE_INDEX:@""}]}};
    
    [array insertObject:allDefault atIndex:0];     
    
    _merchantTypes = array.copy;
}

- (void)setItems:(NSMutableArray *)items
{
    NSMutableArray * array = [NSMutableArray array];
    
    for(NSDictionary * dic in items)
    {
        NSDictionary * newDic = @{NAME:dic[ITEM_NAME],OTHER_DATA:dic};
        
        [array addObject:newDic];
    }
    
    _items = array.copy;
}

- (void)setBrandList:(NSMutableArray *)brandList
{
    NSMutableArray * array = [NSMutableArray array];
    
    for(NSDictionary * dic in brandList)
    {
        NSDictionary * newDic = @{NAME:dic[BRAND_NAME],OTHER_DATA:dic};
        
        [array addObject:newDic];
    }
    
    _brandList = array.copy;
}

- (NSString*)getItemNameWithItemId:(NSNumber*)itemId
{
    for(NSDictionary * dic in self.items)
    {
        NSDictionary * dataDic = dic[OTHER_DATA];
        NSNumber * dataId = dataDic[ITEM_ID];
        if(itemId.integerValue == dataId.intValue)
        {
            return dic[NAME];
            
            break;
        }
    }
    
    return nil;
}

- (NSString*)getDefaultMainSortWithSortName:(NSString*)sortName
{
    for(NSInteger i = 0;i < self.merchantSortList.count;i++)
    {
        NSMutableDictionary * dic = self.merchantSortList[i];
        
        NSString * name = dic[NAME];
        
        if([name isEqualToString:sortName])
        {
            return name;
        }
    }

    return @"";
}


- (NSString*)getDefaultMainShoppingNameWithAreaName:(NSString*)areaName
{
    for(NSInteger i = 0;i < self.shoppingList.count;i++)
    {
        NSMutableDictionary * dic = self.shoppingList[i];
        
        NSString * mainAreaName = dic[NAME];
        
        NSArray * list = dic[OTHER_DATA][SHOPPING_LIST];
        
        if([Utils checkObjectIsNull:list] == false)
        {
            list = @[];
        }

        for(NSMutableDictionary * diction in list)
        {
            NSString * name = diction[SHOPPING_AREA_NAME];

            if([name isEqualToString:areaName])
            {
                return mainAreaName;
            }
        }
    }
    return @"";
}


@end
