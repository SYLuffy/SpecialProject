//
//  MerchatMapViewController.m
//  DawnGathering
//
//  Created by 李冬岐 on 2024/1/8.
//

#import "MerchantMapViewController.h"
#import <MAMapKit/MAMapKit.h>
#import "MerchantMapListView.h"
#import "MAInfowindowView.h"
#import "MerchantDetailViewController.h"
#import "SystemAuthority.h"


#define kUserID @"my-name-2"

@interface MerchantMapViewController ()<MAMapViewDelegate>

@property (nonatomic,strong)MAMapView * mapView;

@property (nonatomic,strong)MerchantMapListView * listView;

@property (nonatomic,strong)NSMutableArray * allAnnotation;

@property (nonatomic,assign)BOOL isNeedSetMerchantCenter;//是否需要设置第一个商店为地图中心点;

@property (nonatomic,strong)AMapLocationManager * locationManager;

@property (nonatomic,assign)BOOL isBackPop;//如果是返回回来不需要充值定

@end

@implementation MerchantMapViewController

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [Utils setDefaultNavigationBar:self];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSString * defaultCityName = [Utils getUserDefaultByKey:USER_DEFAULT_CITY];
    
    if(!_cityName || [defaultCityName isEqualToString:self.cityName])
    {
        //只需要用户中心点就行;
        self.isNeedSetMerchantCenter = false;
    }else{
        //需要因为不是用户中心点;
        self.isNeedSetMerchantCenter = true;
    }
    
    [self initAppearence];
    
    
    if(self.items)
    {
        self.listView.items = self.items;
    }
    
    if(self.cityName && self.lat && self.lng)
    {
        self.listView.userLat = self.lat;
        self.listView.userLng = self.lng;
        //第一次带默认的经纬度进来
        [self.listView setUserMapCenterLat:self.lat lng:self.lng cityName:self.cityName isRefreshList:true];
    }else{
        [self refreshLocationAuthHandler];
    }
}

- (void)getUserLocation
{
    // 带逆地理（返回坐标和地址信息）。将下面代码中的 YES 改成 NO ，则不会返回地址信息。
    [self.locationManager requestLocationWithReGeocode:YES completionBlock:^(CLLocation *location, AMapLocationReGeocode *regeocode, NSError *error) {
        
                                                         
        if (error)
        {
            NSLog(@"locError:{%ld - %@};", (long)error.code, error.localizedDescription);
            
            if (error.code != AMapLocationErrorLocateFailed)
            {
                
                [self getUserLocation];
                
            }else{
                NSString * defaultCity = [Utils getUserDefaultByKey:USER_DEFAULT_CITY];
                
                if(defaultCity && defaultCity.length > 0)
                {
                    self.cityName = defaultCity;
                    self.lat = [Utils getUserDefaultByKey:USER_DEFAULT_LATITUDE];
                    self.lng = [Utils getUserDefaultByKey:USER_DEFAULT_LONGITUDE];
                }else{
                    self.cityName = @"成都市";
                    self.lat = [NSNumber numberWithInt:0];
                    self.lng = [NSNumber numberWithInt:0];
                }
                
                [self showSettingLocationAlert];
                
                self.listView.userLat = self.lat;
                self.listView.userLng = self.lng;
                
                [self.listView setUserMapCenterLat:self.lat lng:self.lng cityName:self.cityName isRefreshList:true];
                
            }
            return;
        }
        
        NSString * latString = [NSString stringWithFormat:@"%.6lf",location.coordinate.latitude];
        NSString * lngString = [NSString stringWithFormat:@"%.6lf",location.coordinate.longitude];
        
        self.lat = [NSNumber numberWithFloat:latString.floatValue];
        self.lng = [NSNumber numberWithFloat:lngString.floatValue];
        
        self.cityName = regeocode.city;
        
        [Utils setUserDefaultByKey:USER_DEFAULT_CITY andValue:regeocode.city];
        [Utils setUserDefaultByKey:USER_DEFAULT_LATITUDE andValue:self.lat];
        [Utils setUserDefaultByKey:USER_DEFAULT_LONGITUDE andValue:self.lng];
        
        self.listView.userLat = self.lat;
        self.listView.userLng = self.lng;
        
        [self.listView setUserMapCenterLat:self.lat lng:self.lng cityName:self.cityName isRefreshList:true];
    }];
}

- (void)showSettingLocationAlert
{
    [Utils alertWithTitle:@"提示" msg:@"请打开定位权限，以查看附近的商户！" andConfirm:^(BOOL isConfirm) {
        //直接进入设置界面;
        NSURL *appSettings = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
        [[UIApplication sharedApplication] openURL:appSettings options:@{} completionHandler:nil];
    } cancel:^{
        
    }];
}

- (void)initAppearence
{
    self.mapView = [[MAMapView alloc] initWithFrame:self.view.bounds];
    self.mapView.delegate = self;
    
   
    [self.view addSubview:self.mapView];
    
    CGFloat listHeight = self.view.frame.size.height - [Utils getNavigationBarAndStatusBarHeight:self];
    
    self.listView = [[MerchantMapListView alloc] initWithFrame:CGRectMake(0, listHeight * 0.5, self.view.frame.size.width, listHeight)];
    
    self.listView.blackWhiteId = self.blackWhiteId;
    
    self.listView.blackWhiteIdList = self.blackWhiteIdList;
    
    [self.view addSubview:self.listView];
    WS(weakSelf);
    self.listView.tapMerchantWithMerhcantIdHandler = ^(NSNumber * _Nonnull merchantId , NSNumber * _Nonnull distance) {
        [weakSelf gotoMerchantWithMerchantIdHandler:merchantId distance:distance];
    };
    
    self.listView.merchantMapRefresh = ^(NSArray * _Nullable list) {
        [weakSelf refreshPointAnnotationWithMerchantList:list];
    };
    
    _mapView.showsUserLocation = YES;
    _mapView.userTrackingMode = MAUserTrackingModeFollow;
    [_mapView setZoomLevel:14 animated:YES];
}

- (void)refreshLocationAuthHandler{
    
    TenAuthorizationStatus status = [SystemAuthority locationStatus];
    
    if(status == TenAuthorizationStatusAuthorized)
    {
        //同意授权;
        [self getUserLocation];
    }else if(status == TenAuthorizationStatusNotDetermined){
        WS(weakSelf);
        [SystemAuthority getLocationAuthority:^(BOOL isOpen) {
            
            if(isOpen)
            {
                [weakSelf getUserLocation];
            }
            
        }];
    }else
    {
        [self showSettingLocationAlert];
    }
}

- (void)refreshPointAnnotationWithMerchantList:(NSArray*)list
{
    //取出第一个数据;
    if(self.isNeedSetMerchantCenter)
    {
        NSDictionary * firstDic = list.firstObject;
        NSString * latitude = firstDic[LATITUDE];
        NSString * longitude = firstDic[LONGITUDE];
        
        CLLocationCoordinate2D coordinateCenter = CLLocationCoordinate2DMake(latitude.floatValue, longitude.floatValue);
        
        [self.mapView setCenterCoordinate:coordinateCenter];
        if(self.listView.currentType != MerchantMapListOffsetTypeBottom)
        {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                CLLocationCoordinate2D coordinateCenter =[self.mapView convertPoint:CGPointMake(self.view.bounds.size.width * 0.5, self.view.bounds.size.height * 0.5) toCoordinateFromView:self.mapView];
                [self.mapView setCenterCoordinate:coordinateCenter animated:NO];
            });
        }
    }
    
    [_mapView removeAnnotations:self.allAnnotation];
    
    self.allAnnotation = [NSMutableArray array];
    
    for(NSDictionary * dic in list)
    {
        NSString * latitude = dic[LATITUDE];
        NSString * longitude = dic[LONGITUDE];
        
        NSString * merchantName = dic[MERCHANT_NAME];
        NSNumber * distance = dic[DISTANCE];
        NSNumber * merchantId = dic[MERCHANT_ID];
        //NSString * address = dic[ADDRESS];
        
        MAPointAnnotation *pointAnnotation = [[MAPointAnnotation alloc] init];
        pointAnnotation.coordinate = CLLocationCoordinate2DMake(latitude.floatValue, longitude.floatValue);
        pointAnnotation.title = merchantName;
        
        
        NSString * mapLogo = dic[@"mapLogo"];
        if(!mapLogo || mapLogo.length == 0)
        {
            mapLogo = dic[@"brandMapLogo"];
        }
    
        NSDictionary * subDic = @{IMG:mapLogo,MERCHANT_ID:merchantId,DISTANCE:distance};
        NSString * jsonStr = [Utils dictionaryToJson:subDic];
        
        pointAnnotation.subtitle = jsonStr;
        [_mapView addAnnotation:pointAnnotation];
        
        [self.allAnnotation addObject:pointAnnotation];
    
    }
    
    self.isNeedSetMerchantCenter = true;//重置需要设置第一家为用户中心点;
}

- (void)gotoMerchantWithMerchantIdHandler:(NSNumber*)merchantId distance:(NSNumber*)distance
{
    self.isBackPop = true;
    MerchantDetailViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_MERCHAT andIdentifier:@"MerchantDetailViewController"];
    
    vc.merchantId = merchantId;
    vc.items = @[];
    vc.cityName = self.cityName;
    vc.lat = self.lat;
    vc.lng = self.lng;
    vc.distance = distance;
    vc.blackWhiteId = self.blackWhiteId;
    vc.blackWhiteIdList = self.blackWhiteIdList;
    
    [self.navigationController pushViewController:vc animated:true];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    if(self.isBackPop == false)
    {
        CLLocationCoordinate2D coordinateCenter = [self.mapView convertPoint:CGPointMake(self.view.bounds.size.width * 0.5, self.view.bounds.size.height * 0.75) toCoordinateFromView:self.mapView];
        
        
        [self.mapView setCenterCoordinate:coordinateCenter];
    }
}


- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];

    
}


- (IBAction)backAndPopHandler:(UIBarButtonItem *)sender {
    
    [self.listView.menu closeView];
    
    [self.navigationController popViewControllerAnimated:true];
}

#pragma mark -- MAMapViewDelegate

//- (void)mapView:(MAMapView *)mapView mapWillMoveByUser:(BOOL)wasUserAction
//{
//    if(self.listView.currentType != MerchantMapListOffsetTypeBottom)
//    {
//        [self.listView setViewOffsetWithType:MerchantMapListOffsetTypeBottom];
//    }
//}

- (void)mapView:(MAMapView *)mapView didSingleTappedAtCoordinate:(CLLocationCoordinate2D)coordinate
{
    [self.listView.searchView.merchantText resignFirstResponder];
    
    if(self.listView.currentType == MerchantMapListOffsetTypeTop)
    {
        [self.listView.menu closeView];
        [self.listView setViewOffsetWithType:MerchantMapListOffsetTypeMiddle];
    }
    
    
}
- (void)mapView:(MAMapView *)mapView mapDidZoomByUser:(BOOL)wasUserAction{
    [self.listView.searchView.merchantText resignFirstResponder];
    
    if(self.listView.currentType != MerchantMapListOffsetTypeBottom && wasUserAction)
    {
        [self.listView setViewOffsetWithType:MerchantMapListOffsetTypeBottom];
    }
}

- (MAAnnotationView *)mapView:(MAMapView *)mapView viewForAnnotation:(id <MAAnnotation>)annotation
{
    
    if ([annotation isKindOfClass:[MAPointAnnotation class]])
    {
        static NSString *poiIdentifier = @"poiIdentifier";
        MAInfowindowView *poiAnnotationView = (MAInfowindowView *)[self.mapView dequeueReusableAnnotationViewWithIdentifier:poiIdentifier];
        if (poiAnnotationView == nil)
        {
            poiAnnotationView = [[MAInfowindowView alloc] initWithAnnotation:annotation reuseIdentifier:poiIdentifier];
            
            // 屏蔽默认的calloutView
            poiAnnotationView.canShowCallout = NO;
        }
        
        MAPointAnnotation *poiAnno = (MAPointAnnotation *)annotation;
        poiAnnotationView.title = poiAnno.title;
        
        NSDictionary * dic = [Utils dictionaryWithJsonString:poiAnno.subtitle];
        
        poiAnnotationView.distance = dic[DISTANCE];
        poiAnnotationView.merchantId = dic[MERCHANT_ID];
        
        WS(weakSelf);
        poiAnnotationView.tapMAInfowindowView = ^(NSNumber *merchantId , NSNumber * distance) {
           
            [weakSelf gotoMerchantWithMerchantIdHandler:merchantId distance:distance];
        };
        
        return poiAnnotationView;
    }
    
    return nil;
}


//- (void)mapView:(MAMapView *)mapView didAddAnnotationViews:(NSArray *)views{
//
//    for(UIView * view in views)
//    {
//        MAPinAnnotationView * piview = (MAPinAnnotationView *)view;
//        [_mapView selectAnnotation:piview.annotation animated:true];
//    }
//
//}


- (void)mapView:(MAMapView *)mapView mapDidMoveByUser:(BOOL)wasUserAction
{
    
    //地图被拖动过后;
    if(wasUserAction)
    {
        self.isNeedSetMerchantCenter = false;//拖动过后不许要设置只需要取当前坐标的商家;
        CLLocationCoordinate2D location;
        
        if(self.listView.currentType == MerchantMapListOffsetTypeBottom)
        {
            location = mapView.centerCoordinate;
        }else{
            location = [mapView convertPoint:CGPointMake(self.view.bounds.size.width * 0.5, self.view.bounds.size.height * 0.25) toCoordinateFromView:mapView];
        }
        
        CLGeocoder * geoCoder = [[CLGeocoder alloc] init];
        
        CLLocation * clocation = [[CLLocation alloc]initWithLatitude:location.latitude longitude:location.longitude];
        
        [geoCoder reverseGeocodeLocation:clocation completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
                
            CLPlacemark * place = placemarks.firstObject;
            NSString * cityName = place.addressDictionary[@"City"];
            
            NSString * latString = [NSString stringWithFormat:@"%.6lf",location.latitude];
            NSString * lngString = [NSString stringWithFormat:@"%.6lf",location.longitude];
            
            NSNumber * lat = [NSNumber numberWithFloat:latString.floatValue];
            NSNumber * lng = [NSNumber numberWithFloat:lngString.floatValue];
            
            [self.listView setUserMapCenterLat:lat lng:lng cityName:cityName isRefreshList:false];
            
            
            
        }];
        
    }
}

- (AMapLocationManager *)locationManager
{
    
    if(!_locationManager)
    {
        // 带逆地理信息的一次定位（返回坐标和地址信息）
        _locationManager = [[AMapLocationManager alloc] init];
        
        [_locationManager setDesiredAccuracy:kCLLocationAccuracyHundredMeters];
        //   定位超时时间，最低2s，此处设置为2s
        _locationManager.locationTimeout = 2;
        //   逆地理请求超时时间，最低2s，此处设置为2s
        _locationManager.reGeocodeTimeout = 2;
    }
    
    return _locationManager;
   
}

@end
