//
//  MerchatMapViewController.h
//  DawnGathering
//
//  Created by 李冬岐 on 2024/1/8.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MerchantMapViewController : UIViewController

@property (nonatomic,strong)NSNumber * lat;
@property (nonatomic,strong)NSNumber * lng;
@property (nonatomic,strong)NSString * cityName;

@property (nonatomic,strong)NSNumber * blackWhiteId;
@property (nonatomic,strong)NSArray * blackWhiteIdList;

@property (nonatomic,strong)NSMutableArray <NSString*>* items;
@end

NS_ASSUME_NONNULL_END
