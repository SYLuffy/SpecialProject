//
//  MenuCollectionViewCell.m
//  DawnGathering
//
//  Created by 李冬岐 on 2024/1/11.
//

#import "MenuCollectionViewCell.h"

@implementation MenuCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
