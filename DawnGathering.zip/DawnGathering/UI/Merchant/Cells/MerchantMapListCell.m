//
//  MerchantMapListCell.m
//  DawnGathering
//
//  Created by 李冬岐 on 2024/1/8.
//

#import "MerchantMapListCell.h"
#import "SystemAuthority.h"

@implementation MerchantMapListCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    TenAuthorizationStatus status = [SystemAuthority locationStatus];
    
    if(status != TenAuthorizationStatusAuthorized)
    {
        self.distanceIcon.hidden = true;
        self.merchantDistanceLabel.hidden = true;
    }else{
        self.distanceIcon.hidden = false;
        self.merchantDistanceLabel.hidden = false;
    }
    
}

- (void)drawRect:(CGRect)rect
{
    [super drawRect:rect];
    
}

- (void)setItems:(NSArray*)items
{
    //删除所有元素再添加;
    [self.itemsView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    CGFloat gap = 5;
    
    for(NSInteger i = 0; i < items.count; i++)
    {
        UILabel * itemView = [[UILabel alloc] initWithFrame:CGRectMake(i * gap + i * 64, 0, 64, 20)];
        itemView.backgroundColor = [UIColor colorWithHexString:@"#FDA23F" alpha:0.2];
        
        itemView.font = [UIFont fontWithName:DEFAULT_FONT_NAME size:11];
        itemView.textColor = UIColorFromRGB(0xFDA23F);
        itemView.textAlignment = NSTextAlignmentCenter;
        itemView.layer.masksToBounds = true;
        itemView.layer.cornerRadius = 4.0f;
        
        NSDictionary * dic = items[i];
        
        NSString * itemName = dic[ITEM_NAME];
        
        itemView.text = itemName;
        
        [self.itemsView addSubview:itemView];
        
    }
    
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (IBAction)tapCellHandler:(UIButton *)sender {
    
    if(self.tapMerchantWithIdHandler)
    {
        self.tapMerchantWithIdHandler(self.merchantId , self.distance);
        return;
    }
    
    if(self.tapMerchantWithBrandIdHandler)
    {
        self.tapMerchantWithBrandIdHandler(self.brandIdIndex);
    }
}

@end
