//
//  MerchantMapListCell.h
//  DawnGathering
//
//  Created by 李冬岐 on 2024/1/8.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^TapMerchantWithBrandIdHandler)(NSString  * _Nullable  brandIdIndex);
typedef void(^TapMerchantWithIdHandler)(NSNumber * _Nullable merchantId , NSNumber * _Nullable distance);

@interface MerchantMapListCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *merchantImageView;
@property (weak, nonatomic) IBOutlet UILabel *merchantTitleLabel;

@property (weak, nonatomic) IBOutlet UILabel *merchantTypeLabel;
@property (weak, nonatomic) IBOutlet UILabel *merchantAddressLabel;
@property (weak, nonatomic) IBOutlet UILabel *merchantDistanceLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *typeNameLeft;//默认29 隐藏10;
@property (weak, nonatomic) IBOutlet UIImageView *typeLogoImageView;
@property (weak, nonatomic) IBOutlet UIView *itemsView;//专项福利容器
@property (weak, nonatomic) IBOutlet UIImageView *distanceIcon;

@property (nonatomic,strong)NSString * brandIdIndex;
@property (nonatomic,strong)NSNumber * merchantId;
@property (nonatomic,strong)NSNumber * distance;

@property (nonatomic,copy)TapMerchantWithBrandIdHandler tapMerchantWithBrandIdHandler;
@property (nonatomic,copy)TapMerchantWithIdHandler tapMerchantWithIdHandler;

- (void)setItems:(NSArray*)items;
@end

NS_ASSUME_NONNULL_END
