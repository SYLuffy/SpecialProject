//
//  MerchantViewController.h
//  DawnGathering
//
//  Created by 李冬岐 on 2024/1/12.
//

#import <UIKit/UIKit.h>
#import "BaseMerchantViewController.h"
#import "WMZDropDownMenu.h"

NS_ASSUME_NONNULL_BEGIN

@interface MerchantBrandViewController : UIViewController

@property (nonatomic,strong)NSString * brandIndex;

@property (nonatomic,strong)NSString * merchantName;
@property (nonatomic,strong)NSString * merchantDesc;

@property (nonatomic,strong)NSNumber * merchantCount;

@property (nonatomic,strong)NSString * brandLogo;


@property (nonatomic,strong)NSNumber * preLat;
@property (nonatomic,strong)NSNumber * preLng;
@property (nonatomic,strong)NSString * preCityName;

@property (nonatomic,strong)NSNumber * blackWhiteId;
@property (nonatomic,strong)NSArray * blackWhiteIdList;

@end

@interface CollectionViewBrandItemHeadrView : WMZDropCollectionViewHeadView

@end

NS_ASSUME_NONNULL_END
