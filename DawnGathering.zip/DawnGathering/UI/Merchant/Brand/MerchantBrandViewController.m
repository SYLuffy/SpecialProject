//
//  MerchantViewController.m
//  DawnGathering
//
//  Created by 李冬岐 on 2024/1/12.
//

#import "MerchantBrandViewController.h"
#import "QuickRefresh.h"
#import "MerchantMapListCell.h"
#import "MenuCollectionViewCell.h"
#import "MerchantListHeader.h"
#import "MerchantDetailViewController.h"
#import "MenuModel.h"
#import "UITableView+EZErrorView.h"
@interface MerchantBrandViewController ()<UITableViewDataSource,UITableViewDelegate,WMZDropMenuDelegate>
@property (weak, nonatomic) IBOutlet UIImageView *merchantLogoImageView;
@property (weak, nonatomic) IBOutlet UILabel *merchantNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *merchantCountLabel;
@property (weak, nonatomic) IBOutlet UIView *topGrayView;
@property (weak, nonatomic) IBOutlet UITableView *listTableView;

@property (nonatomic,strong)MerchantListHeader * header;

@property (nonatomic,strong)NSArray * dataSource;

@property (nonatomic,strong)QuickRefresh * refresh;

@property (nonatomic,assign)NSInteger page;

@property (nonatomic,assign)BOOL isGetUserLocation;

@property (nonatomic,strong)NSNumber * lat;
@property (nonatomic,strong)NSNumber * lng;

@property (nonatomic,strong)NSArray * items;

@property (nonatomic,strong)AMapLocationManager * locationManager;

@property (nonatomic,strong)NSString * cityName;

@property (nonatomic,strong)NSString * requestId;

@property (nonatomic,strong)NSString * areaIndexId;
@property (nonatomic,strong)NSString * merchantIndexId;
@property (nonatomic,strong)NSString * sortType;

@property (nonatomic,strong)WMZDropDownMenu *menu;
@property (nonatomic,strong)MenuModel * menuModel;
@property (nonatomic,strong)WMZDropMenuParam *menuParam;

@property (nonatomic,strong) NoDataView *noDataView;

@property (nonatomic,strong) NSArray * brandIndexList;

@end

@implementation MerchantBrandViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.areaIndexId = @"";
    self.merchantIndexId = @"";
    self.sortType = @"";
    self.page = 1;
    self.items = @[];
    self.requestId = @"";
    self.dataSource = @[];
    
    self.listTableView.dataSource = self;
    self.listTableView.delegate = self;
    
    self.listTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    self.header = (MerchantListHeader*)[Utils getXibByName:@"MerchantListHeader"];
    
    if(self.brandLogo)
    {
        [Utils loadImage:self.merchantLogoImageView andURL:self.brandLogo isLoadRepeat:false];
    }
    
    if(self.merchantName)
    {
        self.merchantNameLabel.text = self.merchantName;
    }
    
    if(self.merchantCount)
    {
        self.merchantCountLabel.text = [NSString stringWithFormat:@"商家数：%ld家",self.merchantCount.integerValue];
    }
    
    CGFloat defaultHeight = 91;
    if(self.merchantDesc)
    {
        self.header.descLabel.text = self.merchantDesc;
        if(self.merchantDesc.length == 0)
        {
            self.header.descViewHeight.constant = 0;
            
            defaultHeight -= 91;
        }
    }
    
    UIView * headerContainer = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, defaultHeight)];
    
    headerContainer.backgroundColor = [UIColor whiteColor];
    
    self.header.frame = headerContainer.bounds;
    
    [headerContainer addSubview:self.header];
    
    self.listTableView.tableHeaderView = headerContainer;
    
    self.listTableView.tableHeaderView.backgroundColor = [UIColor clearColor];
    self.listTableView.backgroundColor = [UIColor clearColor];
    
    self.listTableView.tableFooterView = [UIView new];
    
    self.refresh = [[QuickRefresh alloc] init];
    
    [self.refresh gifModelRefresh:self.listTableView refreshType:RefreshTypeDouble firstRefresh:false timeLabHidden:true stateLabHidden:true dropDownBlock:^{
            
        self.page = 1;
        [self refreshHandler];
    } upDropBlock:^{
        
        self.page += 1;
        [self refreshHandler];
    }];
    
    _noDataView= [NoDataView xibView];
    [_noDataView setImageOrTitileNoDataViewType:NoDataViewTypeDefault];
   
    _noDataView.frame = CGRectMake(0, 240, self.view.frame.size.width, self.view.frame.size.height - [Utils getNavigationBarAndStatusBarHeight:self] - 240);
    
    [self.view insertSubview:_noDataView atIndex:0];
    
    [self getUserLocation];
    
    
    UIBezierPath *cornerRadiusPath = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(0, 0, self.view.frame.size.width, 160) byRoundingCorners:UIRectCornerBottomLeft | UIRectCornerBottomRight cornerRadii:CGSizeMake(10, 10)];

    CAShapeLayer *cornerRadiusLayer = [ [CAShapeLayer alloc ] init];

    cornerRadiusLayer.frame = CGRectMake(0, 0, self.view.frame.size.width, 160);

    cornerRadiusLayer.path = cornerRadiusPath.CGPath; 
    
    self.topGrayView.layer.mask = cornerRadiusLayer;
    
//    [Utils cornerRadiusBottomLRWithView:self.topGrayView withRadius:10];//添加圆角
    
    _menuParam =
    MenuParam()
    .wTableViewWidthSet(@[@(0.32),@(0.68)])
    .wTableViewColorSet(@[[UIColor colorWithHexString:@"F8F8F8"],[UIColor whiteColor]])
    .wCollectionViewSectionShowExpandCountSet(20)
    //注册自定义的collectionViewHeadView  如果使用了自定义collectionViewHeadView 必填否则会崩溃
    .wReginerCollectionHeadViewsSet(@[@"CollectionViewBrandItemHeadrView"])
    .wReginerCollectionCellsSet(@[@"MenuCollectionViewCell",MenuCollectionViewCell.class])
    .wMainRadiusSet(20)
    .wMenuTitleEqualCountSet(2)
    .wCollectionViewDefaultFootViewPaddingYSet(15)
    .wCollectionViewCellSelectBgColorSet([UIColor colorWithHexString:@"FDA23F" alpha:0.1])
    .wCollectionViewCellSelectTitleColorSet([Utils getMainColor]);
    
    self.menu = [[WMZDropDownMenu alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 50) withParam:_menuParam];

    self.menu.delegate = self;
    
}


- (void)getUserLocation
{
    self.lat = self.preLat;
    self.lng = self.preLng;
    
    self.cityName = self.preCityName;
    
    [self setMenuWithCityName:self.cityName];
}

- (void)scrollToTopHandler{
    
    CGFloat top = 91;
    if(self.merchantDesc.length == 0 || !self.merchantDesc)
    {
        top -= 91;
    }
    
    [self.listTableView setContentOffset:CGPointMake(0, top) animated:true];
}

- (void)menu:(WMZDropDownMenu *)menu didConfirmAtSection:(NSInteger)section selectNoramelData:(NSMutableArray*)selectNoramalData selectStringData:(NSMutableArray*)selectData
{
    
    NSMutableArray * array = [NSMutableArray array];
    for(WMZDropTree * dic in selectNoramalData)
    {
        NSDictionary * otherDic = dic.otherData;
        
        NSNumber * itemId = otherDic[ITEM_ID];
        
        [array addObject:[NSString stringWithFormat:@"%ld",itemId.integerValue]];
    }
    
    self.items = array.copy;
    self.page = 1;
    [self refreshHandler];
}

- (void)refreshHandler{
    
    if(!_blackWhiteIdList)
    {
        _blackWhiteIdList = [SharedInstance getInstance].sendBlackWhiteList;
    }
    
    if(self.page == 1) self.requestId = @"";
    //请求数据
    [ServiceManager getMerchantListWithItems:self.items word:@"" isCutWord:true Lng:self.lng Lat:self.lat resId:self.requestId page:@(self.page) pageSize:@10 areaIndex:self.areaIndexId merchantIndex:self.merchantIndexId sortType:self.sortType blackWhiteId:self.blackWhiteId brandIndex:self.brandIndex blackWhiteIdList:self.blackWhiteIdList brandIndexList:nil success:^(NSDictionary *data) {
        
        NSDictionary * dic = data[DATA];
        
        if([Utils checkObjectIsNull:dic])
        {
            NSArray * merchantData = dic[MERCHANT_DATA];
            
            if([Utils checkObjectIsNull:merchantData])
            {
                if(self.page == 1)
                {
                    self.dataSource = merchantData;
                }else{
                    self.dataSource = [self.dataSource arrayByAddingObjectsFromArray:merchantData];
                }
                
                if(merchantData.count < 10)
                {
                    [self.refresh noMoreData];
                }
            }else{
                if(self.page != 1)
                {
                    [self.refresh noMoreData];
                }else{
                    self.dataSource = @[];
                }
            }
        }else{
            if(self.page != 1)
            {
                [self.refresh noMoreData];
            }else{
                self.dataSource = @[];
            }
        }
        
        if(self.dataSource.count == 0)
        {
            self.noDataView.hidden = false;
            [self.refresh noMoreData];
        }else{
            self.noDataView.hidden = true;
        }
        
        NSString * resId = dic[RES_ID];
        self.requestId = resId;
        [self.listTableView reloadData];
        [self.refresh endRefreshing];
        
    } failure:^(NSError *error) {
        
        [self.refresh noMoreData];
        [self.refresh endRefreshing];
        self.noDataView.hidden = false;
    }];
}

- (void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    
    
}

- (IBAction)backAndPopHandler:(UIBarButtonItem *)sender {
    [self.menu closeView];
    [self.navigationController popViewControllerAnimated:true];
}

#pragma mark -- UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    MerchantMapListCell * cell = [tableView dequeueReusableCellWithIdentifier:@"MerchantMapListCell"];
    NSDictionary * dic = self.dataSource[indexPath.row];
    if(!cell)
    {
        cell = (MerchantMapListCell*)[Utils getXibByName:@"MerchantMapListCell"];
    }
    WS(weakSelf);
    
    cell.tapMerchantWithIdHandler = ^(NSNumber * _Nullable merchantId , NSNumber * _Nullable distance) {
        [weakSelf gotoMerchantDetailHandlerWithMerchantId:merchantId distance:distance];
    };
    
    if([dic isKindOfClass:[NSNumber class]] == false){
        NSString * imgURL = dic[IMG];
        if(imgURL.length == 0 || !imgURL)
        {
            imgURL = dic[BRAND_LOGO];
        }
        NSString * typeLogo = dic[TYPE_LOGO];
        NSString * merhcantName = dic[MERCHANT_NAME];
        NSString * typeName = dic[TYPE_NAME];
        NSString * areaName = dic[AREA_NAME];
        NSNumber * distance = dic[DISTANCE];
        NSNumber * merchantId = dic[MERCHANT_ID];
        
        cell.merchantTitleLabel.text = merhcantName;
        cell.merchantAddressLabel.text = areaName;
        cell.merchantTypeLabel.text = typeName;
        [Utils loadImage:cell.merchantImageView andURL:imgURL isLoadRepeat:false];
        if(typeLogo && typeLogo.length > 0)
        {
            [Utils loadImage:cell.typeLogoImageView andURL:typeLogo isLoadRepeat:false];
            cell.typeLogoImageView.hidden = false;
            cell.typeNameLeft.constant = 29;
        }else{
            cell.typeLogoImageView.hidden = true;
            cell.typeNameLeft.constant = 10;
        }
        
        
        cell.distance = distance;
        cell.merchantId = merchantId;
        NSString *uint;
        CGFloat showDis = 0;
        
        if(distance.integerValue > 1000)
        {
            uint = @"km";
            showDis = distance.floatValue / 1000;
            cell.merchantDistanceLabel.text = [NSString stringWithFormat:@"%.2lf%@",showDis,uint];
        }else{
            uint = @"m";
            showDis = distance.floatValue;
            cell.merchantDistanceLabel.text = [NSString stringWithFormat:@"%.0lf%@",showDis,uint];
            
        }
        
        NSArray * items = dic[ITEMS];
        if([Utils checkObjectIsNull:items] && items.count > 0)
        {
            [cell setItems:items];
        }
    }
    
    return cell;
}

- (void)gotoMerchantDetailHandlerWithMerchantId:(NSNumber*)merchantId distance:(NSNumber*)distance
{
    MerchantDetailViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_MERCHAT andIdentifier:@"MerchantDetailViewController"];
    
    vc.merchantId = merchantId;
    vc.items = @[];
    vc.distance = distance;
    vc.cityName = self.cityName;
    vc.lat = self.lat;
    vc.lng = self.lng;
    vc.blackWhiteId = self.blackWhiteId;
    vc.blackWhiteIdList = self.blackWhiteIdList;
    
    [self.navigationController pushViewController:vc animated:true];
}
 
#pragma mark -- UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //如果有专项显示需要 增加高度到125.0f
    NSDictionary * dic = self.dataSource[indexPath.row];
    NSArray * items = dic[ITEMS];
    if([Utils checkObjectIsNull:items] && items.count > 0)
    {
        return 125.0f;
    }
    return 110.0f;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 50.0f;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView * header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 50)];
    [header addSubview:self.menu];
    
    return header;
}

- (AMapLocationManager *)locationManager
{
    
    if(!_locationManager)
    {
        // 带逆地理信息的一次定位（返回坐标和地址信息）
        _locationManager = [[AMapLocationManager alloc] init];
        
        [_locationManager setDesiredAccuracy:kCLLocationAccuracyHundredMeters];
        //   定位超时时间，最低2s，此处设置为2s
        _locationManager.locationTimeout = 2;
        //   逆地理请求超时时间，最低2s，此处设置为2s
        _locationManager.reGeocodeTimeout = 2;
    }
    
    return _locationManager;
   
}


#pragma mark -- WMZDropMenuDelegate

- (CGFloat)popFrameY
{
    return [Utils getNavigationBarAndStatusBarHeight:[Utils getCurrentVC]] + 180;
}

//自定义collectionhearder
- (nullable UICollectionReusableView*)menu:(WMZDropDownMenu *)menu headViewForUICollectionView:(WMZDropCollectionView*)collectionView AtDropIndexPath:(WMZDropIndexPath*)dropIndexPath AtIndexPath:(NSIndexPath*)indexpath
{
    CollectionViewBrandItemHeadrView *headView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:NSStringFromClass([CollectionViewBrandItemHeadrView class]) forIndexPath:indexpath];
    
    headView.textLa.text = @"专项";
   
    headView.textLa.font = [UIFont fontWithName:DEFAULT_FONT_NAME size:14];
    return headView;
}
/// 自定义collectionViewCell内容
- (nullable UICollectionViewCell*)menu:(WMZDropDownMenu *)menu cellForUICollectionView:(WMZDropCollectionView*)collectionView
    AtDropIndexPath:(WMZDropIndexPath*)dropIndexPath AtIndexPath:(NSIndexPath*)indexpath dataForIndexPath:(WMZDropTree*)model
{
    MenuCollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([MenuCollectionViewCell class]) forIndexPath:indexpath];
    
    if(model.isSelected)
    {
        cell.bg.layer.borderWidth = 1;
        cell.bg.layer.borderColor = [Utils getMainColor].CGColor;
        cell.bg.backgroundColor = [UIColor colorWithHexString:@"FDA23F" alpha:0.1];
        
    }else{
        cell.bg.layer.borderWidth = 0;
        cell.bg.layer.borderColor = [Utils getMainColor].CGColor;
        cell.bg.backgroundColor = UIColorFromRGB(0xF5F5F5);
    }
    
    cell.contentLabel.text = model.name;
    
    return cell;
}

- (nullable UITableViewCell*)menu:(WMZDropDownMenu *)menu cellForUITableView:(WMZDropTableView*)tableView AtIndexPath:(NSIndexPath*)indexpath dataForIndexPath:(WMZDropTree*)model
{
    //选择地址需要自定也cell
    if(tableView.dropIndex.section == 2 || tableView.dropIndex.section == 1)
    {
        UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"mainAddressCell"];
        
        if(!cell)
        {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"mainAddressCell"];
        }
        
        cell.textLabel.font = [UIFont fontWithName:DEFAULT_FONT_NAME size:14];
        
        if(model.isSelected)
        {
            cell.textLabel.textColor = [Utils getMainColor];
            cell.contentView.backgroundColor = [UIColor whiteColor];
            cell.backgroundColor = [UIColor whiteColor];
        }else{
            cell.textLabel.textColor = UIColorFromRGB(0x222222);
            cell.contentView.backgroundColor = [UIColor clearColor];
            cell.backgroundColor = [UIColor clearColor];
        }
        
        UIImage * checkIcon = [UIImage imageNamed:@"ic_menu_check"];
        checkIcon = [checkIcon imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
        UIImageView *image = [[UIImageView alloc]initWithImage:checkIcon];
        image.translatesAutoresizingMaskIntoConstraints = NO;
        image.tintColor = [Utils getMainColor];
        image.frame = CGRectMake(0, 0, 20, 20);
        image.hidden = true;
        if(tableView.dropIndex.row == 1)
        {
            image.hidden = !model.isSelected;
        }
        cell.accessoryView = image;
        
        cell.textLabel.text = model.name;
        
        return cell;
    }
    
    return nil;
    
}

- (void)setMenuWithCityName:(NSString*)cityName
{
    if(!_blackWhiteIdList)
    {
        _blackWhiteIdList = [SharedInstance getInstance].sendBlackWhiteList;
    }
 
    [ServiceManager getFilterConditionWithCityName:cityName blackWhiteIdList:self.blackWhiteIdList success:^(NSDictionary *data) {
        
        NSDictionary * params = data[DATA];
        
        self.menuModel = [[MenuModel alloc] initByDictionary:params];
        
        
        if(self.menuModel.items.count == 0)
        {
            
            self.menuParam.wMenuTitleEqualCountSet(2);
            
            [self.menu setParam:self.menuParam];
        }
        
        NSArray * searchList = self.menuModel.shoppingList.firstObject[OTHER_DATA][SHOPPING_LIST];
        
        self.areaIndexId = searchList.firstObject[SEARCH_AREA_INDEX];
        
        NSArray * merchantIndexList = self.menuModel.merchantTypes.firstObject[OTHER_DATA][CHILD_LIST];
        
        self.merchantIndexId = merchantIndexList.firstObject[MERCHANT_TYPE_INDEX];
        
        NSArray * sortList = self.menuModel.merchantSortList;
        
        self.sortType = sortList.firstObject[OTHER_DATA][SORT_TYPE_INDEX];
        
        [self.menu updateUI];
        
        [self refreshHandler];
    }];
}

- (NSArray*)titleArrInMenu:(WMZDropDownMenu *)menu{
    NSMutableArray * menuList = @[
        @{WMZMenuTitleNormal:@"距离最近",WMZMenuTitleImage:@"ic_xiala",WMZMenuTitleSelectImage:@"ic_shangla",WMZMenuTitleColor:UIColorFromRGB(0x222222),WMZMenuTitleSelectColor:UIColorFromRGB(0x222222)},
        @{WMZMenuTitleNormal:@"全城",WMZMenuTitleImage:@"ic_xiala",WMZMenuTitleSelectImage:@"ic_shangla",WMZMenuTitleColor:UIColorFromRGB(0x222222),WMZMenuTitleSelectColor:UIColorFromRGB(0x222222)}
        
    ].mutableCopy;
    
    if(self.menuModel.items.count > 0)
    {
        [menuList addObject:@{WMZMenuTitleNormal:@"更多",WMZMenuTitleImage:@"ic_xiala",WMZMenuTitleSelectImage:@"ic_shangla",WMZMenuTitleColor:UIColorFromRGB(0x222222),WMZMenuTitleSelectColor:UIColorFromRGB(0x222222)}];
    }
    
    return menuList.copy;
}

- (NSInteger)menu:(WMZDropDownMenu *)menu numberOfRowsInSection:(NSInteger)section{
    if (section == 1){
        return 2;
    }
    return 1;
}

- (NSArray *)menu:(WMZDropDownMenu *)menu dataForRowAtDropIndexPath:(WMZDropIndexPath *)dropIndexPath{
    if (dropIndexPath.section == 0) {
        NSString * mainName = [self.menuModel getDefaultMainSortWithSortName:@"距离最近"];
        
        return [self.menuModel getMerchantSortWithSortName:mainName];
    }else if (dropIndexPath.section == 1) {
        if (dropIndexPath.row == 0) return [self.menuModel getShoppingListWithAreaName:@"全城"];
        
        if (dropIndexPath.row == 1){
            
            NSString * mainName = [self.menuModel getDefaultMainShoppingNameWithAreaName:@"全城"];
            NSArray * list =  [self getAreaData][mainName];
            
            return list;
        }
    }else if(dropIndexPath.section == 2){
        if (dropIndexPath.row == 0) return self.menuModel.items;
    }
    return @[];
}

- (MenuUIStyle)menu:(WMZDropDownMenu *)menu uiStyleForRowIndexPath:(WMZDropIndexPath *)dropIndexPath{
    if (dropIndexPath.section == 2) {
        return MenuUICollectionView;
    }
    return MenuUITableView;
}


//点击第几个关闭
- (BOOL)menu:(WMZDropDownMenu *)menu closeWithTapAtDropIndexPath:(WMZDropIndexPath *)dropIndexPath{
    if (dropIndexPath.section == 1) {
        //选择城市第二级就返回
        if (dropIndexPath.row == 1) return YES;
        else return NO;
    }else if (dropIndexPath.section == 0) {
        return YES;
    }
    return NO;
}

/*
*点击方法
*/
- (void)menu:(WMZDropDownMenu *)menu didSelectRowAtDropIndexPath:(WMZDropIndexPath *)dropIndexPath dataIndexPath:(NSIndexPath *)indexpath data:(WMZDropTree*)data{
    NSLog(@"标题所在列:%ld \n 联动层级:%ld  \n 点击indexPath:%@ \n 点击的数据 :%@",dropIndexPath.section,dropIndexPath.row,indexpath,data);
    //三级联动示例
    if (dropIndexPath.section == 1) {
        //更新第二层
        if (dropIndexPath.row  == 0) {
            [menu updateData:[self getAreaData][data.name] ForRowAtDropIndexPath:dropIndexPath];
        }else if(dropIndexPath.row == 1)
        {
            //点击确定了;
            NSDictionary * dic = data.originalData[OTHER_DATA];
            
            NSString * areaId = dic[SEARCH_AREA_INDEX];
            
            self.areaIndexId = areaId;
           
            [self refreshHandler];
        }
    }else if(dropIndexPath.section == 0)
    {
        //距离最近
        NSDictionary * dic = data.otherData;
        
        self.sortType = dic[SORT_TYPE_INDEX];
        
        [self refreshHandler];
    }
}

//模拟点击标题网络请求数据
- (void)menu:(WMZDropDownMenu *)menu didSelectTitleInSection:(NSInteger)section btn:(WMZDropMenuBtn *)selectBtn networkBlock:(MenuAfterTime)block{
   
    [self scrollToTopHandler];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        block();
    });
}

//标题栏是否筛选互斥
- (BOOL)menu:(WMZDropDownMenu *)menu dropIndexPathConnectInSection:(NSInteger)section
{
    return NO;
}
//是否是单选还是多选
- (MenuEditStyle)menu:(WMZDropDownMenu *)menu editStyleForRowAtDropIndexPath:(WMZDropIndexPath*)dropIndexPath
{
    if(dropIndexPath.section == 2)
    {
        return MenuEditMoreCheck;
    }
    
    return MenuEditOneCheck;
}

- (MenuShowAnimalStyle)menu:(WMZDropDownMenu *)menu showAnimalStyleForRowInSection:(NSInteger)section{
    return MenuShowAnimalBottom;
}
- (MenuHideAnimalStyle)menu:(WMZDropDownMenu *)menu hideAnimalStyleForRowInSection:(NSInteger)section{
    return MenuHideAnimalTop;
}

- (void)menu:(WMZDropDownMenu *)menu customDefauultCollectionFootView:(WMZDropConfirmView *)confirmView{
    confirmView.showBorder = NO;
    confirmView.confirmBtn.backgroundColor = [Utils getMainColor];
    
    [confirmView.confirmBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
}

- (NSDictionary*)getAreaData{
    
    //获取区级下面数据;
    NSMutableDictionary * areaData = [NSMutableDictionary dictionary];
    
    for(NSDictionary * dic in self.menuModel.shoppingList)
    {
        NSString * areaName = dic[NAME];
        NSArray * list = dic[OTHER_DATA][SHOPPING_LIST];
        
        NSMutableArray * array = [NSMutableArray array];
        for(NSDictionary * diction in list)
        {
            NSDictionary * areaData;
            NSString * name = diction[SHOPPING_AREA_NAME];
            if([name isEqualToString:@"全城"])
            {
                areaData = @{NAME:name,IS_SELECTED:@(YES),OTHER_DATA:diction};
            }else{
                areaData = @{NAME:name,OTHER_DATA:diction};
            }
            
            [array addObject:areaData];
        }
        
        [areaData setObject:array forKey:areaName];
    }
    
    
    
    return areaData.copy;

}



@end

//自定义tableview head
@implementation CollectionViewBrandItemHeadrView
@end
