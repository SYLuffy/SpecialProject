//
//  MerchantListViewController.h
//  DawnGathering
//
//  Created by 李冬岐 on 2024/1/9.
//

#import <UIKit/UIKit.h>
#import "BaseMerchantViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface MerchantListViewController : BaseMerchantViewController


@property (nonatomic,strong)NSNumber * blackWhiteId;
@property (nonatomic,strong)NSArray * blackWhiteIdList;

@property (nonatomic,strong)NSString * showTitle;

@property (nonatomic,strong)NSArray <NSString*>* items;

@end

@interface CollectionViewListItemHeadrView : WMZDropCollectionViewHeadView

@end

NS_ASSUME_NONNULL_END
