//
//  MerchantDetailViewController.m
//  DawnGathering
//
//  Created by 李冬岐 on 2024/1/12.
//

#import "MerchantDetailViewController.h"
#import "MerchantDetailCell.h"
#import "MerchantDetailCollectionCell.h"
#import "MerchantDetailDescCell.h"
#import "MerchantDetailHeader.h"
#import "BroadcastView.h"
#import "ShowItemPopView.h"
#import "UniversalPopView.h"
#import "JZLocationConverter.h"
#import "MerchantPhotoViewController.h"
#import "MerchantBrandViewController.h"
#import <IQKeyboardManager.h>
#import <MapKit/MapKit.h>
#import "WPPaymentPasswordVC.h"
#import "ScanCodeViewController.h"
#import "QuestionBackViewController.h"
#import "MMImagePreviewView.h"

#define NORMAL_CELL @"normalCell"
#define COLLECTION_CELL @"collectionCell"
#define DESC_CELL @"descCell"

#define IS_QR_CODE @"isQRCode"

@interface MerchantDetailViewController ()<UITableViewDelegate,UITableViewDataSource,WPPaymentPasswordVCDelegate>
@property (weak, nonatomic) IBOutlet UITableView *listTableView;
@property (nonatomic,strong)NSArray * dataSource;
@property (nonatomic,strong)MerchantDetailHeader * header;

@property (nonatomic,strong)BroadcastView * broadcastView;

@property (nonatomic,strong)NSString * merchantTel;//商家电话;
@property (nonatomic,strong)NSString * merchantLat;//商家经度
@property (nonatomic,strong)NSString * merchantLng;//商家纬度

@property (nonatomic,strong)NSString * address;

@property (nonatomic,strong)NSString * gotoMapURL;

@property (nonatomic,strong)NSDictionary * brandInfo;

@property (nonatomic,strong)NSArray * useItems;//可用福利;
@property (nonatomic,strong)NSArray * service;//商户服务
@property (nonatomic,strong)NSString * merchantName;
@property (nonatomic,strong)NSString * notice;
@property (nonatomic,strong)NSArray * albums;
@property (nonatomic,strong)NSMutableArray * imageViews;


@property (nonatomic, strong) MMImagePreviewView *previewView;
@end

@implementation MerchantDetailViewController

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [Utils setDefaultNavigationBar:self];
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.dataSource = @[@{TYPE:NORMAL_CELL,NAME:@"可用福利",IMG:@"ic_canuse_gift",IS_QR_CODE:@0},
                        @{TYPE:NORMAL_CELL,NAME:@"商户服务",IMG:@"ic_merchant_service",IS_QR_CODE:@0},
                        @{TYPE:NORMAL_CELL,NAME:@"门店扫码",IMG:@"ic_goto_qrcode",IS_QR_CODE:@1},
                        @{TYPE:COLLECTION_CELL},
                        @{TYPE:DESC_CELL,CONTENT:@""}];
    self.previewView = [[MMImagePreviewView alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.listTableView.delegate = self;
    self.listTableView.dataSource = self;
    
    self.imageViews = [NSMutableArray array];
    
    self.listTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    self.listTableView.backgroundColor = [UIColor clearColor];
    
    self.listTableView.tableHeaderView.backgroundColor = [UIColor clearColor];
    
    UIView * headerContainer = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 412)];
    
    headerContainer.backgroundColor = [UIColor whiteColor];
    
    self.header = (MerchantDetailHeader*)[Utils getXibByName:@"MerchantDetailHeader"];

    
    self.header.frame = headerContainer.bounds;
    WS(weakSelf);
    self.header.tapGotoMerchantPhotoHandler = ^{
        [weakSelf gotoMerchantPhotoHandler];
    };
    self.header.tapGotoUserMapNavigate = ^{
        [weakSelf gotoNavigateMapHandler];
    };
    
    self.header.tapUserCallMerchant = ^{
        [weakSelf callMerchantPhoneHandler];
    };
    
    [headerContainer addSubview:self.header];
    
    self.broadcastView = (BroadcastView*)[Utils getXibByName:@"BroadcastView"];
    
    self.broadcastView.tapBoradcastLabelHandler = ^(NSInteger index) {
        [weakSelf tapBroadcastWithIndex:index];
        
    };
    NSString *uint;
    CGFloat showDis = 0;
    if(self.distance.integerValue > 1000)
    {
        uint = @"km";
        showDis = self.distance.floatValue / 1000;
        self.header.distanceLabel.text = [NSString stringWithFormat:@"%.2lf%@",showDis,uint];
    }else{
        uint = @"m";
        showDis = self.distance.floatValue;
        self.header.distanceLabel.text = [NSString stringWithFormat:@"%.0lf%@",showDis,uint];
        
    }
    
    self.listTableView.tableHeaderView = headerContainer;
    
    self.listTableView.tableFooterView = [UIView new];
    
    [self refreshHandler];
    
}

- (void)gotoNavigateMapHandler
{
    CLLocationCoordinate2D originalLocation = CLLocationCoordinate2DMake(self.merchantLat.floatValue,self.merchantLng.floatValue);
    WS(weakSelf);
    //调用系统导航;
    [[SharedInstance getInstance] showNavigateMapActionViewControllerWithViewController:self back:^(NSString *title) {
            
        if([title isEqualToString:@"百度地图"])
        {
            //百度需要转换坐标;
            CLLocationCoordinate2D baiduLocation = [JZLocationConverter gcj02ToBd09:originalLocation];
            NSString * Latitude = [NSString stringWithFormat:@"%.6lf",baiduLocation.latitude];
            NSString * Longitude = [NSString stringWithFormat:@"%.6lf",baiduLocation.longitude];
            
            NSURL * baidu_App = [NSURL URLWithString:@"baidumap://"];
                if ([[UIApplication sharedApplication] canOpenURL:baidu_App]) {
                    // 如果集成的是百度地图就需要用bd09ll否则gcj02
                    weakSelf.gotoMapURL = [[NSString stringWithFormat:@"baidumap://map/direction?origin={{我的位置}}&destination=latlng:%@,%@|name:%@&coord_type=bd09ll&mode=driving&src=ios.blackfish.XHY",Latitude,Longitude,self.address] stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
                    
                }
            
        }else if([title isEqualToString:@"高德地图"])
        {
            NSURL * gaode_App = [NSURL URLWithString:@"iosamap://"];
                if ([[UIApplication sharedApplication] canOpenURL:gaode_App]) {
                    weakSelf.gotoMapURL = [[NSString stringWithFormat:@"iosamap://path?sourceApplication=ios.blackfish.XHY&dlat=%f&dlon=%f&dname=%@&style=2&dev=0",self.merchantLat.floatValue,self.merchantLng.floatValue,self.address] stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]]; //先出现地点位置，然后再手动点击导航
                }
        }else if([title isEqualToString:@"Apple地图"])
        {
            NSURL * apple_App = [NSURL URLWithString:@"http://maps.apple.com/"];
            if ([[UIApplication sharedApplication] canOpenURL:apple_App]) {
                
                MKMapItem *currentLocation = [MKMapItem mapItemForCurrentLocation];
                MKMapItem *tolocation = [[MKMapItem alloc] initWithPlacemark:[[MKPlacemark alloc] initWithCoordinate:originalLocation addressDictionary:nil]];
                tolocation.name = self.address;
                [MKMapItem openMapsWithItems:@[currentLocation,tolocation] launchOptions:@{MKLaunchOptionsDirectionsModeKey:MKLaunchOptionsDirectionsModeDriving,
                                                                                           MKLaunchOptionsShowsTrafficKey:[NSNumber numberWithBool:YES]}];
            }
        }else if([title isEqualToString:@"腾讯地图"])
        {
            NSURL * qq_App = [NSURL URLWithString:@"qqmap://"];
            if([[UIApplication sharedApplication] canOpenURL:qq_App]){
                
                NSString *urlString = [NSString stringWithFormat:@"qqmap://map/routeplan?type=drive&fromcoord=%f,%f&from=我的位置&referer=jikexiu",self.lat.floatValue, self.lng.floatValue];
                urlString = [NSString stringWithFormat:@"%@&tocoord=%f,%f&to=%@",urlString, self.merchantLat.floatValue, self.merchantLng.floatValue, self.address];
                
                self.gotoMapURL = [urlString stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
            }
        }
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:self.gotoMapURL] options:@{} completionHandler:nil];
    }];
}

- (void)callMerchantPhoneHandler
{
    //给商家打电话;
    NSMutableString *str = [[NSMutableString alloc] initWithFormat:@"telprompt://%@",self.merchantTel];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:str] options:@{} completionHandler:nil];
}

- (void)refreshHandler
{
    
    [ServiceManager getMerchantDetailWithMerchantId:self.merchantId items:self.items success:^(NSDictionary *data) {
        
        
        NSDictionary * dic = data[MERCHANT_DATA];
        NSString* merchantName = dic[MERCHANT_NAME];
        self.merchantName = merchantName;
        NSString* typeName = dic[TYPE_NAME];
        NSString* notice = dic[NOTICE];
        
        NSString * merchantDesc = dic[MERCHANT_DESC];
        NSString * address = dic[ADDRESS];
        NSString * payText = dic[PAY_TEXT];
        NSArray * albums = dic[ALBUMS];
        self.albums = albums;
        NSString * businessTime = dic[BUSINESS_TIME];
        NSArray * slideshow = dic[SLIDES_SHOW];
        
        NSArray * items = dic[ITEMS];
        NSArray * service = dic[SERVICE];
        
        NSString * tel = dic[TELEPHONE];
        
        NSString * latitude = dic[LATITUDE];
        NSString * longitude = dic[LONGITUDE];
        NSString * typeLogo = dic[TYPE_LOGO];
        
        NSDictionary * brandInfo = dic[BRAND_INFO];
        
        NSNumber * capita = dic[CAPITA];//人均消费;
        
        NSString * logo = dic[IMG];
        
        if(!logo || logo.length == 0)
        {
            logo = dic[BRAND_LOGO];
            
            if(!logo || logo.length == 0)
            {
                logo = @"ic_default_merchant_detail_logo";
            }
        }
        
        if([Utils checkObjectIsNull:brandInfo])
        {
            self.brandInfo = brandInfo;
            
            if([Utils checkObjectIsNull:notice] == false || notice.length == 0)
            {
                notice = brandInfo[BRAND_NOTICE];
            }
        }
        
        self.notice = notice;
        if([Utils checkObjectIsNull:items])
        {
            self.useItems = items;
        }
        
        if([Utils checkObjectIsNull:service])
        {
            self.service = service;
        }
        
        if([Utils checkObjectIsNull:slideshow] == false || slideshow.count == 0)
        {
            slideshow = @[logo];
            self.header.photoButton.hidden = true;
            self.header.pageLabel.hidden = true;
        }else{
            self.header.photoButton.hidden = false;
            self.header.pageLabel.hidden = false;
        }
        
        if(capita.integerValue > 0)
        {
            self.header.oneCostLabel.text = [NSString stringWithFormat:@"人均消费￥%.0lf/人",capita.floatValue];
        }else{
            self.header.oneCostLabel.text = @"";
        }
        
        self.dataSource = @[@{TYPE:NORMAL_CELL,NAME:@"可用福利",IMG:@"ic_canuse_gift",IS_QR_CODE:@0},
                            @{TYPE:NORMAL_CELL,NAME:@"商户服务",IMG:@"ic_merchant_service",IS_QR_CODE:@0},
                            @{TYPE:NORMAL_CELL,NAME:@"门店扫码",IMG:@"ic_goto_qrcode",IS_QR_CODE:@1,PAY_TEXT:payText},
                            @{TYPE:COLLECTION_CELL},
                            @{TYPE:DESC_CELL,CONTENT:merchantDesc}];
        
        [self.broadcastView updateTableViewCellWithData:@[@{TITLE:notice},@{TITLE:notice}]];
        self.merchantTel = tel;
        
        self.merchantLat = latitude;
        self.merchantLng = longitude;
        
        self.header.merchantNameLabel.text = merchantName;
        self.address = address;
        self.header.addressLabel.text = [NSString stringWithFormat:@"门店地址：%@",address];
        self.header.openTimeLabel.text = businessTime;
        CGFloat headerHeight = 0.0f;
        if([Utils checkObjectIsNull:slideshow])
        {
            headerHeight = 412;
            
            self.header.scrollView.imageURLStringsGroup = slideshow;
            self.header.pageLabel.text = [NSString stringWithFormat:@"1/%ld",slideshow.count];
            WS(weakSelf);
            self.header.tapImageWithIndex = ^(NSInteger index) {
                [weakSelf tapImageWithIndex:index];
            };
            
            for(NSString * url in slideshow)
            {
                UIImageView * imageView = [[UIImageView alloc] init];
                
                imageView.center = CGPointMake(SCREEN_WIDTH * 0.5, SCREEN_HEIGHT * 0.5);
                
                [Utils loadImage:imageView andURL:url isLoadRepeat:false];
                
                [self.imageViews addObject:imageView];
                
                [self.view addSubview:imageView];
            }
            
        }else{
            //隐藏banner;
            headerHeight = 212;
            
            self.header.topDistance.constant = 20;
            
            self.header.bannerImageContainer.hidden = true;
        }
        
        if(!notice || notice.length == 0)
        {
            //如果没有广播还要在减去45高度;
            headerHeight -= 45;
            
            self.header.noticeHeight.constant = 0.0f;
            self.header.noticeTopDistance.constant = 0.0f;
            self.header.broadcastContainer.hidden = true;
        }else{
            self.header.noticeHeight.constant = 30.0f;
            self.header.noticeTopDistance.constant = 15.0f;
            self.header.broadcastContainer.hidden = false;
        }
        
        UIView * headerContainer = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, headerHeight)];
        
        headerContainer.backgroundColor = [UIColor whiteColor];
        
        self.header.frame = headerContainer.bounds;
        
        [headerContainer addSubview:self.header];
        
        self.listTableView.tableHeaderView = headerContainer;
        
        [SharedInstance getInstance].isGetedWebHeight = false;
        
        if(typeLogo.length == 0)
        {
            self.header.flagImageView.hidden = true;
            self.header.typeLabelLeft.constant = 10;
        }else{
            [Utils loadImage:self.header.flagImageView andURL:typeLogo isLoadRepeat:false];
            self.header.flagImageView.hidden = false;
            self.header.typeLabelLeft.constant = 29;
        }
        
        
        
        self.header.typeLabel.text = typeName;
        
        [self.listTableView reloadData];
        
    }];
}

- (void)tapBroadcastWithIndex:(NSInteger)index
{
    UniversalPopView * popView = (UniversalPopView*)[Utils getXibByName:@"UniversalPopView"];
    
    popView.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
    
    popView.contentDesc = self.notice;
    
    [popView fadeIn];
    
    [[Utils currentWindow] addSubview:popView];
}

- (void)viewWillLayoutSubviews
{
    [super viewWillLayoutSubviews];
    
    self.broadcastView.frame = self.header.broadcastContainer.bounds;
    
    [self.header.broadcastContainer addSubview:self.broadcastView];
}

-(void)gotoMerchantPhotoHandler
{
    MerchantPhotoViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_MERCHAT andIdentifier:@"MerchantPhotoViewController"];
    
    if(![Utils checkObjectIsNull:self.albums])
    {
        self.albums = @[];
    }
    vc.albums = self.albums;
    [self.navigationController pushViewController:vc animated:true];
}

#pragma mark -- UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSDictionary * dic = self.dataSource[indexPath.row];
    
    NSString * type = dic[TYPE];
    
    if([type isEqualToString:NORMAL_CELL])
    {
        MerchantDetailCell * cell = [tableView dequeueReusableCellWithIdentifier:@"MerchantDetailCell"];
        
        if(!cell)
        {
            cell = (MerchantDetailCell*)[Utils getXibByName:@"MerchantDetailCell"];
        }
        
        NSString * img = dic[IMG];
        NSString * name = dic[NAME];
        NSString * payText = dic[PAY_TEXT];
        NSNumber * isQrCode = dic[IS_QR_CODE];
        cell.iconImageView.image = [UIImage imageNamed:img];
        cell.contentNameLabel.text = name;
        
        if([name isEqualToString:@"可用福利"])
        {
            cell.labelColor = [Utils getMainColor];
            cell.labelBackgroundColor = [UIColor colorWithHexString:@"#FDA23F" alpha:0.2];
            cell.items = self.useItems;
        }
        
        if([name isEqualToString:@"商户服务"])
        {
            cell.labelColor = UIColorFromRGB(0X999999);
            cell.labelBackgroundColor = [UIColor colorWithHexString:@"#F5F5F5" alpha:1];
            cell.items = self.service;
        }
        
        if(isQrCode.boolValue)
        {
            cell.gotoScanCodeButtonView.hidden = false;
            cell.itemNameView.hidden = true;
            cell.payTextLabel.text = payText;
        }
        
        return  cell;
    }else if([type isEqualToString:COLLECTION_CELL])
    {
        MerchantDetailCollectionCell * cell = [tableView dequeueReusableCellWithIdentifier:@"MerchantDetailCollectionCell"];
        
        if(!cell)
        {
            cell = (MerchantDetailCollectionCell*)[Utils getXibByName:@"MerchantDetailCollectionCell"];
        }
        
        WS(weakSelf);
        cell.tapMerchantDetailCollectionWithIndexHandler = ^(NSInteger index) {
            [weakSelf tapCollectionWithIndexHandler:index];
        };
        
        if(!self.brandInfo)
        {
            cell.merchantView.hidden = true;
        }else{
            NSNumber * merchantCount = self.brandInfo[MERCHANT_COUNT];
            
            cell.merchantCountLabel.text = [NSString stringWithFormat:@"%ld家",merchantCount.integerValue];
        }
        
        NSLog(@"%@",self.brandInfo);
    
        
        return cell;
    }else if([type isEqualToString:DESC_CELL])
    {
        MerchantDetailDescCell * cell = [tableView dequeueReusableCellWithIdentifier:@"MerchantDetailDescCell"];
        
        if(!cell)
        {
            cell = (MerchantDetailDescCell*)[Utils getXibByName:@"MerchantDetailDescCell"];
        }
        
        NSString * content = dic[CONTENT];
        
        //cell.contentLabel.text = content;
        
        [cell setContentWithHtmlString:content];
        WS(weakSelf);
        cell.refreshMerchantDetailMainTableViewHandler = ^{
            [weakSelf.listTableView reloadData];//获取到webview内容高度刷新整个list
        };
        
        return cell;
    }
    
    
    return [UITableViewCell new];
}

- (void)tapCollectionWithIndexHandler:(NSInteger)index
{
    if(index == 0)
    {
        //全部门店
        MerchantBrandViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_MERCHAT andIdentifier:@"MerchantBrandViewController"];
        
        vc.brandIndex = self.brandInfo[BRAND_INDEX];
        
        vc.merchantName = self.brandInfo[BRAND_NAME];
        
        vc.merchantDesc = self.brandInfo[BRAND_INTRODUCTION];
        
        vc.merchantCount = self.brandInfo[MERCHANT_COUNT];
        
        vc.brandLogo = self.brandInfo[BRAND_LOGO];
        
        vc.preLat = self.lat;
        vc.preLng = self.lng;
        
        vc.preCityName = self.cityName;
        
        vc.blackWhiteId = self.blackWhiteId;
        vc.blackWhiteIdList = self.blackWhiteIdList;
        
        
        [self.navigationController pushViewController:vc animated:true];
        
    }else if(index == 1)
    {
        //在线客服;
        [self showConnectCustomerHandler];
    }else if(index == 2){
        //意见反馈;
        QuestionBackViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_MERCHAT andIdentifier:@"QuestionBackViewController"];
        
        vc.merchantId = self.merchantId;
        
        [self.navigationController pushViewController:vc animated:YES];
    }
}

- (void)showConnectCustomerHandler
{
    //联系客服
    [Utils setDefaultNavigationBar:self];
    [IQKeyboardManager sharedManager].enable = false;
    [Utils setQiYuInfo];
    
    QYSource *source = [[QYSource alloc] init];
    
    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
    NSString *app_Version = [infoDictionary objectForKey:@"CFBundleShortVersionString"];
    NSString * sendTitle = [NSString stringWithFormat:@"设备:iOS;应用名称:蜀光惠;版本号:%@;%@",app_Version,[NSString stringWithFormat:@"蜀光惠-商户详情-%@",self.merchantName]];

    source.title = sendTitle;
    source.urlString = @"";
    QYSessionViewController *sessionViewController = [[QYSDK sharedSDK] sessionViewController];
    sessionViewController.robotWelcomeTemplateId = 6655338;
    sessionViewController.robotId = 5401983;
//    sessionViewController.groupId = 1070381;
    sessionViewController.openRobotInShuntMode = NO;
    sessionViewController.commonQuestionTemplateId = 4494027;
    sessionViewController.sessionTitle = @"蜀光惠客服";
    sessionViewController.source = source;
    dispatch_async(dispatch_get_main_queue(), ^{
        
        [self.navigationController pushViewController:sessionViewController animated:true];
    });
    
    UIBarButtonItem * leftBackButton = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"ic_title_back"] style:UIBarButtonItemStylePlain target:self action:@selector(onBack:)];
    leftBackButton.tintColor = [UIColor blackColor];
    sessionViewController.navigationItem.leftBarButtonItem = leftBackButton;
}

- (void)onBack:(id)sender{

    [IQKeyboardManager sharedManager].enable = true;
    [self.navigationController popViewControllerAnimated:true];
}

#pragma mark -- UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary * dic = self.dataSource[indexPath.row];
    
    NSString * type = dic[TYPE];
    
    if([type isEqualToString:NORMAL_CELL])
    {
        if(indexPath.row == 0)
        {
            //可用福利;
            
            ShowItemPopView * popView = (ShowItemPopView*)[Utils getXibByName:@"ShowItemPopView"];
            
            popView.dataSource = self.useItems;
            
            popView.frame = CGRectMake(0, 0, SCREEN_WIDTH ,SCREEN_HEIGHT);
            
            [popView fadeIn];
            
            [[Utils currentWindow] addSubview:popView];
            
        }else if(indexPath.row == 1)
        {
            //商户服务;
            
            ShowItemPopView * popView = (ShowItemPopView*)[Utils getXibByName:@"ShowItemPopView"];
            
            popView.titleLabel.text = @"商户服务";
            
            popView.dataSource = self.service;
            
            popView.frame = CGRectMake(0, 0, SCREEN_WIDTH ,SCREEN_HEIGHT);
            
            popView.itemBgColor = UIColorFromRGB(0xF5F5F5);
            
            popView.itemLabelColor = UIColorFromRGB(0x999999);
            
            [popView fadeIn];
            
            [[Utils currentWindow] addSubview:popView];
            
            
        }else if(indexPath.row == 2)
        {
            //门店扫码;
            [self gotoScanCodeHandler];
        }
    }
}

- (void)gotoScanCodeHandler
{
    if([SharedInstance getInstance].payPasswordEmpty ==  0)
    {
        WPPaymentPasswordVC *vc = (WPPaymentPasswordVC *)[Utils getViewControllerByStoryBoardName:SB_NAME_ME andIdentifier:SB_ID_PAY_MENT_PASS_WORD];
        vc.ppType = WPPaymentPasswordTypeInitPassword;
        vc.enterType = @1;
        vc.delegate = self;
        [self.navigationController pushViewController:vc animated:YES];
        
        return;
    }
    
    [self scanCodeVCPush];
}

-(void)scanCodeVCPush{
    
    [SharedInstance getInstance].userSetScreenBrightness = [[UIScreen mainScreen] brightness];
    
    ScanCodeViewController * vc = [Utils getViewControllerByStoryBoardName:SCAN_CODE andIdentifier:SB_ID_SCAN_CODE_VC];
   
    vc.isPresent = true;
    WPNavigationController *navVC = [[WPNavigationController alloc]initWithRootViewController:vc];

    [self presentViewController:navVC animated:true completion:nil];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary * dic = self.dataSource[indexPath.row];
    
    NSString * type = dic[TYPE];
    NSString * title = dic[NAME];
    
    if([type isEqualToString:NORMAL_CELL])
    {
        if([title isEqualToString:@"可用福利"] && self.useItems == nil)
        {
            return 0.0f;
        }
        if([title isEqualToString:@"商户服务"] && self.service == nil)
        {
            return 0.0f;
        }
        
        return 60.0f;
    }else if([type isEqualToString:COLLECTION_CELL])
    {
        if(self.brandInfo)
        {
            return 160.0f;
        }else{
            return 112.0f;
        }
        
    }else if([type isEqualToString:DESC_CELL])
    {
        return [MerchantDetailDescCell getCellHeight];
        
    }
    return 0;
}


- (IBAction)backAndPopHandler:(UIBarButtonItem *)sender {
    [self.navigationController popViewControllerAnimated:true];
}

- (void)dealloc
{
    [SharedInstance getInstance].isGetedWebHeight = false;
}

#pragma mark -- WPPaymentPasswordVCDelegate

- (void)paymentPasswordVerifypwd:(NSString *)pwd
{
    [self scanCodeVCPush];
}

- (void)tapImageWithIndex:(NSInteger)index
{
    _previewView.pageNum = self.imageViews.count;
//    _previewView.scrollView.scrollEnabled = false;
  
    _previewView.scrollView.contentSize = CGSizeMake(_previewView.frame.size.width*self.imageViews.count, _previewView.frame.size.height);
    
    [[Utils currentWindow] addSubview:self.previewView];
    [_previewView.scrollView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    [[Utils currentWindow] bringSubviewToFront:_previewView];
    
    // 添加子视图
    NSInteger count = self.imageViews.count;
    CGRect convertRect;
    if(count == 1)
    {
        [_previewView.pageControl removeFromSuperview];
    }
    for (NSInteger i = 0; i < count; i ++)
    {
        // 转换Frame
        UIImageView *pImageView = self.imageViews[i];
        
        convertRect = [[pImageView superview] convertRect:pImageView.frame toView:[Utils currentWindow]];
        // 添加
        MMScrollView *scrollView = [[MMScrollView alloc] initWithFrame:CGRectMake(i*_previewView.frame.size.width, 0, _previewView.frame.size.width, _previewView.frame.size.height)];
        scrollView.tag = 100+i;
        scrollView.maximumZoomScale = 2.0;
        scrollView.image = pImageView.image;
        scrollView.contentRect = convertRect;
        // 单击
        [scrollView setTapBigView:^(MMScrollView *scrollView){
            [self singleTapBigViewCallback:scrollView];
        }];
        // 长按
        [scrollView setLongPressBigView:^(MMScrollView *scrollView){
            [self longPresssBigViewCallback:scrollView];
        }];
        [_previewView.scrollView addSubview:scrollView];
        if (i == index) {
            [UIView animateWithDuration:0.3 animations:^{
                self.previewView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.6];
                self.previewView.pageControl.hidden = NO;
                [scrollView updateOriginRect];
            }];
        } else {
            [scrollView updateOriginRect];
        }
    }
    // 更新offset
    CGPoint offset = _previewView.scrollView.contentOffset;
    offset.x = index * SCREEN_WIDTH;
    _previewView.scrollView.contentOffset = offset;
}
#pragma mark - 大图单击||长按
- (void)singleTapBigViewCallback:(MMScrollView *)scrollView
{
   
    [UIView animateWithDuration:0.3 animations:^{
        self.previewView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0];
        self.previewView.pageControl.hidden = YES;
        scrollView.contentRect = scrollView.contentRect;
        scrollView.zoomScale = 1.0;
    } completion:^(BOOL finished) {
        [self.previewView removeFromSuperview];
    }];
}

- (void)longPresssBigViewCallback:(MMScrollView *)scrollView
{
    
}

@end
