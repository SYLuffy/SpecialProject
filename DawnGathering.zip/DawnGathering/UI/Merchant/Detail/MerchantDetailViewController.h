//
//  MerchantDetailViewController.h
//  DawnGathering
//
//  Created by 李冬岐 on 2024/1/12.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MerchantDetailViewController : UIViewController

@property (nonatomic,strong)NSNumber * merchantId;
@property (nonatomic,strong)NSArray * items;

@property (nonatomic,strong)NSString * merchantTitle;

@property (nonatomic,strong)NSString * cityName;
@property (nonatomic,strong)NSNumber * lat;
@property (nonatomic,strong)NSNumber * lng;

@property (nonatomic,strong)NSNumber * distance;
@property (nonatomic,strong)NSNumber * blackWhiteId;
@property (nonatomic,strong)NSArray * blackWhiteIdList;
@end

NS_ASSUME_NONNULL_END
