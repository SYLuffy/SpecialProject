//
//  QuestionBackViewController.m
//  DawnGathering
//
//  Created by 李冬岐 on 2024/1/15.
//

#import "QuestionBackViewController.h"
#import "QuestionBackCell.h"
#import "QuestionBackFooter.h"
#import <UITextView+ZWPlaceHolder.h>

#define NORMAL_CELL @"NORMAL_CELL"


@interface QuestionBackViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UITableView *listTableView;

@property (nonatomic,strong)NSArray * dataSrouce;

@property (nonatomic,strong)NSString * selectContent;

@property (nonatomic,strong)QuestionBackFooter * footerView;
@end

@implementation QuestionBackViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.listTableView.dataSource = self;
    self.listTableView.delegate = self;
    
    
    self.selectContent = @"门店名称有误";
    self.listTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    UIView * footer = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 264)];
    
    self.footerView = (QuestionBackFooter*)[Utils getXibByName:@"QuestionBackFooter"];
    
    self.footerView.frame = footer.bounds;
    
    WS(weakSelf);
    self.footerView.tapSendQuestionHandler = ^{
        [weakSelf sendQuestionHandler];
    };
    
    [footer addSubview:self.footerView];
    
    self.listTableView.tableFooterView = footer;
    
    self.listTableView.tableFooterView.backgroundColor = [UIColor clearColor];
    
    self.dataSrouce = @[];
    
    
    
    self.selectContent = self.dataSrouce.firstObject[CONTENT];
    
    self.footerView.inputText.text = self.selectContent;
    
    
    
    [self refreshHandler];
}

- (void)refreshHandler
{
    [ServiceManager getMerchantQuestionBackListWithMerhcantId:self.merchantId success:^(NSDictionary *data) {
    
        NSArray * correction = data[CORRECTION];
    
        self.dataSrouce = correction;
    
        NSString * value = self.dataSrouce.firstObject;
        
        self.selectContent = value;
        
        self.footerView.inputText.text = self.selectContent;
        
        [self.footerView.inputText.delegate textViewDidChange:self.footerView.inputText];
        
        [self.listTableView reloadData];
        
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:0];
        [self.listTableView selectRowAtIndexPath:indexPath animated:NO scrollPosition:UITableViewScrollPositionNone];
        
    }];
}

- (void)sendQuestionHandler
{
    if(self.footerView.inputText.text.length == 0)
    {
        [Utils showToast:@"请描述遇到的问题！"];
        return;
    }
    
    [ServiceManager setMerchantQuestionBackWithMerhcantId:self.merchantId content:self.footerView.inputText.text success:^(NSDictionary *data) {
        
        [Utils showToast:@"发送成功感谢您的反馈!"];
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.6 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            
            [self.navigationController popViewControllerAnimated:true];
            
        });
        
        
    }];
}
- (IBAction)backAndPopHandler:(UIBarButtonItem *)sender {
    
    [self.navigationController popViewControllerAnimated:true];
}

#pragma mark -- UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataSrouce.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString * value = self.dataSrouce[indexPath.row];
   
    QuestionBackCell * cell = [tableView dequeueReusableCellWithIdentifier:@"QuestionBackCell"];
    if(!cell)
    {
        cell = (QuestionBackCell*)[Utils getXibByName:@"QuestionBackCell"];
    }
    
    if(indexPath.row == 0)
    {
        cell.isCornerRidausTop = true;
    }else if(indexPath.row == _dataSrouce.count - 1)
    {
        cell.isCornerRidausBottom = true;
    }
    NSString * content = value;
    
    cell.contentLabel.text = content;
    
    return cell;
    
}

#pragma mark -- UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString * value = self.dataSrouce[indexPath.row];
    
    self.selectContent = value;
    
    self.footerView.inputText.text = self.selectContent;
    
    [self.footerView.inputText.delegate textViewDidChange:self.footerView.inputText];

}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewAutomaticDimension;
}

@end
