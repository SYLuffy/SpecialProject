//
//  QuestionBackViewController.h
//  DawnGathering
//
//  Created by 李冬岐 on 2024/1/15.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface QuestionBackViewController : UIViewController

@property (nonatomic,strong)NSNumber * merchantId;

@end

NS_ASSUME_NONNULL_END
