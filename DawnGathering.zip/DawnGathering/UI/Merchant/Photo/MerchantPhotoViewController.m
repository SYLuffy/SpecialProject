//
//  MerchantPhotoViewController.m
//  DawnGathering
//
//  Created by 李冬岐 on 2024/1/12.
//

#import "MerchantPhotoViewController.h"
#import "ImageCollectionViewCell.h"
#import "MMImagePreviewView.h"

@interface MerchantPhotoViewController ()<UICollectionViewDelegate,UICollectionViewDataSource>
@property (strong, nonatomic) UICollectionView *collectionView;

@property (nonatomic,strong)NSArray * list;

@property (nonatomic, strong) MMImagePreviewView *previewView;

@property (nonatomic,strong) NSMutableArray <UIImageView*>* imageViews;

@end

@implementation MerchantPhotoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.previewView = [[MMImagePreviewView alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.imageViews = [NSMutableArray array];
    
    if(self.albums)
    {
        self.list = self.albums;
    }
    
    self.collectionView.userInteractionEnabled = YES;
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc]init];
    layout.scrollDirection = UICollectionViewScrollDirectionVertical;

    self.collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(7.5, 0, self.view.frame.size.width - 15, self.view.frame.size.height - [Utils getNavigationBarAndStatusBarHeight:self]) collectionViewLayout:layout];
    
   
    [self.collectionView registerNib:[UINib nibWithNibName:@"ImageCollectionViewCell" bundle:[NSBundle mainBundle]] forCellWithReuseIdentifier:@"ImageCollectionViewCell"];
    self.collectionView.delegate = self;
    self.collectionView.dataSource = self;
    self.collectionView.scrollEnabled = true;
    self.collectionView.showsHorizontalScrollIndicator = NO;
    
    [self.view addSubview:self.collectionView];
    
    
    [self.collectionView reloadData];
    
}
- (IBAction)backAndPopHandler:(UIBarButtonItem *)sender {
    
    [self.navigationController popViewControllerAnimated:true];
}

#pragma mark -- UICollectionViewDataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return [_list count];
}

- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    ImageCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"ImageCollectionViewCell" forIndexPath:indexPath];
    if (!cell) {
        cell = [ImageCollectionViewCell xibTableViewCell];
    }
    
    cell.contentImageView.layer.masksToBounds = true;
    cell.contentImageView.layer.cornerRadius = 10.0f;
    
    NSString * imageURL = self.list[indexPath.row];
    
    [self.imageViews addObject:cell.contentImageView];
    
    [Utils loadImage:cell.contentImageView andURL:imageURL  isLoadRepeat:true];
    
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    [self tapImageWithIndex:indexPath.row];
}

#pragma mark -- UICollectionViewDelegateFlowLayout

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    CGFloat cellWidth = (SCREEN_WIDTH - 15) / 2;
    CGFloat cellHeight = 0.666 * cellWidth;
    
    return CGSizeMake(cellWidth,cellHeight);
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    
    return 0;
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return 0;
}
- (UIEdgeInsets) collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(0, 0, 0, 0);
}


- (void)tapImageWithIndex:(NSInteger)index
{
    _previewView.pageNum = self.imageViews.count;
    _previewView.scrollView.contentSize = CGSizeMake(_previewView.frame.size.width*self.imageViews.count, _previewView.frame.size.height);
    
    [[Utils currentWindow] addSubview:self.previewView];
    [_previewView.scrollView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    [[Utils currentWindow] bringSubviewToFront:_previewView];
    
    // 添加子视图
    NSInteger count = self.imageViews.count;
    CGRect convertRect;
    if (count == 1) {
        [_previewView.pageControl removeFromSuperview];
    }
    for (NSInteger i = 0; i < count; i ++)
    {
        // 转换Frame
        UIImageView *pImageView = self.imageViews[i];
        convertRect = [[pImageView superview] convertRect:pImageView.frame toView:[Utils currentWindow]];
        // 添加
        MMScrollView *scrollView = [[MMScrollView alloc] initWithFrame:CGRectMake(i*_previewView.frame.size.width, 0, _previewView.frame.size.width, _previewView.frame.size.height)];
        scrollView.tag = 100+i;
        scrollView.maximumZoomScale = 2.0;
        scrollView.image = pImageView.image;
        scrollView.contentRect = convertRect;
        // 单击
        [scrollView setTapBigView:^(MMScrollView *scrollView){
            [self singleTapBigViewCallback:scrollView];
        }];
        // 长按
        [scrollView setLongPressBigView:^(MMScrollView *scrollView){
            [self longPresssBigViewCallback:scrollView];
        }];
        [_previewView.scrollView addSubview:scrollView];
        if (i == index) {
            [UIView animateWithDuration:0.3 animations:^{
                self.previewView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.6];
                self.previewView.pageControl.hidden = NO;
                [scrollView updateOriginRect];
            }];
        } else {
            [scrollView updateOriginRect];
        }
    }
    // 更新offset
    CGPoint offset = _previewView.scrollView.contentOffset;
    offset.x = index * SCREEN_WIDTH;
    _previewView.scrollView.contentOffset = offset;
}
#pragma mark - 大图单击||长按
- (void)singleTapBigViewCallback:(MMScrollView *)scrollView
{
    [UIView animateWithDuration:0.3 animations:^{
        self.previewView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0];
        self.previewView.pageControl.hidden = YES;
        scrollView.contentRect = scrollView.contentRect;
        scrollView.zoomScale = 1.0;
    } completion:^(BOOL finished) {
        [self.previewView removeFromSuperview];
    }];
}

- (void)longPresssBigViewCallback:(MMScrollView *)scrollView
{
    
}

@end
