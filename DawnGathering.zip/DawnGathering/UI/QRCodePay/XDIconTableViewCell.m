//
//  XDIconTableViewCell.m
//  HLGA
//
//  Created by 谢丹 on 2020/9/9.
//  Copyright © 2020 Linus. All rights reserved.
//

#import "XDIconTableViewCell.h"

@implementation XDIconTableViewCell



@end
