//
//  WPScanSelectPayTableViewCell.h
//  HLGA
//
//  Created by 谢丹 on 2021/10/28.
//  Copyright © 2021 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WPDiscountModel.h"

typedef void(^ScanSelectPayType)(WPDiscountModel *model);

NS_ASSUME_NONNULL_BEGIN

@interface WPScanSelectPayTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *iconImageView;

@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *moneyLabel;

@property (weak, nonatomic) IBOutlet UIButton *selectButton;

@property (nonatomic,strong) ScanSelectPayType selectPayType;

- (void)configureDiscountsModel:(WPDiscountModel *)model;

@end

NS_ASSUME_NONNULL_END
