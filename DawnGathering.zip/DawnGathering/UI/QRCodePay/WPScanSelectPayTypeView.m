//
//  WPScanSelectPayTypeView.m
//  HLGA
//
//  Created by 谢丹 on 2021/10/28.
//  Copyright © 2021 Linus. All rights reserved.
//

#import "WPScanSelectPayTypeView.h"


@interface WPScanSelectPayTypeView ()<UIGestureRecognizerDelegate,UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) UITableView *tableView;
@property (nonatomic,strong) UIView *contentView;
@property (nonatomic,strong) NSString *account;

@end

@implementation WPScanSelectPayTypeView

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self setupUI];
    }
    return self;
}

-(instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self setupUI];
    }
    return  self;
}

- (void)setupUI{
    
    UITapGestureRecognizer *gesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismiss)];
    gesture.delegate = self;
    [self addGestureRecognizer:gesture];
    
    self.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
    self.backgroundColor = [UIColor colorWithHexString:@"000000" alpha:0];
    
    self.contentView = [[UIView alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT, SCREEN_WIDTH, 60 * [SharedInstance getInstance].userInfo.scanDiscounts.count + 60 + BottomEdge)];
    self.contentView.backgroundColor = [UIColor whiteColor];
    [self addSubview:self.contentView];
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 60)];
    titleLabel.text = @"选择付款账户";
    titleLabel.backgroundColor = [UIColor whiteColor];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.font = [UIFont boldSystemFontOfSize:16];
    [self.contentView addSubview:titleLabel];
    [self.contentView addSubview:self.tableView];
}

#pragma mark -UITableViewDelegate,UITableViewDataSource

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return [SharedInstance getInstance].userInfo.scanDiscounts.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    WPScanSelectPayTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"WPScanSelectPayTableViewCell"];
    WPDiscountModel *disCountModel = [SharedInstance getInstance].userInfo.scanDiscounts[indexPath.section];
    [cell configureDiscountsModel:disCountModel];
    if ([disCountModel.account isEqualToString:self.account]) {
        cell.selectButton.selected = YES;
    }else{
        cell.selectButton.selected = NO;
    }
    cell.selectPayType = ^(WPDiscountModel *model) {
        if (self.selectPayTypeClick) {
            self.selectPayTypeClick(model);
        }
        [self dismiss];
    };
    return cell;
}



- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer{
    if (CGRectContainsPoint(self.frame, [gestureRecognizer locationInView:self.contentView])) {
        return NO;
    }
    return YES;
}


#pragma mark - other methods

- (void)show{
    
    [[Utils getCurrentVC].navigationController.view addSubview:self];
  
    self.backgroundColor = [UIColor colorWithHexString:@"000000" alpha:0];
    self.contentView.backgroundColor = [UIColor colorWithHexString:@"ffffff" alpha:0];
    self.contentView.frame = CGRectMake(0, SCREEN_HEIGHT, self.contentView.frame.size.width, self.contentView.frame.size.height);
    [UIView animateWithDuration:0.3 delay:0 usingSpringWithDamping:0.8 initialSpringVelocity:1 options:UIViewAnimationOptionTransitionCurlUp animations:^{
        
        self.backgroundColor = [UIColor colorWithHexString:@"000000" alpha:0.35];
        self.contentView.backgroundColor = [UIColor colorWithHexString:@"ffffff" alpha:1];
        self.contentView.frame = CGRectMake(0, SCREEN_HEIGHT - self.contentView.frame.size.height, self.contentView.frame.size.width, self.contentView.frame.size.height);
    } completion:^(BOOL finished) {
        
    }];
}

- (void)dismiss{
    [UIView animateWithDuration:0.3 animations:^{
        self.backgroundColor = [UIColor colorWithHexString:@"000000" alpha:0];
        self.contentView.backgroundColor = [UIColor colorWithHexString:@"ffffff" alpha:0];
        self.contentView.frame = CGRectMake(0, SCREEN_HEIGHT, self.contentView.frame.size.width, self.contentView.frame.size.height);
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
    
}

-(void)setSelectItemByAccount:(NSString *)account{
    
    self.account = account;
    [self.tableView reloadData];
    
}

#pragma mark - setter

-(UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 60, SCREEN_WIDTH, self.contentView.frame.size.height - 60) style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.rowHeight = 60;
        _tableView.tableFooterView = [[UIView alloc] init];
//        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableView.backgroundColor = [UIColor colorWithHexString:@"FFFFFF"];
        [_tableView registerNib:[UINib nibWithNibName:@"WPScanSelectPayTableViewCell" bundle:nil] forCellReuseIdentifier:@"WPScanSelectPayTableViewCell"];
    }
    return _tableView;
}

@end
