//
//  ScanPayStatusViewController.m
//  CultureChengDu
//
//  Created by Linus on 2017/12/13.
//  Copyright © 2017年 Linus. All rights reserved.
//

#import "ScanPayStatusViewController.h"
#import "ScanPayResultCell.h"
#import "ScanCodeResultHeader.h"


@interface ScanPayStatusViewController ()<UITableViewDelegate,UITableViewDataSource>
{
    NSDictionary * scanPayDictionar;
}

@property (strong,nonatomic)NSDictionary * adDataSource;
@property (weak, nonatomic) IBOutlet UIButton *confirmButton;
@property (nonatomic,strong)NSArray * dataSource;
@property (weak, nonatomic) IBOutlet UITableView *listTableView;

@property (nonatomic,strong)NSString * addOrSubFlag;
@property (nonatomic,strong)ScanCodeResultHeader * header;

@end

@implementation ScanPayStatusViewController

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateSuccessHandler) name:EVENT_SCAN_PAY_SUCCESS object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateFaultHandler) name:EVENT_SCAN_PAY_FAULT object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateCancelHandler) name:EVENT_SCAN_PAY_CANCEL object:nil];
    [Utils setDefaultNavigationBar:self];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    
    self.listTableView.dataSource = self;
    self.listTableView.delegate = self;
    self.listTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    UIView * header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 210)];
    
    self.header = (ScanCodeResultHeader*)[Utils getXibByName:@"ScanCodeResultHeader"];
    
    self.header.frame = header.bounds;

    [header addSubview:self.header];
    
    self.listTableView.tableHeaderView = header;
    
    self.listTableView.tableFooterView = [[UIView alloc]init];
    
    NSLog(@"支付结果：%@",[SharedInstance getInstance].scanPayDictionary);
    scanPayDictionar = [SharedInstance getInstance].scanPayDictionary;
    [self.confirmButton gradualDefaultButton];
    
    NSNumber * state = scanPayDictionar[STATE];
    NSNumber * orderType = scanPayDictionar[ORDER_TYPE];
    if(orderType.integerValue == 0)
    {
        switch (state.integerValue) {
            case 0:
            {
                //支付成功
                self.addOrSubFlag = @"-";
                [self paySuccessInit];
            }
                break;
            case 1:
            {
                //支付失败
                self.addOrSubFlag = @"";
                [self payFaultInit];
            }
                break;
            default:
                self.addOrSubFlag = @"";
                break;
        }
    }else if(orderType.integerValue == 1){
        //撤销;
        self.addOrSubFlag = @"+";
        [self revocationInit];
    }
    
}

- (void)revocationInit{
    
    scanPayDictionar = [SharedInstance getInstance].scanPayDictionary;
    [self.confirmButton setTitle:@"完成" forState:UIControlStateNormal];
    NSString * errorMsg = scanPayDictionar[ERROR_MSG];
    NSNumber * state = scanPayDictionar[STATE];
    
    NSString * nilMessage;
    
    self.title = @"撤销结果";
    
    if(state.integerValue == 0)
    {
        self.header.payResultStatusLabel.text = @"撤销成功";
        self.header.payResultImageView.image = [UIImage imageNamed:@"pay_success_image"];
        nilMessage = @"";
        
    }else if(state.integerValue == 1){
        self.header.payResultStatusLabel.text = @"撤销失败";
        self.header.payResultImageView.image = [UIImage imageNamed:@"pay_failure_image"];
        nilMessage = @"请尝试再次撤销或联系客服";
    }
    if(errorMsg.length > 0){
        self.header.failureDescLabel.text = errorMsg;
    }else{
        self.header.failureDescLabel.text = nilMessage;
    }
    
    //NSString * serialNumber = scanPayDictionar[SERIAL_NUMBER];
    
    NSMutableArray *itemArray = scanPayDictionar[ITEMS];
    
    //[itemArray insertObject:@{ITEM_NAME:@"订单编号",CONTENT:serialNumber} atIndex:0];
    
    
    NSInteger totalAmount = 0;
    for(NSDictionary * dic in itemArray)
    {
        NSNumber * amount = dic[AMOUNT];
        
        totalAmount += amount.integerValue;
    }
    
    //使用红包金额;
    NSNumber * useRpAmount = scanPayDictionar[USE_RP_AMOUNT];
    
    NSNumber * rpAmount = scanPayDictionar[RP_AMOUNT];
    
    totalAmount += useRpAmount.integerValue;
    
    NSString * amountText = [NSString stringWithFormat:@"%.2lf",totalAmount * 0.01];

    [Utils setUintWithLabel:self.header.amountLabel andText:amountText fontSize:16];
    
    self.header.rpAmountLabel.textColor = UIColorFromRGB(0x666666);
    
    if(rpAmount.integerValue > 0)
    {
        self.header.rpView.hidden = false;
    }else{
        self.header.rpView.hidden = true;
    }
    self.header.rpAmountLabel.text = [NSString stringWithFormat:@"红包撤回：-%.2lf",rpAmount.floatValue * 0.01];
    
    if(useRpAmount.integerValue > 0)
    {
        [itemArray addObject:@{AMOUNT:useRpAmount,ITEM_NAME:@"红包返还"}];
    }
    
    self.dataSource = itemArray;
    
    [self.listTableView reloadData];
    
    
    
}

- (void)paySuccessInit{
    
    self.title = @"支付结果";
    
    self.header.failureDescLabel.hidden = true;

    [self.confirmButton setTitle:@"完成" forState:UIControlStateNormal];
    self.header.payResultImageView.image = [UIImage imageNamed:@"pay_success_image"];
    scanPayDictionar = [SharedInstance getInstance].scanPayDictionary;
    self.header.payResultStatusLabel.text = @"支付成功";
    //改动;
    
    //NSString * serialNumber = scanPayDictionar[SERIAL_NUMBER];
    NSMutableArray *itemArray = scanPayDictionar[ITEMS];
    //[itemArray insertObject:@{ITEM_NAME:@"订单编号",CONTENT:serialNumber} atIndex:0];
    
    NSInteger totalAmount = 0;
    for(NSDictionary * dic in itemArray)
    {
        NSNumber * amount = dic[AMOUNT];
        
        totalAmount += amount.integerValue;
    }
    //使用红包金额;
    NSNumber * useRpAmount = scanPayDictionar[USE_RP_AMOUNT];
    
    NSNumber * rpAmount = scanPayDictionar[RP_AMOUNT];
    
    totalAmount += useRpAmount.integerValue;
    
    NSString * amountText = [NSString stringWithFormat:@"%.2lf",totalAmount * 0.01];
    
    [Utils setUintWithLabel:self.header.amountLabel andText:amountText fontSize:16];
    
   
    
    if(rpAmount.integerValue > 0)
    {
        self.header.rpView.hidden = false;
        self.header.rpAmountLabel.text = [NSString stringWithFormat:@"获得红包：%.2lf",rpAmount.floatValue * 0.01];
    }else{
        self.header.rpView.hidden = true;
    }
    
    
    
    if(useRpAmount.integerValue > 0)
    {
        [itemArray addObject:@{AMOUNT:useRpAmount,ITEM_NAME:@"红包抵扣"}];
    }
    
    
    self.dataSource = itemArray;
    
    [self.listTableView reloadData];
    
    
}


- (void)payFaultInit{
    
    self.title = @"支付结果";
    
    self.header.amountLabel.hidden = true;
    self.header.rpView.hidden = true;
    self.header.failureDescLabel.hidden = false;
    
    self.header.payResultImageView.image = [UIImage imageNamed:@"pay_failure_image"];
    scanPayDictionar = [SharedInstance getInstance].scanPayDictionary;
    self.header.payResultStatusLabel.text = @"支付失败";

    [self.confirmButton setTitle:@"返回" forState:UIControlStateNormal];
    NSString * errorMsg = scanPayDictionar[ERROR_MSG];
    if(errorMsg.length > 0){
        self.header.failureDescLabel.text = [NSString stringWithFormat:@"失败原因：%@",errorMsg];
    }else{
        self.header.failureDescLabel.text = @"";
    }
}

- (void)updateFaultHandler{
    [self payFaultInit];
}

- (void)updateSuccessHandler{
    [self paySuccessInit];
}
- (void)updateCancelHandler{
    [self backPopHandler:nil];
}



- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:EVENT_SCAN_PAY_SUCCESS object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:EVENT_SCAN_PAY_FAULT object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:EVENT_SCAN_PAY_CANCEL object:nil];
}

- (IBAction)confirmHandler:(UIButton *)sender {
    
    [self backPopHandler:nil];
}

- (IBAction)backPopHandler:(UIBarButtonItem *)sender {
    
    if(self.isPresent)
    {
        [self dismissViewControllerAnimated:true completion:nil];
        if(self.keepSocket)
        {
            [self.keepSocket disconnect];
            self.keepSocket = nil;
        }
        return;
    }
    
    NSInteger orderType = [scanPayDictionar[ORDER_TYPE] integerValue];
    NSInteger state = [scanPayDictionar[STATE] integerValue];
    if (orderType == 0 && state == 0) {
        //支付成功
        [self backHome];
    }else{
        [self.navigationController popViewControllerAnimated:YES];
    }
    
    
}

- (void)backHome{
    
    if(self.keepSocket)
    {
        [self.keepSocket disconnect];
        self.keepSocket = nil;
    }
    
    WPMainBC *tabbar = (WPMainBC *)[Utils currentWindow].rootViewController;
    WPNavigationController *nav = tabbar.viewControllers[tabbar.selectedIndex];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"UpdateTabbarSelectIndex" object:self userInfo:@{@"selectIndex":@(0)}];
    tabbar.selectedIndex = 0;
    [nav popToRootViewControllerAnimated:NO];
    
}

#pragma mark -- UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;
{

    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ScanPayResultCell * cell = [tableView dequeueReusableCellWithIdentifier:@"ScanPayResultCell"];
    
    if(!cell)
    {
        cell = (ScanPayResultCell*)[Utils getXibByName:@"ScanPayResultCell"];
    
    }
    
    NSDictionary * dic = self.dataSource[indexPath.row];
    NSString * itemName = dic[ITEM_NAME];
    NSNumber * amount = dic[AMOUNT];
    NSString * content = dic[CONTENT];
    
    if([itemName isEqualToString:@"订单编号"])
    {
        cell.amountLabel.text = content;
    }else{
        
        if([itemName isEqualToString:@"红包抵扣"])
        {
            cell.amountLabel.textColor = UIColorFromRGB(0xFF462D);
        }
        
        cell.amountLabel.text = [NSString stringWithFormat:@"%@%.2lf",self.addOrSubFlag,amount.integerValue * 0.01];
    }
    
    cell.itemNameLabel.text = itemName;
    
    return cell;
}

#pragma mark -- UITableViewDelegate


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 55.0f;
}

@end
