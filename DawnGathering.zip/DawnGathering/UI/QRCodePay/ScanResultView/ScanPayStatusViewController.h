//
//  ScanPayStatusViewController.h
//  CultureChengDu
//
//  Created by Linus on 2017/12/13.
//  Copyright © 2017年 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GCDAsyncSocket.h"

@interface ScanPayStatusViewController : UIViewController

@property(nonatomic,strong)GCDAsyncSocket * keepSocket;
@property (nonatomic,strong)NSString *rpMsg;//积分红包显示消息

@property (nonatomic,assign)BOOL isPresent;

@end
