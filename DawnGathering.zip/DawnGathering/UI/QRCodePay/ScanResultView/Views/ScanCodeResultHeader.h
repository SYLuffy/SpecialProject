//
//  ScanCodeResultHeader.h
//  DawnGathering
//
//  Created by 李冬岐 on 2024/5/10.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ScanCodeResultHeader : UIView
@property (weak, nonatomic) IBOutlet UIImageView *payResultImageView;
@property (weak, nonatomic) IBOutlet UILabel *payResultStatusLabel;
@property (weak, nonatomic) IBOutlet UILabel *failureDescLabel;
@property (weak, nonatomic) IBOutlet UILabel *amountLabel;
@property (weak, nonatomic) IBOutlet UILabel *rpAmountLabel;
@property (weak, nonatomic) IBOutlet UIView *rpView;

@end

NS_ASSUME_NONNULL_END
