//
//  ScanCodeResultHeader.m
//  DawnGathering
//
//  Created by 李冬岐 on 2024/5/10.
//

#import "ScanCodeResultHeader.h"

@implementation ScanCodeResultHeader

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
