//
//  ScanPayResultCell.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/8/23.
//

#import "ScanPayResultCell.h"

@implementation ScanPayResultCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
