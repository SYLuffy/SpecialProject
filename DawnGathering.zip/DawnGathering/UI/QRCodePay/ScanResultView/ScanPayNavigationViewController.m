//
//  ScanPayNavigationViewController.m
//  CultureChengDu
//
//  Created by Linus on 2017/12/13.
//  Copyright © 2017年 Linus. All rights reserved.
//

#import "ScanPayNavigationViewController.h"

@interface ScanPayNavigationViewController ()

@end

@implementation ScanPayNavigationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
