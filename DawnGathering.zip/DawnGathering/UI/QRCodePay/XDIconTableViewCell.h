//
//  XDIconTableViewCell.h
//  HLGA
//
//  Created by 谢丹 on 2020/9/9.
//  Copyright © 2020 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface XDIconTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *selectIconImageView;
@property (weak, nonatomic) IBOutlet UIImageView *iconImageView;
@property (weak, nonatomic) IBOutlet UILabel *iconNameLabel;


@end

NS_ASSUME_NONNULL_END
