//
//  WPScanSelectPayTableViewCell.m
//  HLGA
//
//  Created by 谢丹 on 2021/10/28.
//  Copyright © 2021 Linus. All rights reserved.
//

#import "WPScanSelectPayTableViewCell.h"


@interface WPScanSelectPayTableViewCell ()

@property (nonatomic,strong)WPDiscountModel *model;

@end

@implementation WPScanSelectPayTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (IBAction)selectClick:(UIButton *)sender {
    
    if (self.selectPayType) {
        self.selectPayType(self.model);
    }
    
    
}


-(void)configureDiscountsModel:(WPDiscountModel *)model{
    
    self.model = model;
    
    if (model.itemId == 0) {
        self.iconImageView.image = [UIImage imageNamed:@"scan_icon_default"];
    }else{
        self.iconImageView.image = [UIImage imageNamed:@"scan_icon_discount"];
    }
    
    self.nameLabel.text = model.itemName;
    self.moneyLabel.text = [NSString stringWithFormat:@"余额：%.2f",model.amount /100.0];
    
}


@end
