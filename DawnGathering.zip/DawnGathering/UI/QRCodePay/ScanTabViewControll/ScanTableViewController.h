//
//  ScanTableViewController.h
//  CultureChengDu
//
//  Created by Linus on 2017/12/13.
//  Copyright © 2017年 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScanTableViewController : UITableViewController

typedef void(^SelectTableCell)(NSString *segueiDentifier);

@property(nonatomic,copy)SelectTableCell selectCell;

@end
