//
//  ScanTableViewController.m
//  CultureChengDu
//
//  Created by Linus on 2017/12/13.
//  Copyright © 2017年 Linus. All rights reserved.
//

#import "ScanTableViewController.h"

static NSArray const* sections;

@interface ScanTableViewController ()
{
    NSArray * images;
    BOOL notHaveMoney;
}
@property (weak, nonatomic) IBOutlet UILabel *balanceLabel;
@property (weak, nonatomic) IBOutlet UIButton *chargeButton;
@property (weak, nonatomic) IBOutlet UIImageView *hexinSelectedImage;
@property (weak, nonatomic) IBOutlet UIImageView *wechatSelectedImage;
@property (weak, nonatomic) IBOutlet UIImageView *alipaySelectedImage;

@property (weak, nonatomic) IBOutlet UITableViewCell *cellOne;
@property (weak, nonatomic) IBOutlet UITableViewCell *cellTwo;
@property (weak, nonatomic) IBOutlet UITableViewCell *cellThree;

@end

@implementation ScanTableViewController

+ (void)initialize{
    
    sections = @[@1];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    images = @[_hexinSelectedImage,_wechatSelectedImage,_alipaySelectedImage];
    self.tableView.tableHeaderView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 0, 0.1)];
    
    self.tableView.backgroundColor = [UIColor clearColor];
    
    self.tableView.scrollEnabled = false;
    
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    self.view.backgroundColor = [UIColor clearColor];
    
    self.cellOne.backgroundColor = [UIColor clearColor];
    self.cellTwo.backgroundColor = [UIColor clearColor];
    self.cellThree.backgroundColor = [UIColor clearColor];
    
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    for(NSInteger i = 0;i < images.count;i ++)
    {
        UIImageView * image = images[i];
        [image setHidden:true];
    }
    
    UIImageView * selectedImage = images[0];
    [selectedImage setHidden:false];
}
- (IBAction)gotoChargeHandler:(UIButton *)sender {
    
    //去充值
//    UIViewController * vc = [Utils getViewControllerByStoryBoardName:MINE andIdentifier:CHARGE_VC];
//
//    UINavigationController *navVC = [[UINavigationController alloc]initWithRootViewController:vc];
//
//    [self presentViewController:navVC animated:true completion:nil];
}

#pragma mark - Table view data source

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if(indexPath.row == 0)
    {
        //和信通
        
//        if(notHaveMoney == true)
//        {
//            return;
//        }
        
        self.selectCell(SELECTED_HEXIN);
        
    }else if(indexPath.row == 1)
    {
        //微信
        self.selectCell(SELECTED_WECHAT);
    }else if(indexPath.row == 2)
    {
        //支付宝
        self.selectCell(SELECTED_ALIPAY);
    }
    
    for(NSInteger i = 0;i < images.count;i ++)
    {
        UIImageView * image = images[i];
        [image setHidden:true];
    }
    
    UIImageView * selectedImage = images[indexPath.row];
    [selectedImage setHidden:false];
    
    
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 64;
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return sections.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSNumber * number = sections[section];
    NSInteger num = number.integerValue;
    return num;
}

@end
