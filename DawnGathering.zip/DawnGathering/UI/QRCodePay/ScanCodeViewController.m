//
//  ScanCodeViewController.m
//  CultureChengDu
//
//  Created by Linus on 2017/12/12.
//  Copyright © 2017年 Linus. All rights reserved.
//

#import "ScanCodeViewController.h"
#import "GCDAsyncSocket.h"
#import "Models.h"
#import "SCManager.h"
#import "ScanTableViewController.h"
#import <AlipaySDK/AlipaySDK.h>
#import "UIImage+tools.h"
#import "ScanPayStatusViewController.h"
#import "UIView+WPRadius.h"
#import "WPScanSelectPayTypeView.h"
#import "WPPaymentPasswordVC.h"

@interface ScanCodeViewController ()<GCDAsyncSocketDelegate>
{
    
    BOOL notHaveMoney;
    __block int timeout; //倒计时时间
    dispatch_source_t _timer;
    BOOL isContent;
    BOOL isPaying;
    NSString * currentQrString;
    __weak IBOutlet NSLayoutConstraint *bottomLineDistance;
    __weak IBOutlet NSLayoutConstraint *topWhiteDistance;
    __weak IBOutlet NSLayoutConstraint *bottomUpdateDistance;
    __weak IBOutlet NSLayoutConstraint *bottomLogoDistance;
    __weak IBOutlet NSLayoutConstraint *bottomDescDistance;
    __weak IBOutlet NSLayoutConstraint *topQrCodeImageDistance;
    __weak IBOutlet NSLayoutConstraint *topCode128ImageDistance;
}

@property (nonatomic,strong) GCDAsyncSocket *clinetSocket;
@property (weak, nonatomic) IBOutlet UIImageView *qrCodeImage;
@property (weak, nonatomic) IBOutlet UIImageView *code128BarImage;
@property (weak, nonatomic) IBOutlet UILabel *codeNumberLabel;

@property (nonatomic,strong)NSString * orderNO;

@property (weak, nonatomic) IBOutlet UIView *topBackgroundView;
@property (weak, nonatomic) IBOutlet UIView *dashLineView;

@property (nonatomic,strong)NSNumber * payType;

@end

@implementation ScanCodeViewController


- (instancetype)initWithCoder:(NSCoder *)coder
{
    self = [super initWithCoder:coder];
    if (self) {
        isContent = false;
    }
    return self;
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [self.navigationController setNavigationBarHidden:NO animated:animated];
    [[UIScreen mainScreen] setBrightness:0.9];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateBrightHandler:) name:EVENT_OPEN_OR_CLOSE_BRIGHT object:nil];

    [Utils setClearNavigationBar:self titleColor:[UIColor whiteColor]];
    
    isPaying = false;

    
    //只能是和信通
    self.payType = @0;
    
    if(isContent ==  true){
        //返回界面刷新一次二维码;
        [self getQrCodeData:self.payType];
    }
    [self getUserInfo];
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:EVENT_OPEN_OR_CLOSE_BRIGHT object:nil];
    [[UIScreen mainScreen] setBrightness:[SharedInstance getInstance].userSetScreenBrightness];
    
//    self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
//    [self.navigationController.navigationBar setTranslucent:false];
//    self.navigationController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName:[UIColor blackColor]};
//    self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    

    [self stopTimer];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.clinetSocket = [[GCDAsyncSocket alloc] initWithDelegate:self delegateQueue:dispatch_get_main_queue()];
    [self.clinetSocket connectToHost:[Utils getNOCardPayHost] onPort:[Utils getNOCardPort] withTimeout:-1 error:nil];
    self.qrCodeImage.userInteractionEnabled = true;
    self.code128BarImage.userInteractionEnabled = true;
    
    UITapGestureRecognizer * tapGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(showBigQrCodeHandler:)];
    [self.qrCodeImage addGestureRecognizer:tapGesture];
    
    UITapGestureRecognizer * tapCode128BarGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(showBigCode128BarHandler:)];
    [self.code128BarImage addGestureRecognizer:tapCode128BarGesture];
    
    if([Utils iPhoneFiveCheck]){
        //判断是否是iPhone5适配;
        topWhiteDistance.constant = 5;
        bottomUpdateDistance.constant = 10;
    }
    topCode128ImageDistance.constant = SCREEN_HEIGHT * 0.1754;
    topQrCodeImageDistance.constant = SCREEN_HEIGHT * 0.309;
    
    if(self.isPresent)
    {
        UIScreenEdgePanGestureRecognizer * edgeGes = [[UIScreenEdgePanGestureRecognizer alloc] initWithTarget:self action:@selector(leftSliderHandler:)];
        edgeGes.edges = UIRectEdgeLeft;
        [self.view addGestureRecognizer:edgeGes];
    }

}

- (void)leftSliderHandler:(UIPanGestureRecognizer*)gesture
{
    [self dismissViewControllerAnimated:true completion:nil];
}

- (void)viewWillLayoutSubviews{
    [super viewWillLayoutSubviews];
    
    [Utils cornerRadiusTopLRWithView:self.topBackgroundView withRadius:10];
    
    [Utils drawDashLine:self.dashLineView lineLength:4 lineSpacing:4 lineColor:[Utils getMainColor]];
}

- (void)showVertifyPassword
{   WS(weakSelf);
    [[SharedInstance getInstance] showPayPopViewWithContent:@"请输入支付密码" amount:@(0) :^(NSString *pwd) {
        [weakSelf verifypwd:pwd];
    } retryInput:^{
        
        [weakSelf showVertifyPassword];
    }];
    
}


- (void)getUserInfo{
    //判断自动登录
    NSString *sid = [Utils getUserDefaultByKey:SID];
    if (sid.length != 0) {
        [ServiceManager getUserInformationBySid:sid successBack:^(NSDictionary *data) {
            NSDictionary * result = data[DATA];
            
            UserInfo * userInfo = [[UserInfo alloc] initByDictionary:result];
            [BuglyManager setPhoneNum:userInfo.telephone];
            [SharedInstance getInstance].userInfo = userInfo;
            [SharedInstance getInstance].sid = userInfo.sid;
            [Utils setUserDefaultByKey:SID andValue:userInfo.sid];
        
        } failure:^(NSError *error) {
          
        }];
    }
}


#pragma mark - GCDAsynSocket Delegate
- (void)socket:(GCDAsyncSocket *)sock didConnectToHost:(NSString *)host port:(uint16_t)port{

    NSLog(@"链接成功 host:%@",host);
    [self.clinetSocket readDataWithTimeout:-1 tag:0];
    [self autoLogin];
    
}

//收到消息
- (void)socket:(GCDAsyncSocket *)sock didReadData:(NSData *)data withTag:(long)tag{
    
    [self didReadData:data];
}

-(void) didReadData:(NSData *)data {
    
    //将接收到的数据保存到缓存数据中
    ScCmd * sc_one = [ScCmd new];
    [[SCManager getInstance] resultSpliceAttribute:data andObj:sc_one];
    [self handleTcpResponseData:sc_one];//处理包数据
    [self.clinetSocket readDataWithTimeout:-1 tag:0];//socket读取数据
}

- (void)handleTcpResponseData:(ScCmd*)data{
    
    switch (data.cmd) {
        case 101:
            NSLog(@"登陆成功");
            isContent = true;
            [self getQrCodeData:self.payType];
            break;
        case 102:
        {
            NSDictionary * qrDic = [Utils dictionaryWithJsonString:data.content];
            NSString * qrString = qrDic[RESULT];
            currentQrString = qrString;
            if(qrString == nil)
            {
                [Utils showToast:@"二维码获取失败"];
                return;
            }
            
            NSString *splitString = [qrString stringByReplacingOccurrencesOfString:@";" withString:@""];
            NSString *showNumber = [NSString stringWithFormat:@"%@  %@  %@  %@  %@",[splitString substringWithRange:NSMakeRange(0,3)],[splitString substringWithRange:NSMakeRange(3,4)],[splitString substringWithRange:NSMakeRange(7,4)],[splitString substringWithRange:NSMakeRange(11,4)],[splitString substringWithRange:NSMakeRange(15,splitString.length - 15)]];
            
            self.codeNumberLabel.text = showNumber;
            self.qrCodeImage.image = [Utils getImage:2 setData:qrString setWidth:1800 setHeight:1800];
            
            if([qrString hasPrefix:@"生产失败"])
            {
                [Utils showToast:@"二维码生成失败"];
            }else{
                self.code128BarImage.image = [Utils getImage:1 setData:qrString setWidth:600 setHeight:70];
            }
            
            
            [self startTimer];
            
        }
            break;
        case 103:
        {
            //请求微信支付宝支付;
            
            NSDictionary * qrDic = [Utils dictionaryWithJsonString:data.content];
            NSNumber * payType = qrDic[PAY_TYPE];//0:和信通,1:微信,2:支付宝
            NSString * orderId = qrDic[OTHER_ORDER_ID];
            NSNumber * money = qrDic[USE_MONEY];
            
            if(self.payType.integerValue != 0)
            {
                if(self.payType.integerValue == 2)
                {
                    [self alipayByAmount:money andOrderInfo:orderId];
                }else{
//                    [self wechatByAmount:money andOrderInfo:orderId];
                }
            }
        }
        case 104:
        {
            //收到服务端支付结果
            NSDictionary * qrDic = [Utils dictionaryWithJsonString:data.content];
            
            [SharedInstance getInstance].scanPayDictionary = qrDic;
            
            NSString *rpMseeage = qrDic[@"rpMsg"];
            NSNumber * state = qrDic[STATE];
            NSNumber * orderType = qrDic[ORDER_TYPE];//订单类型 0支付 1为撤消
            if(orderType.integerValue == 0)
            {
                switch (state.integerValue) {
                    case 0:
                    {
                        //支付成功
                        [self paySuccess:rpMseeage];
                    }
                        break;
                    case 1:
                    {
                        //支付失败
                        [self payFault];
                    }
                        break;
                    case 2:
                    {
                        //支付中
                        [self payIng];
                    }
                        break;
                    default:
                        break;
                }
            }else if(orderType.integerValue == 1){
                //撤销直接显示结果界面
                ScanPayStatusViewController * payStatusVC = (ScanPayStatusViewController*)[Utils getViewControllerByStoryBoardName:SCAN_CODE andIdentifier:SB_ID_SCAN_PAY_RESULT_VC];
                payStatusVC.keepSocket = self.clinetSocket;
                payStatusVC.rpMsg = rpMseeage;
                payStatusVC.isPresent = self.isPresent;
                [self.navigationController pushViewController:payStatusVC animated:true];
            }
            
        }
            break;
        case 105:
            NSLog(@"取消成功");
            [Utils showToast:@"取消支付"];
            [self getQrCodeData:self.payType];
            break;
        case 108:
        {
            NSDictionary * qrDic = [Utils dictionaryWithJsonString:data.content];
            NSString * infoString = qrDic[@"payOrderInfo"];
            NSDictionary * orderInfo = [Utils dictionaryWithJsonString:infoString];
            [self wechatByOrderInfo:orderInfo];
            break;
        }
        case 110:
        {
            NSDictionary * dic = [Utils dictionaryWithJsonString:data.content];
            
            NSString * msg = dic[RESULT];
            
            [[SharedInstance getInstance] showNeedRealNameView:msg];
            break;
        }
        case 120:
        {
            NSDictionary * dic = [Utils dictionaryWithJsonString:data.content];
            
            NSString * orderNO = dic[SERIAL_NUMBER];
            
            self.orderNO = orderNO;
            
            [self gotoPayWithPassword];
            break;
        }
           
        default:
            break;
    }
}


- (void)gotoPayWithPassword
{
    BOOL isNO = [[Utils passwordForService:FACE_ID_NO] isEqualToString:NO_FACE_ID_PAY];
    
    if(isNO)
    {
        
        WS(weakSelf);
        [SharedInstance loadAuthentication:^(NSString *payStatus) {
            
            switch (payStatus.integerValue) {
                case 1:
                {
                    //成功
                    NSString *payPWD = [Utils passwordForService:FACE_ID_PASSWORD];
                    [weakSelf verifypwd:payPWD];
                    break;
                }
                case 0:
                    [Utils showToast:@"支付失败"];
                    break;
                case -1:
                {
                    [Utils showToast:@"支付取消"];
                    break;
                }
                case -2:
                {
                    [weakSelf showVertifyPassword];
                    break;
                }
                default:
                    break;
            }
            
        }];
    }else{
        [self showVertifyPassword];
    }
}


#pragma mark - click methods


- (IBAction)updateQrCodeHandler:(UIButton *)sender {
    [self getQrCodeData:@0];
}

- (IBAction)backCloseHandler:(UIBarButtonItem *)sender {
    
    [self.clinetSocket disconnect];
    isContent = false;
    
    if(self.isPresent)
    {
        [self dismissViewControllerAnimated:true completion:nil];
    }else{
        [self.navigationController popViewControllerAnimated:YES];
    }
    
    
}


#pragma mark - other methods

- (void)updateBrightHandler:(NSNotification*)notification{
    NSInteger type = [(NSNumber *)notification.object integerValue];
    
    if(type == 1)
    {
        [[UIScreen mainScreen] setBrightness:[SharedInstance getInstance].userSetScreenBrightness];
    }else{
        [[UIScreen mainScreen] setBrightness:0.9];
    }
    
}

- (void)startTimer
{
    if(_timer != nil)
    {
        dispatch_source_cancel(_timer);
    }
    
    timeout = 60;
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    _timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0,queue);
    dispatch_source_set_timer(_timer,dispatch_walltime(NULL, 0),1.0*NSEC_PER_SEC, 0); //每秒执行
    dispatch_source_set_event_handler(_timer, ^{
        if(timeout<=0){ //倒计时结束，关闭
            dispatch_source_cancel(_timer);
            dispatch_async(dispatch_get_main_queue(), ^{
                //刷新二维码;
                [self startTimer];
                [self getQrCodeData:self.payType];
            });
        }else{
            timeout--;
        }
    });
    dispatch_resume(_timer);
}

- (void)stopTimer{
    if(_timer != nil)
    {
        dispatch_source_cancel(_timer);
    }
    
}

- (void)paySuccess:(NSString *)rpMessage{
    
    if(self.payType.integerValue != 0)
    {
        //非和信通需要监听后发送结果
       if(isPaying == false)
       {
           ScanPayStatusViewController * payStatusVC = [Utils getViewControllerByStoryBoardName:SCAN_CODE andIdentifier:SCAN_PAY_NAV];
           payStatusVC.isPresent = self.isPresent;
           [self presentViewController:payStatusVC animated:true completion:nil];
       }else{
           [[NSNotificationCenter defaultCenter] postNotificationName:EVENT_SCAN_PAY_SUCCESS object:nil];
       }
    }else{
        ScanPayStatusViewController * payStatusVC = (ScanPayStatusViewController*)[Utils getViewControllerByStoryBoardName:SCAN_CODE andIdentifier:SB_ID_SCAN_PAY_RESULT_VC];
        payStatusVC.keepSocket = self.clinetSocket;
        payStatusVC.rpMsg = rpMessage;
        payStatusVC.isPresent = self.isPresent;
        [self.navigationController pushViewController:payStatusVC animated:true];
    }
}

- (void)payFault{
    if(self.payType.integerValue != 0)
    {
        if(isPaying == false)
        {
            ScanPayStatusViewController * payStatusVC = [Utils getViewControllerByStoryBoardName:SCAN_CODE andIdentifier:SCAN_PAY_NAV];
            payStatusVC.isPresent = self.isPresent;
            [self presentViewController:payStatusVC animated:true completion:nil];
        }else{
            [[NSNotificationCenter defaultCenter] postNotificationName:EVENT_SCAN_PAY_SUCCESS object:nil];
        }
    }else
    {
        ScanPayStatusViewController * payStatusVC = (ScanPayStatusViewController*)[Utils getViewControllerByStoryBoardName:SCAN_CODE andIdentifier:SB_ID_SCAN_PAY_RESULT_VC];
        payStatusVC.keepSocket = self.clinetSocket;
        payStatusVC.isPresent = self.isPresent;
        [self.navigationController pushViewController:payStatusVC animated:true];
    }
}

- (void)payIng{
    
    isPaying = true;
    
    ScanPayStatusViewController * payStatusVC = [Utils getViewControllerByStoryBoardName:SCAN_CODE andIdentifier:SCAN_PAY_NAV];
    payStatusVC.isPresent = self.isPresent;
    self.modalPresentationStyle = UIModalPresentationOverCurrentContext;
    [self presentViewController:payStatusVC animated:true completion:nil];
}

- (void)alipayByAmount:(NSNumber*)amount andOrderInfo:(NSString*)orderInfo
{
    [[AlipaySDK defaultService] payOrder:orderInfo fromScheme:@"whcd" callback:^(NSDictionary *resultDic) {
        
        NSString * status = [resultDic objectForKey:@"resultStatus"];
        
        if(status.integerValue == 9000)
        {
            //支付成功
            //[self performSegueWithIdentifier:CHOOSE_PAY_METHOD_GOTO_PAY_SUCCESS sender:self];
        }else if(status.integerValue == 6001)
        {
            //取消支付
            [self cancelPayHandler];
        }else{
            //支付失败
            [Utils showToast:@"支付失败"];
        }
    }];
}

- (void)cancelPayHandler{
    [[NSNotificationCenter defaultCenter] postNotificationName:EVENT_SCAN_PAY_CANCEL object:nil];
    
    CsCmd * csCmd = [CsCmd new];
    csCmd.cmd = 105;
    csCmd.userId = [SharedInstance getInstance].userInfo.userId.intValue;
    NSDictionary * scanData =  [SharedInstance getInstance].scanPayDictionary;
    NSString * orderId = scanData[ORDER_ID];
    NSDictionary * hash = @{ORDER_ID:orderId};
    csCmd.content = [Utils dictionaryToJson:hash];
    id sendData =  [[SCManager getInstance] RequestSpliceAttribute:csCmd];
    [self.clinetSocket writeData:sendData withTimeout:-1 tag:0];
}

- (void)wechatByOrderInfo:(NSDictionary*)orderInfo
{
    [[SharedInstance getInstance] wechatByPayInfo:orderInfo];
    
    
    [SharedInstance getInstance].wechatPayResult = ^(NSInteger result) {
        
        if(result == 1)
        {
           //支付成功;
//            self.payType = @1;
//            [self paySuccess:@"支付成功"];
           
        }else{
            //支付失败
            [Utils showToast:@"支付失败"];
        }
        
    };
        
}


- (void)autoLogin {
    
    CsCmd * csCmd = [CsCmd new];
    csCmd.cmd = 101;
    csCmd.userId = [SharedInstance getInstance].userInfo.userId.intValue;
    NSDictionary * hash = @{SID:[SharedInstance getInstance].sid};
    csCmd.content = [Utils dictionaryToJson:hash];
    id sendData =  [[SCManager getInstance] RequestSpliceAttribute:csCmd];
    [self.clinetSocket writeData:sendData withTimeout:-1 tag:0];
}

- (void)getQrCodeData:(NSNumber*)flag{
    
    CsCmd * csCmd = [CsCmd new];
    csCmd.cmd = 102;
    csCmd.userId = [SharedInstance getInstance].userInfo.userId.intValue;
    NSString * phone = [SharedInstance getInstance].userInfo.telephone;
    NSDictionary * hash = @{PHONE:phone,FLAG:flag,ACCOUNT_FUNDING_TYPE:[SharedInstance getInstance].userInfo.defaultFundingType,CHANNEL_ID:@1};
    csCmd.content = [Utils dictionaryToJson:hash];
    id sendData =  [[SCManager getInstance] RequestSpliceAttribute:csCmd];
    [self.clinetSocket writeData:sendData withTimeout:-1 tag:0];
}


- (void)openAllStoreHandler:(UIBarButtonItem*)item{
    
    [Utils pushWebViewControllerURL:[SharedInstance getInstance].merchantUrl owner:self];
}


- (void)showBigCode128BarHandler:(UITapGestureRecognizer*)gesture
{
    if(!currentQrString)
    {
        return;
    }
    
    
    UIView * background = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
    background.backgroundColor = [UIColor whiteColor];
    background.userInteractionEnabled = true;
    [[Utils currentWindow] addSubview:background];
    
    UIImageView * bigQrImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH - 60, 100)];
    bigQrImageView.image = [Utils getImage:1 setData:currentQrString setWidth:1000 setHeight:1000];
    background.transform = CGAffineTransformMakeScale(0.01, 0.01);
    [background addSubview:bigQrImageView];
    bigQrImageView.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2);
    
    [UIView animateWithDuration:0.2 animations:^{
        background.transform = CGAffineTransformMakeScale(1, 1);
    }];
    
    UITapGestureRecognizer * tapGestrue = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(hideBigQrImageHandler:)];
    [background addGestureRecognizer:tapGestrue];
    
    UILabel * showNumberLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, bigQrImageView.frame.size.height + bigQrImageView.frame.origin.y + 5, SCREEN_WIDTH, 20)];
    showNumberLabel.font = [UIFont fontWithName:[Utils getGlobalFontName] size:18];
    showNumberLabel.text = self.codeNumberLabel.text;
    showNumberLabel.textAlignment = NSTextAlignmentCenter;
    [background addSubview:showNumberLabel];
    
}


- (void)showBigQrCodeHandler:(UITapGestureRecognizer*)gesture
{
    if(!currentQrString){
        return;
    }
    
    UIView * background = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
    background.backgroundColor = [UIColor whiteColor];
    background.userInteractionEnabled = true;
    [[Utils currentWindow] addSubview:background];
    
    UIImageView * bigQrImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH - 10, SCREEN_WIDTH - 10)];
    bigQrImageView.image = [Utils getImage:2 setData:currentQrString setWidth:1000 setHeight:1000];
    background.transform = CGAffineTransformMakeScale(0.01, 0.01);
    [background addSubview:bigQrImageView];
    bigQrImageView.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2);
    [UIView animateWithDuration:0.2 animations:^{
        background.transform = CGAffineTransformMakeScale(1, 1);
    }];
    
    UITapGestureRecognizer * tapGestrue = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(hideBigQrImageHandler:)];
    [background addGestureRecognizer:tapGestrue];
}

- (void)hideBigQrImageHandler:(UITapGestureRecognizer*)gestrue{
    
    UIView * view = gestrue.view;
    [UIView animateWithDuration:0.2 animations:^{
        view.transform = CGAffineTransformMakeScale(0.01, 0.01);
    } completion:^(BOOL finished) {
        [view removeFromSuperview];
    }];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if([segue.identifier isEqualToString:TABLE_EMBED_SEGUE])
    {
        ScanTableViewController * scanTableVC = (ScanTableViewController*)segue.destinationViewController;
        scanTableVC.selectCell = ^(NSString *segueiDentifier) {
            
            if([segueiDentifier isEqualToString:SELECTED_HEXIN]){
                self.payType = @0;
            }else if([segueiDentifier isEqualToString:SELECTED_WECHAT])
            {
                self.payType = @1;
            }else{
                self.payType = @2;
            }
            [self getQrCodeData:self.payType];
        };
    }
}


-(void)verifypwd:(NSString *)pwd{
    
    //请求服务
    [ServiceManager qrPayVerifyPasswordWithSerialNumber:self.orderNO pwd:pwd success:^(NSDictionary *data) {
        
        [Utils showToast:@"验证成功,扣款中..."];
    }];
}

- (IBAction)tapChargebackOrderHandler:(UIButton *)sender {
    UIViewController * vc = [Utils getViewControllerByStoryBoardName:SB_NAME_SETTING andIdentifier:@"ChargebackOrderViewController"];
    [self.navigationController pushViewController:vc animated:true];
}



@end
