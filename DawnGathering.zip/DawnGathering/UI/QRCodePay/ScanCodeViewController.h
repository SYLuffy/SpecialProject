//
//  ScanCodeViewController.h
//  CultureChengDu
//
//  Created by Linus on 2017/12/12.
//  Copyright © 2017年 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WPDiscountModel.h"

@interface ScanCodeViewController : UIViewController


@property (nonatomic,strong)WPDiscountModel *discountModel;


@property (nonatomic,assign)BOOL isPresent;

@end
