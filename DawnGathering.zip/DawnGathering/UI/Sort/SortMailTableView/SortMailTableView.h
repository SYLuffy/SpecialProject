//
//  SortMailTableView.h
//  DawnGathering
//
//  Created by 李冬岐 on 2023/10/23.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^TapMainTableViewCellWithIndexHandler)(NSInteger index);

@interface SortMailTableView : UIView

@property (copy,nonatomic)TapMainTableViewCellWithIndexHandler tapMainTableViewCellWithIndexHandler;


- (instancetype)initWithFrame:(CGRect)frame dataSource:(NSArray*)dataSource rowHieght:(CGFloat)rowHeight;

- (void)moveContentWithIndex:(NSInteger)index setButton:(BOOL)setButton;

- (NSString*)getCurrentTitle;

- (void)updateWithDataSource:(NSArray*)dataSource;

@end

NS_ASSUME_NONNULL_END
