//
//  SortMailTableView.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/10/23.
//

#import "SortMailTableView.h"
#import "SortMailTableViewCell.h"


@interface SortMailTableView()<UITableViewDelegate,UITableViewDataSource>


@property (nonatomic,strong)NSArray * dataSource;

@property (nonatomic,assign)CGFloat rowHeight;

@property (nonatomic,strong)UITableView * listTableView;

@property (nonatomic,assign)NSInteger currentIndex;

@end

@implementation SortMailTableView


- (instancetype)initWithFrame:(CGRect)frame dataSource:(NSArray*)dataSource rowHieght:(CGFloat)rowHeight
{
    self = [super initWithFrame:frame];
    if (self) {
        
        
        
        self.rowHeight = rowHeight;
        
        self.dataSource = dataSource;
        
        self.listTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height) style:UITableViewStylePlain];
        
        self.listTableView.dataSource = self;
        
        self.listTableView.delegate = self;
        
        self.listTableView.showsVerticalScrollIndicator = false;
        
        self.listTableView.rowHeight = rowHeight;
        
        self.listTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        
        self.listTableView.tableFooterView = [UIView new];
        
        [self addSubview:self.listTableView];
        
        
    }
    
    self.listTableView.backgroundColor = [UIColor clearColor];
    
    [self.listTableView reloadData];
    
    
    if(self.dataSource.count > 0)
    {
        
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:0];
        
        self.currentIndex = 0;
        
        [self.listTableView selectRowAtIndexPath:indexPath animated:NO scrollPosition:UITableViewScrollPositionNone];
    }
    
    return self;
}

- (void)updateWithDataSource:(NSArray*)dataSource
{
    _dataSource = dataSource;
    
    [self.listTableView reloadData];
    
    if(self.dataSource.count > 0)
    {
        
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:0];
        
        self.currentIndex = 0;
        
        [self.listTableView selectRowAtIndexPath:indexPath animated:NO scrollPosition:UITableViewScrollPositionNone];
    }
}


#pragma mark -- UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    SortMailTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"SortMailTableViewCell"];
    
    if(!cell)
    {
        cell = (SortMailTableViewCell*)[Utils getXibByName:@"SortMailTableViewCell"];
    }
    
    NSDictionary * dic = self.dataSource[indexPath.row];
    NSString * name = dic[CAT_NAME];
    cell.titleLabel.text = name;
    
    
    return cell;
    
}

#pragma mark -- UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(self.tapMainTableViewCellWithIndexHandler)
    {
        self.tapMainTableViewCellWithIndexHandler(indexPath.row);
    }
    
    self.self.currentIndex = indexPath.row;
    
    [self moveContentWithIndex:indexPath.row setButton:NO];
   
}

- (void)moveContentWithIndex:(NSInteger)index setButton:(BOOL)setButton
{
    
    if(setButton)
    {
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:index inSection:0];
        
        [self.listTableView selectRowAtIndexPath:indexPath animated:NO scrollPosition:UITableViewScrollPositionNone];
    }
    
    CGFloat maxContentOffset = self.listTableView.contentSize.height - self.listTableView.frame.size.height;
    
    if(maxContentOffset < 0) maxContentOffset = 0;
    
    CGFloat moveY = (index - 1) * self.rowHeight;
    
    if(moveY > maxContentOffset) moveY = maxContentOffset;
    
    if(moveY < 0) moveY = 0;
    
    [self.listTableView setContentOffset:CGPointMake(self.listTableView.contentOffset.x, moveY) animated:true];
}


- (NSString*)getCurrentTitle
{
    NSDictionary * dic = self.dataSource[self.currentIndex];
    
    NSString * title = dic[CAT_NAME];
    
    return title;
}

@end
