//
//  SortMailTableViewCell.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/10/24.
//

#import "SortMailTableViewCell.h"

@implementation SortMailTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    if(selected)
    {
        self.titleLabel.font = [UIFont fontWithName:MEDIUM_FONT_NAME size:15];
        self.titleLabel.textColor = [Utils getMainColor];
    }else{
        self.titleLabel.font = [UIFont fontWithName:DEFAULT_FONT_NAME size:14];
        self.titleLabel.textColor = UIColorFromRGB(0x666666);
    }
}

@end
