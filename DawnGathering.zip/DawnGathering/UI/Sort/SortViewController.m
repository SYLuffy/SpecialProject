//
//  SortViewController.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/10/23.
//

#import "SortViewController.h"
#import "SortMailTableView.h"
#import "SortTopScrollView.h"
#import "SortContentTableView.h"
#import "SortPopView/SortPopView.h"

@interface SortViewController ()<SortContentTableViewDelegate,SortTopCollectionViewDelegate>

@property (nonatomic,strong)SortMailTableView * mainTableView;

@property (nonatomic,strong)SortTopScrollView  * topScrollView;

@property (nonatomic,strong)SortContentTableView * contentTableView;

@property (nonatomic,strong)UIButton * rightButon;

@property (nonatomic,strong)NSArray * dataTopSounce;

@property (nonatomic,strong)NSArray * dataSource;

@property (nonatomic,strong)NSArray * contentDataSource;

@property (nonatomic,assign)BOOL hasTopScroll;

@property (nonatomic,strong)UIView * topView;

@property (nonatomic,strong)NSString * selectionCodes;

@property (nonatomic,strong)NSNumber * level;

@property (nonatomic,strong)NSNumber * currentPageID;

@property (nonatomic,assign)NSInteger mainIndex;

@end

@implementation SortViewController

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [Utils setDefaultNavigationBar:self];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    NSArray * dataSource = @[];
    
    self.hasTopScroll = true;
   
    self.mainTableView = [[SortMailTableView alloc] initWithFrame:CGRectMake(0, 0, RADIO * 99, self.view.frame.size.height - [Utils getNavigationBarAndStatusBarHeight:self]) dataSource:dataSource rowHieght:56];
    
    self.mainIndex = 0;
    
    WS(weakSelf);
    self.mainTableView.tapMainTableViewCellWithIndexHandler = ^(NSInteger index) {
        [weakSelf selectedMainIndex:index];
    };
    
    [self.view addSubview:self.mainTableView];
    
    self.topView = [[UIView alloc] initWithFrame:CGRectMake(self.mainTableView.frame.size.width, 0, self.view.frame.size.width - self.mainTableView.frame.size.width, 56)];
    
    [self.view addSubview:self.topView];
    
    
    self.dataTopSounce = @[];
    
    self.topScrollView = [[SortTopScrollView alloc] initWithFrame:CGRectMake(0, 10, self.topView.frame.size.width - 50, 36)  dataSrouce:self.dataTopSounce];
    self.topScrollView.delegate = self;
    [self.topView addSubview:self.topScrollView];
    
    NSArray * dataContentSource = @[];
    self.contentTableView = [[SortContentTableView alloc] initWithFrame:CGRectMake(self.topView.frame.origin.x, self.topView.frame.size.height, self.topView.frame.size.width - 15, self.view.frame.size.height - self.topView.frame.size.height - [Utils getNavigationBarAndStatusBarHeight:self]) dataSource:dataContentSource];
    
    self.contentTableView.delegate = self;
    
    [self.view addSubview:self.contentTableView];
    
    
    self.rightButon = [UIButton buttonWithType:UIButtonTypeCustom];
    
    self.rightButon.frame = CGRectMake(self.topScrollView.frame.size.width, 0, 50, 50);
    
    [self.rightButon setImage:[UIImage imageNamed:@"ic_sort_xiala"] forState:UIControlStateNormal];
    
    [self.rightButon addTarget:self action:@selector(rightButtonHandler:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.topView addSubview:self.rightButon];
    
    id currentID = [SharedInstance getInstance].currentClassifyID;
    
    NSNumber * sendID;
    
    if([currentID isKindOfClass:[NSString class]])
    {
        sendID = @([currentID integerValue]);
    }else{
        sendID = currentID;
    }
    
    self.currentPageID = sendID;
    
    [ServiceManager getSortDataWithPageID:sendID success:^(NSDictionary *data) {
        
        NSArray * list = data[CATEGORIES];
        NSNumber * level = data[LEVEL];
        NSString * title = data[TITLE];
        self.level = level;
        
        if(title && title.length > 0)
        {
            self.title = title;
        }
        
        self.selectionCodes = data[PRODUCT_SET];
        
        self.dataSource = list;
        
        NSArray * children = list.firstObject[CHILDREN];
        
        [self.mainTableView updateWithDataSource:list];
        
        if(level.integerValue == 3)
        {
            if(children)
            {
                self.dataTopSounce = children;
                [self.topScrollView updateWithDataSource:children];
            }
            
            if(children)
            {
                [self.contentTableView updateWithDataSource:children titleHidden:false];
                
                self.contentDataSource = children;
            }
            
            self.hasTopScroll = true;
        }else{
            self.topView.hidden = true;
            
            self.contentTableView.frame = CGRectMake(self.topView.frame.origin.x, 0, self.topView.frame.size.width, self.view.frame.size.height - [Utils getNavigationBarAndStatusBarHeight:self]);
            
            
            if(children)
            {
                [self.contentTableView updateWithDataSource:children titleHidden:true];
                
                self.contentDataSource = children;
            }
            
            self.hasTopScroll = false;
        }
        
    }];
    
}

- (void)rightButtonHandler:(UIButton*)sender
{
    
    if(self.dataTopSounce == nil || self.dataTopSounce.count == 0)
    {
        [Utils showToast:@"无分类数据!"];
        return;
    }
    
    SortPopView * popView = [[SortPopView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT - [Utils getNavigationBarAndStatusBarHeight:self]) dataSrouce:self.dataTopSounce title:[self.mainTableView getCurrentTitle] currentIndex:self.topScrollView.currentIndex];
    
    
    WS(weakSelf);
    popView.tapSortPopViewWithIndex = ^(NSInteger index) {
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            weakSelf.contentTableView.canAutoMove = false;
            if(weakSelf.hasTopScroll)
            {
                [weakSelf.topScrollView moveContentWithIndex:index setButton:true];
            }
            
            
            [weakSelf.contentTableView moveContentWithIndex:index];
        });
        
       
        
    };
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [popView fadeIn];
    });
    
    [self.view addSubview:popView];
}


- (void)selectedMainIndex:(NSInteger)index
{
    NSDictionary * selectDataSource = self.dataSource[index];
    NSArray * children = selectDataSource[CHILDREN];
    
    self.mainIndex = index;
    
    if(self.hasTopScroll)
    {
        if(children)
        {
            self.dataTopSounce = children;
            [self.topScrollView updateWithDataSource:children];
        }
        
        if(children)
        {
            [self.contentTableView updateWithDataSource:children titleHidden:false];
            
            self.contentDataSource = children;
        }
    }else{
        
        
        if(children)
        {
            [self.contentTableView updateWithDataSource:children titleHidden:true];
            
            self.contentDataSource = children;
        }
    }
    
   
    
    
}


- (IBAction)backAndPopHandler:(UIBarButtonItem *)sender {
    
    [self.navigationController popViewControllerAnimated:true];
}


#pragma mark -- SortContentTableViewDelegate
- (void)tableViewDidScrollWithIndex:(NSInteger)index
{
    [self.topScrollView moveContentWithIndex:index setButton:true];
}

- (void)tableViewDidSelectedItemWithIndex:(NSInteger)index cellIndex:(NSInteger)cellIndex
{
    //点击;
    NSDictionary * dic;
    NSString * code;
    
    NSString * indexs;
    
    if(self.level.integerValue == 2)
    {
        dic = self.contentDataSource[index];
        
        NSArray * children = dic[CHILDREN];
        
        NSMutableArray * allCodes = [NSMutableArray array];
        
        [allCodes addObject:dic[CODE]];
        
        for(NSDictionary * dic in children)
        {
            NSString * tempCode = dic[CODE];
            [allCodes addObject:tempCode];
        }
        
        code = [allCodes componentsJoinedByString:@","];
        
        indexs = [NSString stringWithFormat:@"%ld,%ld",self.mainIndex,index];
        
    }else if(self.level.integerValue == 3)
    {
        NSDictionary * secondDic = self.contentDataSource[cellIndex];
        
        dic = secondDic[CHILDREN][index];
        
        code = dic[CODE];
    }

    
    NSString * title = dic[CAT_NAME];
    
    if(code.length > 0 && self.selectionCodes.length > 0)
    {
        NSString * goURL = [NSString stringWithFormat:@"%@?%@=%@&%@=%@&title=%@&pageId=%@",[SharedInstance getInstance].saasURLModel.searchURL,SELECTION_CODES,self.selectionCodes,PLATFORM_CATEGORIES,code,title,self.currentPageID];
        
        NSString * webURL;
        if(indexs)
        {
            webURL = [NSString stringWithFormat:@"%@&indexs=%@",goURL,indexs];
        }else
        {
            webURL = goURL;
        }
        
        [Utils pushWebViewControllerURL:webURL owner:self];
    }
    
}
- (void)tableViewDidSelectedTitleAllItemWithCellIndex:(NSInteger)cellIndex
{
    NSDictionary * dic = self.contentDataSource[cellIndex];
    
    NSArray * children = dic[CHILDREN];
    
    NSMutableArray * allCodes = [NSMutableArray array];
    
    [allCodes addObject:dic[CODE]];
    
    if([Utils checkObjectIsNull:children])
    {
        for(NSDictionary * dic in children)
        {
            NSString * tempCode = dic[CODE];
            [allCodes addObject:tempCode];
        }
    }
    
    
    
    NSString * code = [allCodes componentsJoinedByString:@","];
    
    NSString * title = dic[CAT_NAME]; 
    
    NSString * indexs = [NSString stringWithFormat:@"%ld,%ld",self.mainIndex,cellIndex];
    
    if(code.length > 0 && self.selectionCodes.length > 0)
    {
        NSString * goURL = [NSString stringWithFormat:@"%@?%@=%@&%@=%@&title=%@&indexs=%@&pageId=%@",[SharedInstance getInstance].saasURLModel.searchURL,SELECTION_CODES,self.selectionCodes,PLATFORM_CATEGORIES,code,title,indexs,self.currentPageID];
        [Utils pushWebViewControllerURL:goURL owner:self];
    }
    
}

#pragma mark -- SortTopCollectionViewDelegate


- (void)topCollectionDidScrollWithIndex:(NSInteger)index;
{
    self.contentTableView.canAutoMove = false;
    
    [self.contentTableView moveContentWithIndex:index];
}
@end
