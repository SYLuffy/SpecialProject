//
//  SortContentTableView.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/10/24.
//

#import "SortContentTableView.h"
#import "SortContentTableViewCell.h"

@interface SortContentTableView()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong)UITableView * listTableView;

@property (nonatomic,strong)NSArray * dataSource;

@property (nonatomic,assign)NSInteger currentIndex;

@property (nonatomic,assign)BOOL isDragView;

@property (nonatomic,assign)BOOL titleHidden;
@end

@implementation SortContentTableView

- (instancetype)initWithFrame:(CGRect)frame dataSource:(NSArray*)dataSource
{
    self = [super initWithFrame:frame];
    if (self) {
        self.dataSource = dataSource;
        
        self.listTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height) style:UITableViewStylePlain];
        
        self.listTableView.dataSource = self;
        
        self.listTableView.delegate = self;
        
        self.listTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        
        self.listTableView.showsVerticalScrollIndicator = false;
        
        self.listTableView.tableFooterView = [UIView new];
        
        [self addSubview:self.listTableView];
    }
    
    self.listTableView.backgroundColor = [UIColor whiteColor];
    
    self.listTableView.layer.masksToBounds = true;
    self.listTableView.layer.cornerRadius = 8;
    
    self.canAutoMove = false;
    
    return self;
    
}

- (void)updateWithDataSource:(NSArray*)dataSource titleHidden:(BOOL)titleHidden
{
    _titleHidden = titleHidden;
    _dataSource = dataSource;
    
    if(titleHidden)
    {
        //如果是隐藏
        NSMutableArray * copyDataSrouce = [NSMutableArray array];
        
        [copyDataSrouce addObject:@{CHILDREN:dataSource}];
        
        self.dataSource = copyDataSrouce.copy;
    }
    
    if(dataSource.count > 0)
    {
        [self.listTableView setContentOffset:CGPointMake(0, 0) animated:true];
        
    }
    
    [self.listTableView reloadData];
    
    
    
}

#pragma mark -- UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    SortContentTableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:@"SortContentTableViewCell"];
    
    if(!cell)
    {
        cell = (SortContentTableViewCell*)[Utils getXibByName:@"SortContentTableViewCell"];
    }
    
    NSDictionary * dic = self.dataSource[indexPath.row];
    
    
    NSString * title = dic[CAT_NAME];
    
    NSArray * list = dic[CHILDREN];
    
    if([Utils checkObjectIsNull:list] == false)
    {
        list = @[];
    }
    
    
    cell.index = indexPath.row;
    [cell setDataSource:list title:title];
    
    [cell hiddentTitle:self.titleHidden];
    
    WS(weakSelf);
    cell.tapSortContentTableViewCellWithIndex = ^(NSInteger index , NSInteger cellIndex) {
        [weakSelf.delegate tableViewDidSelectedItemWithIndex:index cellIndex:cellIndex];
    };
    
    cell.tapAllSecondCategroyWithIndex = ^(NSInteger cellIndex) {
        [weakSelf.delegate tableViewDidSelectedTitleAllItemWithCellIndex:cellIndex];
    };
    
    return cell;
    
}



#pragma mark -- UITableViewDelegate


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary * dic = self.dataSource[indexPath.row];
  
    NSArray * list = dic[CHILDREN];
    
    if([Utils checkObjectIsNull:list] == false)
    {
        list = @[];
    }
    
    return [SortContentTableViewCell getCellHeightWithList:list totalWidth:self.frame.size.width];
}


- (void)moveContentWithIndex:(NSInteger)index
{
    if(_currentIndex == index)
    {
        return;
    }
    
    _currentIndex = index;
    
    NSIndexPath * indexPath = [NSIndexPath indexPathForRow:_currentIndex inSection:0];
    [self.listTableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionTop animated:true];
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    self.canAutoMove = true;
}
//- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
//    self.isDragView = false;
//}


- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if(self.canAutoMove == false)
    {
        return;
    }
    
    NSIndexPath * path = [self.listTableView indexPathForRowAtPoint:scrollView.contentOffset];
    
    [self.delegate tableViewDidScrollWithIndex:path.row];
}

- (void)updateContentViewFrame:(CGRect)frame
{
    self.listTableView.frame = CGRectMake(0, 0, frame.size.width, frame.size.height);
    
    self.frame = frame;
}

@end
