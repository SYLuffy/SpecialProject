//
//  SortContentTableView.h
//  DawnGathering
//
//  Created by 李冬岐 on 2023/10/24.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol SortContentTableViewDelegate <NSObject>//协议

- (void)tableViewDidScrollWithIndex:(NSInteger)index;

- (void)tableViewDidSelectedItemWithIndex:(NSInteger)index cellIndex:(NSInteger)cellIndex;

- (void)tableViewDidSelectedTitleAllItemWithCellIndex:(NSInteger)cellIndex;

@end

@interface SortContentTableView : UIView

- (instancetype)initWithFrame:(CGRect)frame dataSource:(NSArray*)dataSource;


- (void)updateWithDataSource:(NSArray*)dataSource titleHidden:(BOOL)titleHidden;

- (void)moveContentWithIndex:(NSInteger)index;

- (void)updateContentViewFrame:(CGRect)frame;


@property (nonatomic, weak, nullable) id <SortContentTableViewDelegate> delegate;

@property (nonatomic,assign)BOOL canAutoMove;

@end

NS_ASSUME_NONNULL_END
