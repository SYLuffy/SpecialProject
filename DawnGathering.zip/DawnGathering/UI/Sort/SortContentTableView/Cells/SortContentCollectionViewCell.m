//
//  SortContentCollectionViewCell.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/10/24.
//

#import "SortContentCollectionViewCell.h"

@implementation SortContentCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
