//
//  SortContentTableViewCell.h
//  DawnGathering
//
//  Created by 李冬岐 on 2023/10/24.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^TapSortContentTableViewCellWithIndex)(NSInteger index ,NSInteger cellIndex);

typedef void(^TapAllSecondCategroyWithIndex)(NSInteger cellIndex);

@interface SortContentTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *titleHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *titleTopdistance;
@property (weak, nonatomic) IBOutlet UIImageView *titleNextImageView;
@property (nonatomic,assign)NSInteger index;

@property (nonatomic,copy)TapSortContentTableViewCellWithIndex tapSortContentTableViewCellWithIndex;
@property (nonatomic,copy)TapAllSecondCategroyWithIndex tapAllSecondCategroyWithIndex;

- (void)setDataSource:(NSArray *)dataSource title:(NSString*)title;

- (void)hiddentTitle:(BOOL)hidden;

+ (CGFloat)getCellHeightWithList:(NSArray*)list totalWidth:(CGFloat)totalWidth;


@end

NS_ASSUME_NONNULL_END
