//
//  SortContentTableViewCell.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/10/24.
//

#import "SortContentTableViewCell.h"
#import "SortContentCollectionViewCell.h"
#define IMAGE_HEIGHT 55
#define CELL_COL 3

@interface SortContentTableViewCell()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;

@property (nonatomic,strong)NSArray * dataSource;
@property (weak, nonatomic) IBOutlet UIButton *titleButton;

@end

@implementation SortContentTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.collectionView.userInteractionEnabled = YES;

    [self.collectionView registerNib:[UINib nibWithNibName:@"SortContentCollectionViewCell" bundle:[NSBundle mainBundle]] forCellWithReuseIdentifier:@"SortContentCollectionViewCell"];
    self.collectionView.delegate = self;
    self.collectionView.dataSource = self;
    self.collectionView.scrollEnabled = false;
    self.collectionView.showsHorizontalScrollIndicator = NO;
    
    self.titleNextImageView.hidden = true;
}



- (void)setDataSource:(NSArray *)dataSource title:(NSString*)title
{
    self.titleLabel.text = title;
    
    self.dataSource = dataSource;
    
    [self.collectionView reloadData];
}


#pragma mark --  UICollectionViewDataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.dataSource.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    SortContentCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"SortContentCollectionViewCell" forIndexPath:indexPath];
    if (!cell) {
        cell = (SortContentCollectionViewCell*)[Utils getXibByName:@"SortContentCollectionViewCell"];
    }
    
    NSDictionary *dic = self.dataSource[indexPath.row];
    
    NSString * content = dic[CAT_NAME];
    
    NSString * imageURL = dic[IMG];
    
    cell.titleLabel.text = content;
    
    
    [Utils loadImage:cell.iconImageView andURL:imageURL isLoadRepeat:false];
    
    return cell;
}
-(BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    if(self.tapSortContentTableViewCellWithIndex)
    {
        self.tapSortContentTableViewCellWithIndex(indexPath.row , self.index);
    }
    
   
}
#pragma mark -- UICollectionViewDelegateFlowLayout

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    CGFloat width = (self.frame.size.width - 30) *0.33;
    
    CGFloat height = 45 + (width - 10);
    
    
    return CGSizeMake(width,height);
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    
    return 0;
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return 0;
}
- (UIEdgeInsets) collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(0, 0, 0, 0);
}

+ (CGFloat)getCellHeightWithList:(NSArray*)list totalWidth:(CGFloat)totalWidth
{
    
    if(list.count == 0) return 65;
    
    CGFloat width = (totalWidth - 30) *0.33;
    
    CGFloat height = 45 + (width - 10);
    
    NSInteger temp = list.count % CELL_COL;
    NSInteger row = list.count / CELL_COL;
    
    if(temp > 0) row += 1;
    
    height = row * height;
    
    return height + 65;
}

- (void)hiddentTitle:(BOOL)hidden
{
    if(hidden)
    {
        self.titleHeight.constant = 0;
        self.titleTopdistance.constant = 0;
    }else{
        self.titleHeight.constant = 20;
        self.titleTopdistance.constant = 15;
    }
    self.titleButton.hidden = hidden;
    
    self.titleNextImageView.hidden = hidden;
    self.titleLabel.hidden = hidden;
}
- (IBAction)tapAllSecondHandler:(UIButton *)sender {
    
    if(self.tapAllSecondCategroyWithIndex)
    {
        self.tapAllSecondCategroyWithIndex(self.index);
    }
}

@end
