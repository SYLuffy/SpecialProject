//
//  SortTopScrollView.h
//  DawnGathering
//
//  Created by 李冬岐 on 2023/10/24.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN


@protocol SortTopCollectionViewDelegate <NSObject>//协议

- (void)topCollectionDidScrollWithIndex:(NSInteger)index;

@end

typedef void(^TapSortTopScrollViewWithIndex)(NSInteger index);

@interface SortTopScrollView : UIView



@property (nonatomic,copy)TapSortTopScrollViewWithIndex tapSortTopScrollViewWithIndex;


- (instancetype)initWithFrame:(CGRect)frame dataSrouce:(NSArray*)dataSource;

- (void)moveContentWithIndex:(NSInteger)index setButton:(BOOL)setButton;

- (void)updateWithDataSource:(NSArray*)dataSource;

@property (nonatomic,assign)NSInteger currentIndex;

@property (nonatomic, weak, nullable) id <SortTopCollectionViewDelegate> delegate;
@end

NS_ASSUME_NONNULL_END
