//
//  SortTopScrollView.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/10/24.
//

#import "SortTopScrollView.h"
#import "SortTopCollectionViewCell.h"

@interface SortTopScrollView()<UICollectionViewDelegate,UICollectionViewDataSource>

@property (nonatomic,strong)NSArray * dataSource;

@property (nonatomic,strong)UICollectionView * collectionView;





@end

@implementation SortTopScrollView

- (instancetype)initWithFrame:(CGRect)frame dataSrouce:(NSArray*)dataSource
{
    self = [super initWithFrame:frame];
    if (self) {
        
        self.dataSource = dataSource;
        
        self.collectionView.userInteractionEnabled = YES;

        UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
        
        flowLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
        
        self.collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height) collectionViewLayout:flowLayout];
        
        [self.collectionView registerNib:[UINib nibWithNibName:@"SortTopCollectionViewCell" bundle:[NSBundle mainBundle]] forCellWithReuseIdentifier:@"SortTopCollectionViewCell"];
        self.collectionView.delegate = self;
        self.collectionView.dataSource = self;
        self.collectionView.scrollEnabled = true;
        self.collectionView.showsHorizontalScrollIndicator = NO;
        
        self.collectionView.backgroundColor = [UIColor clearColor];
        
    }
    

    
    [self addSubview:self.collectionView];
    
    [self.collectionView reloadData];
    
    
    if(self.dataSource.count > 0)
    {
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:0];
        [self collectionView:self.collectionView didSelectItemAtIndexPath:indexPath];
        
        [self.collectionView selectItemAtIndexPath:indexPath animated:NO scrollPosition:UICollectionViewScrollPositionNone];
    }
   
    return self;
}



#pragma mark --  UICollectionViewDataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.dataSource.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    SortTopCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"SortTopCollectionViewCell" forIndexPath:indexPath];
    if (!cell) {
        cell = (SortTopCollectionViewCell*)[Utils getXibByName:@"SortTopCollectionViewCell"];
    }
    
    NSDictionary *dic = self.dataSource[indexPath.row];
    
    NSString * content = dic[CAT_NAME];
    
    cell.titleLabel.text = content;
    
    
    return cell;
}
-(BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
   if(self.tapSortTopScrollViewWithIndex)
   {
       self.tapSortTopScrollViewWithIndex(indexPath.row);
   }
    
    [self moveContentWithIndex:indexPath.row setButton:false];
    
    if(self.delegate)
    {
        [self.delegate topCollectionDidScrollWithIndex:indexPath.row];
    }
}

- (void)updateWithDataSource:(NSArray*)dataSource
{
    _dataSource = dataSource;
    
    [self.collectionView reloadData];
    
    if(self.dataSource.count > 0)
    {
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:0];
        [self collectionView:self.collectionView didSelectItemAtIndexPath:indexPath];
        
        [self.collectionView selectItemAtIndexPath:indexPath animated:NO scrollPosition:UICollectionViewScrollPositionNone];
    }
    
    [self moveContentWithIndex:0 setButton:false];
}


- (void)moveContentWithIndex:(NSInteger)index setButton:(BOOL)setButton
{
    if(_currentIndex == index)
    {
        return;
    }
    
    _currentIndex = index;
    
    
    if(setButton)
    {
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:_currentIndex inSection:0];
        
        [self.collectionView selectItemAtIndexPath:indexPath animated:NO scrollPosition:UICollectionViewScrollPositionNone];
    }
    
    
    CGFloat totalWidth = 0.0f;
    
    for(NSDictionary * dic in self.dataSource)
    {
        NSString * content = dic[CAT_NAME];
        
        CGFloat width = [Utils getLabelWidthByHeight:26 andContent:content andFont:[UIFont fontWithName:DEFAULT_FONT_NAME size:12]] + 28;
        
        totalWidth += width;
    }
    
    CGFloat maxContentOffset = totalWidth - self.collectionView.frame.size.width;
    
    if(maxContentOffset < 0) maxContentOffset = 0;
    
    CGFloat moveX = 0.0;
    
    for(NSInteger i = 0; i < self.dataSource.count; i++)
    {
        if(i == _currentIndex)
        {
            break;
        }
        
        NSDictionary * dic = self.dataSource[i];
        
        NSString * content = dic[CAT_NAME];
        
        CGFloat width = [Utils getLabelWidthByHeight:26 andContent:content andFont:[UIFont fontWithName:DEFAULT_FONT_NAME size:12]] + 28;
        
        moveX += width;
        
        
    }
    
    if(moveX > maxContentOffset) moveX = maxContentOffset;
    
    if(moveX < 0) moveX = 0;
    
    [self.collectionView setContentOffset:CGPointMake(moveX, self.collectionView.contentOffset.y) animated:true];
}


#pragma mark -- UICollectionViewDelegateFlowLayout

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    NSDictionary * dic = self.dataSource[indexPath.row];
    
    NSString * content = dic[CAT_NAME];
    
    CGFloat width = [Utils getLabelWidthByHeight:26 andContent:content andFont:[UIFont fontWithName:DEFAULT_FONT_NAME size:12]] + 28;
    
    CGFloat height = self.frame.size.height;
    return CGSizeMake(width,height);
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    
    return 0;
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return 0;
}
- (UIEdgeInsets) collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(0, 0, 0, 0);
}



@end
