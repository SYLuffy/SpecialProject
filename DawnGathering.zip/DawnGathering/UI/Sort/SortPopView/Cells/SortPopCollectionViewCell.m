//
//  SortPopCollectionViewCell.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/10/25.
//

#import "SortPopCollectionViewCell.h"

@implementation SortPopCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)drawRect:(CGRect)rect
{
    [super drawRect:rect];
    
    if(self.titleLabel.layer.cornerRadius == 0)
    {
        self.titleLabel.layer.masksToBounds = true;
        self.titleLabel.layer.cornerRadius = self.titleLabel.frame.size.height / 2;
    }
}

- (void)setSelected:(BOOL)selected
{
    if(selected)
    {
        self.titleLabel.backgroundColor = [Utils getMainColor];
        self.titleLabel.textColor = [UIColor whiteColor];
        
    }else{
        self.titleLabel.backgroundColor = [UIColor whiteColor];
        self.titleLabel.textColor = UIColorFromRGB(0x222222);
        
    }
    
}

@end
