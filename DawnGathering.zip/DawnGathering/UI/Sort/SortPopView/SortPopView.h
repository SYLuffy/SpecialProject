//
//  SortPopView.h
//  DawnGathering
//
//  Created by 李冬岐 on 2023/10/24.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN


typedef void(^TapSortPopViewWithIndex)(NSInteger index);

@interface SortPopView : UIView

- (instancetype)initWithFrame:(CGRect)frame dataSrouce:(NSArray*)dataSource title:(NSString*)title currentIndex:(NSInteger)currentIndex;

@property (nonatomic,copy)TapSortPopViewWithIndex tapSortPopViewWithIndex;



- (void)fadeIn;

@end

NS_ASSUME_NONNULL_END
