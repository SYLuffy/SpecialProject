//
//  SortPopView.m
//  DawnGathering
//
//  Created by 李冬岐 on 2023/10/24.
//

#import "SortPopView.h"
#import "SortPopCollectionViewCell.h"

#define CELL_ROW 3

#define SORT_POP_CELL_HEIGHT 40

@interface SortPopView()<UICollectionViewDelegate,UICollectionViewDataSource>

@property (nonatomic,strong)NSArray * dataSource;

@property (nonatomic,strong)UICollectionView * collectionView;

@property (nonatomic,assign)NSInteger currentIndex;

@property (nonatomic,strong)UIView * darkMask;

@property (nonatomic,strong)UIView * popView;

@property (nonatomic,strong)UILabel * titleLabel;

@property (nonatomic,strong)UIButton * rightButton;

@end

@implementation SortPopView

- (instancetype)initWithFrame:(CGRect)frame dataSrouce:(NSArray*)dataSource title:(NSString*)title currentIndex:(NSInteger)currentIndex
{
    self = [super initWithFrame:frame];
    
    self.currentIndex = currentIndex;
    
    CGFloat popHeight = [self getPopHeightWithDataSource:dataSource];
    
    if(!_darkMask)
    {
        _darkMask = [[UIView alloc] initWithFrame:frame];
        
        _darkMask.backgroundColor = [UIColor blackColor];
        
    }
    
    UITapGestureRecognizer * tapMaskGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapMaskAndCloseHandler)];
    
    self.darkMask.userInteractionEnabled = true;
    
    [self.darkMask addGestureRecognizer:tapMaskGesture];
    
    [self addSubview:_darkMask];
    
    _darkMask.alpha = 0.0f;
    if(!_popView)
    {
        _popView = [[UIView alloc] initWithFrame:CGRectMake(0, -popHeight, frame.size.width, popHeight)];
        
        _popView.backgroundColor = UIColorFromRGB(0xF6F7F9);
        
        
    }
    
    [self addSubview:_popView];
    
    if(!_titleLabel)
    {
        self.titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(22.5, 15, self.popView.frame.size.width - 30, 22)];
        
        self.titleLabel.font = [UIFont fontWithName:MEDIUM_FONT_NAME size:16];
        
        self.titleLabel.textColor = UIColorFromRGB(0x222222);
    }
    
    self.titleLabel.text = title;
    
    [self.popView addSubview:self.titleLabel];
    
    
    if (self) {
        
        self.dataSource = dataSource;
        
        self.collectionView.userInteractionEnabled = YES;

        UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
        
        flowLayout.scrollDirection = UICollectionViewScrollDirectionVertical;
        
        self.collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(15, 50, self.popView.frame.size.width - 30, self.popView.frame.size.height - 67) collectionViewLayout:flowLayout];
        
        [self.collectionView registerNib:[UINib nibWithNibName:@"SortPopCollectionViewCell" bundle:[NSBundle mainBundle]] forCellWithReuseIdentifier:@"SortPopCollectionViewCell"];
        self.collectionView.delegate = self;
        self.collectionView.dataSource = self;
        self.collectionView.scrollEnabled = true;
        self.collectionView.showsHorizontalScrollIndicator = NO;
        
        self.collectionView.backgroundColor = [UIColor clearColor];
    }
    
    [self.popView addSubview:self.collectionView];
    
    [self.collectionView reloadData];
    
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:self.currentIndex inSection:0];
    
    [self.collectionView selectItemAtIndexPath:indexPath animated:NO scrollPosition:UICollectionViewScrollPositionNone];
    
    if(!_rightButton)
    {
        _rightButton = [UIButton buttonWithType:UIButtonTypeCustom];
        
        [_rightButton setImage:[UIImage imageNamed:@"ic_sort_shangla"] forState:UIControlStateNormal];
        
        [_rightButton addTarget:self action:@selector(rightButtonHandler:) forControlEvents:UIControlEventTouchUpInside];
        
        
        
    }
    
    _rightButton.frame = CGRectMake(self.popView.frame.size.width - 41, 15, 26, 26);
    
    [self.popView addSubview:_rightButton];
    
    return self;
}

- (void)rightButtonHandler:(UIButton*)sender
{
    [self fadeClose];
}

- (void)tapMaskAndCloseHandler
{
    [self fadeClose];
}

- (void)fadeIn
{
    
    self.darkMask.alpha = 0;
    self.popView.center = CGPointMake(self.frame.size.width * 0.5, -self.popView.frame.size.height/ 2);
    
    [UIView animateWithDuration:0.4 animations:^{
        self.darkMask.alpha = 0.3;
        self.popView.center = CGPointMake(self.frame.size.width * 0.5, self.popView.frame.size.height / 2);
    }];
}

- (void)fadeClose
{
    [UIView animateWithDuration:0.4 animations:^{
        
        self.darkMask.alpha = 0;
        self.popView.center = CGPointMake(self.frame.size.width * 0.5, -self.popView.frame.size.height/ 2);
        
    } completion:^(BOOL finished) {
        
        [self removeFromSuperview];
        
    }];
}


- (void)fadeOut
{
    [UIView animateWithDuration:0.4 animations:^{
        
        self.darkMask.alpha = 0;
        self.popView.center = CGPointMake(self.frame.size.width * 0.5, -self.popView.frame.size.height/ 2);
        
    } completion:^(BOOL finished) {
        
        [self removeFromSuperview];
        
        if(self.tapSortPopViewWithIndex)
        {
            self.tapSortPopViewWithIndex(self.currentIndex);
        }
        
    }];
}


#pragma mark --  UICollectionViewDataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.dataSource.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    SortPopCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"SortPopCollectionViewCell" forIndexPath:indexPath];
    if (!cell) {
        cell = (SortPopCollectionViewCell*)[Utils getXibByName:@"SortPopCollectionViewCell"];
    }
    
    NSDictionary *dic = self.dataSource[indexPath.row];
    
    NSString * content = dic[CAT_NAME];
    
    cell.titleLabel.text = content;
    
    
    return cell;
}
-(BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    self.currentIndex = indexPath.row;
    
    [self fadeOut];
}

#pragma mark -- UICollectionViewDelegateFlowLayout

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    CGFloat width = (self.frame.size.width - 30) * 0.33;
    
    return CGSizeMake(width,SORT_POP_CELL_HEIGHT * RADIO);
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    
    return 0;
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return 0;
}
- (UIEdgeInsets) collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(0, 0, 0, 0);
}

- (CGFloat)getPopHeightWithDataSource:(NSArray*)dataSource
{
    if(dataSource.count == 0) return 0;
    
    NSInteger tempCount = dataSource.count % CELL_ROW;
    
    NSInteger count = dataSource.count / CELL_ROW;
    
    if(tempCount > 0) count += 1;
    
    CGFloat hegiht = SORT_POP_CELL_HEIGHT * RADIO;
    
    CGFloat totalHeight = count * hegiht;
    
    return totalHeight + 67;
}

@end
