//
//  JXCategoryNumberCellModel.m
//  DQGuess
//
//  Created by jiaxin on 2018/4/24.
//  Copyright © 2018年 jingbo. All rights reserved.
//

#import "JXCategoryNumberCellModel.h"

@implementation JXCategoryNumberCellModel

@end
