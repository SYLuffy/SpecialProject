//
//  JXCategoryTitleCell.m
//  UI系列测试
//
//  Created by jiaxin on 2018/3/15.
//  Copyright © 2018年 jiaxin. All rights reserved.
//

#import "JXCategoryTitleCell.h"
#import "JXCategoryTitleCellModel.h"

@interface JXCategoryTitleCell ()
@property (nonatomic, strong) CALayer *maskLayer;
@property (nonatomic, strong) JXCategoryTitleCellModel *myCellModel;

@end

@implementation JXCategoryTitleCell

- (void)initializeViews
{
    [super initializeViews];
    
    _titleLabel = [[UILabel alloc] init];
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    [self.contentView addSubview:self.titleLabel];

    _maskTitleLabel = [[UILabel alloc] init];
    _maskTitleLabel.hidden = YES;
    self.maskTitleLabel.textAlignment = NSTextAlignmentCenter;
    [self.contentView addSubview:self.maskTitleLabel];
    
    _subTitleLabel = [[UILabel alloc] init];
    self.subTitleLabel.textAlignment = NSTextAlignmentCenter;
    _subTitleLabel.layer.masksToBounds = true;
    
    _subTitleLabel.font = [UIFont fontWithName:DEFAULT_FONT_NAME size:12];
    
    [self.contentView addSubview:_subTitleLabel];
    

    _maskLayer = [CALayer layer];
    self.maskLayer.backgroundColor = [UIColor redColor].CGColor;
    self.maskTitleLabel.layer.mask = self.maskLayer;
    
    self.backgroundColor = [UIColor clearColor];
}

- (void)layoutSubviews {
    [super layoutSubviews];

    JXCategoryTitleCellModel *myCellModel = self.myCellModel;
    
    if(myCellModel.subTitle != nil)
    {
        self.titleLabel.center = CGPointMake(self.contentView.center.x,self.titleLabel.frame.size.height * 0.5 + 10);
        
        self.subTitleLabel .center = CGPointMake(self.contentView.center.x,self.contentView.frame.size.height - self.titleLabel.frame.size.height * 0.5);
        
        if(self.subTitleLabel.layer.cornerRadius == 0)
        {
            self.subTitleLabel.layer.cornerRadius = self.subTitleLabel.frame.size.height * 0.5;
        }
        self.subTitleLabel.hidden = false;
        
        if(myCellModel.subTitle.length == 0)
        {
            self.titleLabel.center = CGPointMake(self.contentView.center.x,self.titleLabel.frame.size.height * 0.5 + 20);
        }
    }else{
        self.titleLabel.center = self.contentView.center;
        self.subTitleLabel.hidden = true;
    }
    
    self.maskTitleLabel.center = self.contentView.center;
}

- (void)reloadData:(JXCategoryBaseCellModel *)cellModel {
    [super reloadData:cellModel];

    JXCategoryTitleCellModel *myCellModel = (JXCategoryTitleCellModel *)cellModel;
    
    self.myCellModel = myCellModel;
    
    CGFloat pointSize = myCellModel.titleFont.pointSize;
    UIFontDescriptor *fontDescriptor = myCellModel.titleFont.fontDescriptor;
    if (myCellModel.selected) {
        fontDescriptor = myCellModel.titleSelectedFont.fontDescriptor;
        pointSize = myCellModel.titleSelectedFont.pointSize;
    }
    if (myCellModel.titleLabelZoomEnabled) {
        self.titleLabel.font = [UIFont fontWithDescriptor:fontDescriptor size:pointSize*myCellModel.titleLabelZoomScale];
        self.maskTitleLabel.font = [UIFont fontWithDescriptor:fontDescriptor size:pointSize*myCellModel.titleLabelZoomScale];
    }else {
        self.titleLabel.font = [UIFont fontWithDescriptor:fontDescriptor size:pointSize];
        self.maskTitleLabel.font = [UIFont fontWithDescriptor:fontDescriptor size:pointSize];
    }

    self.maskTitleLabel.hidden = !myCellModel.titleLabelMaskEnabled;
    if (myCellModel.titleLabelMaskEnabled) {
        self.titleLabel.textColor = myCellModel.titleColor;
        self.maskTitleLabel.font = myCellModel.titleFont;
        self.maskTitleLabel.textColor = myCellModel.titleSelectedColor;

        self.maskTitleLabel.text = myCellModel.title;
        [self.maskTitleLabel sizeToFit];

        CGRect frame = myCellModel.backgroundViewMaskFrame;
        frame.origin.x -= (self.contentView.bounds.size.width - self.maskTitleLabel.bounds.size.width)/2;
        frame.origin.y = 0;
        [CATransaction begin];
        [CATransaction setDisableActions:YES];
        self.maskLayer.frame = frame;
        [CATransaction commit];
    }else {
        if (myCellModel.selected) {
            self.titleLabel.textColor = myCellModel.titleSelectedColor;
            self.subTitleLabel.textColor = myCellModel.subTitleSelectedColor;
            self.subTitleLabel.backgroundColor = myCellModel.subTitleSelectedBackgroundColor;
        }else {
            self.titleLabel.textColor = myCellModel.titleColor;
            self.subTitleLabel.textColor = myCellModel.subTitleColor;
            self.subTitleLabel.backgroundColor = [UIColor clearColor];
        }
        
        
    }

    self.titleLabel.text = myCellModel.title;
    self.subTitleLabel.text = myCellModel.subTitle;
    [self.subTitleLabel sizeToFit];
    self.subTitleLabel.bounds = CGRectMake(0, 0, self.subTitleLabel.frame.size.width + 15, self.subTitleLabel.bounds.size.height + 6);
    [self.titleLabel sizeToFit];
    [self setNeedsLayout];
    [self layoutIfNeeded];
}


@end
