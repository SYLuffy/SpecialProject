//
//  JXCategoryTitleCell.h
//  UI系列测试
//
//  Created by jiaxin on 2018/3/15.
//  Copyright © 2018年 jiaxin. All rights reserved.
//

#import "JXCategoryIndicatorCell.h"

@interface JXCategoryTitleCell : JXCategoryIndicatorCell

@property (nonatomic, strong) UILabel *titleLabel;

@property (nonatomic, strong) UILabel *maskTitleLabel;

@property (nonatomic, strong) UILabel * subTitleLabel;

@end
