//
//  EBBannerViewController.h
//  demo
//
//  Created by 吴星辰 on 2017/10/23.
//  Copyright © 2017年 吴星辰. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EBBannerViewController : UIViewController

+(void)setSupportedInterfaceOrientations:(UIInterfaceOrientationMask)orientations;
+(void)setStatusBarHidden:(BOOL)hidden;

@end
