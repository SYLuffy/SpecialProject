//
//  FYLCityModel.m


#import "FYLCityModel.h"


@implementation FYLProvince

+ (NSDictionary *)modelCustomPropertyMapper {
    return @{@"name" : @"provinceName",
             @"city" : @"citys"};
}

+ (NSDictionary *)modelContainerPropertyGenericClass {
    return @{@"city" : [FYLCity class]};
}

@end

@implementation FYLCity

+ (NSDictionary *)modelCustomPropertyMapper {
    return @{@"name" : @"citysName",
             @"town" : @"towns"};
}

+ (NSDictionary *)modelContainerPropertyGenericClass {
    return @{@"town" : [FYLTown class]};
}

@end

@implementation FYLTown

+ (NSDictionary *)modelCustomPropertyMapper {
    return @{@"name" : @"townsName"};
}

@end
