//
//  SGQRCode.h
//  Version 3.5.1
//  https://github.com/kingsic/SGQRCode
//
//  Created by kingsic on 2016/8/16.
//  Copyright © 2016年 kingsic. All rights reserved.
//

#import "SGScanCode.h"
#import "SGScanView.h"
#import "SGCreateCode.h"
#import "SGAuthorization.h"
