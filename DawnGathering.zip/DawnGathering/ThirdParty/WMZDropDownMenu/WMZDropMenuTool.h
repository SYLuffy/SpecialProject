//
//  WMZDropMenuTool.h
//  WMZDropDownMenu
//
//  Created by wmz on 2019/11/19.
//  Copyright © 2019 wmz. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/// 设置阴影
typedef enum :NSInteger{
    MenuShadowPathTop,
    MenuShadowPathBottom,
    MenuShadowPathLeft,
    MenuShadowPathRight,
    MenuShadowPathCommon,
    MenuShadowPathAround
}MenuShadowPathType;

typedef enum :NSInteger{
    ///图片在左，文字在右，默认
    MenuBtnPositionLeft     = 1,
    ///图片在右，文字在左
    MenuBtnPositionRight    = 2,
    ///图片在上，文字在下
    MenuBtnPositionTop      = 3,
    ///图片在下，文字在上
    MenuBtnPositionBottom   = 4,
}MenuBtnPosition;

@interface WMZDropMenuTool : NSObject
/// 设置图文位置
+ (void)TagSetImagePosition:(MenuBtnPosition)postion spacing:(CGFloat)spacing button:(UIButton*)btn;
/// 计算按钮字体宽高
+(CGSize)boundingRectWithSize:(NSString*)txt Font:(UIFont*) font Size:(CGSize)size;
/// 设置单边框
+ (void)viewPathWithColor:(UIColor *)shadowColor  PathType:(MenuShadowPathType)shadowPathType PathWidth:(CGFloat)shadowPathWidth heightScale:(CGFloat)sacle button:(UIView*)btn;
/// 设置圆角 单边
+(void)setView:(UIView*)view Radii:(CGSize)size RoundingCorners:(UIRectCorner)rectCorner;
/// 获取当前VC
+ (UIViewController *)getCurrentVC;

@end

/// 动画完成
typedef void (^DropMenuAnimalBlock)(void);

@interface WMZDropMenuAnimal : NSObject
/// 垂直移动出现
void verticalMoveShowAnimation (UIView *view ,NSTimeInterval duration,DropMenuAnimalBlock block);
/// 垂直移移动消失
void verticalMoveHideAnimation (UIView *view ,NSTimeInterval duration,DropMenuAnimalBlock block);
/// 横向移动出现
void landscapeMoveShowAnimation(UIView *view ,NSTimeInterval duration,BOOL right,DropMenuAnimalBlock block);
/// 横向移动消失
void landscapeMoveHideAnimation(UIView *view ,NSTimeInterval duration,BOOL right,DropMenuAnimalBlock block);
/// Boss样式移动出现
void BossMoveShowAnimation (UIView *view ,NSTimeInterval duration,DropMenuAnimalBlock block);
/// Boss样式移动消失
void BossMoveHideAnimation (UIView *view ,NSTimeInterval duration,DropMenuAnimalBlock block);
/// 垂直从下移动出现
void verticalBottomMoveShowAnimation (UIView *view ,NSTimeInterval duration,DropMenuAnimalBlock block);
/// 垂直从上移动消失
void verticalTopMoveHideAnimation (UIView *view ,NSTimeInterval duration,DropMenuAnimalBlock block);

@end

/// 渐变色
typedef enum :NSInteger{
    ///水平方向渐变
    MenuGradientChangeDirectionLevel,
    ///垂直方向渐变
    MenuGradientChangeDirectionVertical,
    ///主对角线方向渐变
    MenuGradientChangeDirectionUpwardDiagonalLine,
    ///副对角线方向渐变
    MenuGradientChangeDirectionDownDiagonalLine,         
}MenuGradientChangeDirection;

@interface UIColor (MenuGradientColor)
/// 渐变色
+ (instancetype)menuColorGradientChangeWithSize:(CGSize)size
                direction:(MenuGradientChangeDirection)direction
                startColor:(UIColor*)startcolor
                endColor:(UIColor*)endColor;
@end


@interface UIImage (MenuImageName)
/// 从bundle获取图片
+ (UIImage*)bundleImage:(NSString*)name;

@end

NS_ASSUME_NONNULL_END


