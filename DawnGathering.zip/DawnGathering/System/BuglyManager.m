//
//  BuglyManager.m
//  TIFamily
//
//  Created by 谢丹 on 2020/4/22.
//  Copyright © 2020 葛亮. All rights reserved.
//

#import "BuglyManager.h"
#import "Utils.h"
@implementation BuglyManager

+(void)initBugly{
    
    BOOL development = YES;
    BuglyConfig *config = [[BuglyConfig alloc] init];
    config.reportLogLevel = BuglyLogLevelInfo;
    config.channel = @"release";
    config.blockMonitorEnable = YES;//卡顿检测

    if (!isProduction) {
        config.debugMode = YES;
        config.channel = @"debug";
        development = NO;
    }

//    [Bugly startWithAppId:@"ea050d0c20"
//        developmentDevice:development
//                   config:config];
    
}


+ (void)setPhoneNum:(NSString *)phoneNum {
    [Bugly setUserIdentifier:phoneNum];
}


+ (void)reportExceptionWithMessage:(NSString *)message parmas:(NSDictionary *)parmas error:(NSString *)error{
    [Bugly reportExceptionWithCategory:3 name:message reason:error callStack:@[] extraInfo:parmas terminateApp:NO];
}


@end
