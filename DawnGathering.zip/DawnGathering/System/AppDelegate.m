//
//  AppDelegate.m
//  HLGA
//
//  Created by Linus on 2018/5/8.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import "AppDelegate.h"
#import <IQKeyboardManager.h>
#import <UserNotifications/UserNotifications.h>
#import "Utils.h"
#import "EBBannerView.h"
#import <WXApi.h>
#import <AlipaySDK/AlipaySDK.h>
#import "BuglyManager.h"
#import "WPNavigationController.h"
#import <AMapLocationKit/AMapLocationKit.h>
#import <TYRZUISDK/TYRZUISDK.h>
#import <TABAnimated.h>


#define QUICK_LOGIN_APPID @"300012392242"

#define QUICK_LOGIN_APPKEY @"E001A2CCFB09B08896D915AD39A64EE0"


@interface AppDelegate ()<UNUserNotificationCenterDelegate>

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    UIApplicationShortcutIcon * icon = [UIApplicationShortcutIcon iconWithTemplateImageName:@"wppickup_sccode_icon"];
    
    UIApplicationShortcutItem * item = [[UIApplicationShortcutItem alloc] initWithType:@"com.open.qrcode" localizedTitle:@"付款" localizedSubtitle:nil icon:icon userInfo:nil];
    
    application.shortcutItems = @[item];

    [SharedInstance getInstance].userSetScreenBrightness = [[UIScreen mainScreen] brightness];
    
    self.window.backgroundColor = [UIColor whiteColor];
    [IQKeyboardManager sharedManager].enable = YES;
    [IQKeyboardManager sharedManager].shouldResignOnTouchOutside = YES;
    [IQKeyboardManager sharedManager].shouldToolbarUsesTextFieldTintColor = YES;
    [IQKeyboardManager sharedManager].enableAutoToolbar = NO;
    [SharedInstance getInstance].isHomePerformOne  = YES;
    
    [BuglyManager initBugly];

    
    if (@available(iOS 10.0, *)) {
        UNUserNotificationCenter * center = [UNUserNotificationCenter currentNotificationCenter];
        center.delegate = self;
        
        [center requestAuthorizationWithOptions:(UNAuthorizationOptionSound | UNAuthorizationOptionAlert | UNAuthorizationOptionBadge) completionHandler:^(BOOL granted, NSError * _Nullable error)
         {
            if( !error )
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                    [[UIApplication sharedApplication] registerForRemoteNotifications]; // required to get the app to do anything at all about push notifications
                    NSLog( @"Push registration success." );
                });
            }
        }];
    }
    
    
    //判断是否由远程消息通知触发应用程序启动
    if ([launchOptions objectForKey:UIApplicationLaunchOptionsRemoteNotificationKey]!=nil) {
        [Utils clearAppBadge];
        [SharedInstance getInstance].isFromPushGotoMessage = true;
        
    }else{
        [SharedInstance getInstance].isFromPushGotoMessage = false;
    }
    
    [self initSDK];
    
    return YES;
}

- (void)application:(UIApplication *)application performActionForShortcutItem:(UIApplicationShortcutItem *)shortcutItem completionHandler:(void (^)(BOOL))completionHandler
{
    if([shortcutItem.type isEqualToString:@"com.open.qrcode"])
    {
        //打开二维码;
        [[NSNotificationCenter defaultCenter] postNotificationName:EVENT_OPEN_QR_CODE object:self userInfo:nil];
    }
}

- (void)initSDK{
    [WXApi registerApp:@"wx11959e1c575b11a1" universalLink:@"https://ygfuli.com/sghapp/"];
    
    [UAFSDKLogin.shareLogin registerAppId:QUICK_LOGIN_APPID AppKey:QUICK_LOGIN_APPKEY];
    //调用自检函数
//    [WXApi checkUniversalLinkReady:^(WXULCheckStep step, WXCheckULStepResult* result) {
//        NSLog(@"%@, %u, %@, %@", @(step), result.success, result.errorInfo, result.suggestion);
//    }];
    [TABAnimated sharedAnimated].animationType = TABAnimationTypeShimmer;
//    [TABAnimated sharedAnimated].openAnimationTag = YES;
//    
    //[TalkingData sessionStarted:@"FF44506CBD0F4E6589204787CA08B823" withChannelId:@"sgh"];
    
//    [[QYSDK sharedSDK] registerAppId:@"04929abefb9294751518cb2e7dea70bf" appName:@"蜀光惠"];
    
    QYSDKOption * option = [[QYSDKOption alloc] init];
    
    option.templateId = 6659585;
    option.appName = @"蜀光惠";
    option.appKey = @"04929abefb9294751518cb2e7dea70bf";
    
    [[QYSDK sharedSDK] registerWithOption:option];
    
    [AMapServices sharedServices].apiKey = @"5a0ce22e7cfaaac5a1cb4fbef1c1eb67";
    
    [AMapLocationManager updatePrivacyAgree:AMapPrivacyAgreeStatusDidAgree];
    
    [AMapLocationManager updatePrivacyShow:AMapPrivacyShowStatusDidShow privacyInfo:AMapPrivacyInfoStatusDidContain];
}



- (void)applicationWillResignActive:(UIApplication *)application {
    [[NSNotificationCenter defaultCenter] postNotificationName:EVENT_OPEN_OR_CLOSE_BRIGHT object:@1];
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    [[NSNotificationCenter defaultCenter] postNotificationName:EVENT_OPEN_OR_CLOSE_BRIGHT object:@0];
}


- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url{
    if([url.host isEqualToString:@"safepay"] == true)
    {
        [[AlipaySDK defaultService] processOrderWithPaymentResult:url standbyCallback:^(NSDictionary *resultDic) {
            
            NSNumber * resultStatus = resultDic[@"resultStatus"];
            NSString * statusString = [NSString stringWithFormat:@"%ld",(long)resultStatus.integerValue];
            [[NSNotificationCenter defaultCenter] postNotificationName:EVENT_ALIPAY_BACK object:self userInfo:@{@"status":statusString}];
        }];
        
        return true;
    }
    return [WXApi handleOpenURL:url delegate:[SharedInstance getInstance]];
}


- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation{
    if([url.host isEqualToString:@"safepay"])
    {
        [[AlipaySDK defaultService] processOrderWithPaymentResult:url standbyCallback:^(NSDictionary *resultDic) {
    
            NSNumber * resultStatus = resultDic[@"resultStatus"];
            NSString * statusString = [NSString stringWithFormat:@"%ld",(long)resultStatus.integerValue];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:EVENT_ALIPAY_BACK object:self userInfo:@{@"status":statusString}];
        }];
        
        return true;
    }
    return [WXApi handleOpenURL:url delegate:[SharedInstance getInstance]];
}

- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken{
    NSString *token = [NSString stringWithFormat:@"%@", deviceToken];
    //获取终端设备标识，这个标识需要通过接口发送到服务器端，服务器端推送消息到APNS时需要知道终端的标识，APNS通过注册的终端标识找到终端设备。
    NSString *pushToken = [[[[token description]
                             stringByReplacingOccurrencesOfString:@"<" withString:@""]
                            stringByReplacingOccurrencesOfString:@">" withString:@""]
                           stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    [SharedInstance getInstance].pushToken = pushToken;
    
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler {
    
    if (userInfo == nil || [userInfo isKindOfClass:[NSNull class]]) {
        return;
    }
    
    if (application.applicationState == UIApplicationStateBackground ) {
        [[NSNotificationCenter defaultCenter] postNotificationName:EVENT_LAUNCH_IN_APP object:nil];
        
    }
}


- (void)applicationDidBecomeActive:(UIApplication *)application{
    
    //返回APP唤醒调用;
    [[NSNotificationCenter defaultCenter] postNotificationName:EVENT_BECOME_ACTIVE object:nil];
    
}

@end
