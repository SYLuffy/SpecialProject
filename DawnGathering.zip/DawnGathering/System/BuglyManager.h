//
//  BuglyManager.h
//  TIFamily
//
//  Created by 谢丹 on 2020/4/22.
//  Copyright © 2020 葛亮. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Bugly/Bugly.h>


NS_ASSUME_NONNULL_BEGIN

@interface BuglyManager : NSObject

+ (void)initBugly;
+ (void)setPhoneNum:(NSString *)phoneNum;
+ (void)reportExceptionWithMessage:(NSString *)message parmas:(NSDictionary *)parmas error:(NSString *)error;



@end

NS_ASSUME_NONNULL_END
