//
//  AppDelegate.h
//  HLGA
//
//  Created by Linus on 2018/5/8.
//  Copyright © 2018年 Linus. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <WXApi.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate,WXApiDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

